select '<hr/><h2>Import LC2UIBackend processes</h2>';
-- select '<p>drop plugin tables</p>';
drop table IF EXISTS LC2UIBackend;
drop table IF EXISTS LC2UIBackend_main;
drop table IF EXISTS LC2UIBackend_install;
drop table IF EXISTS LC2UIBackend_help;
drop table IF EXISTS LC2UIBackend_data;
drop table IF EXISTS LC2UIBackend_work;
drop table IF EXISTS LC2UIBackend_procdata;
drop table IF EXISTS LC2UIBackendtemp;
drop table IF EXISTS LC2UIBackend_datatemp;
drop table IF EXISTS LC2UIBackend_worktemp;
drop table IF EXISTS LC2UIBackend_proc;
drop table IF EXISTS LC2UIBackend_tests;
drop table IF EXISTS LC2UIBackend_proctemp;
---------------------------------------------------------------
select '<span>Creating tables</span>';
---------------------------------------------------------------
CREATE TABLE LC2UIBackend( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,  "url" TEXT NULL);
CREATE TABLE LC2UIBackend_main( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE LC2UIBackend_install( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE LC2UIBackend_help( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE LC2UIBackend_data( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE LC2UIBackend_work( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE LC2UIBackend_proc( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE LC2UIBackend_tests( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE LC2UIBackend_procdata( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE IF NOT EXISTS LC2UIBackendtemp ("name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "url" TEXT NULL);
CREATE TABLE IF NOT EXISTS LC2UIBackend_proctemp( "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "url" TEXT NULL);
---------------------------------------------------------------
-- import menu
select '<span>start import to plugin tables</span>';
---------------------------------------------------------------
.separator ";"
--.import .\\resources\\plugins\\LC2UIBackend\\import\\import.csv LC2UIBackendtemp
-- INSERT INTO LC2UIBackend(first_name,name,zipcode, city, description) select first_name,name,zipcode, city, description  from LC2UIBackendtemp;
.import .\\resources\\plugins\\LC2UIBackend\\import\\import.csv LC2UIBackend
.import .\\resources\\plugins\\LC2UIBackend\\import\\main.csv LC2UIBackend_main
.import .\\resources\\plugins\\LC2UIBackend\\import\\install.csv LC2UIBackend_install
.import .\\resources\\plugins\\LC2UIBackend\\import\\help.csv LC2UIBackend_help
.import .\\resources\\plugins\\LC2UIBackend\\import\\data.csv LC2UIBackend_data
.import .\\resources\\plugins\\LC2UIBackend\\import\\work.csv LC2UIBackend_work
.import .\\resources\\plugins\\LC2UIBackend\\import\\tests.csv LC2UIBackend_tests
---------------------------------------------------------------
-- import procs
select '<span>importing processes</span>';
---------------------------------------------------------------
.separator ","
.import '.\\resources\\plugins\\LC2UIBackend\\import\\proc.csv' LC2UIBackend_proctemp
select 'LC2UIBackend_proctemp count:';
select count(*) from LC2UIBackend_proctemp;
.separator ";"
INSERT INTO LC2UIBackend_proc(first_name,name,zipcode, description,url) select first_name,name,zipcode, description,url  from LC2UIBackend_proctemp;
select 'LC2UIBackend_proc count:';
select count(*) from LC2UIBackend_proc;
-- eof insert work data
-- eof insert work data
---------------------------------------------------------------
-- done
select '<span>import done</span>';
---------------------------------------------------------------
select 'LC2UIBackend count:';
select count(*) from LC2UIBackend;
select '<p>start data import to plugin tables</p>';
-- delete from LC2UIBackend_datatemp;
--
select '<p>LC2UIBackend count:';
select count(*) from LC2UIBackend;
select 'LC2UIBackend_data count:';
select count(*) from LC2UIBackend_data;
select 'LC2UIBackend_procdata count:';
select count(*) from LC2UIBackend_procdata;
select 'LC2UIBackend_work count:';
select count(*) from LC2UIBackend_work;
select 'LC2UIBackend_proc count:';
select count(*) from LC2UIBackend_proc;
select 'LC2UIBackend_proctemp count:';
select count(*) from LC2UIBackend_proctemp;

drop table IF EXISTS LC2UIBackendtemp;
-- drop table IF EXISTS LC2UIBackend_proctemp;
-- select '<p>Import done</p>';
select '<h4>Import LC2UIBackend processes done.</h4>';
.exit