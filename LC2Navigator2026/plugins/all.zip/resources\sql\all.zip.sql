 PRAGMA foreign_keys=OFF;
BEGIN TRANSACTION;
SELECT '<h1>IMPORTING LC2Navigator2026</h1>';
SELECT '<h2>PLUGINS v.1.17.12.25.3</h2>';
SELECT 'LC2Navigator 2025 - Register Plugins count:';
select count(*) from plugins;
SELECT '<h1>Update 17.12.25</h1>';
SELECT 'Truncating registered Plugins count:';
select count(*) from plugins;
delete from plugins;
SELECT 'Intial Plugins count:';
select count(*) from plugins;
INSERT OR REPLACE INTO plugins (person_id,name,url) VALUES(0,'All Plugins Download v.1.17.12.25','execPluginDL(''out'',''https://raw.githubusercontent.com/David-Honisch/Microsoft-Windows/refs/heads/master/LC2Navigator2026/plugins/'',''all.zip'')');
INSERT OR REPLACE INTO plugins (person_id,name,url) VALUES(1,'All Plugins Download v.1.17.12.25','execPluginDL(''out'',''https://raw.githubusercontent.com/David-Honisch/Microsoft-Windows/refs/heads/master/LC2Navigator2026/plugins/'',''all.zip'')');
------------------------------------------------------
-- database container ----------------------------------------------
------------------------------------------------------
INSERT OR REPLACE INTO plugins (person_id,name,url) VALUES(10,'All Plugins Download v.1.17.12.25','execPluginDL(''out'',''https://raw.githubusercontent.com/David-Honisch/Microsoft-Windows/refs/heads/master/LC2Navigator2026/plugins/'',''all.zip'')');
INSERT OR REPLACE INTO plugins (person_id,name,url) VALUES(11,'node_modules Download v.1.17.12.25.1','execPluginDL(''out'',''https://raw.githubusercontent.com/David-Honisch/LC2Navigator2026/main/LC2Navigator2026/plugins/'',''node_modules.zip'')');
INSERT OR REPLACE INTO plugins (person_id,name,url) VALUES(12,'Assets Download v.1.17.12.25.1','execPluginDL(''out'',''https://raw.githubusercontent.com/David-Honisch/LC2Navigator2026/main/LC2Navigator2026/plugins/'',''assets.zip'')');

INSERT OR REPLACE INTO plugins (person_id,name,url) VALUES(13,'Resources Download v.1.17.12.25.1','execPluginDL(''out'',''https://raw.githubusercontent.com/David-Honisch/LC2Navigator2026/main/LC2Navigator2026/plugins/'',''resources.zip'')');
INSERT OR REPLACE INTO plugins (person_id,name,url) VALUES(13,'Resources CMDs Download v.1.17.12.25.1','execPluginDL(''out'',''https://raw.githubusercontent.com/David-Honisch/LC2Navigator2026/main/LC2Navigator2026/plugins/'',''resources_cmd.zip'')');
INSERT OR REPLACE INTO plugins (person_id,name,url) VALUES(13,'Resources XMLs and XSLTs Download v.1.17.12.25.1','execPluginDL(''out'',''https://raw.githubusercontent.com/David-Honisch/LC2Navigator2026/main/LC2Navigator2026/plugins/'',''resources_xml.zip'')');

INSERT OR REPLACE INTO plugins (person_id,name,url) VALUES(20,'SQLITE+Dlls Core Application Download v.1.0 Update 17.12.25.1','execPluginDL(''out'',''https://raw.githubusercontent.com/David-Honisch/Microsoft-Windows/refs/heads/master/LC2Navigator2026/plugins/'',''sqlite3win.zip'')');
INSERT OR REPLACE INTO plugins (person_id,name,url) VALUES(21,'schema Download v.1.17.12.25.1','execPluginDL(''out'',''https://raw.githubusercontent.com/David-Honisch/LC2Navigator2026/main/LC2Navigator2026/plugins/'',''schema.zip'')');

INSERT OR REPLACE INTO plugins (person_id,name,url) VALUES(21,'lc2navigatorconfig Download v.1.17.12.25.1','execPluginDL(''out'',''https://raw.githubusercontent.com/David-Honisch/LC2Navigator2026/main/LC2Navigator2026/plugins/'',''lc2navigatorconfig.zip'')');
--lc2replaceinfile
INSERT OR REPLACE INTO plugins (person_id,name,url) VALUES(22,'lc2replaceinfile Download v.1.0','execPluginDL(''out'',''https://raw.githubusercontent.com/David-Honisch/Microsoft-Windows/refs/heads/master/LC2Navigator2026/plugins/tools/'',''lc2replaceinfile.zip'')');
-------
INSERT OR REPLACE INTO plugins (person_id,name,url) VALUES(23,'LC2Database Download v.1.17.12.25.1','execPluginDL(''out'',''https://raw.githubusercontent.com/David-Honisch/LC2Navigator2026/main/LC2Navigator2026/plugins/db/'',''LC2Database.zip'')');
--------

INSERT OR REPLACE INTO plugins (person_id,name,url) 
VALUES(122,'LC2CRC32 Download v.1.0 Update 17.12.25','execPluginDL(''out'',''https://raw.githubusercontent.com/David-Honisch/Microsoft-Windows/refs/heads/master/LC2Navigator2026/plugins/tools/'',''LC2CRC32.zip'')');
INSERT OR REPLACE INTO plugins (person_id,name,url) 
VALUES(123,'LC2ShortCutCLI Download v.1.0 Update 17.12.25','execPluginDL(''out'',''https://raw.githubusercontent.com/David-Honisch/Microsoft-Windows/refs/heads/master/LC2Navigator2026/plugins/tools/'',''LC2ShortCutCLI.zip'')');

--lc2wsdl_client_app
INSERT OR REPLACE INTO plugins (person_id,name,url) 
VALUES(125,'lc2wsdl_client_app Download v.1 17.12.25','execPluginDL(''out'',''https://raw.githubusercontent.com/David-Honisch/Microsoft-Windows/refs/heads/master/LC2Navigator2026/plugins/tools/'',''lc2wsdl_client_app.zip'')');
-- lc2newplugin
INSERT OR REPLACE INTO plugins (person_id,name,url) 
VALUES(126,'lc2newplugin Download v.1 17.12.25','execPluginDL(''out'',''https://raw.githubusercontent.com/David-Honisch/Microsoft-Windows/refs/heads/master/LC2Navigator2026/plugins/tools/'',''lc2newplugin.zip'')');
--lc2imgtag
INSERT OR REPLACE INTO plugins (person_id,name,url) 
VALUES(127,'lc2imgtag Download v.1 17.12.25','execPluginDL(''out'',''https://raw.githubusercontent.com/David-Honisch/Microsoft-Windows/refs/heads/master/LC2Navigator2026/plugins/tools/'',''lc2imgtag.zip'')');
--lc2imgtag
INSERT OR REPLACE INTO plugins (person_id,name,url) 
VALUES(128,'lc2miniDiffusion.zip Download v.1 17.12.25','execPluginDL(''out'',''https://raw.githubusercontent.com/David-Honisch/Microsoft-Windows/refs/heads/master/LC2Navigator2026/plugins/tools/'',''lc2miniDiffusion.zip'')');
-- INSERT OR REPLACE INTO plugins (person_id,name,url) 
-- VALUES(13,'LC2RegistryWizard Download v.1.1 - Update 06.02.2025','execPluginDL(''out'',''https://raw.githubusercontent.com/David-Honisch/LC2Navigator2026/main/LC2Navigator2026/plugins/tools/'',''LC2RegistryWizard.zip'')');
-- INSERT OR REPLACE INTO plugins (person_id,name,url) 
-- VALUES(14,'LC2bat2exe Download (requires docker or podman) v.1.06.02.2025.1 - Update 12.05.2025','execPluginDL(''out'',''https://raw.githubusercontent.com/David-Honisch/LC2Navigator2026/main/LC2Navigator2026/plugins/tools/'',''LC2bat2exe.zip'')');
-- INSERT OR REPLACE INTO plugins (person_id,name,url) 
-- VALUES(15,'LC2Clock Download v.2.0121 - Update 09.02.2025','execPluginDL(''out'',''https://raw.githubusercontent.com/David-Honisch/LC2Navigator2026/main/LC2Navigator2026/plugins/tools/'',''LC2Clock.zip'')');
------------
-- INSERT OR REPLACE INTO plugins (person_id,name,url) 
-- VALUES(15,'LC2JSVideoPlayer.zip Download v.2.0121 - Update 11.02.2025','execPluginDL(''out'',''https://raw.githubusercontent.com/David-Honisch/LC2Navigator2026/main/LC2Navigator2026/plugins/media/'',''LC2JSVideoPlayer.zip'')');
--------------------------
-- build tools (maven and ant)
-- SELECT '<h1>IMPORTING build plugins</h1>';
-- INSERT OR REPLACE INTO plugins (person_id,name,url) 
-- VALUES(520,'apache-maven Download v.2.0121 - Update 09.02.2025','execPluginDL(''out'',''https://raw.githubusercontent.com/David-Honisch/LC2Navigator2026/main/LC2Navigator2026/plugins/build/'',''apache-maven.zip'')');
-- INSERT OR REPLACE INTO plugins (person_id,name,url) 
-- VALUES(521,'apache-ant Download v.2.0121 - Update 09.02.2025','execPluginDL(''out'',''https://raw.githubusercontent.com/David-Honisch/LC2Navigator2026/main/LC2Navigator2026/plugins/build/'',''apache-ant.zip'')');


-- SELECT '<h1>IMPORTING database plugins</h1>';
------------------------------------------------------
-- database container ----------------------------------------------
------------------------------------------------------
SELECT '<h1>IMPORTING container part 2</h1>';
INSERT OR REPLACE INTO plugins (person_id,name,url) 
VALUES(1000,'LC2DBCLI Download v.1.17.12.25.1 (requires OpenJDK(Java))','execPluginDL(''out'',''https://raw.githubusercontent.com/David-Honisch/Microsoft-Windows/refs/heads/master/LC2Navigator2026/plugins/db/'',''LC2DBCLI.zip'')');
--lc2container
-- INSERT OR REPLACE INTO plugins (person_id,name,url) 
-- VALUES(1001,'LC2Oracle23C Download (requires docker or podman) v.2.0121 - Update 09.02.2025','execPluginDL(''out'',''https://raw.githubusercontent.com/David-Honisch/LC2Navigator2026/main/LC2Navigator2026/plugins/db/oracle/'',''LC2Oracle23C.zip'')');
--- Apache PHP MySQL
INSERT OR REPLACE INTO plugins (person_id,name,url) 
VALUES(1002,'lc2container Download (requires docker or podman) v.1.17.12.25.1','execPluginDL(''out'',''https://raw.githubusercontent.com/David-Honisch/Microsoft-Windows/refs/heads/master/LC2Navigator2026/plugins/container/'',''lc2container.zip'')');
INSERT OR REPLACE INTO plugins (person_id,name,url) 
VALUES(1003,'lc2container Services Download (requires docker or podman) v.1.17.12.25.1','execPluginDL(''out'',''https://raw.githubusercontent.com/David-Honisch/Microsoft-Windows/refs/heads/master/LC2Navigator2026/plugins/container/'',''lc2containerservice.zip'')');
--lc2stable_diffusion
INSERT OR REPLACE INTO plugins (person_id,name,url) 
VALUES(1004,'lc2stable_diffusion Download (requires docker or podman) v.1.17.12.25.1','execPluginDL(''out'',''https://raw.githubusercontent.com/David-Honisch/Microsoft-Windows/refs/heads/master/LC2Navigator2026/plugins/container/'',''lc2stable_diffusion.zip'')');

INSERT OR REPLACE INTO plugins (person_id,name,url) 
VALUES(1005,'lc2docker2exe Download (requires docker or podman) v.1.17.12.25.1','execPluginDL(''out'',''https://raw.githubusercontent.com/David-Honisch/Microsoft-Windows/refs/heads/master/LC2Navigator2026/plugins/tools/'',''lc2docker2exe.zip'')');
--- EOF Apache PHP MySQL
-- complete container, interpreter and database 
-- INSERT OR REPLACE INTO plugins (person_id,name,url) 
-- VALUES(2000,'lc2dockerphpapache Download (requires docker or podman) v.1.2.06.01.2025 - Update06.01.2025','execPluginDL(''out'',''https://raw.githubusercontent.com/David-Honisch/LC2Navigator2026/main/LC2Navigator2026/plugins/container/'',''lc2dockerphpapache.zip'')');
-- INSERT OR REPLACE INTO plugins (person_id,name,url) 
-- VALUES(2001,'lc2dockerphpapache php backend service Download (requires docker or podman) v.1.0121a - Update 09.02.2025','execPluginDL(''out'',''https://raw.githubusercontent.com/David-Honisch/LC2Navigator2026/main/LC2Navigator2026/plugins/container/'',''lc2dockerphpapacheservice.zip'')');
-- complete container, interpreter and database 
-- INSERT OR REPLACE INTO plugins (person_id,name,url) 
-- VALUES(2002,'LC2bat2exe Download (requires docker or podman) v.2.0121 - Update 09.02.2025','execPluginDL(''out'',''https://raw.githubusercontent.com/David-Honisch/LC2Navigator2026/main/LC2Navigator2026/plugins/tools/'',''LC2bat2exe.zip'')');
-- INSERT OR REPLACE INTO plugins (person_id,name,url) 
-- VALUES(2003,'LC2IPFS Download (requires docker or podman) v.2.0121 - Update 09.02.2025','execPluginDL(''out'',''https://raw.githubusercontent.com/David-Honisch/LC2Navigator2026/main/LC2Navigator2026/plugins/web/'',''LC2IPFS.zip'')');
------------------------------------------------------
-- data ----------------------------------------------
------------------------------------------------------
-- SELECT '<h1>IMPORTING data plugins</h1>';
-- INSERT OR REPLACE INTO plugins (person_id,name,url) 
-- VALUES(3000,'LC2CVEGrabber Download v.2.0121 - Update 12.02.2025','execPluginDL(''out'',''https://raw.githubusercontent.com/David-Honisch/LC2Navigator2026/main/LC2Navigator2026/plugins/data/'',''LC2CVEGrabber.zip'')');
-- INSERT OR REPLACE INTO plugins (person_id,name,url) 
-- VALUES(3001,'LC2DEBanksUpdater Download v.2.0121 - Update 12.02.2025','execPluginDL(''out'',''https://raw.githubusercontent.com/David-Honisch/LC2Navigator2026/main/LC2Navigator2026/plugins/data/'',''LC2DEBanksUpdater.zip'')');
-- INSERT OR REPLACE INTO plugins (person_id,name,url) 
-- VALUES(3002,'LC2Eurostat Download v.2.0121 - Update 12.02.2025','execPluginDL(''out'',''https://raw.githubusercontent.com/David-Honisch/LC2Navigator2026/main/LC2Navigator2026/plugins/data/'',''LC2Eurostat.zip'')');
------------------------------------------------------
-- core container ----------------------------------------------
------------------------------------------------------
-- SELECT '<h1>IMPORTING core container</h1>';
-- INSERT OR REPLACE INTO plugins (person_id,name,url) 
-- VALUES(4000,'lc2dockerphpapache Download v.2.0121 - Update 15.02.2025','execPluginDL(''out'',''https://raw.githubusercontent.com/David-Honisch/LC2Navigator2026/main/LC2Navigator2026/plugins/container/'',''lc2dockerphpapache.zip'')');
-- INSERT OR REPLACE INTO plugins (person_id,name,url) 
-- VALUES(4001,'lc2dockerphpapacheservice Download v.2.0121a - Update 15.02.2025','execPluginDL(''out'',''https://raw.githubusercontent.com/David-Honisch/LC2Navigator2026/main/LC2Navigator2026/plugins/container/'',''lc2dockerphpapacheservice.zip'')');
------------------------------------------------------
-- more container ----------------------------------------------
------------------------------------------------------
-- INSERT OR REPLACE INTO plugins (person_id,name,url) 
-- VALUES(5001,'lc2mongodb Download v.0.1.0122 - Update 15.04.2025','execPluginDL(''out'',''https://raw.githubusercontent.com/David-Honisch/LC2Navigator2026/main/LC2Navigator2026/plugins/db/mongodb/'',''lc2mongodb.zip'')');

------------------------------------------------------
-- more container ----------------------------------------------
------------------------------------------------------
-- SELECT '<h1>IMPORTING container part 2</h1>';
-- INSERT OR REPLACE INTO plugins (person_id,name,url) 
-- VALUES(6001,'LC2RotatingTorproxy Download v.2.0121 - Update 15.02.2025','execPluginDL(''out'',''https://raw.githubusercontent.com/David-Honisch/LC2Navigator2026/main/LC2Navigator2026/plugins/container/'',''LC2RotatingTorproxy.zip'')');
-- INSERT OR REPLACE INTO plugins (person_id,name,url) 
-- VALUES(6002,'LC2ApacheTC Download v.2.0121 - Update 15.02.2025','execPluginDL(''out'',''https://raw.githubusercontent.com/David-Honisch/LC2Navigator2026/main/LC2Navigator2026/plugins/container/'',''LC2ApacheTC.zip'')');

-- INSERT OR REPLACE INTO plugins (person_id,name,url) 
-- VALUES(6003,'LC2UIBackend Download v.0.1.0122 - Update 15.04.2025','execPluginDL(''out'',''https://raw.githubusercontent.com/David-Honisch/LC2Navigator2026/main/LC2Navigator2026/plugins/java/'',''LC2UIBackend.zip'')');
------------------------------------------------------
-- more container ----------------------------------------------
------------------------------------------------------
-- INSERT OR REPLACE INTO plugins (person_id,name,url) 
-- VALUES(6004,'LC2Iso2God Download v.0.1.0122 - Update 15.04.2025','execPluginDL(''out'',''https://raw.githubusercontent.com/David-Honisch/LC2Navigator2026/main/LC2Navigator2026/plugins/tools/'',''LC2Iso2God.zip'')');
-- web related
INSERT OR REPLACE INTO plugins (person_id,name,url) 
VALUES(6005,'lc2webllmchat Download v.0.01 - Update 22.05.2025','execPluginDL(''out'',''https://raw.githubusercontent.com/David-Honisch/Microsoft-Windows/refs/heads/master/LC2Navigator2026/plugins/tools/'',''lc2webllmchat.zip'')');

INSERT OR REPLACE INTO plugins (person_id,name,url) 
VALUES(6006,'lc2tts Download v.0.01 - Update 22.05.2025','execPluginDL(''out'',''https://raw.githubusercontent.com/David-Honisch/Microsoft-Windows/refs/heads/master/LC2Navigator2026/plugins/tools/'',''lc2tts.zip'')');

INSERT OR REPLACE INTO plugins (person_id,name,url) 
VALUES(6007,'LC2Authme Download v.0.01 - Update 01.06.2025','execPluginDL(''out'',''https://raw.githubusercontent.com/David-Honisch/Microsoft-Windows/refs/heads/master/LC2Navigator2026/plugins/tools/'',''LC2Authme.zip'')');

INSERT OR REPLACE INTO plugins (person_id,name,url) 
VALUES(6008,'lc2color Download v.0.01 - Update 25.07.2025','execPluginDL(''out'',''https://raw.githubusercontent.com/David-Honisch/Microsoft-Windows/refs/heads/master/LC2Navigator2026/plugins/tools/'',''lc2color.zip'')');
--lc2aieditor
INSERT OR REPLACE INTO plugins (person_id,name,url) 
VALUES(6009,'lc2aieditor Download v.0.01 - Update 25.07.2025','execPluginDL(''out'',''https://raw.githubusercontent.com/David-Honisch/Microsoft-Windows/refs/heads/master/LC2Navigator2026/plugins/tools/'',''lc2aieditor.zip'')');

INSERT OR REPLACE INTO plugins (person_id,name,url) 
VALUES(6010,'lc2sqlite Download v.0.02 - Update 25.07.2025','execPluginDL(''out'',''https://raw.githubusercontent.com/David-Honisch/Microsoft-Windows/refs/heads/master/LC2Navigator2026/plugins/tools/'',''lc2sqlite.zip'')');
-- LC2SteamAchievementManager
INSERT OR REPLACE INTO plugins (person_id,name,url) 
VALUES(6011,'LC2SteamAchievementManager Download v.0.01 - Update 02.10.2025','execPluginDL(''out'',''https://raw.githubusercontent.com/David-Honisch/Microsoft-Windows/refs/heads/master/LC2Navigator2026/plugins/tools/'',''LC2SteamAchievementManager.zip'')');

INSERT OR REPLACE INTO plugins (person_id,name,url) 
VALUES(6012,'lc2memory Download v.0.01 - Update 30.10.2025','execPluginDL(''out'',''https://raw.githubusercontent.com/David-Honisch/Microsoft-Windows/refs/heads/master/LC2Navigator2026/plugins/tools/'',''lc2memory.zip'')');

INSERT OR REPLACE INTO plugins (person_id,name,url) 
VALUES(6013,'lc2crud Download v.0.01 - Update 30.10.2025','execPluginDL(''out'',''https://raw.githubusercontent.com/David-Honisch/Microsoft-Windows/refs/heads/master/LC2Navigator2026/plugins/tools/'',''lc2crud.zip'')');



INSERT OR REPLACE INTO plugins (person_id,name,url) VALUES(9000000,'Some Plugins doesn´t work up to now. Please update all plugins soon','alert(''Update all plugins. There might be some brandnew updates.'')');
SELECT 'SUCCESSFULLY IMPORTED.';
SELECT 'Registered Plugins count:';
select count(*) from plugins;
SELECT 'Plugins IMPORT done.';
SELECT '<h1>IMPORTING PLUGINS done.</h1>';
COMMIT;