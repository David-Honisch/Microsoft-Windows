var hostName = "http://localhost:5000";
var pluginName = "LC2Eurostat";
var pluginTable = "LC2Eurostat";
var installDirectories = [
    // 'lcwebclient_final_lib',
    // 'org.letztechance.domain.web.GrabUrls',
    // 'org.letztechance.domain.web.GrabUrls\\org.letztechance.domain.web.GrabUrls_lib',
    'resources\\plugins\\lcwebclient_final',
    'resources\\plugins\\lcwebclient_final\\lcwebclient_final_lib',
    'resources\\plugins\\org.letztechance.domain.web.GrabUrls',
    'resources\\plugins\\org.letztechance.domain.web.GrabUrls\\org.letztechance.domain.web.GrabUrls_lib',

];
var corelibs = [
    'jquery',
    'https',
    'stream',
    'line-reader',
    'fs',
    'request',
    'runtime-npm-install',
    'decompress-zip',
    'csv',
    'jszip',
    'sax',
    'xlsx',
    'xlsx-to-json',
    'xlsx-to-json-lc',
    'xml2js',
    'xmlbuilder',
    'xmldom',
    'xml-js',
    'xmljson',
    'miniget',
    'ytdl-core'
];

var downloadUrls = [
	{
        path: "https://www.letztechance.org/img.png?width=400&height=400&image=logo.png&text=LC2Eurostat&r=20&g=20&b=20&test=.",
        file: "logo.png"
    },
    {
        path: "https://raw.githubusercontent.com/David-Honisch/Microsoft-Windows/master/LC2Navigator2023/plugins/",
        file: "apache-maven.zip",
    },
    {
        path: "https://raw.githubusercontent.com/David-Honisch/Microsoft-Windows/master/LC2Navigator2023/plugins/",
        file: "apache-ant.zip",
    },
    {
        path: "https://ec.europa.eu/eurostat/estat-navtree-portlet-prod/BulkDownloadListing?file=data/",
        file: "ei_bpm6ca_q.tsv.gz",
    },
    {
        path: "https://ec.europa.eu/eurostat/estat-navtree-portlet-prod/BulkDownloadListing?file=data/",
        file: "ei_bpm6fa_q.tsv.gz",
    },
    {
        path: "https://ec.europa.eu/eurostat/estat-navtree-portlet-prod/BulkDownloadListing?file=data/",
        file: "ei_bpm6ca_m.tsv.gz",
    }
	,
    {
        path: "https://ec.europa.eu/eurostat/estat-navtree-portlet-prod/BulkDownloadListing?file=data/",
        file: "ei_bpm6iip_q.tsv.gz",
    }
	,
    {        
        path: "https://ec.europa.eu/eurostat/estat-navtree-portlet-prod/BulkDownloadListing?file=data/",
		file: "enps_nama_10_gdp.tsv.gz",
    }
	,
    {        
        path: "https://ec.europa.eu/eurostat/api/dissemination/statistics/1.0/data/",
		file: "nama_10_gdp",
    }
	
    
];