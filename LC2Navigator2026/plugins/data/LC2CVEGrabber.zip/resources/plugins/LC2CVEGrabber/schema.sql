select '<hr/><h2>Import LC2CVEGrabber processes</h2>';
-- select '<p>drop plugin tables</p>';
drop table IF EXISTS LC2CVEGrabber;
drop table IF EXISTS LC2CVEGrabber_main;
drop table IF EXISTS LC2CVEGrabber_install;
drop table IF EXISTS LC2CVEGrabber_help;
drop table IF EXISTS LC2CVEGrabber_data;
drop table IF EXISTS LC2CVEGrabber_info;
drop table IF EXISTS LC2CVEGrabber_work;
drop table IF EXISTS LC2CVEGrabber_procdata;
drop table IF EXISTS LC2CVEGrabbertemp;
drop table IF EXISTS LC2CVEGrabber_datatemp;
drop table IF EXISTS LC2CVEGrabber_worktemp;
drop table IF EXISTS LC2CVEGrabber_proc;
drop table IF EXISTS LC2CVEGrabber_tests;
drop table IF EXISTS LC2CVEGrabber_proctemp;
drop table IF EXISTS LC2CVEGrabber_proc_temp;
---------------------------------------------------------------
select '<span>Creating tables</span>';
---------------------------------------------------------------
CREATE TABLE LC2CVEGrabber( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,  "url" TEXT NULL);
CREATE TABLE LC2CVEGrabber_main( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE LC2CVEGrabber_install( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE LC2CVEGrabber_help( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE LC2CVEGrabber_data( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE LC2CVEGrabber_info( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
--CREATE TABLE LC2CVEGrabber_work( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE LC2CVEGrabber_work( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "first_name" TEXT NULL,"name" TEXT NOT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
-- CREATE TABLE LC2CVEGrabber_proc( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE IF NOT EXISTS LC2CVEGrabber_proc ( "first_name" TEXT NULL, "name" TEXT NOT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE IF NOT EXISTS LC2CVEGrabber_proc_temp ("name" TEXT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
--CREATE TABLE IF NOT EXISTS LC2CVEGrabber_proctemp( "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "url" TEXT NULL);
---------------------------------------------------------------
CREATE TABLE LC2CVEGrabber_tests( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE LC2CVEGrabber_procdata( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
---------------------------------------------------------------
-- CREATE TABLE IF NOT EXISTS LC2CVEGrabber_proc_temp (
-- "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "url" TEXT NULL
-- );

---------------------------------------------------------------
-- import menu
select '<span>start import to plugin tables</span>';
---------------------------------------------------------------
.separator ";"
.import .\\resources\\plugins\\LC2CVEGrabber\\import\\import.csv LC2CVEGrabbertemp
-- INSERT INTO LC2CVEGrabber(first_name,name,zipcode, city, description) select first_name,name,zipcode, city, description  from LC2CVEGrabbertemp;
.import .\\resources\\plugins\\LC2CVEGrabber\\import\\import.csv LC2CVEGrabber
.import .\\resources\\plugins\\LC2CVEGrabber\\import\\main.csv LC2CVEGrabber_main
.import .\\resources\\plugins\\LC2CVEGrabber\\import\\install.csv LC2CVEGrabber_install
.import .\\resources\\plugins\\LC2CVEGrabber\\import\\help.csv LC2CVEGrabber_help
.import .\\resources\\plugins\\LC2CVEGrabber\\import\\data.csv LC2CVEGrabber_data
.import .\\resources\\plugins\\LC2CVEGrabber\\import\\info.csv LC2CVEGrabber_info
.import .\\resources\\plugins\\LC2CVEGrabber\\import\\work.csv LC2CVEGrabber_work
.import .\\resources\\plugins\\LC2CVEGrabber\\import\\proc.csv LC2CVEGrabber_proc
.import .\\resources\\plugins\\LC2CVEGrabber\\import\\tests.csv LC2CVEGrabber_tests
---------------------------------------------------------------
-- import procs
select '<span>importing processes</span>';
---------------------------------------------------------------
-- .separator ';'
.import '.\\resources\\plugins\\LC2CVEGrabber\\allitems.csv' LC2CVEGrabber_work
-- .import '.\\resources\\plugins\\LC2CVEGrabber\\blz-aktuell-csv-data.csv' LC2CVEGrabber_proc
select '<h6>raw data successfully imported</h6>'; 
select '<p>LC2CVEGrabber_proc_temp count:';
select count(*)  from LC2CVEGrabber_proc_temp;
select '</p>';
-- INSERT INTO LC2CVEGrabber_data (first_name,name,zipcode, city, description,url) select substr( name, 0, 9 ),rtrim(substr( name, 10, 58 )), substr(name,68,71), substr(name,73,78), name,trim(substr( name, 140, 169))  from LC2CVEGrabber_proc_temp;
-- .separator ","
-- .import '.\\resources\\plugins\\LC2CVEGrabber\\import\\proc.csv' LC2CVEGrabber_proctemp
-- .separator ";"
-- INSERT INTO LC2CVEGrabber_proc(first_name,name,zipcode, description,url) select first_name,name,zipcode, description,url  from LC2CVEGrabber_proctemp;
-- select 'LC2CVEGrabber_work count:';
-- select count(*) from LC2CVEGrabber_proc;
-- eof insert work data
-- eof insert work data
---------------------------------------------------------------
-- done
select '<span>import done</span>';
---------------------------------------------------------------
select 'LC2CVEGrabber count:';
select count(*) from LC2CVEGrabber;
select '<p>start data import to plugin tables</p>';
-- delete from LC2CVEGrabber_datatemp;
--
select '<p>LC2CVEGrabber count:';
select count(*) from LC2CVEGrabber;
select 'LC2CVEGrabber_data count:';
select count(*) from LC2CVEGrabber_data;
select 'LC2CVEGrabber_info count:';
select count(*) from LC2CVEGrabber_info;

select 'LC2CVEGrabber_procdata count:';
select count(*) from LC2CVEGrabber_procdata;
select 'LC2CVEGrabber_work count:';
select count(*) from LC2CVEGrabber_work;
select 'LC2CVEGrabber_proc count:';
select count(*) from LC2CVEGrabber_proc;
select 'LC2CVEGrabber_proc_temp count:';
select count(*) from LC2CVEGrabber_proc_temp;

drop table IF EXISTS LC2CVEGrabbertemp;
-- drop table IF EXISTS LC2CVEGrabber_proctemp;
-- select '<p>Import done</p>';
select '<h4>Import LC2CVEGrabber processes done.</h4>';
.exit