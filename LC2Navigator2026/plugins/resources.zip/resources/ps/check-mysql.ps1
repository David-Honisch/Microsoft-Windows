# C:\Scripts\Check-MySQL.ps1

# Define MySQL Connection Parameters
# $server = "localhost"
# $database = "your_database_name"
# $user = "your_username"
# $pass = "your_password"
# C:\Scripts\ProcessArgs.ps1

# Define parameters the script accepts
param(
    [string]$database,
    [string]$user,
    [string]$pass,
    [int]$MaxRetries
)

Write-Host "<pre>"
Write-Host "--------------------------------"
Write-Host "PowerShell Script Initialized:"
Write-Host "Database Name: $database"
Write-Host "User Name:     $user"
Write-Host "Max Retries:   $MaxRetries"
Write-Host "--------------------------------"
Write-Host "</pre>"

# You can now use these variables in your script logic
if ($MaxRetries -gt 5) {
    Write-Host "Warning: Retries count is high."
}
# Path to the MySQL Connector/Net Assembly (adjust path as needed)
# $connectorPath = "C:\Program Files (x86)\MySQL\MySQL Connector NET 8.0\MySql.Data.dll"
$connectorPath = ".\MySql.Data.dll"

Write-Host "<pre>"
# Load the MySQL Assembly
try {
    Add-Type -Path $connectorPath
} catch {
    Write-Host "ERROR: Failed to load MySQL Connector DLL. Check the path: $connectorPath"
    exit 1
}

# Construct the connection string
$connStr = "Server=$server;Database=$database;Uid=$user;Pwd=$pass;"
$conn = New-Object MySql.Data.MySqlClient.MySqlConnection($connStr)

try {
    # Open the connection
    $conn.Open()
    
    # Simple query to test the connection (get server version)
    $command = $conn.CreateCommand()
    $command.CommandText = "SELECT VERSION()"
    $version = $command.ExecuteScalar()

    Write-Host "SUCCESS: Successfully connected to MySQL Server version: $version"
    exit 0 # Success exit code
}
catch {
    # Handle connection errors
    Write-Host "ERROR: Connection failed to $server. Details: $_.Exception.Message"
    exit 1 # Failure exit code
}
finally {
    # Ensure the connection is always closed
    if ($conn.State -eq 'Open') {
        $conn.Close()
    }
	Write-Host "</pre>"
}