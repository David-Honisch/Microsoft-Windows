Get-ScheduledTask -TaskPath \Microsoft\Windows\Win*
Get-ScheduledTask StartComponentCleanup | Get-ScheduledTaskInfo
Get-ScheduledTask | Get-ScheduledTaskInfo | ? NumberOfMissedRuns -gt 0
# Disable-ScheduledTask -TaskName StartComponentCleanup
# Get-ScheduledTask | Get-ScheduledTaskInfo | ? NumberOfMissedRuns -gt 10 | Disable-ScheduledTask
# Get-ScheduledTask | ? State -eq running | Stop-ScheduledTask