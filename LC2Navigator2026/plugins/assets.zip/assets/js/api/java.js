/*
#! /usr/bin/env node
"use strict"
   This file does not need to be updated, only java-caller-config.json must be !
*/
const { JavaCaller,JavaCallerCli } = window.nodeRequire("java-caller");
const spawn = window.nodeRequire("child_process").spawn;
function printJavaResult(text) {
  var java = window.nodeRequire('java');
  var javaLangSystem = java.import('java.lang.System');
  javaLangSystem.out.printlnSync(text);
}
function getJavaClass(className,numbers) {
  let result = "";
  let args = [];
  args.push(className); // remove first argument
  // Push the numbers other arguments
  numbers.forEach((element) => {
    args.push(element);
  });

  // Starting our worker
  console.log("Starting work");
  let spawn = getSpawn();
  let worker = spawn("java", args);
  printJavaWorker(worker); 
}

function getSpawn() {
  return window.nodeRequire("child_process").spawn;
}
function printJavaWorker(worker) {
  let result = "Result:";
  // let worker = spawn("java", args);
  worker.stdout.on("data", function (data) {
    console.log("response: " + data);
    // $("#app_cnt").append("<h1>Data:"+data+"</h1>");
    result += "<h1>Data:"+data+"</h1>";
  });
  worker.on("close", function (code, signal) {
    console.log("Java finished with exit code of " + code);
    // $("#app_cnt").append("Code:"+code);
    result += "<p>process returncode:"+code+"</p>";
    $("#app_cnt").append(result);
  });
  
}