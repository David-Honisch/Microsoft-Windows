console.log('TEST SERVER binary and instance(s):\n');
class SERVER {
    static run(o, NODEAPI,params, jarPath) {
        console.log("Test Server Params:"+JSON.stringify(params)+"\n");
        NODEAPI.getServerInstances(o,params,jarPath);
        console.log(this.name + " done.\n");


    }
    static test() {
        console.log(this.name + ' test successfull.');
    }

}
module.exports = SERVER;