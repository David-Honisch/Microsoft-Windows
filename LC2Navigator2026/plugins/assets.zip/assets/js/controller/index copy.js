var remote = window.nodeRequire('electron').remote;
//arguments = remote.getGlobal('sharedObject').prop1;
//console.log(arguments);
//alert(arguments);
//LC2Navigator 2022
var app = angular.module('app', ['ui.bootstrap']);

// const APPCFG = "application.config.json";
const path = window.nodeRequire('path');
const jQuery = window._PAGE_.jQuery;
const { readFileSync, fs } = window.nodeRequire('fs');
const cfg = window.nodeRequire(path.join(__dirname, '..', '..', 'config.json'));
//const model = window.nodeRequire(path.join(__dirname, '..', 'assets', 'js', 'app', 'model.js'));
const model = window.nodeRequire(path.join(__dirname, '..', '..', 'assets', 'js', 'app', 'model.js'));
const cpath = path.join(__dirname);
const dbPath = path.join(__dirname, '..', 'lc.db'); // remote.getGlobal('sharedObj').dbPath; // remote.getGlobal('sharedObj').dbPath;
const gelectron = window.nodeRequire('electron');
const shell = gelectron.shell;
// const OPEN_LINK = "https://www.letztechance.org/openlink?";
// -var remote = window.nodeRequire('electron').remote;
// const rootLib = window.nodeRequire('app-root-path');
// const appRoot = path.dirname(('' + rootLib).replace("app.asar", ""));
// console.log('rootLib:' + rootLib);
var dialogProperties = {
    // appendTo: "#dialog",
    show: "puff",
    hide: "explode",
    top: 140,
    resizable: true,
    closeOnEscape: true,
    minWidth: 150,
    minHeight: 150,
    // position: { my: "left top", of: "left top" },
    height: "auto",
    width: "auto"
};

function JSController($scope, $http, $filter) {
    const APPCFG = "application.config.json";
    const path = window.nodeRequire('path');
    // default values for pagination and filtering    
    $scope.title = "LC2Navigator2025 - HOME";
    $scope.cfg = [];
}
