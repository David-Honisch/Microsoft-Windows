SELECT '<h1>SQL assets SCRIPT IS RUNNING</h1>';
SELECT '<h5>Init import script</h5>';
--DELETE FROM importscripts;
SELECT '<h5>INSERT import script</h5>';
SELECT '<h4>SET CLEAR</h4>';
SELECT '<h4>INSERT assets to applications</h4>';
-- 
INSERT OR REPLACE INTO importscripts(name, first_name, description, zipcode, city, street, url)VALUES('assets Plugin v.1.4','assets Plugin v.1.4','','','','','execPluginCMD(''out'',''assets'');');  
-- 
SELECT '<h5>INSERT PLUGINS DONE v.0.001</h5>';
SELECT '<h4>'||(SELECT COUNT(*) FROM application)||' plugin added...</h4>';
SELECT '<h1>UPDATE SQL SCRIPT DONE</h1>';