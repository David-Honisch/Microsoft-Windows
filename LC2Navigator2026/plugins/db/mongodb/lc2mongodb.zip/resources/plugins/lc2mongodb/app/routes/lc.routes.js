module.exports = app => {
  const restController = require("../controllers/lc.controller.js");

  var router = require("express").Router();

  // Create a new Tutorial
  router.post("/", restController.create);

  // Retrieve all Tutorials
  router.get("/", restController.findAll);

  router.get("/all", restController.findAll);

  // Retrieve all published Tutorials
  router.get("/published", restController.findAllPublished);

  // Retrieve a single Tutorial with id
  router.get("/:id", restController.findOne);

  // Update a Tutorial with id
  router.put("/:id", restController.update);

  // Delete a Tutorial with id
  router.delete("/:id", restController.delete);

  // Create a new Tutorial
  router.delete("/", restController.deleteAll);

  app.use("/api/tutorials", router);
};
