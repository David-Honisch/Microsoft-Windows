select '<hr/><h2>LC2Database v.1.0</h2>';
select '<p>drop plugin tables</p>';
drop table IF EXISTS LC2Database;
drop table IF EXISTS LC2Database_main;
drop table IF EXISTS LC2Database_install;
drop table IF EXISTS LC2Database_help;
drop table IF EXISTS LC2Database_data;
drop table IF EXISTS LC2Database_info;
drop table IF EXISTS LC2Database_work;
drop table IF EXISTS LC2Database_procdata;
drop table IF EXISTS LC2Databasetemp;
drop table IF EXISTS LC2Database_datatemp;
drop table IF EXISTS LC2Database_worktemp;
drop table IF EXISTS LC2Database_proc;
drop table IF EXISTS LC2Database_tests;
drop table IF EXISTS LC2Database_proctemp;
---------------------------------------------------------------
drop table IF EXISTS LC2Database_mysql;
drop table IF EXISTS LC2Database_mongodb;
drop table IF EXISTS LC2Database_oracle;
drop table IF EXISTS LC2Database_sqlserver;
drop table IF EXISTS LC2Database_postgressql;
drop table IF EXISTS LC2Database_sqlite;
---------------------------------------------------------------
select '<span>Creating tables</span>';
---------------------------------------------------------------
CREATE TABLE LC2Database( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,  "url" TEXT NULL);
CREATE TABLE LC2Database_main( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE LC2Database_install( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE LC2Database_help( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE LC2Database_data( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE LC2Database_info( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE LC2Database_work( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
--CREATE TABLE LC2Database_proc( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE LC2Database_proc( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
---------------------------------------------------------------
CREATE TABLE LC2Database_mysql( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE LC2Database_oracle( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE LC2Database_mongodb( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE LC2Database_postgressql( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE LC2Database_sqlserver( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE LC2Database_sqlite( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
---------------------------------------------------------------
CREATE TABLE LC2Database_tests( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE LC2Database_procdata( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
---------------------------------------------------------------
CREATE TABLE IF NOT EXISTS LC2Databasetemp (
"name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "url" TEXT NULL
);
CREATE TABLE IF NOT EXISTS LC2Database_proctemp( "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "url" TEXT NULL);
---------------------------------------------------------------
-- import menu
select '<span>start import to plugin tables</span>';
---------------------------------------------------------------
.separator ";"
--.import .\\resources\\plugins\\LC2Database\\import\\import.csv LC2Databasetemp
-- INSERT INTO LC2Database(first_name,name,zipcode, city, description) select first_name,name,zipcode, city, description  from LC2Databasetemp;
.import .\\resources\\plugins\\LC2Database\\import\\import.csv LC2Database
.import .\\resources\\plugins\\LC2Database\\import\\main.csv LC2Database_main
.import .\\resources\\plugins\\LC2Database\\import\\install.csv LC2Database_install
.import .\\resources\\plugins\\LC2Database\\import\\help.csv LC2Database_help
.import .\\resources\\plugins\\LC2Database\\import\\info.csv LC2Database_info
.import .\\resources\\plugins\\LC2Database\\import\\data.csv LC2Database_data
.import .\\resources\\plugins\\LC2Database\\import\\work.csv LC2Database_work
.import .\\resources\\plugins\\LC2Database\\import\\proc.csv LC2Database_proc
.import .\\resources\\plugins\\LC2Database\\import\\tests.csv LC2Database_tests
---------------------------------------------------------------
.import .\\resources\\plugins\\LC2Database\\import\\mysql.csv LC2Database_mysql
.import .\\resources\\plugins\\LC2Database\\import\\mongodb.csv LC2Database_mongodb
.import .\\resources\\plugins\\LC2Database\\import\\oracle.csv LC2Database_oracle
.import .\\resources\\plugins\\LC2Database\\import\\postgressql.csv LC2Database_postgressql
.import .\\resources\\plugins\\LC2Database\\import\\sqlserver.csv LC2Database_sqlserver
.import .\\resources\\plugins\\LC2Database\\import\\sqlite.csv LC2Database_sqlite
-------------------------------------------------------------
-- import procs
-- select '<span>importing processes</span>';
-------------------------------------------------------------
-- .separator ","
-- .import '.\\resources\\plugins\\LC2Database\\import\\proc.csv' LC2Database_proctemp
-- .separator ";"
-- INSERT INTO LC2Database_proc(first_name,name,zipcode, description,url) select first_name,name,zipcode, description,url  from LC2Database_proctemp;
-- select 'LC2Database_work count:';
-- select count(*) from LC2Database_proc;
-- eof insert work data
-- eof insert work data
---------------------------------------------------------------
-- done
select '<span>import done</span>';
---------------------------------------------------------------
select 'LC2Database count:';
select count(*) from LC2Database;
select '<p>start data import to plugin tables</p>';
-- delete from LC2Database_datatemp;
--
select '<p>LC2Database count:';
select count(*) from LC2Database;
select '</br>LC2Database_data count:';
select count(*) from LC2Database_data;
select '</br>LC2Database_info count:';
select count(*) from LC2Database_info;
select '</br>LC2Database_help count:';
select count(*) from LC2Database_help;
select '</br>LC2Database_procdata count:';
select count(*) from LC2Database_procdata;
select '</br>LC2Database_work count:';
select count(*) from LC2Database_work;
select '</br>LC2Database_proc count:';
select count(*) from LC2Database_proc;
select '</br>LC2Database_proctemp count:';
select count(*) from LC2Database_proctemp;

select '</br>LC2Database_mysql count:';
select count(*) from LC2Database_mysql;
select '</br>LC2Database_mongodb count:';
select count(*) from LC2Database_mongodb;
select '</br>LC2Database_oracle count:';
select count(*) from LC2Database_oracle;
select '</br>LC2Database_sqlserver count:';
select count(*) from LC2Database_sqlserver;

drop table IF EXISTS LC2Databasetemp;
-- drop table IF EXISTS LC2Database_proctemp;
-- select '<p>Import done</p>';
select '<h4>Import LC2Database processes done.</h4>';
.exit