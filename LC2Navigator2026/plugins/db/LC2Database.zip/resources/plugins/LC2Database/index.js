function pluginINIT(pName) {
    const APPCFG = "application.config.json";
    try {
        var cfg = getAppConfig(APPCFG);
        //const api = window.nodeRequire(path.join(__dirname, '..', 'assets', 'js', 'api', 'api.js'));
        var arg = getPluginArguments();
        console.log(arg);
        //
        // var dlPath = cfg.api.baseurl;
        var dlPath = cfg.resources.homeurldir;
        var resDir = path.join(__dirname, '../../');
        var localFileName = resDir + pName + "-news.json";
        // get_Download_File(dlPath, cfg.resources.sqlite, cfg.resources.sqlite, resDir, pluginName + '');
        // get_Download_File(dlPath, cfg.resources.sqlitexslt, cfg.resources.sqlitexslt, resDir, pluginName + '');
        execCMD("call resources\\cmd\\register_plugin.bat " + pName, pName + "_info", true, false);
        // execCMD("call tasklist /FO CSV /FI \"STATUS eq running\" /NH> .\\resources\\plugins\\" + pluginName + "\\import\\proc.csv", pName + "_install", true, false);
        //creating schema import        
        $('#' + pName + '').before(getPluginButtons(pName));
        // $('#' + pName + '_main').before(getPluginButtons(pName));
        $('#' + pName + '_main').append(getPluginButtons(pName));
        // printDirectory('resources\\plugins\\' + pName + '\\', '' + pName + '_info', true);
        //queries
		execCMD("call  resources\\app\\sqlite\\SQLite3.exe \"resources\\" + pName + ".db\" \".read .\\\\resources\\\\plugins\\\\" + pName + "\\\\schema.sql\"", pName + "", true, false);

        setTimeout(() => {
            set_DragOver(pName+'maindrop', 'newdb', pName+"htmlout", pName+"outFile", ["bat", "csv", "git", "h", "c", "cpp", "js", "json", "log", "nfo", "md", "xls", "xlsx", "txt", "xml", "xslt"]);
            execCMD("resources\\cmd\\register.config.bat",  pName + "", true, false);
            // execCMD("resources\\cmd\\checkrequirement.bat .\\resources\\" + pluginName + "\\csv\\check.csv", "#" + pluginName + "_install", true, false);
        }, 3000);
        //queries
        setTimeout(() => {            
            getExecPluginCMDList(".\\resources\\" + pName + ".db", pluginTable, '#' + pName + '_main', true);
            execPluginCMDTableList(".\\resources\\" + pluginName + ".db", pluginTable + "_main", '#' + pluginName + '', true);
			execPluginCMDTableList(".\\resources\\" + pluginName + ".db", pluginTable + "_main", '#' + pluginName + '_main', true);            
            execPluginCMDTableList(".\\resources\\" + pluginName + ".db", pluginTable + "_install", '#' + pluginName + '_install', true);
			
            execPluginCMDTableList(".\\resources\\" + pluginName + ".db", pluginTable + "_info", '#' + pluginName + '_info', true);
            execPluginCMDTableList(".\\resources\\" + pluginName + ".db", pluginTable + "_help", '#' + pluginName + '_help', true);
			//plugin features
			execPluginCMDTableList(".\\resources\\" + pluginName + ".db", pluginTable + "_mysql", '#' + pluginName + '_mysql', true);
			execPluginCMDTableList(".\\resources\\" + pluginName + ".db", pluginTable + "_mongodb", '#' + pluginName + '_mongodb', true);
			execPluginCMDTableList(".\\resources\\" + pluginName + ".db", pluginTable + "_oracle", '#' + pluginName + '_oracle', true);
			execPluginCMDTableList(".\\resources\\" + pluginName + ".db", pluginTable + "_postgressql", '#' + pluginName + '_postgressql', true);
			execPluginCMDTableList(".\\resources\\" + pluginName + ".db", pluginTable + "_sqlserver", '#' + pluginName + '_sqlserver', true);
			execPluginCMDTableList(".\\resources\\" + pluginName + ".db", pluginTable + "_sqlite", '#' + pluginName + '_sqlite', true);
            execCMD("resources\\cmd\\checkrequirement.bat .\\resources\\plugins\\" + pluginName + "\\csv\\check.csv", "" + pluginName + "_install", true, false);
			//eof plugin features
            // printDirectory('.\\resources\\plugins\\' + pluginName,'' + pluginName + '',true,false);
            // printDirectory('.\\resources\\plugins\\'+ pluginName,'' + pluginName + '_main',true,false);
            
            // execCMD("call  resources\\app\\sqlite\\SQLite3.exe  \"resources\\" + pluginName + ".db\" \"select * from " + pluginTable + "_work\">\"resources\\plugins\\" + pluginName + "\\csv\\data.csv\"",pName + "_info", true, false);

        }, 6000);
    } catch (error) {
        $("" + out).append("<p class=\"alert\">" + error + "<p>");
        console.error(error);
        console.error(error.stack);
    }
}