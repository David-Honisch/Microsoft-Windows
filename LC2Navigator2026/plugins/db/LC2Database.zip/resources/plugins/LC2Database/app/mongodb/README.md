# LC2Navigator2024

- https://github.com/David-Honisch/LC2Navigator2024/tree/main/LC2Navigator2024

<a href="https://github.com/David-Honisch/LC2Navigator2024/tree/main/LC2Navigator2024"><img src="https://github.com/David-Honisch/LC2Navigator2024/raw/main/LC2Navigator2024/LC2ExcelTransform.jpg" alt="LC2Navigator2024 Screenshot" width="400" /></a>