select '<hr/><h2>Import LC2Oracle23C processes</h2>';
-- select '<p>drop plugin tables</p>';
drop table IF EXISTS LC2Oracle23C;
drop table IF EXISTS LC2Oracle23C_main;
drop table IF EXISTS LC2Oracle23C_install;
drop table IF EXISTS LC2Oracle23C_help;
drop table IF EXISTS LC2Oracle23C_data;
drop table IF EXISTS LC2Oracle23C_work;
drop table IF EXISTS LC2Oracle23C_procdata;
drop table IF EXISTS LC2Oracle23Ctemp;
drop table IF EXISTS LC2Oracle23C_datatemp;
drop table IF EXISTS LC2Oracle23C_worktemp;
drop table IF EXISTS LC2Oracle23C_proc;
drop table IF EXISTS LC2Oracle23C_tests;
drop table IF EXISTS LC2Oracle23C_proctemp;
---------------------------------------------------------------
select '<span>Creating tables</span>';
---------------------------------------------------------------
CREATE TABLE LC2Oracle23C( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,  "url" TEXT NULL);
CREATE TABLE LC2Oracle23C_main( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE LC2Oracle23C_install( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE LC2Oracle23C_help( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE LC2Oracle23C_data( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE LC2Oracle23C_work( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE LC2Oracle23C_proc( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE LC2Oracle23C_tests( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE LC2Oracle23C_procdata( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE IF NOT EXISTS LC2Oracle23Ctemp ("name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "url" TEXT NULL);
CREATE TABLE IF NOT EXISTS LC2Oracle23C_proctemp( "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "url" TEXT NULL);
---------------------------------------------------------------
-- import menu
select '<span>start import to plugin tables</span>';
---------------------------------------------------------------
.separator ";"
--.import .\\resources\\plugins\\LC2Oracle23C\\import\\import.csv LC2Oracle23Ctemp
-- INSERT INTO LC2Oracle23C(first_name,name,zipcode, city, description) select first_name,name,zipcode, city, description  from LC2Oracle23Ctemp;
.import .\\resources\\plugins\\LC2Oracle23C\\import\\import.csv LC2Oracle23C
.import .\\resources\\plugins\\LC2Oracle23C\\import\\main.csv LC2Oracle23C_main
.import .\\resources\\plugins\\LC2Oracle23C\\import\\install.csv LC2Oracle23C_install
.import .\\resources\\plugins\\LC2Oracle23C\\import\\help.csv LC2Oracle23C_help
.import .\\resources\\plugins\\LC2Oracle23C\\import\\data.csv LC2Oracle23C_data
.import .\\resources\\plugins\\LC2Oracle23C\\import\\work.csv LC2Oracle23C_work
.import .\\resources\\plugins\\LC2Oracle23C\\import\\tests.csv LC2Oracle23C_tests
---------------------------------------------------------------
-- import procs
select '<span>importing processes</span>';
---------------------------------------------------------------
.separator ","
.import '.\\resources\\plugins\\LC2Oracle23C\\import\\proc.csv' LC2Oracle23C_proctemp
select 'LC2Oracle23C_proctemp count:';
select count(*) from LC2Oracle23C_proctemp;
.separator ";"
INSERT INTO LC2Oracle23C_proc(first_name,name,zipcode, description,url) select first_name,name,zipcode, description,url  from LC2Oracle23C_proctemp;
select 'LC2Oracle23C_proc count:';
select count(*) from LC2Oracle23C_proc;
-- eof insert work data
-- eof insert work data
---------------------------------------------------------------
-- done
select '<span>import done</span>';
---------------------------------------------------------------
select 'LC2Oracle23C count:';
select count(*) from LC2Oracle23C;
select '<p>start data import to plugin tables</p>';
-- delete from LC2Oracle23C_datatemp;
--
select '<p>LC2Oracle23C count:';
select count(*) from LC2Oracle23C;
select 'LC2Oracle23C_data count:';
select count(*) from LC2Oracle23C_data;
select 'LC2Oracle23C_procdata count:';
select count(*) from LC2Oracle23C_procdata;
select 'LC2Oracle23C_work count:';
select count(*) from LC2Oracle23C_work;
select 'LC2Oracle23C_proc count:';
select count(*) from LC2Oracle23C_proc;
select 'LC2Oracle23C_proctemp count:';
select count(*) from LC2Oracle23C_proctemp;

drop table IF EXISTS LC2Oracle23Ctemp;
-- drop table IF EXISTS LC2Oracle23C_proctemp;
-- select '<p>Import done</p>';
select '<h4>Import LC2Oracle23C processes done.</h4>';
.exit