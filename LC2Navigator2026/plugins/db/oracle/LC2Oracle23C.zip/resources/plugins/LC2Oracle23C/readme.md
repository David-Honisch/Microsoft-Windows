<h1>LC2CRC32</h1>

<h2>LC2CRC32 Plugin v.1.0</h2>

## Source:
https://letztechance.org
<a href="https://www.letztechance.org/">LetzteChance.Org</a>
<a href="https://www.letztechance.org/vue/">LetzteChance.Org v.2.0 Alpha (powered by VUE)</a>


## Windows 64 Bit Installer:

LC2Navigator 2022:
https://raw.githubusercontent.com/David-Honisch/Microsoft-Windows/master/LC2Navigator2022/LC2Navigator2022install.exe


LC2Navigator 2021:
https://raw.githubusercontent.com/David-Honisch/Microsoft-Windows/master/LC2Navigator2020/LC2Navigator2020install.exe
Permanent Link:
https://www.letztechance.org/read-20-35.html

## Linux 64 Bit Installer:
(coming soon)
https://www.letztechance.org/read-20-40.html

## Logo:
<img src="https://www.letztechance.org/assets/img/logo-big.svg" alt="logo" />


## What is "LC2CRC32" app?

it is a small application to verify files

It�s a part of LC2Navigator2022 living as a plugin but it is independent usable

It�s a native Webapplication based on NodeJS/Electron Javascript and SQLite.
Different technologies used like electron, nodejs, sql, sqlite, html5, jquery and many more...

I�ve build an windows artifact and windows installer only in 64 Bit. 
32 Bit is not supported.

There are different "Plugins" with a different technology stack.

## Plugins (LC2Navigator 2021/LC2Navigator 2022 compatible)

- 1;Install SQLITE v.1.0(sqlite3win.zip) and required scripts
- 2;Core Plugins v.1.0 
- 3;All Plugins (Alle Plugins) v.1.0
- 4;apache-maven.zip
- 5;apache-ant.zip;
- 6;lc2linkcli.zip
- 7;excelimport.zip
- 8;lc2irc
- 9;graburls
- 10;LC2RotatingTorproxy
- 11;lc2process (only Navigator 2022)
- 12;org.letztechance.domain.web.GrabUrls
- 13;lc2php
- 14;lc2mysqldocker - Mysql Docker Container (only Navigator 2022)
- 15;LC2Python
- 16;postgresdocker - Postgres Docker Container (only Navigator 2022)
- 17;LC2bat2exe
- 18;LC2DockerSonarCube - Sonarcube Docker Container
- 19;LC2DockerJenkins - Jenkins Docker Container
- 20;LC2DockerPHPMyAdmin - PHPMyAdmin Mysql Docker Container
- 21;LC2J-Lawyer
- 22;LC2HTTPAnalysis
- 23;LC2Grafana - Grafana Docker Container
- 24;LC2ELK - Docker Container
- 25;LC2Kubernetes - Demo Kubernetes Cluster
- 26;LC2RegistryWizard - Some nice and small Registry Scripts
- 27;LC2ApacheDS - Apache Directory Docker
- 28;LC2Games - Some small games
- 29;LC2Java.Starter.v.1.0 - A small project management system made with Quarkus /Postgres (Docker)
- 30;LC2Matplotlib.zip - Python MathplotLib rendering on QT
- 31;LC2XMLFileBackup.zip A nice small powershell to Backup files based on XML
- 32;LC2MongoDB.zip MongoDB Dockeer Container
- 32;LC2Kong.zip Kong Community Edition Dockeer Container
- 33;LC2OracleDB.zip Oracle 19c Express Edition Dockeer Container
- 34;LC2AysncPing.zip - A Little C# Executable that pings a server async
- 35;LC2FileEnDeCypter.zip - A Little C# Executable that pings a server async (only Navigator 2022)
- 35;LC2FileEnDeCypter.zip - A Little C# Executable that pings a server async (only Navigator 2022)

more in progress...

# Deprecated or unsupported Plugins

- SQLIte and NPM AutoInstall Packages 
	- Required. Please always update this package
- Core 
	- SQLITE Import, Export, CRUD and more...
- LC2Process 
	- Show and kill system processes
- LC2Redirect 
	- Redirect Output
- LC2Zip 
	- .NET Core
- LC2Zip 
	- ZIP Java Java Installer (SWT)
- LC2UnZip 
	- Unzip .NET Core
- LC2UnZip 
	- LC2UnZip Java Java Installer (SWT)
- LC2DL 
	- LetzteChance.Org offizieller Downloader
- LC2Start.NET 
	- LetzteChance.Org offizieller Windows .NET 4.72 Installer
- LC2SQLIITEGUI 
	- LetzteChance.Org offizieller LC2SQLIITEGUI
- LC2RESTIFY 
	- LC2RESTIFY
- LC2SOAP 
	- LC2SOAP
- LC2ExcelTransform 
	- Up to now there is Supports xls|xlsx|xlsm|xlsb|xml|csv|txt|dif|sylk|slk|prn|ods|fods|htm|html based Editor and Converter
- LC2SAPUI
	- - SAP.UI Electron Webpack Project (Routing JSON and query based fragments and models)
- LC2Docker 
	- Some fist scripts (updates coming soon.
- LC2FTP 
	- FTP Client based on HMTL/NodeJS
- LC2EXPRESS 
	- HTTP NPM HTTPSERVER
- LC2UnityServer 
	- LC2UnityServer
- LC2UnityServerClient 
	- LC2UnityServerClient Chromium Client 
- LC2Color 
	- .NET v.4.7.2
- LC2Color 
	- .NET Core v.3.1
- LC2Python 
	- LC2Python (Python 3 Scripts)
- LC2PHP 
	- LC2PHP (PHP Installation required)
- LC2FFMPEG 
	- LC2FFMPEG
- LC2PAINT 
- LC2PAINT - Simple 3D Painter with small animations
- LC2MySQLDocker 
	- LC2MySQLDocker - Docker MySQL Server to host tcp port 3306
- LC2PostGresSQL 
	- LC2MySQLDocker - Docker Postgres Server to host tcp port
- LC2SQLServer 
	- LC2SQLServer - Docker MySQL to host tcp port	
- LC2RotatingTorproxy 
	- LC2RotatingTorproxy - Docker LC2RotatingTorproxy ha proxy with rotating tor proxy list nodes
- LC2Python
	- LC2Python - Docker LC2Python some python scripts

- see plugin itslelf for more information
	
	
- see all plugins download
<a href="https://raw.githubusercontent.com/David-Honisch/Microsoft-Windows/master/LC2Navigator2020/plugins/all.zip">All active Plugins</a>
<a href="https://raw.githubusercontent.com/David-Honisch/Microsoft-Windows/master/LC2Navigator2020/LC2Navigator2020install.exe">Installer</a>
<a href="https://www.letztechance.org/">LetzteChance.Org</a>
<a href="https://www.letztechance.org/vue/">LetzteChance.Org v.2.0 Alpha (powered by VUE)</a>


 
Example Screenshot of LC2ExcelTransform:
- LC2ExcelTransform 
	- Up to now there is Supports xls|xlsx|xlsm|xlsb|xml|csv|txt|dif|sylk|slk|prn|ods|fods|htm|html based Editor and Converter
<img src="https://raw.githubusercontent.com/David-Honisch/Microsoft-Windows/master/LC2Navigator2022/LC2ExcelTransform.png" alt="LC2ExcelTransform Exampel Screenshot" width="400" />


##Basic Requirements

Windows 64
Mac IOS
Linux

Note:curently only windows x64 builds available. 32 Bit Electron build is not longer supported


## Plugin Software Requirements (no autoinstall !!)

Python 3
JDK 8<

Note:curently only windows x64 builds available. 32 Bit Electron build is not longer supported

## Download Installer (Microsoft Windows x64):

<a href="https://raw.githubusercontent.com/David-Honisch/Microsoft-Windows/master/LC2Navigator2020/LC2Navigator2020install.exe">Installer</a>

## HomePage - Download Installer (Microsoft Windows x64):

https://www.letztechance.org/read-20-35.html

## Plugin requirements
- JDK 8<
- Docker Desktop
- Python 3x
- PHP 7.x
- CURL
- Maven
- Ant
- MsBuild
- ...
- It may be various. Please, read the notes of the plugin or any development comments

## Supported os

<img width="30" alt="windows" src="app-resources/readme/windows.svg?sanitize=true" />
<img width="30" alt="mac" src="app-resources/readme/mac.svg?sanitize=true" />
<img width="30" alt="linux" src="app-resources/readme/linux.svg?sanitize=true" />

## Download

- Free ?? yes
- No ads ?? yes

Find your download: [https://github.com/David-Honisch/Microsoft-Windows/tree/master/LC2Navigator2020](https://github.com/David-Honisch/Microsoft-Windows/tree/master/LC2Navigator2020)

## Change log

##### 1.1.0
Allow fetch and download a single video

##### 1.0.0
Fetch videos from youtube playlist and download them one by one or all.

## Disclaimer

1. Please use this app for downloading only public resources.
2. The app doesn't store ANY media files ANYWHERE except on the device who use this app.

<div>
  Icons made by <a href="https://www.flaticon.com/authors/pixel-perfect" title="Pixel perfect">Pixel perfect</a> from <a href="https://www.flaticon.com/" title="Flaticon">www.flaticon.com</a> is licensed by <a href="http://creativecommons.org/licenses/by/3.0/" title="Creative Commons BY 3.0" target="_blank">CC 3.0 BY</a>
</div>

## Development
	
- Not open source
- No comments

Just using electron.


## Development Notes

You can find scripts on this repository to solve following package.json entries:
    npm run tlint
	npm run webpack	
    npm run electron
	npm run test
	npm run build
	npm run buildwindows
	npm run buildmacos
	npm run buildlinux


### Stack

- [electron](http://electronjs.org/)
- [jquery](https://jquery.org/)
- [sqlite](https://sqlite.org/)
- [java](https://java.org/)
- [spring boot](https://spring.io/)
- [typescript](https://www.typescriptlang.org/)
- [webpack](https://webpack.js.org/)

#### Tests

- TODO
more plugins coming soon.. P-)
[emed java directly](https://github.com/jreznot/electron-java-app)
[jest](https://jestjs.io/)

#### Libraries

- Electron
- NodeJS
- SQL.js
- SQLITE
- HTML5
- JQuery

- Angular 10
- ReactJS
- SAP.UI
- Phaser IO

- .NET CORE 3<
- ASP .NET CORE 
- .NET CORE EF
- .NET CORE NHIBERNATE
- JSF
- ASF
- Vadim

- Jenkins
- Grafana
- ELK (Elastic Search Kibanan ...)
- Kong


- Spring Boot
- Spring MVC
- Spring Rest
- Hibernate

see plugins...

### TODO

?? Okay, there a lot of tasks todo....

### Plugins
LC2ImportExcelTransform v.1.01a
<img src="excelimportexport.jpg" alt="logo" />

 Description
Oracle Database XE Release 21c (21.3.0.0) Docker Image Documentation

Oracle Database XE Release 21c is the developer edition of the industry-leading relational database server. The Oracle XE Database server Docker image contains Oracle Database Express Edition Release 21c (21.3.0.0) running on Oracle Linux 7. This image contains a default database in a multitenant configuration with one pluggable database. For more information on Oracle Database server Release 21c, see:

http://docs.oracle.com/en/database/
Using This Image
Starting an Oracle Database Server Instance

The Oracle XE Database 21c server Docker image contains a pre-built database, so the startup time is very fast. Fast startup can be helpful in CI/CD scenarios. To start an Oracle Database server instance, run the following command where,<oracle-db> is the name of the container:

  $ docker run -d --name <oracle-db>
  container-registry.oracle.com/database/express:21.3.0-xe

When the container is started, a random password is used for the SYS, SYSTEM and PDBADMIN users. This is termed as the default password.
Note:

    Throughout this document, words enclosed within angle brackets < > indicate variables in code lines.
    To change the default password, see: "Changing the Default Password for SYS User"
    To learn about advanced use cases, see: "Custom Configurations"

The Oracle Database server is ready to use when the STATUS field shows (healthy) in the docker ps output.
Custom Configurations

To facilitate custom configurations, the Oracle Database server container provides configuration parameters that you can use when starting the container. For example, this is the detailed docker run command supporting all custom configurations:

docker run --name <container name> \
-p <host port>:1521 -p <host port>:5500 \
-e ORACLE_PWD=<your database passwords> \
-e ORACLE_CHARACTERSET=<your character set> \
-v [<host mount point>:]/opt/oracle/oradata \
container-registry.oracle.com/database/express:21.3.0-xe

Parameters:
   --name:        The name of the container (default: auto generated)
   -p:            The port mapping of the host port to the container port.
                  Two ports are exposed: 1521 (Oracle Listener), 5500 (EM Express)
   -e ORACLE_PWD: The Oracle Database SYS, SYSTEM and PDB_ADMIN password (default: auto generated)
   -e ORACLE_CHARACTERSET: 
                  The character set to use when creating the database (default: AL32UTF8)
   -v /opt/oracle/oradata
                  The data volume to use for the database.
                  Has to be writable by the Unix "oracle" (uid: 54321) user inside the container!
                  If omitted the database will not be persisted over container recreation.
   -v /opt/oracle/scripts/startup | /docker-entrypoint-initdb.d/startup
                  Optional: A volume with custom scripts to be run after database startup.
                  For further details see the "Running scripts after setup and on startup" section below.
   -v /opt/oracle/scripts/setup | /docker-entrypoint-initdb.d/setup
                  Optional: A volume with custom scripts to be run after database setup.
                  For further details see the "Running scripts after setup and on startup" section below.

The supported configuration options are:

    ORACLE_PWD: This parameter modifies the password for the SYS, SYSTEM and PDBADMIN users. This parameter is optional, and the default value is randomly generated. Note: If you use this option, then the password will be visible as a container environment variable, and cannot be changed later on.
    ORACLE_CHARACTERSET: This parameter modifies the character set of the database. This parameter is optional, and the default value is set to AL32UTF8. Please Note that, this parameter will set the character set only when a new database is created i.e. a host system directory is mounted using -v option while running the image (Please refer to Mounting Docker volume/host directory for database persistence section).
    Podman Secret Support: This option is supported only when the Podman runtime is being used to run the Oracle Database 21c XE container image. Secret is a utility to pass secure strings of text to the container, such as ssh-keys, or passwords. To specify the password for SYS, SYSTEM and PDBADMIN users securely, create a secret named oracle_pwd. The command is as follows:

echo "<Your Password>" | podman secret create oracle_pwd -

After you create the secret, you open the container securely by using the following command:

podman run --name=<container_name> --secret=oracle_pwd container-registry.oracle.com/database/express:21.3.0-xe

    Mounting Docker volume/host directory for database persistence: To obtain database persistence, either a named Docker volume or a host system directory can be mounted at the location /opt/oracle/oradata inside the container. The difference between these two options are as follows:

        If a Docker volume is mounted on the /opt/oracle/oradata location, then the volume is prepopulated with the data files already present in the image. In this case, the startup will be very fast, similar to starting the image without mount. These data files exist in the image to enable quick startup of the database. To use a Docker volume for the data volume, run the following:

        $ docker run -d --name <oracle-db> -v
        <OracleDBData>:/opt/oracle/oradata
        container-registry.oracle.com/database/express:21.3.0-xe

        If a host system directory is mounted on the /opt/oracle/oradata location, then the data files already present at this location will be overwritten, and a new database setup will begin. It takes a significant amount of time (approximately 15 minutes) to set up a fresh database. To use a directory on the host system for the data volume, run the following:

        $ docker run -d --name <oracle-db> -v
        <writable_directory_path>:/opt/oracle/oradata
        container-registry.oracle.com/database/express:21.3.0-xe

Changing the Default Password for SYS User

On the first startup of the container, a random password is generated for the database if a password is not provided by using the -e option, as described in the "Custom Configurations" section.

To change the password for these accounts, use the docker exec command, to run the setPassword.sh script that is found in the container. Note that the container must be running before you run the script.

For example:

  $ docker exec <oracle-db> ./setPassword.sh <your_password>

Database Alert Logs

You can access the database alert log by using the following command, where <oracle-db> is the name of the container:

  $ docker logs <oracle-db>

Oracle Enterprise Manager Express

The Oracle XE Database inside the container also has Oracle Enterprise Manager (OEM) Express configured. To access OEM Express, start your browser, and enter the OEM URL: https://localhost:5500/em/
Connecting to the Oracle XE Database Server Container

After the Oracle Database server indicates that the container has started, and the STATUS field shows (healthy), client applications can connect to the database.
Connecting from Within the Container

You can connect to the Oracle Database server by running a SQL*Plus command from within the container using one of the following commands:

  $ docker exec -it <oracle-db> sqlplus / as sysdba
  $ docker exec -it <oracle-db> sqlplus sys/<your_password>@XE as sysdba
  $ docker exec -it <oracle-db> sqlplus system/<your_password>@XE
  $ docker exec -it <oracle-db> sqlplus pdbadmin/<your_password>@XEPDB1

Connecting from Outside the Container

By default, Oracle Database exposes port 1521 for Oracle client connections, using Oracle's SQL*Net protocol. SQL*Plus or any Oracle Java Database Connectivity (JDBC) client can be used to connect to the database server from outside of the container.

To connect from outside of the container, start the container with the -p option, as described in the detailed Docker run command in the "Custom Configurations" section.

Discover the mapped port by running the following command:

  $ docker port <oracle-db>

To connect from outside of the container using SQL*Plus, run the following commands:

# To connect to the database at the CDB$ROOT level as sysdba:
  $ sqlplus sys/<your password>@//localhost:1521/XE as sysdba

# To connect as non sysdba at the CDB$ROOT level:
  $ sqlplus system/<your password>@//localhost:1521/XE

# To connect to the default Pluggable Database (PDB) within the XE Database:
  $ sqlplus pdbadmin/<your password>@//localhost:1521/XEPDB1

Reusing the Existing Database

If the database is started using a host system directory mounted at an /opt/oracle/oradata location inside the container, as explained in the Custom Configuration section under ""Mounting Docker volume/host directory for database persistence", then the data files remain persistent even after the container is destroyed. Another container with the same data files can be started by reusing the host system directory.

To reuse this directory on the host system for the data volume, run the following commands:

  $ docker run -d --name <oracle-db> -v
  <writable_host_directory_path>:/opt/oracle/oradata
  container-registry.oracle.com/database/express:21.3.0-xe

Running Scripts After Setup and On Startup

The Docker images can be configured to run scripts after setup and on startup. Currently, .sh and .sql extensions are supported. For post-setup scripts, mount the volume /opt/oracle/scripts/setup to include scripts in this directory. For post-startup scripts, mount the volume /opt/oracle/scripts/startup to include scripts in this directory. Both of these locations are also represented by the symbolic link /docker-entrypoint-initdb.d. This configuration provides synergy with other database Docker images. You can decide whether to put the setup and startup scripts under /opt/oracle/scripts, or under /docker-entrypoint-initdb.d.

After the database is set up or started, the scripts in those folders are run against the database in the container. SQL scripts are run as SYSDBA, and shell scripts are run as the current user. To ensure proper order for running scripts, Oracle recommends that you prefix your scripts with a number. For example: 01_users.sql, 02_permissions.sql, and so on.

Note: The startup scripts are run after the first time that the database setup is complete.

The following example mounts the local directory /home/oracle/myScripts to /opt/oracle/scripts/startup, which is then searched for custom startup scripts:

  $ docker run -d --name <oracle-db> -v
  /home/oracle/myScripts:/opt/oracle/scripts/startup
  container-registry.oracle.com/database/express:21.3.0-xe

## License
MIT
(c)by webmaster@letztechance.org
--------------------------
http://www.letztechance.org
Haftung f�r Inhalte 

Die Inhalte unserer Seiten wurden mit gr��ter Sorgfalt erstellt. F�r die Richtigkeit, Vollst�ndigkeit und 
Aktualit�t der Inhalte k�nnen wir jedoch keine Gew�hr �bernehmen. Als Diensteanbieter sind wir gem�� 
� 7 Abs.1 TMG f�r eigene Inhalte auf diesen Seiten nach den allgemeinen Gesetzen verantwortlich. 
Nach �� 8 bis 10 TMG sind wir als Diensteanbieter jedoch nicht verpflichtet, �bermittelte oder gespeicherte 
fremde Informationen zu �berwachen oder nach Umst�nden zu forschen, die auf eine rechtswidrige 
T�tigkeit hinweisen. 
Verpflichtungen zur Entfernung oder Sperrung der Nutzung von Informationen nach den allgemeinen 
Gesetzen bleiben hiervon unber�hrt. Eine diesbez�gliche Haftung ist jedoch erst ab dem Zeitpunkt 
der Kenntnis einer konkreten Rechtsverletzung m�glich. Bei Bekanntwerden von entsprechenden 
Rechtsverletzungen werden wir diese Inhalte umgehend entfernen. 

Haftung f�r Links 

Unser Angebot enth�lt Links zu externen Webseiten Dritter, auf deren Inhalte wir keinen Einfluss haben. 
Deshalb k�nnen wir f�r diese fremden Inhalte auch keine Gew�hr �bernehmen. F�r die Inhalte der 
verlinkten Seiten ist stets der jeweilige Anbieter oder Betreiber der Seiten verantwortlich. 
Die verlinkten Seiten wurden zum Zeitpunkt der Verlinkung auf m�gliche Rechtsverst��e �berpr�ft. 
Rechtswidrige Inhalte waren zum Zeitpunkt der Verlinkung nicht erkennbar. 
Eine permanente inhaltliche Kontrolle der verlinkten Seiten ist jedoch ohne konkrete Anhaltspunkte einer 
Rechtsverletzung nicht zumutbar. Bei Bekanntwerden von Rechtsverletzungen werden wir derartige Links 
umgehend entfernen. 

Urheberrecht 

Die durch die Seitenbetreiber erstellten Inhalte und Werke auf diesen Seiten unterliegen dem 
deutschen Urheberrecht. 
Die Vervielf�ltigung, Bearbeitung, Verbreitung und jede Art der Verwertung au�erhalb der Grenzen 
des Urheberrechtes bed�rfen der schriftlichen Zustimmung des jeweiligen Autors bzw. Erstellers. 
Downloads und Kopien dieser Seite sind nur f�r den privaten, nicht kommerziellen Gebrauch gestattet. 
Soweit die Inhalte auf dieser Seite nicht vom Betreiber erstellt wurden, werden die Urheberrechte Dritter 
beachtet. Insbesondere werden Inhalte Dritter als solche gekennzeichnet. Sollten Sie trotzdem auf eine 
Urheberrechtsverletzung aufmerksam werden, bitten wir um einen entsprechenden Hinweis. 
Bei Bekanntwerden von Rechtsverletzungen werden wir derartige Inhalte umgehend entfernen. 

Datenschutz 

Die Nutzung unserer Webseite ist in der Regel ohne Angabe personenbezogener Daten m�glich. 
Soweit auf unseren Seiten personenbezogene Daten (beispielsweise Name, Anschrift oder eMail-Adressen) 
erhoben werden, erfolgt dies, soweit m�glich, stets auf freiwilliger Basis. Diese Daten werden ohne Ihre 
ausdr�ckliche Zustimmung nicht an Dritte weitergegeben. 

Wir weisen darauf hin, dass die Daten�bertragung im Internet (z.B. bei der Kommunikation per E-Mail) 
Sicherheitsl�cken aufweisen kann. Ein l�ckenloser Schutz der Daten vor dem Zugriff durch Dritte ist nicht m�glich. 

Der Nutzung von im Rahmen der Impressumspflicht ver�ffentlichten Kontaktdaten durch Dritte zur �bersendung von 
nicht ausdr�cklich angeforderter Werbung und Informationsmaterialien wird hiermit ausdr�cklich widersprochen. 
Die Betreiber der Seiten behalten sich ausdr�cklich rechtliche Schritte im Falle der unverlangten Zusendung 
von Werbeinformationen, etwa durch Spam-Mails, vor. 

Datenschutzerkl�rung f�r die Nutzung von Facebook-Plugins (Like-Button) 

Auf unseren Seiten sind Plugins des sozialen Netzwerks 
Facebook, 1601 South California Avenue, Palo Alto, CA 94304, USA integriert. 
Die Facebook-Plugins erkennen Sie an dem Facebook-Logo oder dem "Like-Button" ("Gef�llt mir") auf unserer Seite. 
Eine �bersicht �ber die Facebook-Plugins finden Sie hier: http://developers.facebook.com/docs/plugins/. 
Wenn Sie unsere Seiten besuchen, wird �ber das Plugin eine direkte Verbindung zwischen Ihrem Browser und 
dem Facebook-Server hergestellt. Facebook erh�lt dadurch die Information, dass Sie mit Ihrer IP-Adresse unsere Seite 
besucht haben. Wenn Sie den Facebook "Like-Button" anklicken w�hrend Sie in Ihrem Facebook-Account eingeloggt sind, 
k�nnen Sie die Inhalte unserer Seiten auf Ihrem Facebook-Profil verlinken. 
Dadurch kann Facebook den Besuch unserer Seiten Ihrem Benutzerkonto zuordnen. Wir weisen darauf hin, dass wir 
als Anbieter der Seiten keine Kenntnis vom Inhalt der �bermittelten Daten sowie deren Nutzung durch Facebook erhalten. 
Weitere Informationen hierzu finden Sie in der Datenschutzerkl�rung von facebook unter http://de-de.facebook.com/policy.php 

Wenn Sie nicht w�nschen, dass Facebook den Besuch unserer Seiten Ihrem Facebook-Nutzerkonto zuordnen kann, 
loggen Sie sich bitte aus Ihrem Facebook-Benutzerkonto aus. 

Datenschutzerkl�rung f�r die Nutzung von Google Analytics 

Diese Website benutzt Google Analytics, einen Webanalysedienst der Google Inc. ("Google"). 
Google Analytics verwendet sog. "Cookies", Textdateien, die auf Ihrem Computer gespeichert werden und die eine Analyse 
der Benutzung der Website durch Sie erm�glichen. 
Die durch den Cookie erzeugten Informationen �ber Ihre Benutzung dieser Website werden in der Regel an einen Server von 
Google in den USA �bertragen und dort gespeichert. Im Falle der Aktivierung der IP-Anonymisierung auf dieser Webseite wird 
Ihre IP-Adresse von Google jedoch innerhalb von Mitgliedstaaten der Europ�ischen Union oder in anderen Vertragsstaaten 
des Abkommens �ber den Europ�ischen Wirtschaftsraum zuvor gek�rzt. 

Nur in Ausnahmef�llen wird die volle IP-Adresse an einen Server von Google in den USA �bertragen und dort gek�rzt. 
Im Auftrag des Betreibers dieser Website wird Google diese Informationen benutzen, um Ihre Nutzung der Website auszuwerten, 
um Reports �ber die Websiteaktivit�ten zusammenzustellen und um weitere mit der Websitenutzung und der Internetnutzung 
verbundene Dienstleistungen gegen�ber dem Websitebetreiber zu erbringen. Die im Rahmen von Google Analytics 
von Ihrem Browser �bermittelte IP-Adresse wird nicht mit anderen Daten von Google zusammengef�hrt. 

Sie k�nnen die Speicherung der Cookies durch eine entsprechende Einstellung Ihrer Browser-Software verhindern; 
wir weisen Sie jedoch darauf hin, dass Sie in diesem Fall gegebenenfalls nicht s�mtliche Funktionen dieser Website vollumf�nglich 
werden nutzen k�nnen. Sie k�nnen dar�ber hinaus die Erfassung der durch das Cookie erzeugten und auf Ihre Nutzung der Website 
bezogenen Daten (inkl. Ihrer IP-Adresse) an Google sowie die Verarbeitung dieser Daten durch Google verhindern, indem sie 
das unter dem folgenden Link verf�gbare Browser-Plugin herunterladen und installieren: 
http://tools.google.com/dlpage/gaoptout?hl=de. 

Datenschutzerkl�rung f�r die Nutzung von Google Adsense 

Diese Website benutzt Google AdSense, einen Dienst zum Einbinden von Werbeanzeigen der Google Inc. ("Google"). 
Google AdSense verwendet sog. "Cookies", Textdateien, die auf Ihrem Computer gespeichert werden und die eine Analyse der Benutzung 
der Website erm�glicht. Google AdSense verwendet auch so genannte Web Beacons (unsichtbare Grafiken). Durch diese Web Beacons 
k�nnen Informationen wie der Besucherverkehr auf diesen Seiten ausgewertet werden. 

Die durch Cookies und Web Beacons erzeugten Informationen �ber die Benutzung dieser Website (einschlie�lich Ihrer IP-Adresse) und 
Auslieferung von Werbeformaten werden an einen Server von Google in den USA �bertragen und dort gespeichert. Diese Informationen 
k�nnen von Google an Vertragspartner von Google weiter gegeben werden. Google wird Ihre IP-Adresse jedoch nicht mit anderen von 
Ihnen gespeicherten Daten zusammenf�hren. 

Sie k�nnen die Installation der Cookies durch eine entsprechende Einstellung Ihrer Browser Software verhindern; wir weisen Sie jedoch 
darauf hin, dass Sie in diesem Fall gegebenenfalls nicht s�mtliche Funktionen dieser Website voll umf�nglich nutzen k�nnen. 
Durch die Nutzung dieser Website erkl�ren Sie sich mit der Bearbeitung der �ber Sie erhobenen 
Daten durch Google in der zuvor beschriebenen Art und Weise und zu dem zuvor benannten Zweck einverstanden. 

Datenschutzerkl�rung f�r die Nutzung von Google 1 

Erfassung und Weitergabe von Informationen: 
Mithilfe der Google 1-Schaltfl�che k�nnen Sie Informationen weltweit ver�ffentlichen. �ber die Google 1-Schaltfl�che 
erhalten Sie und andere Nutzer personalisierte Inhalte von Google und unseren Partnern. Google speichert sowohl die 
Information, dass Sie f�r einen Inhalt 1 gegeben haben, als auch Informationen �ber die Seite, die Sie beim Klicken 
auf 1 angesehen haben. Ihre 1 k�nnen als Hinweise zusammen mit Ihrem Profilnamen und Ihrem Foto in 
Google-Diensten, wie etwa in Suchergebnissen oder in Ihrem Google-Profil, oder an anderen Stellen 
auf Websites und Anzeigen im Internet eingeblendet werden. 
Google zeichnet Informationen �ber Ihre 1-Aktivit�ten auf, um die Google-Dienste f�r Sie und andere zu verbessern. 
Um die Google 1-Schaltfl�che verwenden zu k�nnen, ben�tigen Sie ein weltweit sichtbares, 
�ffentliches Google-Profil, das zumindest den f�r das Profil gew�hlten Namen enthalten muss. 
Dieser Name wird in allen Google-Diensten verwendet. In manchen F�llen kann dieser Name auch einen 
anderen Namen ersetzen, den Sie beim Teilen von Inhalten �ber Ihr Google-Konto verwendet haben. 
Die Identit�t Ihres Google-Profils kann Nutzern angezeigt werden, die Ihre E-Mail-Adresse kennen oder 
�ber andere identifizierende Informationen von Ihnen verf�gen. 

Verwendung der erfassten Informationen: 
Neben den oben erl�uterten Verwendungszwecken werden die von Ihnen bereitgestellten Informationen 
gem�� den geltenden Google-Datenschutzbestimmungen genutzt. Google ver�ffentlicht m�glicherweise 
zusammengefasste Statistiken �ber die 1-Aktivit�ten der Nutzer bzw. gibt diese an Nutzer und Partner weiter, 
wie etwa Publisher, Inserenten oder verbundene Websites. 

Datenschutzerkl�rung f�r die Nutzung von Twitter 

Auf unseren Seiten sind Funktionen des Dienstes Twitter eingebunden. Diese Funktionen werden 
angeboten durch die Twitter Inc., 795 Folsom St., Suite 600, San Francisco, CA 94107, USA. 
Durch das Benutzen von Twitter und der Funktion "Re-Tweet" werden die von Ihnen besuchten Webseiten 
mit Ihrem Twitter-Account verkn�pft und anderen Nutzern bekannt gegeben. Dabei werden auch Daten an Twitter �bertragen. 

Wir weisen darauf hin, dass wir als Anbieter der Seiten keine Kenntnis vom Inhalt der �bermittelten Daten sowie deren Nutzung 
durch Twitter erhalten. Weitere Informationen hierzu finden Sie in der Datenschutzerkl�rung von Twitter unter http://twitter.com/privacy. 

Ihre Datenschutzeinstellungen bei Twitter k�nnen Sie in den Konto-Einstellungen unter http://twitter.com/account/settings �ndern. 

Quellenangaben: eRecht24 Disclaimer, Facebook Datenschutzerkl�rung, Google Analytics Bedingungen, 
Datenschutzerkl�rung f�r Google Adsense, Datenschutzerkl�rung Google 1, Datenschutzerkl�rung f�r Twitter 

Kontakt: 

https://www.letztechance.org/contact.html