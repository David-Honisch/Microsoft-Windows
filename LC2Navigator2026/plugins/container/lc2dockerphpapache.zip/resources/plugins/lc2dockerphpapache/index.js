function pluginINIT(pName) {
    const APPCFG = "application.config.json";
    try {
        var arg = getPluginArguments();
        console.log(arg);
        //
        var cfg = getAppConfig(APPCFG);
        // var dlPath = cfg.api.baseurl;
		var dlPath = cfg.resources.homeurldir;
        var resDir = path.join(__dirname, '../../');
        var localFileName = resDir + pName + "-news.json";        
        get_Download_File(dlPath, cfg.resources.sqlite, cfg.resources.sqlite, resDir, pName);
        get_Download_File(dlPath, cfg.resources.sqlitexslt, cfg.resources.sqlitexslt, resDir, pName);

        //
        // execCMD("call tasklist /FO CSV /FI \"STATUS eq running\" /NH> .\\resources\\plugins\\" + pluginName + "\\import\\work.csv", "pnavmenu", true, false);
        // execCMD("call tasklist /FO CSV /FI \"STATUS eq running\" /NH> .\\resources\\plugins\\" + pluginName + "\\import\\proc.csv", "pnavmenu", true, false);
        //execCMD("call tasklist /FO CSV /NH> .\\resources\\plugins\\" + pluginName + "\\import\\work.csv", "pnavmenu");
        //creating schema import
        execCMD("call  resources\\app\\sqlite\\SQLite3.exe \"resources\\" + pName + ".db\" \".read .\\\\resources\\\\plugins\\\\" + pName + "\\\\schema.sql\"", "pschema", true, false);        
        //eof schema import
        if (getConfirmation('Install requirements of ' + pName + ' now?')) { getOpenDialog('#dialog', '.\\resources\\plugins\\' + pName + '\\install.html', 'Install', { minWidth: 250, minHeight: 150, width: 400 }) };
        getXML(".\\resources\\plugins\\" + pName + "\\xml\\app.xml", ".\\resources\\plugins\\" + pName + "\\xml\\app.xslt", "pnav");
        execCMD("call resources\\cmd\\register_plugin.bat " + pName, "pregister", true, false);
        $('#' + pName + '').before(getPluginButtons(pName));
        $('#' + pName + '_main').append(getPluginButtons(pName));
        // console.log("reading tables...");
        // getExecPluginCMDList(".\\resources\\" + pName + ".db", pluginTable, '#' + pName + '', false);
        setTimeout(() => {
            try {

                // getXSLTTranformation(pluginName + '_info', localFileName, '<h1>TEST<h1><xsl:value-of select="/root" /><xsl:for-each select="root"><xsl:value-of select="subject" /><xsl:value-of select="body" /></xsl:for-each>');
                //
                console.log("reading tables...");
                getExecPluginCMDList(".\\resources\\" + pName + ".db", pluginTable, '#' + pName + '', false);
                execPluginCMDTableList(".\\resources\\" + pluginName + ".db", pluginTable + "_main", '#' + pluginName + '_main', false);
                execPluginCMDTableList(".\\resources\\" + pluginName + ".db", pluginTable + "_install", '#' + pluginName + '_install', false);
                execPluginCMDTableList(".\\resources\\" + pluginName + ".db", pluginTable + "_help", '#' + pluginName + '_help', false);
                
                execCMD("resources\\cmd\\checkrequirement.bat .\\resources\\plugins\\" + pluginName + "\\csv\\check.csv", "" + pluginName + "_install", true, false);
                
                execCMD("call  resources\\app\\sqlite\\SQLite3.exe  \"resources\\" + pluginName + ".db\" \"select * from " + pluginTable + "_work\">\"resources\\plugins\\" + pluginName + "\\csv\\" + pluginName + "_data.csv\"", "pout", true, false);
                
                execCMD("call  \"resources\\plugins\\" + pluginName + "\\resources\\work\\" + pluginName + ".bat\"", "pform", true, false);
                
                

                var res2 = getSQLQuery("select * from " + pluginTable + "_work", "resources\\" + pluginName + ".db");
                showResourceList(res2, pluginName,'', true);

                var res = getSQLQuery("select * from " + pluginTable + "_info", "resources\\" + pluginName + ".db");
                showResourceList(res, pluginName+'_info','', false);
                
                var procres = getSQLQuery("select * from " + pluginTable + "_proc", "resources\\" + pluginName + ".db");
                showResourceList(procres, pluginName+ '_main','', true);

                var testres = getSQLQuery("select * from " + pluginTable + "_tests", "resources\\" + pluginName + ".db");
                showResList(testres, pluginName+ '_tests','', false);

                // printDirectory('resources\\plugins\\' + pluginName + '\\', '' + pluginName + '_install', true);


                setDragOver('inputKeyFile', pluginName + 'result');
                setTimeout(() => {
                    // var out = document.getElementById('result');
                    // console.log(out !== undefined ? "Yes" : "NO !!!");
                    loadExcelResFile(pluginName + 'result', "inputKeyFile");
                }, 4000);

            } catch (error) {
                $("" + out).append("<p class=\"alert\">" + error + "<p>");
                console.error(error);
                console.error(error.stack);
            }
        }, 3000);
    } catch (e) {
        alert(e.stack);
    }
}