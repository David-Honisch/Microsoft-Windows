-- Adminer 4.8.1 MySQL 5.7.44 dump

SET NAMES utf8;
SET time_zone = '+00:00';
SET foreign_key_checks = 0;
SET sql_mode = 'NO_AUTO_VALUE_ON_ZERO';

DROP TABLE IF EXISTS `dbusers`;
CREATE TABLE `dbusers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `role` tinyint(4) NOT NULL,
  `isAdmin` int(1) NOT NULL,
  `u_id` varchar(20) COLLATE latin1_german1_ci NOT NULL,
  `ipaddress` varchar(16) COLLATE latin1_german1_ci DEFAULT NULL,
  `username` varchar(255) COLLATE latin1_german1_ci NOT NULL DEFAULT '',
  `password` varchar(60) COLLATE latin1_german1_ci NOT NULL DEFAULT '',
  `email` varchar(60) COLLATE latin1_german1_ci NOT NULL DEFAULT '',
  `first_name` varchar(50) COLLATE latin1_german1_ci DEFAULT NULL,
  `last_name` varchar(60) COLLATE latin1_german1_ci DEFAULT NULL,
  `phone` varchar(12) COLLATE latin1_german1_ci DEFAULT NULL,
  `fax` varchar(12) COLLATE latin1_german1_ci DEFAULT NULL,
  `alt_phone` varchar(12) COLLATE latin1_german1_ci DEFAULT NULL,
  `reg_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `last_active` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `user_level` smallint(1) NOT NULL DEFAULT '0',
  `notes` longtext COLLATE latin1_german1_ci,
  `admin_notes` longtext COLLATE latin1_german1_ci,
  `hash` varchar(50) COLLATE latin1_german1_ci NOT NULL,
  `deleted` int(11) NOT NULL,
  `enabled` int(11) NOT NULL,
  `confirmed` int(11) NOT NULL,
  `locked` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`),
  UNIQUE KEY `username` (`username`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_german1_ci;

INSERT INTO `dbusers` (`id`, `role`, `isAdmin`, `u_id`, `ipaddress`, `username`, `password`, `email`, `first_name`, `last_name`, `phone`, `fax`, `alt_phone`, `reg_date`, `last_active`, `user_level`, `notes`, `admin_notes`, `hash`, `deleted`, `enabled`, `confirmed`, `locked`) VALUES
(6,	0,	0,	'*14BDCEBE19783CE2AFF',	NULL,	'webmaster',	'$2a$10$2pv8O2GCaeym5y2qQ4xswOpZ.YMT26O2qbZfuXRusQcg.y94oGyhO',	'sux@localhost',	NULL,	NULL,	NULL,	NULL,	NULL,	'2024-08-10 13:24:27',	'2024-08-10 13:24:27',	0,	NULL,	NULL,	'1223',	0,	0,	1,	0),
(5,	0,	1,	'*14BDCEBE19783CE2A1F',	NULL,	'admin',	'$2a$10$2pv8O2GCaeym5y2qQ4xswOpZ.YMT26O2qbZfuXRusQcg.y94oGyhO',	'webmaster@letztechance.org',	'Administrator',	'Administrator',	NULL,	NULL,	NULL,	'2024-08-10 13:24:07',	'2024-08-10 13:24:07',	3,	NULL,	NULL,	'1232345435678990400lkjhgf',	0,	1,	1,	0);

-- 2024-08-10 13:24:56
