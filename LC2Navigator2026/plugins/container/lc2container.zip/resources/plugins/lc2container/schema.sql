select '<hr/><h2>Import lc2container processes</h2>';
select '<p>drop plugin tables</p>';
drop table IF EXISTS lc2container;
drop table IF EXISTS lc2container_main;
drop table IF EXISTS lc2container_install;
drop table IF EXISTS lc2container_help;
drop table IF EXISTS lc2container_data;
drop table IF EXISTS lc2container_info;
drop table IF EXISTS lc2container_work;
drop table IF EXISTS lc2container_procdata;
drop table IF EXISTS lc2containertemp;
drop table IF EXISTS lc2container_datatemp;
drop table IF EXISTS lc2container_worktemp;
drop table IF EXISTS lc2container_proc;
drop table IF EXISTS lc2container_tests;
drop table IF EXISTS lc2container_proctemp;
---------------------------------------------------------------
select '<span>Creating tables</span>';
---------------------------------------------------------------
CREATE TABLE lc2container( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,  "url" TEXT NULL);
CREATE TABLE lc2container_main( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE lc2container_install( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE lc2container_help( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE lc2container_data( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE lc2container_info( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE lc2container_work( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
--CREATE TABLE lc2container_proc( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE lc2container_proc( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
---------------------------------------------------------------
CREATE TABLE lc2container_tests( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE lc2container_procdata( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
---------------------------------------------------------------
CREATE TABLE IF NOT EXISTS lc2containertemp (
"name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "url" TEXT NULL
);
CREATE TABLE IF NOT EXISTS lc2container_proctemp( "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "url" TEXT NULL);
---------------------------------------------------------------
-- import menu
select '<span>start import to plugin tables</span>';
---------------------------------------------------------------
.separator ";"
--.import .\\resources\\plugins\\lc2container\\import\\import.csv lc2containertemp
-- INSERT INTO lc2container(first_name,name,zipcode, city, description) select first_name,name,zipcode, city, description  from lc2containertemp;
.import .\\resources\\plugins\\lc2container\\import\\import.csv lc2container
.import .\\resources\\plugins\\lc2container\\import\\main.csv lc2container_main
.import .\\resources\\plugins\\lc2container\\import\\install.csv lc2container_install
.import .\\resources\\plugins\\lc2container\\import\\help.csv lc2container_help
.import .\\resources\\plugins\\lc2container\\import\\info.csv lc2container_info
.import .\\resources\\plugins\\lc2container\\import\\data.csv lc2container_data
.import .\\resources\\plugins\\lc2container\\import\\work.csv lc2container_work
--.import .\\resources\\plugins\\lc2container\\import\\proc.csv lc2container_proc
.import .\\resources\\plugins\\lc2container\\import\\tests.csv lc2container_tests
---------------------------------------------------------------
-- import procs
-- select '<span>importing processes</span>';
-------------------------------------------------------------
-- .separator ","
-- .import '.\\resources\\plugins\\lc2container\\import\\proc.csv' lc2container_proctemp
-- .separator ";"
-- INSERT INTO lc2container_proc(first_name,name,zipcode, description,url) select first_name,name,zipcode, description,url  from lc2container_proctemp;
-- select 'lc2container_work count:';
-- select count(*) from lc2container_proc;
-- eof insert work data
-- eof insert work data
---------------------------------------------------------------
-- done
select '<span>import done</span>';
---------------------------------------------------------------
select 'lc2container count:';
select count(*) from lc2container;
select '<p>start data import to plugin tables</p>';
-- delete from lc2container_datatemp;
--
select '<p>lc2container count:';
select count(*) from lc2container;
select 'lc2container_data count:';
select count(*) from lc2container_data;
select 'lc2container_info count:';
select count(*) from lc2container_info;
select 'lc2container_help count:';
select count(*) from lc2container_help;
select 'lc2container_procdata count:';
select count(*) from lc2container_procdata;
select 'lc2container_work count:';
select count(*) from lc2container_work;
select 'lc2container_proc count:';
select count(*) from lc2container_proc;
select 'lc2container_proctemp count:';
select count(*) from lc2container_proctemp;

drop table IF EXISTS lc2containertemp;
-- drop table IF EXISTS lc2container_proctemp;
-- select '<p>Import done</p>';
select '<h4>Import lc2container processes done.</h4>';
.exit