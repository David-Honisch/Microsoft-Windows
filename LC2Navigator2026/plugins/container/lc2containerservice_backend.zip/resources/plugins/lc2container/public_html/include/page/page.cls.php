<?php

class Page
{

    private $_env = null;

    private $_dao = null;

    private $_db = null;

    private $_doc = null;

    private $_hptitle = null;

    private $_isShortHead = false;

    private $_rs = null;

    private $_path = "";

    private $_page = "home";

    private $_query = "";

    private $_httpClient = null;

    private $_error = null;

    public function __construct($pEnv, $pDao, $pDb, $pDoc, $httpClient)
    {
        $this->_env = $pEnv;
        $this->_dao = $pDao;
        $this->_db = $pDb;
        $this->_doc = $pDoc;
        $this->_httpClient = $httpClient;
        $this->_isShortHead = false;
        $this->_path = (isset($pDoc["content"]["path"])) ? $pDoc["content"]["path"] : "";
        $this->_page = (isset($pDoc["content"]["page"])) ? $pDoc["content"]["page"] : "";
        // Debug("Test");
    }

    public function printPage()
    {
        $result = "";
        switch ($this->_page) {
            case "login":
                $result = $this->postPage();
                break;
            case "post":
                $result = $this->postPage();
                break;
            case "edit":
                $result = $this->editPage();
                break;
            case "delete":
                $result = $this->deletePage();
                break;
            case "imprint":
                $result = $this->imprintPage();
                break;
            case "contact":
                $result = $this->contactPage();
                break;

            case "logout":
                $result = $this->getDefaultPage("logout", false, false);
                break;
            case "content":
                $result = $this->getDefaultPage("content", false, false);
                break;
            case "LastContent":
                $result = $this->getDefaultPage("lastcontent", false, false);
                break;
                // DatePage
            case "calendar":
                $result = $this->DatePage();
                break;
            case "index":
                $result = $this->indexPage();
                break;
            case "sindex":
                $result = $this->indexPage();
                break;
            case "list":
                $result = $this->listPage();
                break;
            case "read":
                $result = $this->readPage();
                break;
            case "content":
                $result = $this->readPage();
                break;
            case "sread":
                $result = $this->readPage(true);
                break;

            case "fullcalendar":
                $result = HTML::FullCalendar();
                break;
            case "fullcalendarview":
                $result = HTML::FullCalendarView();
                break;
            case "search":
                $result = $this->searchPage();
                break;

                //
            case "rssreader":
                $result = $this->rssReaderPage();
                break;
            case "rss":
                $result = $this->rssPage();
                break;
            case "srss":
                $result = $this->shortRSSPage();
                break;
            case "srss":
                $result = $this->getDefaultPage("srss", false, false);
                break;
                //
            case "sendmail":
                $result = $this->SendMail();
                break;
            case "registeruser":
                $result = $this->RegisterUser();
                break;
            case "upload":
                $result = $this->uploadPage();
                break;
            case "uploadfiles":
                $result = $this->UploadFiles();
                break;
            case "start":
                $result = $this->homePage();
                break;
            case "home":
                $result = $this->homePage(true);
                break;
            case "ytidplayer":
                $result = $this->getDefaultPage("ytidplayer", false, false);
                break;
            default:
                $result = $this->Error(true);
                break;
        }
        echo $result;
    }

    /**
     */
    private function initRequest($pIsShortHead = false)
    {
        if ($pIsShortHead) {
            $this->_doc["isShortHead"] = true;
        }
        if (empty($this->_env["req"]["value1"])) {
            $this->_env["req"]["value1"] = "1";
        }
        if (empty($this->_env["req"]["value2"])) {
            $this->_env["req"]["value2"] = "1";
        }
        // search
        if (!empty($this->_env["req"]["query"])) {
            $this->_query = $this->_env["req"]["query"];
        }
    }

    private function getHead($pIsShortHead = false, $isCached = false)
    {
        $head = $this->_env["skin"] . "/header.cls.php";
        $foot = $this->_env["skin"] . "/footer.cls.php";
        // echo "Debug".$head;
        if (file_exists($head) && file_exists($foot)) {
            require_once($head);
            $header = new Header($this->_db, $this->_env);
            return $header->getHTML($pIsShortHead);
        } else {
            return null;
            // die();
        }
    }

    private function getFoot($isCached = false)
    {
        $foot = $this->_env["skin"] . "/footer.cls.php";
        if (file_exists($foot)) {
            require_once($foot);
            $footer = new Footer($this->_db, $this->_env);
            return $footer->getHTML($this->_env);
        } else {
            return null;
            // die();
        }
    }

    private function getDefaultPage($title, $pIsShortHead = false, $isCached = false)
    {
        $smarty = null;
        //require_once $this->_env["include"] . "nusoap/src/nusoap.php";
        $result = "";
        $this->_hptitle = $this->_env["hptitle"] . " - " . ($title != null ? $title : "N/A");
        $this->initRequest(false);
        // Debug("OUT:".$this->_env["include"]. 'smarty/src/');
        define('__SMARTY_DIR', $this->_env["include"] . 'smarty/src/');
        if (file_exists($this->_env["include"] . "smarty/libs/Smarty.class.php")) {
            require $this->_env["include"] . "smarty/libs/Smarty.class.php";
            $smarty = new Smarty\Smarty;
        }
        // if (file_exists($this->_env["include"] . "smarty/src/Smarty.php")) {
        //     require $this->_env["include"] . "smarty/src/Smarty.php";
        //     $smarty = new Smarty\Smarty;
        //     //$smarty->assign("product_log", Log::logFile($this->_env["log"], $this->_env["req"]));
        // }
        //$smarty->force_compile = true;
        // $smarty->debugging = false;
        // if ($this->_env["isDefaultdb"] == true) {
        //     $smarty->debugging = true;
        // }
        $smarty->caching = false;
        //$smarty->cache_lifetime = 120;
        $smarty->cache_lifetime = 0;
        // $smarty->assign("log", "TEST");
        // $smarty->assign("logip", "TEST");
        if (file_exists($this->_env["include"] . "log/log.cls.php")) {
            require $this->_env["include"] . "log/log.cls.php";
            // $smarty->assign("product_log", Log::logFile($this->_env["log"], $this->_env["req"]));
        }
        if (file_exists($this->_env["include"] . "log/ipcounter.cls.php")) {
            require $this->_env["include"] . "log/ipcounter.cls.php";
            // $smarty->assign("product_iplog", IPCountLogger::writeToFilePath($this->_env["log"]));
        }
        $smarty->assign("IsShortHead", $pIsShortHead);
        $smarty->assign("env", $this->_env);
        $smarty->assign("hptitle", $this->_env["hptitle"]);
        $smarty->assign("hp_title", $this->_env["hptitle"]);
        // $smarty->assign("modules", $this->_e nv["modules"]);
        $smarty->assign("doc", $this->_doc);
        $smarty->assign("Name", "anonymous", true);
        $smarty->assign("FirstNames", array("John", "Mary", "James", "Henry"));
        $smarty->assign("LastName", array("Doe", "Smith", "Johnson", "Case"));
        $smarty->assign(
            "Class",
            array(
                array("A", "B", "C", "D"),
                array("E", "F", "G", "H"),
                array("I", "J", "K", "L"),
                array("M", "N", "O", "P")
            )
        );
        $smarty->assign(
            "contacts",
            array(
                array("phone" => "1", "fax" => "2", "cell" => "3"),
                array("phone" => "555-4444", "fax" => "555-3333", "cell" => "760-1234")
            )
        );
        $smarty->assign("option_values", array("NY", "NE", "KS", "IA", "OK", "TX"));
        $smarty->assign("option_usoutput", array("New York", "Nebraska", "Kansas", "Iowa", "Oklahoma", "Texas"));
        $smarty->assign("option_usoutput", array("NRW", "Berlin", "Hamburg", "Sachsen", "Sachsen Anhalt", "Thueringen"));
        $smarty->assign("option_selected", "DE");

        //log
        //  if (file_exists($this->_env["include"] ."/log/log.cls.php")) {
        //     require_once $this->_env["include"]."/log/log.cls.php";
        //     //. "-" . $_SERVER['REMOTE_HOST'] . $_SERVER['REMOTE_ADDR'] . $_SERVER['REMOTE_PORT']
        //     $smarty->assign("product_log", Log::logFile("../log/", "-page:" . $_SERVER['SCRIPT_NAME'] . $_SERVER['QUERY_STRING'] ));            
        // }
        // if (file_exists($this->_env["include"] ."/log/ipcounter.cls.php")) {
        //     require_once $this->_env["include"] ."/log/ipcounter.cls.php";            
        //     $smarty->assign("product_iplog", IPCountLogger::writeToFilePath("../log/"));
        // }
        //echo "<h1>Debug</h1>";
        //ini_set('display_errors', true);
        //error_reporting(E_ALL + E_NOTICE);

        $q = isset($this->_env["req"]["q"]) ? $this->_env["req"]["q"] : "";
        // echo "<h1>".$q."</h1>";
        $value1 = isset($_REQUEST["value1"]) ? $_REQUEST["value1"] : (isset($post["value1"]) ? $post["value1"] : '1');
        $value2 = isset($_REQUEST["value2"]) ? $_REQUEST["value2"] : (isset($post["value2"]) ? $post["value2"] : '1');
        $value1 = preg_replace('@/((\&)?PHPSESSID=[0-9]+(\&)?)/i@', "", "" . $value1);
        $value2 = preg_replace('@/((\&)?PHPSESSID=[0-9]+(\&)?)/i@', "", "" . $value2);
        $username = isset($_REQUEST["username"]) ? $_REQUEST["username"] : (isset($post["username"]) ? $post["username"] : 'anonymous');
        $password = isset($_REQUEST["password"]) ? $_REQUEST["password"] : (isset($post["password"]) ? $password["password"] : 'anonymous');

        switch ($q) {
            case 'index':
                $result = "index";
                $smarty->assign("page_action", $result);
                $params = array(
                    'value1' => '' . $value1,
                    'value2' => '' . $value2,
                );
                $smarty->assign("page_content", "" . json_encode($this->_httpClient->call("getIndexJSON", $params, "urn:String", "urn:String")));
                $smarty->assign("page_subject", "Index");
                break;
            case 'home':
                $result = "home";
                $smarty->assign("page_action", $result);
                $params = array(
                    'value1' => '' . $value1,
                    'value2' => '' . $value2,
                );
                if ($this->_env["dbuser"] == $username && $this->_env["dbpassword"] == $password) {
                    $smarty->assign("isloggedin", "true");
                } else {
                    $smarty->assign("isloggedin", "false");
                }
                $smarty->assign("dbusername", $username);
                $smarty->assign("dbpassword", $password);

                $smarty->assign("page_subject", "Home");
                break;
            case 'list':
                $result = "list";
                $smarty->assign("page_action", $result);
                $params = array(
                    'value1' => '' . $value1,
                    'value2' => '' . $value2,
                );
                $t = $this->_httpClient->call("getListJSON", $params, "urn:String", "urn:String");
                $decoded_json = json_decode($t, false);
                $smarty->assign("page_subject", "" . $decoded_json->tableName);
                $smarty->assign("page_content", "" . $decoded_json->tableName);
                $smarty->assign("page_subjecturl", "" . urlencode($decoded_json->tableName));
                break;
            case 'read':
                $result = "read";
                $smarty->assign("page_action", $result);
                $params = array(
                    'value1' => '' . $value1,
                    'value2' => '' . $value2,
                );
                $t = $this->_httpClient->call("getReadJSON", $params, "urn:String", "urn:String");
                $smarty->assign("page_content", "" . json_encode($t));
                $decoded_json = json_decode($t, false);
                $smarty->assign("page_subject", "" . mb_convert_encoding($decoded_json->subject,  "UTF-8"));
                $smarty->assign("page_subjecturl", "" . urlencode($decoded_json->subject));
                $smarty->assign("page_body", "" . mb_convert_encoding($decoded_json->body, "UTF-8"));
                break;
            case 'sread':
                $result = "sread";
                $smarty->assign("page_action", "sread");
                $params = array(
                    'value1' => '' . $value1,
                    'value2' => '' . $value2,
                );
                $t = $this->_httpClient->call("getReadJSON", $params, "urn:String", "urn:String");
                $smarty->assign("page_content", "" . json_encode($t));
                $decoded_json = json_decode($t, false);
                $smarty->assign("page_subject", "" . mb_convert_encoding($decoded_json->subject, "ISO-8859-1",  "UTF-8"));
                $smarty->assign("page_subjecturl", "" . urlencode($decoded_json->subject));
                $smarty->assign("page_body", "" . mb_convert_encoding($decoded_json->body, "ISO-8859-1",  "UTF-8"));
                // $smarty->assign("page_body", "" . $decoded_json->body);
                break;
            case 'getLastContent':
                $action = "getLastContent";
                $result = $action;
                $smarty->assign("page_action", $action);
                $value1 = isset($value1) ? $value1 : "21";
                $value2 = isset($value2) ? $value2 : "1";
                $params = array(
                    'value1' => '' . $value1,
                    'value2' => '' . $value2
                );
                $t = $this->_httpClient->call($action, $params, "urn:String", "urn:String");
                // print_r($params);
                // echo "respone:".$t.".<hr>";
                // print_r(json_encode($t));
                $smarty->assign("content", "" . $t);
                $smarty->assign("page_content", json_encode($t));
                $obj = json_decode($t, false);
                // echo "id:".$obj->{'0'}->{'id'};
                // echo "Respones:".$obj->{'0'}->{'subject'};
                // print_r($obj);
                // $smarty->assign("content_obj", "" . json_decode($obj));
                // $smarty->assign("content_object", $obj);
                $smarty->assign("page_id", "" . $obj->{'0'}->{'id'});
                $smarty->assign("page_subject", "" . mb_convert_encoding($obj->{'0'}->{'subject'}, "ISO-8859-1", "UTF-8"));
                // $smarty->assign("page_subject", "" . $obj->{'0'}->{'subject'});
                // $smarty->assign("page_subjecturl", "" . urlencode($decoded_json->subject));                
                $smarty->assign("page_body", "" .  mb_convert_encoding($obj->{'0'}->{'body'}, "ISO-8859-1",  "UTF-8"));
                break;
            case 'login':
                $result = "login";
                $smarty->assign("page_action", "login");

                $smarty->assign("page_subject", "Login");
                $smarty->assign("page_subjecturl", "Login");
                $smarty->assign("page_body", "<h1>Login</h1>");
                // $smarty->assign("page_body", "" . $decoded_json->body);
                break;
            case 'intro':
                $result = "intro";
                $smarty->assign("page_action", "openlink");

                $smarty->assign("page_subject", "Intro");
                $smarty->assign("page_subjecturl", "Intro");
                $smarty->assign("page_body", "<h1>Intro</h1>");
                // $smarty->assign("page_body", "" . $decoded_json->body);
                break;
            case 'ytidplayer':
                $result = "ytidplayer";
                $smarty->assign("page_action", "ytidplayer");
                $params = array(
                    'value1' => '22',
                    'value2' => '2',
                );
                $t = $this->_httpClient->call("getReadJSON", $params, "urn:String", "urn:String");
                $smarty->assign("page_content", "" . json_encode($t));
                $decoded_json = json_decode($t, false);
                $smarty->assign("page_subject", "" . mb_convert_encoding($decoded_json->subject, "ISO-8859-1",  "UTF-8"));
                $smarty->assign("page_subjecturl", "" . urlencode($decoded_json->subject));
                $smarty->assign("page_body", "" . mb_convert_encoding($decoded_json->body, "ISO-8859-1",  "UTF-8"));
                break;
            case 'db':
                $result = "db";
                $smarty->assign("page_action", "db");

                $smarty->assign("page_subject", "Database");
                $smarty->assign("page_subjecturl", "Database");
                $smarty->assign("page_body", "<h1>Database</h1>");
                // $smarty->assign("page_body", "" . $decoded_json->body);
                break;
            case 'test':
                $result = "home";
                $smarty->assign("page_action", $result);
                $params = array(
                    'value1' => '' . $value1,
                    'value2' => '' . $value2,
                );
                if ($this->_env["dbuser"] == $username && $this->_env["dbpassword"] == $password) {
                    $smarty->assign("isloggedin", "true");
                } else {
                    $smarty->assign("isloggedin", "false");
                }
                $smarty->assign("dbusername", $username);
                $smarty->assign("dbpassword", $password);

                $smarty->assign("page_subject", "Home");
                break;
            default:
                $result = "index";
                $smarty->assign("page_action", "index");
                $smarty->assign("page_subject", "index");
                $smarty->assign("page_content", "index");
                break;
        }
        // echo "FucK:".$result;
        $smarty->display('templates/standard/templates/' . $result . '.tpl');

        //$smarty->display('index.tpl');
        // echo "<h1>Debug2</h1>";

        // $head = $this->getHead($pIsShortHead);
        // $result .= isset($head) ? $head : require_once($this->_env["skin"] . "/head.cls.php");
        // $type = ($pIsShortHead ? "short" : "long");
        // $result .= HTMLCore::createDIV("cnt", "", "cnt", "");
        // $result .= HTMLCore::createDIV("error", "", "error", "");
        // $result .= HTMLCore::createDIV("carousel", "", "carousel", "");
        // $foot = $this->getFoot();
        // $result .= isset($foot) ? $foot : require_once($this->_env["skin"] . "/foot.cls.php");
        //return $result;
    }

    private function Error($isCached)
    {
        $this->_env["error_url"] = isset($this->__SERVER["REDIRECT_STATUS"]) ? $this->__SERVER["REDIRECT_STATUS"] : '';
        return $this->getDefaultPage("Error", false, $isCached);
    }

    private function homePage($isCached = false)
    {
        return $this->getDefaultPage("Home", false, $isCached);
    }

    private function indexPage()
    {
        return $this->getDefaultPage("Index", false, false);
    }

    private function listPage($pIsShortHead = false)
    {
        return $this->getDefaultPage("List", $pIsShortHead);
    }

    private function readPage($pIsShortHead = false)
    {
        return $this->getDefaultPage("Read", $pIsShortHead);
    }

    private function searchPage()
    {
        return $this->getDefaultPage("Search", false);
    }

    private function contactPage()
    {
        return $this->getDefaultPage("Contact", false);
    }

    private function imprintPage()
    {
        return $this->getDefaultPage("Imprint", false);
    }

    private function EmailForm()
    {
        return $this->getDefaultPage("Contact", false);
    }

    private function RegisterUser()
    {
        return $this->getDefaultPage("Contact", false);
    }

    private function SendMail()
    {
        return $this->getDefaultPage("Contact", false);
    }

    private function DatePage()
    {
        return $this->getDefaultPage("Contact", false);
    }

    private function Delete()
    {
        return $this->getDefaultPage("Edit", false);
    }

    private function postPage()
    {
        return $this->getDefaultPage("Post", false);
    }

    private function editPage()
    {
        return $this->getDefaultPage("Edit", false);
    }

    private function deletePage()
    {
        return $this->getDefaultPage("Delete", false);
    }

    private function uploadPage()
    {
        return $this->getDefaultPage("Upload", false);
    }

    // realy return data !!!
    private function rssPage()
    {
        $this->_hptitle = $this->_env["hptitle"] . " - " . msg("rss");
        $this->_rs = null;
        $this->_doc["isNoLeft"] = true;
        $this->_isShortHead = false;

        echo "";
        $this->_query = "";
        if ($this->_isShortHead) {
            $this->_doc["isShortHead"] = true;
        }

        if (!empty($this->_env["req"]["query"])) {
            $this->_query = $this->_env["req"]["query"];
        }
        if (!empty($this->_env["req"]["from"])) {
            $this->_query = $this->_env["req"]["from"];
        }
        $this->_hptitle = $this->_hptitle . " - RSS:" . substr($this->_query, 0, 80) . "";
        $result = $this->getHead();
        if (empty($this->_query)) {
            $this->_query = $_SERVER['REQUEST_URI'];
        }
        if (preg_match("/query=/", $_SERVER['REQUEST_URI'])) {
            $this->_query = explode("query=", $_SERVER['REQUEST_URI'])[1];
        }
        // HTML::getBoxHead ( "RSS/Atom:" . substr ( $this->_query, 0, 80 ), $this->_style = "width:auto;text-align:center" );
        if (!empty($this->_query)) {
            if (file_exists($this->_env["include"] . "rdf/rss.php")) {
                require_once($this->_env["include"] . "rdf/rss.php");
                echo LoadRSS::getRSS($this->_env, $this->_query);
            } else {
                echo "<h1>404 - RSS Manager not found.</h1>";
            }
        }
        $result .= $this->getFoot();
    }

    private function shortRSSPage()
    {
        $this->_hptitle = "" . $this->_env["hptitle"] . " - " . msg("shortrss");
        $this->_rs = null;
        $this->_doc["isNoLeft"] = true;
        $this->_isShortHead = true;

        $this->_query = "";
        if ($this->_isShortHead) {
            $this->_doc["isShortHead"] = true;
        }

        if (!empty($this->_env["req"]["query"])) {
            $this->_query = $this->_env["req"]["query"];
        }
        if (!empty($this->_env["req"]["from"])) {
            $this->_query = $this->_env["req"]["from"];
        }
        if (empty($this->_query)) {
            $this->_query = $_REQUEST["query"];
        }
        if (empty($this->_query)) {
            $this->_query = $_SERVER['REQUEST_URI'];
        }
        if (preg_match("/query=/", $_SERVER['REQUEST_URI'])) {
            $this->_query = explode("query=", $_SERVER['REQUEST_URI'])[1];
        }
        //echo "query:". $this->_query;        
        if (!empty($this->_query)) {
            if (file_exists($this->_env["include"] . "rdf/rss.php")) {
                require_once($this->_env["include"] . "rdf/rss.php");
                echo LoadRSS::getRSS($this->_env, $this->_query);
            } else {
                echo "<h1>404 - RSS Manager not found.</h1>";
            }
        } else {
            echo "<h1>404 - RSS not found.</h1>";
        }
        // $result .= $this->getFoot();
    }

    private function Uploads($isCached = false)
    {
        return $this->getDefaultPage("Edit", false);
    }

    private function UploadFiles()
    {
        $id = !empty($_REQUEST["id"]) ? $_REQUEST["id"] : 0;
        $id = !empty($_REQUEST["query"]) ? $_REQUEST["query"] : 0;
        $id = !empty($_REQUEST["file"]) ? $_REQUEST["file"] : 0;
        if (!empty($id)) {
            $rs = array();
            try {
                // if ($this->env ["userIsLoggedIn"] == 1 && $this->env ["user"] ["user_level"] >= $value ["sid"]) {
                $sql = "SELECT id, name, size, type, content FROM upload WHERE id = " . $id;
                $rs = $this->_db->GetAll("" . $sql);
                if (!empty($rs[0]["name"])) {
                    $fileName = "../uploads/" . $rs[0]["name"];
                    header("Content-Disposition: attachment; filename=" . $rs[0]["name"]);
                    header("Content-Transfer-Encoding: binary");
                    header("Content-length: " . filesize($fileName));
                    header("Content-type: " . $rs[0]["type"]);
                    header("Content-Disposition: attachment; filename=" . $rs[0]["name"]);
                    header("Expires: 0");
                    header("Pragma: no-cache");
                    readfile($fileName);
                } else {
                    echo "<h1>404 - File not found.</h1>";
                }
                die();
            } catch (ADODB_Exception $ex) {
                echo "Transfer failed. Try again...";
            }
        } else {
            json_encode("No file requested.");
        }
        die();
    }

    private function rssReaderPage()
    {
        $this->_hptitle = $this->_env["hptitle"] . " - " . msg("rssreader");
        $this->_rs = null;
        $this->_doc["isNoLeft"] = true;
        $this->_isShortHead = true;
        $this->_rs = null;
        $this->_hptitle = $this->_hptitle . " - Home";
        if ($this->_isShortHead) {
            $this->_doc["isShortHead"] = true;
        }
        if (file_exists($this->_env["include"] . "xml/xml.cls.php")) {
            require_once($this->_env["include"] . "xml/xml.cls.php");
            if (file_exists($this->_env["include"] . "xml/RSS2Writer.cls.php")) {
                require_once($this->_env["include"] . "xml/RSS2Writer.cls.php");
                $this->_rss = new RSS2Writer(
                    "LetzteChance.Org", // Feed Title
                    "LetzteChance.Org RSS 2.0 compatible Feed", // Feed Description
                    "http://www.letztechance.org/rssreader-1-1.html", // Feed Link
                    6, // indent
                    false
                );

                if (!empty($this->_env["req"]["value1"])) {
                    if (!empty($this->_env["req"]["value2"])) {
                        $this->_rs = $this->_dao->getList($this->_doc["CacheIndex"], $this->_env["req"]["value1"], $this->_env["req"]["value2"], true);
                    } else {
                        $this->_rs = $this->_dao->getList($this->_doc["CacheIndex"], $this->_env["req"]["value1"], 1, true);
                    }
                } else {
                    $this->_rs = $this->_dao->getList($this->_doc["CacheIndex"], 1, 1, true);
                }
                // ------------------------------------------------------>
                $this->_hptitle = $this->_hptitle . " - RSS Feed - " . $this->_rs["page"]["name"];
                $this->_rss = XML::getHead($this->_env, $this->_dao, $this->_doc, $this->_hptitle, true, $this->_doc["isShortHead"], $this->_rss);
                // set body!!!!!!!!!!!!!!!!
                XML::getList($this->_env, $this->_rs, $this->_rss);
                // set HTML Foot HTML::getBoxFoot();
                $this->_rss = XML::getFoot($this->_env, $this->_dao, $this->_doc, $this->_hptitle, true, $this->_doc["isShortHead"], $this->_rss);
                echo $this->_rss->getXML();
            } else {
                echo "<h1>404 - The XML Engine could not be found.</h1>";
                $this->_error = array();
                $this->_error["title"] = "503 - Access denied";
                $this->_error["text"] = "503 - Access denied";
                $this->_error["code"] = "503";
                $this->Error();
            }
        } else {
            // echo "<h1>404 - The XML Engine could not be found.</h1>";
            $this->_error = array();
            $this->_error["title"] = "404 - Access denied";
            $this->_error["text"] = "404 - Access denied";
            $this->_error["code"] = "404";
            $this->Error("404 - Access denied");
        }
    }
}
