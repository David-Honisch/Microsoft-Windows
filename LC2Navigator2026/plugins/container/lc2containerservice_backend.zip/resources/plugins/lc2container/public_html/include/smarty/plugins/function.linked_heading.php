<?php

/*
 * Smarty plugin
 * -------------------------------------------------------------
 * Type:     function
 * Name:     linked_heading
 * Version:  1.0
 * Author:   Ben Finney <bignose@zip.com.au>
 * Purpose:  Generate a hyperlinked header element
 * Input:    level  = heading level (1..6)
 *           id     = id name (target of anchor tag)
 *           text   = heading text
 * Example:  {linked_heading level=2 id="about" text="About us"}
 * -------------------------------------------------------------
 */
function smarty_function_linked_heading( $params, &$smarty )
{
    $print_result = true;

    extract( $params );

    $html_result = '';

    // Ensure parameters were specified
    if( empty( $level ) ):
        $smarty->trigger_error(
            'linked_heading: missing "level" parameter' );
        return;
    endif;
    if( empty( $id ) ):
        $smarty->trigger_error(
            'linked_heading: missing "id" parameter' );
        return;
    endif;
    if( empty( $text ) ):
        $smarty->trigger_error(
            'linked_heading: missing "text" parameter' );
        return;
    endif;

    // Force the heading into the 1..6 range
    $level = (int) $level;
    if( $level < 1 ):
        $level = 1;
    elseif( $level > 6 ):
        $level = 6;
    endif;

    // Construct the header element
    $heading_open_tag = '<h' . $level
        . ' id="' . $id . '"'
        . '>';
    $heading_close_tag = '</h' . $level . '>';
    $heading_content =
        '<a href="#' . $id . '"' . "\n"
        . ' title="Direct link to this heading"' . "\n"
        . '>' . $text . '</a>';

    $html_result = 
        $heading_open_tag . "\n"
        . $heading_content . "\n"
        . $heading_close_tag . "\n";

    if( $print_result ):
        print $html_result;
    endif;

    return $html_result;

} // end smarty_function_linked_heading()

/* vim: set expandtab: */

?>
