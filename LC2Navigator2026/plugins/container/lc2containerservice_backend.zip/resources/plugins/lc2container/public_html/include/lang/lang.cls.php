<?php

class Language
{
    private $countries = array(
        'de','de_DE','en','en_US'
    );
    private $messages = array(
        'en_US' => array(
    		'3rdpartydownloads' => '3rd Party Downloads',
            'about' => 'About',
            'account' => 'Account',            
            // 'adress' => 'Adress',
            'agree' => 'Agree',
            'additional' => 'Additional',
            'all' => 'All',
            'allowcookies' => 'Allow Cookies',
            // jquery.cookiebar.min.js
            'all news' => 'All News',
            'allrss' => 'All RSS Feeds',
            
            'andmore' => 'and more',
            'app' => 'Application',
            'area' => 'area',
            'article' => 'article',
            'authorizeuser' => 'Authorizing user',
            // b
            'body' => 'Body',
            'back' => 'Back',
            'browser' => 'Browser',
            // c
            'calendar' => 'Calendar',
            'calnow' => 'Calendar (today)',
            'calweek' => 'Calendar (week)',
            'calmonth' => 'Calendar (week)',
            'category' => 'Category',
            'categories' => 'Categories',
            'category' => 'Category',
            'cheats' => 'Cheats',
            'cheat_news' => 'Cheats',
            'clickhere' => 'Click here ',
            'contact' => 'Contact',
            'contract' => 'Contract',
            'content' => 'Content',
            'chooseyourcountry' => 'choose your country...',
            'copyright' => '&copy 2010 by',
            'calender' => 'Calender',
            'chatandfeeds' => 'Chat and Feeds',            
            'clicktoexpand' => 'click to expand',
            'csharp_vbnet' => 'C# &amp; VB.NET &amp;.NET Core',
            'currentday' => 'current day',
            // d
            'date' => 'Date',
            
            'ddapi' => 'APIs',
            'ddextapi' => 'External APIs',

    		'dependencies' => 'dependencies',
            'documents' => 'Documents',
    		'done' => 'Done',
            'download' => 'Download',
            'downloads' => 'Downloads',
            'download_news' => 'Downloads',
            // e
            'edit' => 'Edit',
    		'elements' => 'Elements',
            'extended' => 'Extended',
            'email' => 'E-Mail',
            'env' => 'Environment',
            'envm' => 'Environment',
            'environment' => 'Environment',
            'error' => 'Fehler',
            'event_news' => 'Event News',
            // f
            'feeds' => 'Feeds',
            'firstname' => 'Firstname',
            'fileuploaded' => 'Document(s) successfully uploaded.',
            'forum' => 'Forum',
            'forums' => 'Forums',
            // g
            'games' => 'Games',
            'gamesm' => 'Games',
    		'generate' => 'Generate',
            'geolocateip' => 'Geo Location',
            'getroute' => 'Get route',
            'gohome' => ' to enter this homepage.',
            // h
            'help' => 'Help',
            'hits' => 'Hits',
            'help' => 'Help',
            'home' => 'Home',
            'homepage' => 'Homepage',
            'howaction' => 'Wie bist Du auf diese Aktion aufmerksam geworden ?',
            // i
            'issend' => 'is send',
            'index' => 'Index',
            'indexpage' => 'Index Page',
    		'init' => 'Initializing',
    		'info' => 'Info',
            'information' => 'Information',
            'internalsearch' => 'Internal Search',
            'imprint' => 'Imprint',
            'iplocation' => 'IP Location',
            'isp' => 'ISP',
            'ispm' => 'ISP',
            //Java_C_C_Plus_Plus
            'java_c_c_plus_plus' => 'Java C C++',
            'javascript_sapui_nodejs' => 'Javascript SapUI NodeJS',
            // j
            'search javascript' => 'Javascript Suche',
            'source' => 'Source',
            'sourcecode' => 'Source Code',
            'start' => 'Start',
            // l
            'lastname' => 'Lastname',
            'languagequestion	' => 'Welche Sprachen beherrschst du ?',
            'languageISO' => 'English',
            'language' => 'Language',
    		'listofforums' => 'List of keywords',
    		'loading' => 'loading',
            'location' => 'location',
            'login' => 'login',
            'loggedin' => 'Successfully loggedin.',
            'login' => 'Login',
            'logout' => 'Logout',
            'links' => 'Urls',
            'List' => 'List',
            // m
            'mediaclips' => 'Media Clips',
            'mediamenu' => 'Media Menu',
            'member' => 'member',
            'members' => 'members',
            'menu' => 'Menu',
            'media' => 'Media',
            'message' => 'Message',
            'more' => 'more',
            'more links' => 'more Links',
            
            'movie' => 'Movie',
            'movies' => 'Movies',
            'music' => 'Music',
            'music_news' => 'Music news',
            
            // n
            'naspnet' => 'ASP .NET',
            'name' => 'Name',    		
            'nevents' => 'Events',
    		'nsecurity' => 'Security',
            'ndownloads' => 'Downloads',
            'ngames_all' => 'Spiele',
            'ncode' => 'Source Code',
            'nmedia' => 'Media',
        	'nsoftware' => '3rd Party Downloads',
    		'ncheats' => 'Cheats',
    		'ncalendar' => 'Calendar',
    		'nall' => 'All',
            'napp' => 'Application',
            'nbilder' => 'Pictures',
            'nc_plus_plus' => 'C++',
            'njava' => 'Java',
            'nhtml5' => 'HTML5',
            'njavascript' => 'Javascript',
            'ncsharp' => 'C#',
            'nsapui' => 'SAP',
            'nplsql' => 'PL/SQL',
            'npython' => 'Python',
            'next' => 'Next',
            'nentertain' => 'Entertain',
            'nextpage' => 'Next page',
            'new' => 'New',
            'news' => 'News',            
            'newest' => 'Newest',
            'news_security' => 'News & Security',
    		'ncharts' => 'Charts',
            'nhyperlinks' => 'Hyperlinks',    		
        	'nlinks' => 'Links',
            'nmedien' => 'Multimedia',
            'nmedia' => 'Multimedia',
            'nnews' => 'News',
            'nneues' => 'News',
            'nmusic' => 'Music',            
            'npolitik' => 'Politic and News',
            'nrss' => 'RSS Feeds',
            'nspiele_cheats' => 'Game Cheats',
            'nspiele' => 'Games',
            'nsport' => 'Sport News',            
    		'nscience' => 'Science',
            'nohits' => 'No hits',
            'not' => 'Not',
            'notfound' => 'Not found',
            'notsend' => 'Not send',
            'nvideo_clips' => 'Video Clips',
            'nxbox' => 'Console Xbox, PS, WII and more...',
            'nvisualbasicscript' => 'Visual Basic Script',
            'nwitze' => 'Gags',
            // o
            'os' => 'Operating System',
            'or' => 'or',
            'openlinklabel' => 'Redirect in 60 seconds',
            'openlinkmsg' => 'Redirect in 60 seconds',
            'options' => 'Options',
            'other_downloads' => 'other downloads',
            // p
            'page' => 'Page',
            'pages' => 'Pages',
            'phone' => 'Phone',
            'password' => 'Password',
            'platform' => 'Platform',
    		'pleasewait' => 'Please wait',
            'pleasetypesearchpattern' => 'Please type in your search pattern...',
            'previouspage' => 'Previous page',
            'profile' => 'Profile',
            'profil' => 'Profil',
            'projects' => 'Projects',
            'products' => 'Products',
            'pictures' => 'Pictures',
            'previous' => 'Back',
            'provider' => 'Provider',
            'plugins' => 'Plugins',
            'pl_sql' => 'PL SQL',
            'postmessage' => 'Post message',
            'politic' => 'Politic',
            'politicarticle' => 'Politic article',
            'politic_sport' => 'Politic &amp; Sport',
            // q
            // r
            'reading' => 'Loading',
            'readmore' => 'Read more',
            'redirectmsg' => 'Automatic Redirect in',
            'redirectin' => 'Redirecting in',
            'register' => 'register',
            'registeruser' => 'Register user',
            'repeat' => 'Repeat',
            'register' => 'Register',
            'registration' => 'Registration',
            'route' => 'Route',
            'replyto' => 'Reply to',
            'rssfeeds' => 'RSS Feeds',
            'rss_feeds' => 'RSS Feeds',
            // s
            'savepassword' => 'save the password',
            'science' => 'Science',
            'seconds' => 'Seconds',
            'search' => 'Search',
            'security' => 'Security',
            'settings' => 'Einstellungen',
            'showmemore' => 'show me more...',
            'signout' => 'Sign out',
            'sport' => 'Sport',
            'successfully' => 'Successfully',
            'support' => 'Support',
            'submit' => 'Submit',
            'status' => 'Status',
            'searchingfor' => 'Searching for',
            'startpage' => 'Start Page',
            'software' => 'Software',
            'subject' => 'Subject',
            'send' => 'send',
            'size' => 'size',
            'startpage' => 'start',
            // t
            'tags' => 'Tags',
            'tagsm' => 'Tags',
            'title' => 'Home',
            'titletext' => 'More than links...',
            'timestamp' => 'Timestamp',
            'tools' => 'Tools',
            'toolsm' => 'Tools',
            'top' => 'Top',
            'topage' => 'to page',
            'translate' => 'Translate',
            'trip' => 'trips',
            'tryagain' => 'Please try again.',
            'trynextpage' => 'Please try next page.',
            'tv' => 'TV',
            'tv_radio' => 'TV and Radio',
            // u
            'user' => 'User',
            'unknown' => 'unknown',
            'university' => 'University',
            'upload' => 'Upload',
            'up' => 'Up',
            // v
            'videoclips' => 'VideoClips',
            'videoofday' => 'Video of the day',
            'videos_movies' => 'Videos & Movies',
            // w
            'wrong' => 'Wrong',
            'welcome' => 'Welcome',
            // x
            // y
            'your' => 'Your',
            'yourip' => 'Your IP'
        ),
        // z
        'de_DE' => array(
        	'3rdpartydownloads' => '3rd_Party_Downloads',
            'about' => '&Uuml;ber',
            'account' => 'Account',
            // 'adress' => 'Adress',
            'agree' => 'Best&auml;tigen',
            'additional' => 'Zus&auml;tzliche',
            'all' => 'Alle',
            'allowcookies' => 'Cookies erlauben ? Cookies sind harmlos und werden niemals zur identifizerung Ihrer Person verwendet.',
            'all news' => 'Alle Themen',
            'allrss' => 'Alle RSS Feeds',
            'andmore' => 'und mehr',
            'app' => 'Application',
            'area' => 'Bereich',
            'article' => 'Artikel',
            'authorizeuser' => 'Authorisiere den Benutzer',
            // b
            'body' => 'K&ouml;rper',
            'back' => 'Zur&uuml;ck',
            'browser' => 'Browser',
            // c
            'calendar' => 'Kalender',            
            'calnow' => 'Aktueller Kalendertag',
            'calweek' => 'Aktuelle Kalenderwoche',
            'calmonth' => 'Aktueller Kalendermonat',
            'category' => 'Kategorie',
            'categories' => 'Kategorien',
            'chatandfeeds' => 'Chat and Feeds',
            'cheats' => 'Cheats',
            'cheat_news' => 'Cheats',
            'clickhere' => 'Klicke hier ',
            'contact' => 'Kontakt',
            'contract' => 'Vertrag',
            'content' => 'Inhalt',
            'chooseyourcountry' => 'W&auml;hlen Sie Ihre Sprache...',
            'copyright' => '&copy 2014 by',
            'clicktoexpand' => 'Klicken Sie hier...',
            'csharp_vbnet' => 'C# &amp; VB.NET &amp;.NET Core',
            'currentday' => 'Aktueller Tag',            
            // d            
            'date' => 'Date',
            'ddapi' => 'APIs',
            'ddextapi' => 'Externe APIs',
        	'dependencies' => 'Abh&auml;ngigkeiten',
            'searchdate' => 'Gesuchtes Datum',
            'documents' => 'Documents',
        	'done' => 'Erledigt',
            'download' => 'Download',
            'downloads' => 'Downloads',
            'download_news' => 'Downloads',
            // e
            'edit' => 'Editieren',
        	'elements' => 'Elemente',
            'extended' => 'Erweitert',
            'email' => 'E-Mail',
            'env' => 'Arbeitsumgebung',
            'envm' => 'Arbeitsumgebung',
            'environment' => 'Arbeitsumgebung',
            'error' => 'Fehler',
            'event_news' => 'Termin Neuigkeiten',
            // f
            'feeds' => 'RSS Feeds',
            'firstname' => 'Vorname',
            'fileuploaded' => 'Dokument(e) erfolgreich hochgeladen.',
            'forum' => 'Forum',
            'forums' => 'Foren',
            // g
            'games' => 'Spiele',
            'gamesm' => 'Spiele',
        	'generate' => 'Generiere',
            'geolocateip' => 'Geologischer Standort',
            'getroute' => 'Suche Route',
            'gohome' => ' um diese Homepage zu betreten.',
            'politic' => 'Politik',
            // h
            'help' => 'Hilfe',
            'hits' => 'Treffer',
            'home' => 'Index Seite',
            'homepage' => 'Homepage',
            'howaction' => 'Wie bist Du auf diese Aktion aufmerksam geworden ?',
            // i
            'issend' => 'ist versendet worden',
            'index' => 'Inhaltsverzeichnis',
            'info' => 'Info',
            'indexpage' => 'Alle Themen',
            'information' => 'Informationen',
        	'init' => 'Initialisiere',
            'internalsearch' => 'Interne Suche',
            'imprint' => 'Impressum',
            'iplocation' => 'Ihr Verbindung',
            'isp' => 'ISP',
            'ispm' => 'ISP',
            // j
            'java_c_c_plus_plus' => 'Java C C++',
            'javascript_sapui_nodejs' => 'Javascript SapUI NodeJS',
            'csharp_vbnet' => 'C# &amp; VB.NET &amp;.NET Core',
            'search javascript' => 'Javascript Search',
            // l
            'lastname' => 'Nachname',
            'languagequestion	' => 'Welche Sprachen beherrschst du ?',
            'languageISO' => 'German',
            'language' => 'Sprache',
        	'loading' => 'Lade',
            'location' => 'Standort',
            'login' => 'Login',
            'loggedin' => 'Erfolgreich eingeloggt.',
            'logout' => 'Logout',
            'links' => 'Links',        
            'List' => 'Liste',
        	'listofforums' => 'Liste aller Themen',
            // m
            'mediaclips' => 'Medien Clips',
            'mediamenu' => 'Medien Men&uuml;',
            'member' => 'Mitglied',
            'members' => 'Mitglieder',
            'menu' => 'Menu',
            'media' => 'Media',
            'message' => 'Nachricht',
            
            'more' => 'mehr',
            'more links' => 'mehr Links',
            
            'movie' => 'Film',
            'movies' => 'Filme',
            'music' => 'Musik',
            'music_news' => 'Musik Neuigkeiten',
            
            // n
            'name' => 'Name',
            'naspnet' => 'ASP .NET',
            'nbilder' => 'Bilder',
            'ncalendar' => 'Kalender',
            'ncode' => 'Source Code',
            'next' => 'N&auml;chste',
            'nentertain' => 'Unterhaltung',
            'nextpage' => 'N&auml;chste&nbsp;Seite',
            'new' => 'Neu',
            'news' => 'Neues',
            'nneues' => 'Neues',
            'newest' => 'Neueste',
            'news_security' => 'News & Security',
        	'nevents' => 'Events',
    		'nsecurity' => 'Security',
            'ndownloads' => 'Downloads',
            'ngames_all' => 'Spiele',            
            'nmedia' => 'Medien',
            'nnews' => 'Neues',
            'nsoftware' => '3rd Party Downloads',
            'nspiele' => 'Spiele',
    		'ncheats' => 'Cheats',
    		'nall' => 'Alle',
            'napp' => 'Applikation',
            'nc_plus_plus' => 'C++',
            'njava' => 'Java',
            'nhtml5' => 'HTML5',
            'njavascript' => 'Javascript',
            'ncsharp' => 'C#',
            'nsapui' => 'SAP',
            'nplsql' => 'PL/SQL',
            'npython' => 'Python',
            'ncharts' => 'Charts',
            'nhyperlinks' => 'Hyperlinks',
        	'nlinks' => 'Links',
            'npolitik' => 'Politik und Nachrichten',
        	'nmedien' => 'Multimedia',
    		'nmusic' => 'Music',
            'not' => 'Nicht',
            'notfound' => 'Nicht gefunden.',
            'nrss' => 'RSS Feeds',
            'nspiele_cheats' => 'Game Cheats',
            'notsend' => 'Nicht gesendet',
        	'nscience' => 'Wissenschaft und Technik',
        	'nsport' => 'Sport',        	
            'nohits' => 'Keine Treffer',
            'nvideo_clips' => 'Video Clips',
            'nxbox' => 'Konsolen Xbox, PS, WII und mehr',
            'nvisualbasicscript' => 'Visual Basic Script',
            'nwitze' => 'Witze',
            // o
            'openlinklabel' => 'Umleitung in',
            'openlinkmsg' => 'Sie werden in 60 Sekunden automatisch umgeleitet',
            'os' => 'Betriebssystem',
            'or' => 'or',
            'options' => 'Einstellungen',
            'other_downloads' => 'andere Downloads',
            // p
            'page' => 'Seite',
            'pages' => 'Seiten',
            'phone' => 'Telefon',
            'password' => 'Passwort',
            'pictures' => 'Bilder',
            'platform' => 'Platform',
        	'pleasewait' => 'Bitte warten',
            'pleasetypesearchpattern' => 'Bitte geben Sie einen Suchbegriff ein...',
            'pl_sql' => 'PL SQL',
            'projects' => 'Projekte',
            'products' => 'Produkte',
            'profile' => 'Profile',
            'profil' => 'Profil',
            'provider' => 'Provider',
            'previous' => 'Vorherige',
            'previouspage' => 'Seite&nbsp;Zur&uuml;ck',
            'plugins' => 'Plugins',
            'politic_sport' => 'Politik &amp; Sport',
            'politicarticle' => 'Politik Artikel',
            'postmessage' => 'Nachricht versenden',
            // q
            // r
            'reading' => 'Lese',
            'readmore' => 'Mehr lesen',
            'redirectmsg' => 'Automatische Weiterleitung in',
            'redirectin' => 'Weiterleitung erfolgt in',
            'register' => 'registrieren',
            'registeruser' => 'Benutzer registrieren',
            'repeat' => 'Wiederholen',
            'register' => 'Registrieren',
            'registration' => 'Registrierung',
            'route' => 'Route',
            'replyto' => 'Antwort an',
            'rssfeeds' => 'RSS Schlagzeilen',
            'rss_feeds' => 'RSS Feeds',
            // s
            'savepassword' => 'Passwort speichern',
            'science' => 'Wissenschaft',
            'science_news' => 'Neues aus der Wissenschaft',
            'seconds' => 'Sekunden',
            'search' => 'Suchen',
            'settings' => 'Einstellungen',
            'security' => 'Sicherheit',
            'showmemore' => 'Zeig mir mehr...',
            'signout' => 'Ausloggen',
            'sport' => 'Sport',
            'successfully' => 'Erfolgreich',
            'support' => 'Unterst&uuml;tzung',
            'submit' => 'Absenden',
            'status' => 'Status',
            'searchingfor' => 'Suche nach',
            'software' => 'Software',
            'startpage' => 'Startseite',
            'subject' => 'Subjekt',
            'send' => 'versenden',
            'size' => 'Gr&ouml;&szlig;e',
            'source' => 'Quelle',
            'sourcecode' => 'Quelletext',
            'start' => 'Start',
            'startpage' => 'Startseite',
            // t
            'tags' => 'Tags',
            'tagsm' => 'Tags',
            'title' => 'Titel',
            'titletext' => 'Suchen und finden...',
            'timestamp' => 'Zeitstempel',
            'tools' => 'Werkzeuge',
            'toolsm' => 'Werkzeuge',
            'top' => 'Oben',
            'topage' => 'Zur Seite',
            'translate' => '&Uuml;bersetzen',
            'trip' => 'Trips',
            'tryagain' => 'Bitte versuchen Sie es erneut.',
            'trynextpage' => 'Bitte versuchen Sie die n&auml;chste Seite',
            'tv' => 'TV Fernsehen',
            'tv_radio' => 'Fernsehen und Radio',
            // u
            'user' => 'Benutzer',
            'unknown' => 'Nicht bekannt.',
            'upload' => 'Hochladen',
            'university' => 'Universit&auml;t',
            'up' => 'Oben',
            // v
            'videoclips' => 'VideoClips',
            'videoofday' => 'Video des Tages',
            'videos_movies' => 'Videos & Movies',
            // w
            'wrong' => 'Wrong',
            'welcome' => 'Willkommen',
            // x
            // y
            'your' => 'Ihr',
            'yourip' => 'Deine IP'
        )
    );

    public function getMessages()
    {
        return $this->messages;
    }
}
global $LANG;
global $messages;
$LANG = "de_DE";
if (! empty($_REQUEST["l"]) && $_REQUEST["l"] == "de_DE") {
    $LANG = 'de_DE';
}
if (! empty($_REQUEST["l"]) && $_REQUEST["l"] == "en_US") {
    $LANG = 'en_US';
}
foreach ($env["uri"]["uri"] as $v) {
    if ($v == "l=de_DE") {
        $LANG = 'de_DE';
    }
    if ($v == "value1=de_DE") {
        $LANG = 'de_DE';
    }
    if ($v == "l=en_US") {
        $LANG = 'en_US';
    }
}

// z
function msg($s)
{
    global $LANG;
    global $messages;
    $_lang = new Language();
    $messages = $_lang->getMessages();
    $LANG = setLanguage($LANG);
    // get message
    if (isset($messages[$LANG][$s])) {
        return $messages[$LANG][$s];
    } else {
        error_log("l10n-Fehler: SPRACHE: $LANG, Meldung: ");
        return $s;
    }
    // Default Language ------------------------------------------------->
}

function setLanguage($LANG)
{
    $LANG = isset($_REQUEST["l"]) ? $_REQUEST["l"] : "de_DE";
    $LANG = isset($_REQUEST["value1"]) && $_REQUEST["value1"] == "de_DE" ? "de_DE" : $LANG;
    $LANG = isset($_REQUEST["value1"]) && $_REQUEST["value1"] == "en_US" ? "en_US" : $LANG;
    // $URI = preg_replace ( '@/((\&)?PHPSESSID=[a-zA-Z0-9]+(\&)?)/i@', "", $_SERVER ['REQUEST_URI'] );
    if (strpos($_SERVER['REQUEST_URI'], 'l=de_DE') !== false) {
        $LANG = 'de_DE';
    }
    if (strpos($_SERVER['REQUEST_URI'], 'l=en_US') !== false) {
        $LANG = 'en_US';
    }
    if (empty($LANG)) {
        $LANG = 'de_DE';
    }
    switch (isset($LANG) ? $LANG : "de_DE") {
        case "de":
            $LANG = 'de_DE';
            break;
        case "DE":
            $LANG = 'de_DE';
            break;
        case "de_DE":
            $LANG = 'de_DE';
            break;
        case "en":
            $LANG = 'en_US';
            break;
        case "US":
            $LANG = 'en_US';
            break;
        case "en_US":
            $LANG = 'en_US';
            break;
        default:
            $LANG = 'de_DE';
            break;
    }
    return $LANG;
}
