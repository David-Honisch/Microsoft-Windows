<?PHP
if(file_exists("./include/mobile/mobile_device_detect.php")){
	require_once("./include/mobile/mobile_device_detect.php");
}
$mobile = mobile_device_detect();
//echo $env["docrootUrl"];
//echo "Out:".$mobile[1];
if (!empty($mobile))
{
	if (isset($mobile[0]))
	{
		if ($mobile[0] == true)
		{
			if (!empty($mobile[1]))
			{
				//echo "Location: ..".$env["docrootUrl"]."mobile/index.php?".$mobile[1];
				//header("Location: ../mobile/index.php?webbrowser="+$mobile[1]);
				header("Location: ..".$env["docrootUrl"]."mobile/index.php?browser=".$mobile[1]);
				exit;
			}
			else
			{
				header("Location: ..".$env["docrootUrl"]."mobile/index.php");
				exit;
			}
		}
	}
}

?>