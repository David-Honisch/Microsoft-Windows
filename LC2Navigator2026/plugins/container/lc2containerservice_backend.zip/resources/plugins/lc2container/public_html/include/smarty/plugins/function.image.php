<?php

/*
 * Smarty plugin
 * -------------------------------------------------------------
 * Type:     function
 * Name:     image
 * Version:  1.0
 * Date:     Novemeber 2, 2002
 * Purpose:	displays an image tag according to the settings, 
 *			features: size limits (width, height), underscript, link
 *       
 * Install:  Drop into the plugin directory
 * Author:   Peter Dudas <duda at bigfish dot hu>
 * -------------------------------------------------------------
 *		CHANGES: 	2002.09.25		- created
 *		CHANGES: 	2003.01.13		- bugfixes, new optional parameters
 *
 */

function smarty_function_image($params, &$smarty)
{
/*	parameters
+ function parameters
	src		- source
	sign	- undertitle
	signvalign	- position of the sign	(top/bottom)
	singClass - class of the sign script
	link	- link to be put on the image	(imglink)
	doLink	- if set and empty, no link will be added even if link (eg. javascript:go(realUrl)) is set (see example)
	target	- link target

	prefix		- if the string was not empty print BEFORE the first char
	postfix		- if the string was not empty print AFTER the last char
	emptytext	- text to print if no image is to display

	width
	height
	maxWidth
	maxheight
	tableWidth
	extra2

+direct html parameters
	//extra	- extra tag to added to the image
	vspace
	hspace
	class
	align			// 1-left, 2-center, 3-right OR left right
	cellpadding		// for the containing table
	alt	
	border
	
example:

<{image src=$cblock.pic.url align=$cblock.pic.align height=$cblock.pic.h width=$cblock.pic.w doLink=$cblock[pic][url] link="javascript:nagyito('".$cblock[pic][url]."');"}>
	
*/

	// START INIT	
	$tablewidth = '10';
	$vspace = 5;
	$hspace = 5;
	$cellpadding = 5;
	$border = '0';


	foreach($params as $key=>$value)	{
		$tmps[strtolower($key)] = $value;
	}	
	unset($params);
	extract($tmps);

	// START DATA CHECKING (size)
	if (empty($src)) {
		if (isset($emptytext))	{
			print $emptytext;
		}
		return '';
	}
	
	// parameter names where single value is expected, but key="value" received
	$tmps = array('align', 'src', 'width', 'height', 'alt');
	foreach($tmps as $tmp)	{
		if (!empty($$tmp))	{
			if (preg_match('/\s*'.$tmp.'+=[\'"]?([^\'"]*)[\'"]?\s*/', $$tmp, $matches))	{
				$$tmp = $matches[1];
			}
		}
	}
	
	if (!empty($align)) {
		if ($align == '3')	{
			$align = 'right';
		} elseif ($align == '1')	{
			$align = 'left';
		}
	} else	{
		$align = 'left';
	}
	$align = ' align="'.$align.'"';

	if (!empty($sign))	{
		$_isSign = TRUE;
	} else	{
		$_isSign = FALSE;
	}

	// END INIT

	if (!empty($prefix))	{
		print $prefix;
	}
	
	if (($maxwidth > 0) AND (!empty($width)))	{
		if ($cellpadding > 0) 	{
			$maxwidth -= 2*$cellpadding;
		}	
		if ($hspace > 0) {
			$maxwidth -= 2*$hspace;
		}	

		if (($width > 0) AND ($width > $maxwidth))	{
			$height = floor(($maxwidth/$width) * $height);
			$width = $maxwidth;
		}
	}
	if (($maxheight > 0) AND (!empty($height)))	{
		if ($cellpadding > 0)	{
			$maxheight -= (2*$cellpadding);
		}	
		if ($vspace > 0)	{
			$maxwidth -= 2*vspace;
		}	
		if (($height>0) AND ($height>$maxheight))	{
			$width = floor(($maxheight/$height) * $width);
			$height = $maxheight;
		}
	}
	//  hogy a szoveg a kulso befoglalo tablaban ne keruljon a kep ala
	// 100 pixel a minimalis szukseges resz a szovegnek hagyva

	if (($maxwidth > 0) AND (($maxwidth-100) < $width))	{
		unset($align);
	}

	if (isset($params['doLink']))	{
		unset($link);
	}
	
	// END CHECK
	
	if ($_isSign == TRUE)	{
		print '<table'.$align.'width="'.$tableWidth.'" cellpadding="'.$cellpadding.'" cellspacing=0 border='.$border.'>';
		if ($signvalign == 'top')	{
				print '<tr><td align="center"><span'.($signclass ? ' class="'.$signclass.'"' : '').'>'.$sign.'</span></td></tr>';
		}
		print '<tr><td'.$align.'>';
		unset($align);
	}


	$tmp = $align.($width ? ' width="'.$width.'"' : '').($height ? ' height="'.$height.'"' : '').($class ? ' class="'.$class.'"' : '');
	$tmp .= ($vspace ? ' vspace="'.$vspace.'"' : '').($hspace ? ' hspace="'.$hspace.'"' : '');
	$tmp .= ($alt ? ' alt="'.$alt.'"' : '');
	

	if (!empty($link) AND ($link != 'http://')) {
		print '<a href="'.$link.'"'.($target ? ' target="'.$target.'"' : '').'><img src="'.$src.'"'.$tmp.'" border='.$border.' /></a>';
	} else 			{
		print '<img src="'.$src.'"'.$tmp.'" border="'.$border.'" />';
	}
	if ($_isSign == TRUE) {
		print '</td></tr>';
		if ($signvalign != 'top') 	{
				print '<tr><td align="center"><span'.($signclass ? ' class="'.$signclass.'"' : '').'>'.$sign.'</span></td></tr>';
		}
		print '</table>'."\n";
	}
	if (!empty($postfix))	{
		print $postfix;
	}
}





?>
