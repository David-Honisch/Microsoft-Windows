<?php

namespace org\letztechance\SqlImport;

use PDO;
use Exception;
use Error;

/**
 * PDO class to import sql from a .sql file
 * adapted from thamaraiselvam's import-database-file-using-php class https://github.com/thamaraiselvam/import-database-file-using-php
 */
class Import
{
    private $filename;
    private $forceDropTables;
    private $conn;

    /**
     * instanciate
     * @param $filename string name of the file to import
     * @param $username string database username
     * @param $password string database password
     * @param $database string database name
     * @param $host string address host localhost or ip address
     * @param $dropTables boolean When set to true delete the database tables
     * @param $forceDropTables boolean [optional] When set to true foreign key checks will be disabled during deletion
     */
    public function __construct($filename, $conn, $database, $dropTables, $forceDropTables = false)
    {
        //set the varibles to properties
        $this->filename = $filename;
        $this->conn = $conn;
        $this->forceDropTables = $forceDropTables;

        //connect to the datase
        $this->connect();

        // //if dropTables is true then delete the tables
        // if ($dropTables == true) {
        //     $this->dropTables();
        // }

        // //open file and import the sql
        // $this->openfile();
    }

    public function import()
    {
        //set the varibles to properties
        //connect to the datase
        $this->connect();

        //if dropTables is true then delete the tables
        if ($this->forceDropTables == true) {
            $this->dropTables();
        }

        //open file and import the sql
        return $this->openfile();
    }



    /**
     * Connect to the database
     */
    private function connect()
    {
        $result = [];
        try {
            $sql = "SELECT * FROM INFORMATION_SCHEMA.INNODB_SYS_TABLES";
            //$sql = "show TABLES;";
            $i = 0;
            $res = $this->conn->query($sql);
            if ($res->num_rows > 0) {
                $result[$i++] = "Successfully conntected.";
            } else {
                $result["results"] = "0 results";
            }
        } catch (Exception $e) {
            echo "Cannot connect: " . $e->getMessage() . "\n";
        }
    }

    /**
     * run queries
     * @param string $query the query to perform
     */
    private function query($query)
    {
        try {
            return $this->conn->query($query);
        } catch (Error $e) {
            echo "Error with query: " . $e->getMessage() . "\n";
        }
    }

    /**
     * Select all tables, loop through and delete/drop them.
     */
    private function dropTables()
    {
        //get list of tables
        $tables = $this->conn->query('SHOW TABLES');

        if ($tables != null) {
            //loop through tables
            foreach ($tables->fetchAll(PDO::FETCH_COLUMN) as $table) {
                if ($this->conn->forceDropTables === true) {
                    //delete table with foreign key checks disabled
                    $this->conn->query('SET FOREIGN_KEY_CHECKS=0; DROP TABLE `' . $table . '`; SET FOREIGN_KEY_CHECKS=1;');
                } else {
                    //delete table
                    $this->conn->query('DROP TABLE `' . $table . '`');
                }
            }
        }
    }

    /**
     * Open $filename, loop through and import the commands
     */
    private function openfile()
    {
        $result = [];
        try {

            //if file cannot be found throw errror
            if (!file_exists($this->filename)) {
                throw new Exception("Error: File not found.\n");
            }

            // Read in entire file
            $fp = fopen($this->filename, 'r');

            // Temporary variable, used to store current query
            $templine = '';

            // Loop through each line
            $i = 0;
            while (($line = fgets($fp)) !== false) {

                // Skip it if it's a comment
                if (substr($line, 0, 2) == '--' || $line == '') {
                    continue;
                }

                // Add this line to the current segment
                $templine .= $line;
                $result[$i++] = $templine;

                // If it has a semicolon at the end, it's the end of the query
                if (substr(trim($line), -1, 1) == ';') {
                    $this->conn->query($templine);

                    // Reset temp variable to empty
                    $templine = '';
                }
            }

            //close the file
            fclose($fp);
        } catch (Exception $e) {
            echo "Error importing: " . $e->getMessage() . "\n";
        }
        return $result;
    }
}
