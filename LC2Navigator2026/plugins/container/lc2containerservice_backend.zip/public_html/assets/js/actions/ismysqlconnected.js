  var url = "/view/index.php";
  var infoAPI = "http://localhost/webservices/client.php?q=getFullIndexJSON";
  //   $('#out').html("running...")
  $("#out").load("/view/fragments/mysqlconnect.php");
  $("#out").load(url, function(responseTxt, statusTxt, xhr) {
      if (statusTxt == "success")
          $('#out').append(".");
      if (statusTxt == "error")
          $('#out').append("Error: " + xhr.status + ": " + xhr.statusText);
  });
  //   $.get(url, function(data, status) {
  //       $('#out').append("Data: " + data + "\nStatus: " + status);
  //   });
  $.get(infoAPI + "&value1=test&value2=test", function(data, status) {
      var result = "";
      var json = JSON.parse(data);
      result += "<select>";
      for (var v in json["list"]) {
          if (json["list"][v]["name"] !== undefined)
              result += "<option>" + json["list"][v]["name"] + "</option>";
      }
      result += "</select>";
      //$('#out').append("infoAPI Data: " + data + "\nStatus: " + status);
      $('#out').append("" + result + "\nStatus: " + status);
  });
  $("#postbutton").click(function() {
      $.post(infoAPI, {
              q: "getFullIndexJSON",
              value1: "Donald+Duck",
          },
          function(data, status) {
              $('#out').append("Data: " + data + "\nStatus: " + status);
          });
      $.get(infoAPI + "&value1=test&value2=test", function(data, status) {
          $('#out').append("infoAPI Data: " + data + "\nStatus: " + status);
      });
  });