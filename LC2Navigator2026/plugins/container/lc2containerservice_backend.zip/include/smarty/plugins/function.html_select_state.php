<?php
/*
 * Smarty plugin
 * -------------------------------------------------------------
 * Type:     function
 * Name:     html_select_state
 * Version:  1.0
 * Purpose:  Prints the dropdowns for states selection.
 * Author:   Matthieu Le goff <tubbix@free.fr>
 *
 * ChangeLog: 1.0 initial release
 * -------------------------------------------------------------
 */
require_once $this->_get_plugin_filepath('function','html_options');
function smarty_function_html_select_state($params, &$smarty)
{
    /* Set the name of the <select> tag. */
    $name  = "State";

    /* Set the different type of states
       us = US states
       uk = UK counties
       fr = FR departements */
    $type  = "us";
    
    /* <select size>'s of <select> tag.
       If not set, uses default dropdown. */
    $size  = null;

    /* Unparsed attributes common to *ALL* the <select>/<input> tags.
       An example might be in the template: extra ='class ="foo"'. */
    $extra = null;


    extract($params);


    $us = array(
         'ak' => 'Alabama',
         'al' => 'Alaska',
         'ar' => 'Arizona',
         'az' => 'Arkansas',
         'ca' => 'California',
         'co' => 'Colorado',
         'ct' => 'Connecticut',
         'de' => 'Delaware',
         'dc' => 'District of Columbia',
         'fl' => 'Florida',
         'ga' => 'Georgia',
         'hi' => 'Hawaii',
         'id' => 'Idaho',
         'il' => 'Illinois',
         'in' => 'Indiana',
         'ia' => 'Iowa',
         'ks' => 'Kansas',
         'ky' => 'Kentucky',
         'la' => 'Louisiana',
         'ma' => 'Maine',
         'md' => 'Maryland',
         'ma' => 'Massachusetts',
         'mi' => 'Michigan',
         'mn' => 'Minnesota',
         'ms' => 'Mississippi',
         'mo' => 'Missouri',
         'mt' => 'Montana',
         'ne' => 'Nebraska',
         'nv' => 'Nevada',
         'ne' => 'New England',
         'nh' => 'New Hampshire',
         'nj' => 'New Jersey',
         'nm' => 'New Mexico',
         'ny' => 'New York',
         'nc' => 'North Carolina',
         'nd' => 'North Dakota',
         'oh' => 'Ohio',
         'ok' => 'Oklahoma',
         'or' => 'Oregon',
         'pa' => 'Pennsylvania',
         'ri' => 'Rhode Island',
         'sc' => 'South Carolina',
         'sd' => 'South Dakota',
         'tn' => 'Tennessee',
         'tx' => 'Texas',
         'ut' => 'Utah',
         'vt' => 'Vermont',
         'va' => 'Virginia',
         'wa' => 'Washington',
         'wv' => 'West Virginia',
         'wi' => 'Wisconsin',
         'wy' => 'Wyoming'
    );
    
    $uk = array(
        'Aberdeenshire',
        'Angus',
        'Argyll',
        'Avon',
        'Ayrshire',
        'Banffshire',
        'Bedfordshire',
        'Berkshire',
        'Berwickshire',
        'Buckinghamshire',
        'Caithness',
        'Cambridgeshire',
        'Cheshire',
        'Clackmannanshire',
        'Cleveland',
        'Clwyd',
        'Cornwall',
        'county',
        'County Antrim',
        'County Armagh',
        'County Down',
        'County Durham',
        'County Fermanagh',
        'County Londonderry',
        'County Tyrone',
        'Cumbria',
        'Derbyshire',
        'Devon',
        'Dorset',
        'Dumfriesshire',
        'Dunbartonshire',
        'Dyfed',
        'East Lothian',
        'East Sussex',
        'Essex',
        'Fife',
        'Gloucestershire',
        'Gwent',
        'Gwynedd',
        'Hampshire',
        'Herefordshire',
        'Hertfordshire',
        'Inverness-shire',
        'Isle of Arran',
        'Isle of Barra',
        'Isle of Bute',
        'Isle of Canna',
        'Isle of Coll',
        'Isle of Colonsay',
        'Isle of Cumbrae',
        'Isle of Eigg',
        'Isle of Gigha',
        'Isle of Harris',
        'Isle of Iona',
        'Isle of Islay',
        'Isle of Jura',
        'Isle of Lewis',
        'Isle of Mull',
        'Isle of North Uist',
        'Isle of Orkney',
        'Isle of Rhum',
        'Isle of Skye',
        'Isle of South Uist',
        'Isle of Tiree',
        'Isle of Wight',
        'Isles of Scilly',
        'Kent',
        'Kincardineshire',
        'Kirkcudbrightshire',
        'Lanarkshire',
        'Lancashire',
        'Leicestershire',
        'Lincolnshire',
        'Merseyside',
        'Middlesex',
        'Mid Glamorgan',
        'Midlothian',
        'Morayshire',
        'Norfolk',
        'Northamptonshire',
        'North Humberside',
        'Northumberland',
        'North Yorkshire',
        'Nottinghamshire',
        'Orkney',
        'Oxfordshire',
        'Peeblesshire',
        'Perthshire',
        'Powys',
        'Renfrewshire',
        'Ross-shire',
        'Roxburghshire',
        'Selkirkshire',
        'Shetland Islands',
        'Shropshire',
        'Somerset',
        'South Glamorgan',
        'South Humberside',
        'South Yorkshire',
        'Staffordshire',
        'Stirlingshire',
        'Suffolk',
        'Surrey',
        'Sutherland',
        'Tyne and Wear',
        'Warwickshire',
        'West Glamorgan',
        'West Lothian',
        'West Midlands',
        'West Sussex',
        'West Yorkshire',
        'Wigtownshire',
        'Wilts',
        'Wiltshire',
        'Worcestershire'
  	);
  	
  	$fr = array(
  	    '01' => 'Ain',
        '02' => 'Aisne',
        '03' => 'Allier',
        '04' => 'Alpes de-Htes Provence',
        '05' => 'Hautes-Alpes',
        '06' => 'Alpes-Maritimes',
        '07' => 'Ard�che',
        '08' => 'Ardennes',
        '09' => 'Ari�ge',
        '10' => 'Aube',
        '11' => 'Aude',
        '12' => 'Aveyron',
        '13' => 'Bouches-du-Rh�ne',
        '14' => 'Calvados',
        '15' => 'Cantal',
        '16' => 'Charente',
        '17' => 'Charente-Maritime',
        '18' => 'Cher',
        '19' => 'Corr�ze',
        '21' => 'C�te d\'Or',
        '22' => 'C�tes d\'Armor',
        '23' => 'Creuse',
        '24' => 'Dordogne',
        '25' => 'Doubs',
        '26' => 'Dr�me',
        '27' => 'Eure',
        '28' => 'Eure-et-Loir',
        '29' => 'Finist�re',
        '2A' => 'Corse du Sud',
        '2B' => 'Hautes-Corse',
        '30' => 'Gard',
        '31' => 'Hautes-Garonne',
        '32' => 'Gers',
        '33' => 'Gironde',
        '34' => 'H�rault',
        '35' => 'Ille-et-Vilaine',
        '36' => 'Indre',
        '37' => 'Indre-et-Loire',
        '38' => 'Is�re',
        '39' => 'Jura',
        '40' => 'Landes',
        '41' => 'Loir-et-Cher',
        '42' => 'Loire',
        '43' => 'Hautes-Loire',
        '44' => 'Loire-Atlantique',
        '45' => 'Loiret',
        '46' => 'Lot',
        '47' => 'Lot-et-Garonne',
        '48' => 'Loz�re',
        '49' => 'Maine-et-Loire',
        '50' => 'Manche',
        '51' => 'Marne',
        '52' => 'Haute-Marne',
        '53' => 'Mayenne',
        '54' => 'Meurthe-et-Moselle',
        '55' => 'Meuse',
        '56' => 'Morbihan',
        '57' => 'Moselle',
        '58' => 'Ni�vre',
        '59' => 'Nord',
        '60' => 'Oise',
        '61' => 'Orne',
        '62' => 'Pas-de-Calais',
        '63' => 'Puy-de-D�me',
        '64' => 'Pyr�n�es-Atlantiques',
        '65' => 'Hautes-Pyr�n�es',
        '66' => 'Pyr�n�es',
        '67' => 'Bas-Rhin',
        '68' => 'Haut-Rhin',
        '69' => 'Rh�ne',
        '70' => 'Hautes-Sa�ne',
        '71' => 'Sa�ne-et-Loire',
        '72' => 'Sarthe',
        '73' => 'Savoie',
        '74' => 'Hautes-Savoie',
        '75' => 'Paris',
        '76' => 'Seine-Maritime',
        '77' => 'Sein-et-Marne',
        '78' => 'Yvelines',
        '79' => 'Deux-S�vres',
        '80' => 'Somme',
        '81' => 'Tarn',
        '82' => 'Tarn-et-Garonne',
        '83' => 'Var',
        '84' => 'Vaucluse',
        '85' => 'Vend�e',
        '86' => 'Vienne',
        '87' => 'Hautes-Vienne',
        '88' => 'Vosges',
        '89' => 'Yonne',
        '90' => 'Territoire de Belfort',
        '91' => 'Essonne',
        '92' => 'Hauts-de-Seine',
        '93' => 'Seine-St-Denis',
        '94' => 'Val de Marne',
        '95' => 'Val d\'Oise',
        '971' => 'Guadeloupe',
        '972' => 'Martinique',
        '973' => 'Guyane',
        '974' => 'R�union'
   );
  	
    $html_result .= '<select name="' . $name . '"';
    if (null !== $size){
        $html_result .= ' size="' . $size . '"';
    }
    if (null !== $extra){
        $html_result .= ' ' . $extra;
    }

    $html_result .= '>'."\n";
    
    $states_names = array();
    $states_values = array();
    
    if ($type == "us") {
        foreach ($us as $key => $value) {
            $states_names[] = $value;
            $states_values[] = $key;
        }
    }
    else if ($type == "uk") {
        foreach ($uk as $value) {
            $states_names[] = $value;
            $states_values[] = $value;
        }
    }
    if ($type == "fr") {
        foreach ($fr as $key => $value) {
            $states_names[] = $value;
            $states_values[] = $key;
        }
    }
    
    $html_result .= smarty_function_html_options(array('output'       => $states_names,
                                                       'values'       => $states_values,
                                                       'print_result' => false),
                                                       $smarty);
    
    $html_result .= '</select>';

    print $html_result;
}

?>
