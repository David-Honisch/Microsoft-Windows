<?php

/*
 * Smarty plugin
 * -------------------------------------------------------------
 * Type:     function
 * Name:     pagerabc
 * Purpose:  displays selection links (eg: filter according the abc)
 * Version:  1.0
 * Date:     September 25, 2002
 * Purpose:  print out
 * Install:  Drop into the plugin directory
 * Author:   Peter Dudas <duda at bigfish dot hu>
 * -------------------------------------------------------------
 *		CHANGES: 	2002.09.25		- created
 *
 *	example:
 *	code:
 *	<{pagerabc posvar="abc" class_num="dl" class_numon="header" separator="
 *  &nbsp;-&nbsp " names="A,B;C,D;E,F;G,H;I,J;K,L;M,N,O;P,Q,R;S,T;U,V,W,X,Y,Z"}>
 *	
 *  result
 *
 *  <a class="header" href="/egyuttes.php?&abc=A,B">A,B</a>
 *  &nbsp;-&nbsp <a class="dl" href="/egyuttes.php?&abc=C,D">C,D</a>
 *  &nbsp;-&nbsp <a class="dl" href="/egyuttes.php?&abc=E,F">E,F</a>
 *  &nbsp;-&nbsp <a class="dl" href="/egyuttes.php?&abc=G,H">G,H</a>
 *  &nbsp;-&nbsp <a class="dl" href="/egyuttes.php?&abc=I,J">I,J</a>
 *  &nbsp;-&nbsp <a class="dl" href="/egyuttes.php?&abc=K,L">K,L</a>
 *  &nbsp;-&nbsp <a class="dl" href="/egyuttes.php?&abc=M,N,O">M,N,O</a>
 *  &nbsp;-&nbsp <a class="dl" href="/egyuttes.php?&abc=P,Q,R">P,Q,R</a>
 *  &nbsp;-&nbsp <a class="dl" href="/egyuttes.php?&abc=S,T">S,T</a>
 *  &nbsp;-&nbsp <a class="dl" href="/egyuttes.php?&abc=U,V,W,X,Y,Z">U,V,W,X,Y,Z</a></p>
 *
 *
 */
function smarty_function_pagerabc($params, &$smarty)
{
/*	
Parameters
	$posvar			- name of the php variable that contains the position data ($_REQUEST)
	$forwardvars		- comma separated list of php variablenames to forward in the links
	$class_num		- class for the page numbers <A> tag!
	$class_numon		- class for the aktive page!
	$separator		- tags to print between the letters (eg: - )
	$lang			- language
	$names			- values to select from (array or csv)
	$values			- values to select from (array or csv)
	$skin			- use predefined values (hu - hungarian ABC)
*/
	extract($params);
	if (empty($posvar))	{
		die('unset variable posvar in smarty func pagerabc');
	}
	
	if (!empty($names))	{
		if (!is_array($names))	{
			$names = explode(';', $names);
		}
		if (!empty($values))	{
			if (!is_array($values))	{
				$values = explode(';', $values);
			}
		} else	{
			$values = $names;
		}
	} else	{
		// predefined abc
		if ($skin == 'hu') {
			$names = array('A','�','B','C','D','E','�','F','G','H','I','�','J','K','L','M','N','O','�','�','�','P','Q','R','S','T','U','�','�','�','V','W','X','Y','Z');
			$values = array('A','�','B','C','D','E','�','F','G','H','I','�','J','K','L','M','N','O','�','�','�','P','Q','R','S','T','U','�','�','�','V','W','X','Y','Z');
			//$names = array('A'	,'B','C','D','E'	,'F','G','H','I','J','K','L','M','N','O'		,'P','Q','R','S','T','U'	,'V','W','X','Y','Z');
			//$values = array('A,�','B','C','D','E,�','F','G','H','I,�','J','K','L','M','N','O,�,�,�','P','Q','R','S','T','U,�,�,�','V','W','X','Y','Z');
		} else	{	
			$names = array('A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U'	,'V','W','X','Y','Z');
			$values = array('A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z');
		}
	}

	$pos = $_REQUEST[$posvar];


	if (!is_array($forwardvars))	{
		$forwardvars = preg_split('/[,;]/', $forwardvars);
	}
	$url = $_SERVER['SCRIPT_NAME'].'?';
	foreach ((array)$forwardvars as $tmp)	{
		if (!empty($tmp) AND (!empty($_REQUEST[$tmp])))
			$url .= '&'.$tmp.'='.$_REQUEST[$tmp];
	}
			
	if ($printempty == TRUE)	{
		print '<a href="'.$url.'&'.$posvar.'=">-</a>'.$separator;
	}
	
	if (!empty($class_num))	{
		$tmp = ' class="'.$class_num.'"';
	}
	foreach($names as $i=>$nam) {
		if (!empty($class_numon))	{
			if ($_REQUEST[$posvar] == $values[$i])	{
				$tmp = ' class="'.$class_numon.'"';
			} elseif (!empty($class_num))	{
				$tmp = ' class="'.$class_num.'"';
			}
		}
		if ($i > 0)	{
			print $separator;
		}
		print '<a'.$tmp.' href="'.$url.'&'.$posvar.'='.$values[$i].'">'.$nam.'</a>';
	}
}



?>
