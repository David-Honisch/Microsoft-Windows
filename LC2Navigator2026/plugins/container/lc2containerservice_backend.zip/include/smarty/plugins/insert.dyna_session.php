<?php
/*
 * Smarty plugin
 * -------------------------------------------------------------
 * Type:     insert
 * Name:     dyna_session
 * Purpose:  return session_name and id, dependent on session
 *           cookies. supports a leading string. returns an
 *           an empty string, if cookie could be set.
 * Examples:
 *
 * Append only session to a link, if necessary:
 *   <a href="file.php{insert name=dyna_session lead_by=?}">link</a>
 *
 * Append session to a link with params, if necessary: 
 *   <a href="file.php?a=1&amp;b=2{insert name=dyna_session lead_by=&amp;}">link</a>
 *
 * Author: Norbert R�cher <norbert.roecher@t-online.de>
 * -------------------------------------------------------------
 */

function smarty_insert_dyna_session($params)
{
    static $session;

    if (!isset($session)){
        $session = ((!$GLOBALS['HTTP_COOKIE_VARS']) ? session_name().'='.session_id():'');
    }

    if (isset ($params['lead_by']) && $session != ''){
        return $params['lead_by'].$session;
    }

    return $session;
}
/* vim: set expandtab: */
?>
