<?PHP
class MobileDeviceDetect
{
	public static function isMobileDevice($env)
	{
		$result["isMobile"] = false;
		$result["mobileUrl"] = "";
		//echo "Debug:!!";
		if(file_exists($env["include"]."mobile/mobile_device_detect.cls.php"))
		{
			//echo "Debug:";
			require_once($env["include"]."mobile/mobile_device_detect.cls.php");
		}
		$mobile = mobile_device_detect();
		//$mobile[0] = true;
		//$mobile[1] = "android";
		
		//
		$result["mobile"] = $mobile;
		if (!empty($mobile))
		{
			if (isset($mobile[0]))
			{
				if ($mobile[0] == true)
				{
					if (!empty($mobile[1]))
					{
						//header("Location: ..".$env["docrootUrl"]."mobile/index.php?browser=".$mobile[1]);
						$result["isMobile"] = true;
						$result["mobileUrl"] = $env["docrootUrl"]."mobile/index.php?browser=";
						//exit;
					}
					else
					{
						//header("Location: ..".$env["docrootUrl"]."mobile/index.php");
						$result["isMobile"] = false;
						$result["mobileUrl"] = $env["docrootUrl"]."mobile/index.php?browser2=";
						//exit;
					}
				}
			}
		}
		//$result["isMobile"] = true;
		return $result;
	}
}
?>