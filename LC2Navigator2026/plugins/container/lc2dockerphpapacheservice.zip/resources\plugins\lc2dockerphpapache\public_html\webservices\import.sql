select '<h1>Imporing data...</h1>';
use dbtest;
SET NAMES utf8;
SET time_zone = '+00:00';
SET foreign_key_checks = 0;
SET sql_mode = 'NO_AUTO_VALUE_ON_ZERO';
select 'Imporing data...';
DROP TABLE IF EXISTS `dbusers`;
CREATE TABLE `dbusers` (`id` int(20) NOT NULL AUTO_INCREMENT, `user` varchar(255) NOT NULL, `pass` varchar(255) NOT NULL, `confirmed` tinyint(4) NOT NULL,  `user_level` tinyint(4) NOT NULL,  PRIMARY KEY (`id`)) ENGINE=InnoDB DEFAULT CHARSET=utf8;
INSERT INTO `dbusers` (`id`, `user`, `pass`, `confirmed`, `user_level`) VALUES (1,	'admin',	'$2a$10$N8J5wRMeJ5v6z65btGmZvOYGgkS9kIEbSwon3tMKnxZV9mzkqpwzu',	1,	0);
INSERT INTO `dbusers` (`id`, `user`, `pass`, `confirmed`, `user_level`) VALUES (2,	'administrator',	'$2a$10$N8J5wRMeJ5v6z65btGmZvOYGgkS9kIEbSwon3tMKnxZV9mzkqpwzu',	1,	0);

CREATE TABLE IF NOT EXISTS `links` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `datestamp` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `thread` int(10) unsigned NOT NULL DEFAULT '0',
  `parent` int(10) unsigned NOT NULL DEFAULT '0',
  `author` varchar(37) COLLATE latin1_german2_ci NOT NULL DEFAULT '',
  `subject` varchar(255) COLLATE latin1_german2_ci NOT NULL DEFAULT '',
  `email` varchar(200) COLLATE latin1_german2_ci NOT NULL DEFAULT '',
  `host` varchar(255) COLLATE latin1_german2_ci NOT NULL DEFAULT '',
  `email_reply` char(1) COLLATE latin1_german2_ci NOT NULL DEFAULT 'N',
  `approved` char(1) COLLATE latin1_german2_ci NOT NULL DEFAULT 'N',
  `sid` varchar(10) COLLATE latin1_german2_ci NOT NULL,
  `modifystamp` int(10) unsigned NOT NULL DEFAULT '0',
  `userid` int(10) unsigned NOT NULL DEFAULT '0',
  `closed` tinyint(4) NOT NULL DEFAULT '0',
  `isPHPCode` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `author` (`author`),
  KEY `userid` (`userid`),
  KEY `datestamp` (`datestamp`),
  KEY `subject` (`subject`),
  KEY `thread` (`thread`),
  KEY `parent` (`parent`),
  KEY `approved` (`approved`),
  KEY `msgid` (`sid`),
  KEY `modifystamp` (`modifystamp`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_german2_ci AUTO_INCREMENT=2 ;

CREATE TABLE IF NOT EXISTS `links_attachments` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `message_id` int(10) unsigned NOT NULL DEFAULT '0',
  `filename` char(50) COLLATE latin1_german2_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`id`,`message_id`),
  KEY `lookup` (`message_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_german2_ci AUTO_INCREMENT=4 ;
CREATE TABLE IF NOT EXISTS `links_bodies` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `body` text COLLATE latin1_german2_ci NOT NULL,
  `thread` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `thread` (`thread`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_german2_ci AUTO_INCREMENT=2 ;

INSERT INTO `links` (`id`, `datestamp`, `thread`, `parent`, `author`, `subject`, `email`, `host`, `email_reply`, `approved`, `sid`, `modifystamp`, `userid`, `closed`) VALUES
(1, '2014-07-07 00:00:00', 1, 0, '1', 'Invoke Webservice', 'webmaster@letztechance.org', 'localhost', 'w', 'N', '0', 0, 0, 0);
INSERT INTO `links_bodies` (`id`, `body`, `thread`) VALUES
(1, 'awk -F &acute;;&acute; &acute;{print $1,$2,$3}&acute; ./test.csv', 1);
select 'create regex function...';
DELIMITER $$
CREATE FUNCTION  `regex_replace`(pattern VARCHAR(1000),replacement VARCHAR(1000),original VARCHAR(1000))
RETURNS VARCHAR(1000)
DETERMINISTIC
BEGIN 
 DECLARE temp VARCHAR(1000); 
 DECLARE ch VARCHAR(1); 
 DECLARE i INT;
 SET i = 1;
 SET temp = '';
 IF original REGEXP pattern THEN 
  loop_label: LOOP 
   IF i>CHAR_LENGTH(original) THEN
    LEAVE loop_label;  
   END IF;
   SET ch = SUBSTRING(original,i,1);
   IF NOT ch REGEXP pattern THEN
    SET temp = CONCAT(temp,ch);
   ELSE
    SET temp = CONCAT(temp,replacement);
   END IF;
   SET i=i+1;
  END LOOP;
 ELSE
  SET temp = original;
 END IF;
 RETURN temp;
END$$
DELIMITER ;
select 'create regex function done.';
select 'Imporing data done.';
-- UPDATE `video_clips_bodies`
-- SET `body` = replace(body, './js/plugins/google/ythtml5.js', './assets/js/plugins/google/ythtml5.js');
-- UPDATE `downloads_bodies`
-- SET `body` = replace(body, './upload/dl.php', 'download.letztechance.org/'); 
