<?php 
/**
 * XmlResponseWriter.class.php
 * @version 1.5
 * @author david@honisch.org
 * @package WebWorkbench.php.xml
 *
 * v.1.0	16.07.2012	david@honisch.org	Erstellung
 * v.1.1	20.07.2012	david@honisch.org	Alle Exceptions berichten nun auch, bei Welcher Methode der Fehler auftrat
 * v.1.2	25.07.2012	david@honisch.org	Änderung
 * 								- Zeile 111: Es wird überprüft, ob es tatsächlich Zeilen zum Verarbeiten.
 * 								Dies behebt den Bug bei dem eine Warnung geworfen wurde:
 * 								"Invalid argument supplied for foreach()"
 * v.1.3	20.08.2012	david@honisch.org	Änderung
 * 								- Zeile 196: strip_tags entfernt nun alle HTML-Tags im Falle einer Exception
 * v.1.4	29.08.2012	david@honisch.org	Änderung
 * 								- Neuer bekannter Block-Typ CSV_STRING hinzugefügt.
 * v.1.5	11.06.2013	david@honisch.org	Änderung
 * 								- Neuer bekannter Block-Typ BLF_CUSTOMER hinzugefügt.
 * v.1.6	22.06.2013	david@honisch.org	Änderung
 * 								- Neuer Block-Typ BLF_CALLPLANCONFIG hinzugefügt.
 *
 * Beschreibung
 *
 * Dieses Klasse dient dem erstellen eines XML-Streams der von der Javascript-Klasse
 * XmlResponseReader.class.js verarbeitet werden kann.
 * Die Ausgabe der toString-Methode ist immer XML und hat stets den folgenden Aufbau:
 *
 * state			Bei 0 ist ein Fehler aufgetreten. Bei 1 werden Nutzdaten geliefert
 * statetext		Text, der den Status 0 oder 1 genauer umschreiben soll
 * blockcount	Anzahl der Nutzdatenblöcke. Ein Block enthält immer die Nutzdaten
 * 					einer Operation (z.B. SQl-Statement)
 * block			Enthält wiederum XML-Entitäten. (z.B. Spaltennamen)
 *
 * Jeder Block MUSS ein Attribut "type" aufweisen.
 * Zur Zeit werden folgende Typen unterstüzt:
 *
 * SQL_RESULTSET	Daten sind das Ergebnis einer Datenbankabfrage
 * CSV_STRING		Daten sind ein Kommaseparierter-String
 * FTS_POST			Daten entsprechen einem FTS-Post mit all seinen Feldern
 *
 * <webdata>
 * 	<state>1</state>
 * 	<statetext>Dies ist ein Test</statetext>
 *  <productiondata blockcount="2" type="SQL_RESULTSET>
 *  	<block num="1">
 *  		...
 *  	</block>
 *  	<block num="2">
 *  		...
 *  	</block>
 *  </productiondata>
 * </webdata>
 *
 * Dieses Scripts benutzt die PHP-Klasse XMLWriter.
 * Daher wird PHP5 zwingend vorrausgesetzt!
 *
 */
class XmlResponseWriter{

	private $xmlWriter; //XML-Writer Objekt. (Nur in PHP5 erhältlich)
	private $acceptedBlockTypes = array("SQL_RESULTSET","CSV_STRING","BLF_CUSTOMER","BLF_CALLPLANCONFIG"); //Bekannte Blocktypen
	private $blocks; //Datenstruktur für Blöcke
	private $state; //Status der Response
	private $stateText; //Statustext der Response

	/**
	 * Der Konstruktor eröffnet das XML-Dokument im Speicher der Servers und
	 * aktiviert eine Formatierung mit Zeilenumbrüchen. Der Kopf der XML-Datei
	 * ist fest auf die Version 1.0 mit dem Kodierung UTF-8 und dem Attribut
	 * standalone="yes" eingetragen.
	 *
	 */
	public function __construct(){

		$this->xmlWriter = new xmlWriter();
		$this->xmlWriter->openURI('php://output');
		$this->xmlWriter->startDocument( '1.0' , 'UTF-8', 'yes' );
		$this->xmlWriter->openMemory();
		$this->xmlWriter->setIndent(true);

		$this->blocks = array();

	}

	/**
	 * Gibt den kompletten XML-Baum aus. Wurden Status und Statustext
	 * im Vorhinein nicht gesetzt, wird eine Exception geworfen.
	 *
	 * @throws InCompleteDataExcepetion
	 *
	 */
	public function __toString(){


		$this->xmlWriter->startElement("webdata");

		//Status informationen
		$this->xmlWriter->writeElement('state', $this->state);
		$this->xmlWriter->writeElement('statetext', $this->stateText);
			
		//Nutzdaten
		$this->xmlWriter->startElement('productiondata');
		$this->xmlWriter->writeAttribute("blockcount", count($this->blocks));
			
		$i = 0;
			
		//Blöcke durchlaufen
		foreach($this->blocks as $block){
				
			$this->xmlWriter->startElement('block');
			$this->xmlWriter->writeAttribute("id", $i);
			$this->xmlWriter->writeAttribute("type", $block->getType());
				
			switch($block->getType()){

				case 'SQL_RESULTSET':
					$blockData = $block->get();
					$y=0;
					foreach($blockData as $row){

						$this->xmlWriter->startElement('datensatz');
						$this->xmlWriter->writeAttribute("id", $y);
						if(is_array($row)){
							foreach($row as $columnName => $columnValue){
								$this->xmlWriter->writeElement($columnName, utf8_encode($columnValue));
							}
						}
						$this->xmlWriter->endElement();
						$y++;
					}
					break;

				case 'BLF_CALLPLANCONFIG':
						
					$blockData = $block->get();

					if($blockData instanceof BLFCallplanDayConfigurationCollection){

						$config = $blockData->get();
						foreach($config as $c){

							$this->xmlWriter->startElement('ARP');
								
							$this->xmlWriter->startElement('id');
							$this->xmlWriter->text($c->getId());
							$this->xmlWriter->endElement();
								
							$this->xmlWriter->startElement('dayNum');
							$this->xmlWriter->text($c->getDayNum());
							$this->xmlWriter->endElement();

							$this->xmlWriter->startElement('kto');
							$this->xmlWriter->text($c->getKto());
							$this->xmlWriter->endElement();
								
							$this->xmlWriter->startElement('employee');
							$this->xmlWriter->text($c->getEmployee());
							$this->xmlWriter->endElement();
								
							$this->xmlWriter->startElement('agency');
							$this->xmlWriter->text($c->getAgency());
							$this->xmlWriter->endElement();
								
							$this->xmlWriter->startElement('callStart');
							$this->xmlWriter->text($c->getCallStart());
							$this->xmlWriter->endElement();

							$this->xmlWriter->startElement('callAprox');
							$this->xmlWriter->text($c->getCallAprox());
							$this->xmlWriter->endElement();

							$this->xmlWriter->startElement('memo');
							$this->xmlWriter->text($c->getMemo());
							$this->xmlWriter->endElement();
								
							$this->xmlWriter->startElement('comment');
							$this->xmlWriter->text($c->getComment());
							$this->xmlWriter->endElement();
								
							$this->xmlWriter->endElement();
						}
					}
					break;

				case 'BLF_CUSTOMER':
					$blockData = $block->get();
						
					if($blockData instanceof BLFCustomerCollection){
						$customers = $blockData->get();
						foreach($customers as $c){
								
							$this->xmlWriter->startElement('customer');
								
							$this->xmlWriter->startElement('kto');
							$this->xmlWriter->text(utf8_encode($c->getKto()));
							$this->xmlWriter->endElement();

							$this->xmlWriter->startElement('matchcode');
							$this->xmlWriter->text(utf8_encode($c->getMatchCode()));
							$this->xmlWriter->endElement();

							$this->xmlWriter->startElement('name1');
							$this->xmlWriter->text(utf8_encode($c->getContact()));
							$this->xmlWriter->endElement();


							$this->xmlWriter->endElement();
						}
					}
						
					break;

				case 'CSV_STRING':
						
					$blockData = $block->get();
					$y=0;
						
					if(!strpos($blockData,";")){

						$this->xmlWriter->startElement('datensatz');
						$this->xmlWriter->writeAttribute("id", 0);
						$this->xmlWriter->writeElement("FIELD_0", utf8_encode($blockData));
						$this->xmlWriter->endElement();

					}else{

						$blockDataParts = explode("\n", $blockData);

						foreach($blockDataParts as $row){
							$this->xmlWriter->startElement('datensatz');
							$this->xmlWriter->writeAttribute("id", $y);
							$z = 0;
								
							$rowParts = explode(";" , $row);
							foreach($rowParts as $val){
								$this->xmlWriter->startElement('FIELD');
								$this->xmlWriter->writeAttribute("id", $z);
								$this->xmlWriter->text(utf8_encode($val));
								$this->xmlWriter->endElement();
								$z++;
							}
							$this->xmlWriter->endElement();
							$y++;
						}
					}
						
					break;

				default:
					//silence
			}
			$this->xmlWriter->endElement();
				
			$i++;
		}
			
		$this->xmlWriter->endElement();
		$this->xmlWriter->endElement();

		return $this->xmlWriter->outputMemory();
	}

	/**
	 * Setzt den Status der XML-Response. Entspricht der
	 * Wert nicht 0 oder 1, so wird automatisch auf 0
	 * gesetzt.
	 * @param unknown_type $state
	 */
	public function setStatus($state){
		if($state != 0 && $state != 1){
			$this->state = 0;
		}else{
			$this->state = $state;
		}
	}

	/**
	 * Setzt den Statustext der XML-Response
	 * @param unknown_type $text
	 */
	public function setStatusText($text){
		$this->stateText = $text;
	}

	/**
	 * Fügt die Daten eines Blockes dem Block-Array hinzu wenn sie einem
	 * Typ entsprechen, der in der Datenstruktur acceptedBlockTypes enthalten
	 * ist.
	 * @param unknown_type $blockdata
	 * @param unknown_type $blocktype
	 * @throws UnknownBlockTypeException
	 */
	public function setBlock($blockData,$blockType){
		if(in_array($blockType, $this->acceptedBlockTypes)){
			$this->blocks[] = new XmlDatenBlock($blockData, $blockType);
		}else{
			throw new UnknownBlockTypeExcepetion("Der angebene Blocktyp ist nicht bekannt.","XmlResponseWrtier::__toString");
		}

	}

	/**
	 * Diese Methode dient dazu im Fehlerfall auch dann eine valide
	 * XML-Datenstruktur auszugeben, wenn zuvor eine Exception dieser
	 * Klasse geworfen wurde.
	 * Sie gibt stets eine  XML-Struktur mit den folgenden
	 * Attributen aus:
	 *
	 * state: 0
	 * statetext: übergeben
	 * productiondata: 0 Blöcke
	 *
	 * Ein klassische Verwendungsart ist der Aufruf dieser Methode in
	 * einem Catch-Block.
	 *
	 */
	public function toStringOnError($stateText){
		$this->xmlWriter->startElement("webdata");
		$this->xmlWriter->writeElement('state', '0');
		$this->xmlWriter->writeElement('statetext', trim(strip_tags($stateText)));
		$this->xmlWriter->startElement('productiondata');
		$this->xmlWriter->writeAttribute("blockcount", 0);
		$this->xmlWriter->endElement();
		$this->xmlWriter->endElement();
		return $this->xmlWriter->outputMemory();
	}
}
?>