<form action='' method='post'>
<div></div>
<table cellspacing='0' class='layout'>
<tr><th>Datenbank System<td><select name='auth[driver]'><option value="server" selected>MySQL<option value="sqlite">SQLite 3<option value="sqlite2">SQLite 2<option value="pgsql">PostgreSQL<option value="oracle">Oracle (beta)<option value="mssql">MS SQL (beta)<option value="mongo">MongoDB (alpha)<option value="elastic">Elasticsearch (beta)</select><script nonce="YTBkNTE1YjcxNDJjYjMwNTBmZTQ1ZDJiMDE4YzBiZTk=">qsl('select').onchange = function () { loginDriver(this); };</script>
<tr><th>Server<td><input name="auth[server]" value="" title="hostname[:port]" placeholder="localhost" autocapitalize="off">
<tr><th>Benutzer<td><input name="auth[username]" id="username" value="root" autocomplete="username" autocapitalize="off"><script nonce="YTBkNTE1YjcxNDJjYjMwNTBmZTQ1ZDJiMDE4YzBiZTk=">focus(qs('#username')); qs('#username').form['auth[driver]'].onchange();</script>
<tr><th>Passwort<td><input type="password" name="auth[password]" autocomplete="current-password">
<tr><th>Datenbank<td><input name="auth[db]" value="" autocapitalize="off">
</table>
<p><input type='submit' value='Login'>
<label><input type='checkbox' name='auth[permanent]' value='1'>Passwort speichern</label>
</form>