<?php
$url = "http://localhost/webservices/server.php?q=load&query=cd_catalog.xml";
$myXMLData = file_get_contents($url);
$xml=simplexml_load_string($myXMLData) or die("Error: Cannot create object");
// echo $xml->to;
// print_r($xml);
// echo json_encode([$xml->to, $xml->body]);
echo json_encode($xml);
?> 