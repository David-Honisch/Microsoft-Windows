<h1>LC2MySQL Database</h1>
<h4>Attempting MySQL connection from php...</h4>
<a href="showdb.php">showdb.php</a>
<hr>
<?php
$host = 'mysql';
$user = 'root';
$pass = 'rootpassword';

// Create connection
$conn = new mysqli($host, $user, $pass);
// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}
// Create database
$sql = "CREATE DATABASE myLCDB";
if ($conn->query($sql) === TRUE) {
  echo "Database created successfully";
} else {
  echo "Error creating database: " . $conn->error;
}
$sql = "show databases";
$res = $conn->query($sql);
if ($res === TRUE) {
  //echo "Database created successfully";
} else {
  echo "Error executing query: " . $conn->error;
}
$conn->close();

?>