'use strict';
// function writeFileSync(wb, filename, opts) {
//     var o = opts || {};
//     o.type = 'file';
//     o.file = filename;
//     if (!o.bookType) switch (o.file.slice(-5).toLowerCase()) {
//         case '.xlsx':
//             o.bookType = 'xlsx';
//             break;
//         case '.xlsm':
//             o.bookType = 'xlsm';
//             break;
//         case '.xlsb':
//             o.bookType = 'xlsb';
//             break;
//         case '.fods':
//             o.bookType = 'fods';
//             break;
//         case '.xlml':
//             o.bookType = 'xlml';
//             break;
//         default:
//             switch (o.file.slice(-4).toLowerCase()) {
//                 case '.xls':
//                     o.bookType = 'biff2';
//                     break;
//                 case '.xml':
//                     o.bookType = 'xml';
//                     break;
//                 case '.ods':
//                     o.bookType = 'ods';
//                     break;
//                 case '.csv':
//                     o.bookType = 'csv';
//                     break;
//             }
//     }
//     return writeSync(wb, o);
// }
// eMsg('Debug');
// var htmlstr;
var XLSX = window.nodeRequire('xlsx');

var $ = $;
var XLSX;
var electron;
var path;
var xlsxj;
var fs;
var cDg;
var convert;
// eMsg('Debug');
try {
    $ = window.nodeRequire('jquery');
    electron = window.nodeRequire('electron').remote;
    path = window.nodeRequire('path');
    fs = window.nodeRequire('fs');
} catch (e) {
    eMsg(e);
}
try {
    convert = XLSX !== undefined ? convert : window.nodeRequire('xml-js');
    xlsxj = xlsxj !== undefined ? xlsxj : window.nodeRequire("xlsx-to-json");
    XLSX = XLSX !== undefined ? XLSX : window.nodeRequire('xlsx');
} catch (e) {
    eMsg(e);
}
try {
    convert = XLSX;
    // XLSX = new XLSX();
} catch (e) {
    eMsg(e);
}
// eMsg('Debug');

var process_wb = (function() {
    var HTMLOUT = document.getElementById('htmlout');

    // var XLSXPORT = document.getElementById('xlsxport');
    // var CSVXPORT = document.getElementById('csvxport');
    // var JSONXPORT = document.getElementById('jsonxport');
    // var XMLXPORT = document.getElementById('xmlxport');
    var WSXPORT = document.getElementById('wsxport');
    // var DBIMPORT = document.getElementById('dbimport');


    return function process_wb(wb) {
        // XLSXPORT.disabled = false;
        // CSVXPORT.disabled = false;
        // JSONXPORT.disabled = false;
        // XMLXPORT.disabled = false;
        WSXPORT.disabled = false;
        // DBIMPORT.disabled = false;
        /* get data */
        var ws = wb.Sheets[wb.SheetNames[0]];
        var data = XLSX.utils.sheet_to_json(ws, { header: 1 });

        /* update canvas-datagrid */
        if (!cDg) cDg = canvasDatagrid({ parentNode: HTMLOUT, data: data });
        cDg.style.height = '100%';
        cDg.style.width = '100%';
        cDg.data = data;
        // XPORT.disabled = false;

        /* create schema (for A,B,C column headings) */
        var range = XLSX.utils.decode_range(ws['!ref']);
        for (var i = range.s.c; i <= range.e.c; ++i) {
            cDg.schema[i - range.s.c].title = XLSX.utils.encode_col(i);
        }

        // HTMLOUT.style.height = (window.innerHeight - 400) + "px";
        // HTMLOUT.style.width = (window.innerWidth - 50) + "px";
        //redundant
        // wb.SheetNames.forEach(function(sheetName) {
        //     htmlstr = XLSX.utils.sheet_to_html(wb.Sheets[sheetName], {
        //         editable: true
        //     });
        //     HTMLCNT.innerHTML += htmlstr;
        // });

        if (typeof console !== 'undefined') console.log("output", new Date());
    };
})();

var do_file = (function() {
    return function do_file(files) {
        var f = files[0];
        var reader = new FileReader();
        reader.onload = function(e) {
            var data = e.target.result;
            data = new Uint8Array(data);
            process_wb(XLSX.read(data, {
                type: 'array'
            }));
        };
        reader.readAsArrayBuffer(f);
    };
})();

(function() {
    var drop = document.getElementById('drop');

    function handleDrop(e) {
        e.stopPropagation();
        e.preventDefault();
        do_file(e.dataTransfer.files);
    }

    function handleDragover(e) {
        e.stopPropagation();
        e.preventDefault();
        e.dataTransfer.dropEffect = 'copy';
    }

    drop.addEventListener('dragenter', handleDragover, false);
    drop.addEventListener('dragover', handleDragover, false);
    drop.addEventListener('drop', handleDrop, false);
})();

(function() {
    var readf = document.getElementById('readf');

    function handleF( /*e*/ ) {
        var o = electron.dialog.showOpenDialog({
            title: 'Select a file',
            filters: [{
                name: "Spreadsheets",
                extensions: "xls|xlsx|xlsm|xlsb|xml|xlw|xlc|csv|txt|dif|sylk|slk|prn|ods|fods|uos|dbf|wks|123|wq1|qpw|htm|html".split("|")
            }],
            properties: ['openFile']
        });
        if (o.length > 0) process_wb(XLSX.readFile(o[0]));
    }
    readf.addEventListener('click', handleF, false);
})();

(function() {
    var xlf = document.getElementById('xlf');

    function handleFile(e) {
        do_file(e.target.files);
    }
    xlf.addEventListener('change', handleFile, false);
})();

function XLSXUtils(XLSX) {
    // var $ = window.nodeRequire('jquery');
    // var electron = window.nodeRequire('electron').remote;
    // var path = window.nodeRequire('path');
    // var fs = window.nodeRequire('fs');
    // var convert = XLSX !== undefined ? convert : window.nodeRequire('xml-js');
    // var xlsxj = xlsxj !== undefined ? xlsxj : window.nodeRequire("xlsx-to-json");
    // var XLSX = XLSX !== undefined ? XLSX : window.nodeRequire('xlsx');
    // alert('SUX');

    this.prep = function(arr) {
        var out = [];
        for (var i = 0; i < arr.length; ++i) {
            if (!arr[i]) continue;
            if (Array.isArray(arr[i])) { out[i] = arr[i]; continue };
            var o = new Array();
            Object.keys(arr[i]).forEach(function(k) { o[+k] = arr[i][k] });
            out[i] = o;
        }
        return out;
    }



    this.export_all = function() {
        // alert('Debu22g');
        var XTENSION = "xls|xlsx|xlsm|xlsb|xml|csv|txt|dif|sylk|slk|prn|ods|fods|htm|html".split("|")
        var HTMLCNT = document.getElementById('htmlcnt');
        var electron = window.nodeRequire('electron').remote;
        return function() {
            try {
                // var wb = XLSX.utils.table_to_book(HTMLCNT);
                var o = electron.dialog.showSaveDialog({
                    title: 'Save file as',
                    filters: [{
                        name: "json",
                        extensions: XTENSION
                    }]
                });
                eMsg(o);
                if (o) {
                    try {
                        if (!cDg) return;
                        /* convert canvas-datagrid data to worksheet */
                        var new_ws = XLSX.utils.aoa_to_sheet(this.prep(cDg.data));
                        /* build workbook */
                        var new_wb = XLSX.utils.book_new();
                        XLSX.utils.book_append_sheet(new_wb, new_ws, 'LetzteChance.Org');
                        /* write file and trigger a download */
                        XLSX.writeFile(new_wb, o, { bookSST: true });
                    } catch (e) {
                        eMsg(e);
                    }
                    electron.dialog.showMessageBox({
                        message: "Exported data to " + o,
                        buttons: ["OK"]
                    });
                } else {
                    electron.dialog.showMessageBox({ message: "Export cancelled ", buttons: ["OK"] });
                }
            } catch (e) {
                eMsg(e);
            }
        };
    };
    // this.export_all();
    //CSV
    this.export_csv = function() {
        var HTMLCNT = document.getElementById('htmlcnt');
        var XTENSION = "csv|CSV|txt|TXT".split("|");
        var electron = window.nodeRequire('electron').remote;
        return function() {
            try {
                var wb = XLSX.utils.table_to_book(HTMLCNT);
                var o = electron.dialog.showSaveDialog({
                    title: 'Save file as',
                    filters: [{
                        name: "csv",
                        extensions: XTENSION
                    }]
                });
                eMsg(o);
                if (o) {
                    try {
                        if (!cDg) return;
                        /* convert canvas-datagrid data to worksheet */
                        var new_ws = XLSX.utils.aoa_to_sheet(this.prep(cDg.data));
                        /* build workbook */
                        var new_wb = XLSX.utils.book_new();
                        XLSX.utils.book_append_sheet(new_wb, new_ws, 'LetzteChance.Org');
                        /* write file and trigger a download */
                        XLSX.writeFile(new_wb, o + 'LetzteChance.Org.xlsx', { bookSST: true });
                        XLSX.writeFile(new_wb, o, { bookSST: true });
                    } catch (e) {
                        eMsg(e);
                    }
                    electron.dialog.showMessageBox({
                        message: "Exported data to " + o,
                        buttons: ["OK"]
                    });
                } else {
                    electron.dialog.showMessageBox({ message: "Export cancelled ", buttons: ["OK"] });
                }
            } catch (e) {
                eMsg(e);
            }
        };

    };
    //XML
    this.export_xml = function() {
        var XTENSION = "xls|xlsx|xlsm|xlsb|xml|csv|txt|dif|sylk|slk|prn|ods|fods|htm|html".split("|")
        var HTMLCNT = document.getElementById('htmlcnt');
        return function() {
            try {
                // var wb = XLSX.utils.table_to_book(HTMLCNT);
                var electron = window.nodeRequire('electron').remote;
                var o = electron.dialog.showSaveDialog({
                    title: 'Save file as',
                    filters: [{
                        name: "xml",
                        extensions: XTENSION
                    }]
                });
                eMsg(o);
                if (o) {
                    try {
                        if (!cDg) return;
                        /* convert canvas-datagrid data to worksheet */
                        var new_ws = XLSX.utils.aoa_to_sheet(this.prep(cDg.data));
                        /* build workbook */
                        var new_wb = XLSX.utils.book_new();
                        XLSX.utils.book_append_sheet(new_wb, new_ws, 'LetzteChance.Org');
                        /* write file and trigger a download */
                        XLSX.writeFile(new_wb, o + 'LetzteChance.Org.xlsx', { bookSST: true });
                        XLSX.writeFile(new_wb, o, { bookSST: true });
                    } catch (e) {
                        eMsg(e);
                    }
                    electron.dialog.showMessageBox({
                        message: "Exported data to " + o,
                        buttons: ["OK"]
                    });
                } else {
                    electron.dialog.showMessageBox({ message: "Export cancelled ", buttons: ["OK"] });
                }
            } catch (e) {
                eMsg(e);
            }
        };
    };
    // alert('TEST');
    //JSON
    this.export_json = function() {
        var HTMLCNT = document.getElementById('htmlcnt');
        var XTENSION = "json|JSON".split("|");
        var electron = window.nodeRequire('electron').remote;
        return function() {
            try {

                var wb = XLSX.utils.table_to_book(HTMLCNT);
                var o = electron.dialog.showSaveDialog({
                    title: 'Save file as',
                    filters: [{
                        name: "json",
                        extensions: XTENSION
                    }]
                });
                eMsg(o);
                if (o) {
                    try {
                        var postFix = '-.LetzteChance.Org.xlsx';
                        // var fileName = o + postFix;
                        if (!cDg) return;
                        /* convert canvas-datagrid data to worksheet */
                        var new_ws = XLSX.utils.aoa_to_sheet(this.prep(cDg.data));
                        /* build workbook */
                        var new_wb = XLSX.utils.book_new();
                        XLSX.utils.book_append_sheet(new_wb, new_ws, 'LetzteChance.Org');
                        /* write file and trigger a download */
                        XLSX.writeFile(new_wb, o + postFix, { bookSST: true });
                        // var workbook = XLSX.readFile(o + postFix);
                        var v = {};
                        new_wb.SheetNames.forEach(function(name) {
                            v[name] = XLSX.utils.sheet_to_json(new_wb.Sheets[name]);
                            fs.writeFileSync(o + name + ".json", JSON.stringify(v[name]), 'utf-8');
                        });
                    } catch (e) {
                        eMsg(e);
                    }
                    electron.dialog.showMessageBox({
                        message: "Exported data to " + o,
                        buttons: ["OK"]
                    });
                } else {
                    electron.dialog.showMessageBox({ message: "Export cancelled ", buttons: ["OK"] });
                }
            } catch (e) {
                eMsg(e);
            }
        };
    };
    // alert('TEST');
    //DB
    this.export_db = function() {
        var XTENSION = "csv|CSV".split("|");
        var tableId = $('#tableId>option:selected').text();
        // return function() {
        try {
            // var wb = XLSX.utils.table_to_book(HTMLCNT);
            var electron = window.nodeRequire('electron').remote;
            var o = electron.dialog.showSaveDialog({
                title: 'Save file as',
                filters: [{
                    name: "csv",
                    extensions: XTENSION
                }]
            });
            eMsg(o);
            if (o) {
                try {
                    if (!cDg) return;
                    /* convert canvas-datagrid data to worksheet */
                    var new_ws = XLSX.utils.aoa_to_sheet(this.prep(cDg.data));
                    /* build workbook */
                    var new_wb = XLSX.utils.book_new();
                    XLSX.utils.book_append_sheet(new_wb, new_ws, 'LetzteChance.Org');
                    /* write file and trigger a download */
                    XLSX.writeFile(new_wb, o, { bookSST: true });
                    new HttpRequest().execCMD('exec.bat .\\resources\\cmd\\dbimport.file.bat "' + o + '" ' + tableId + '', 'outcnt', true);
                    new HttpRequest().execCMD('exec.bat .\\resources\\cmd\\dbimport.bat "' + o + '" ' + tableId + '', 'outcnt', true);
                    document.getElementById('outcnt').innerHTML += '<h1>Import done.</h1>';
                    return true;

                } catch (e) {
                    eMsg(e);
                }
                electron.dialog.showMessageBox({
                    message: "Exported data to " + o,
                    buttons: ["OK"]
                });
            } else {
                electron.dialog.showMessageBox({ message: "Export cancelled ", buttons: ["OK"] });
                return;
            }
        } catch (e) {
            eMsg(e);
        }
    };
    // alert('TEST2');
    //DB
    this.export_ws = function() {
        var XTENSION = "csv|CSV".split("|");
        var tableName = $('#tableId>option:selected').text();
        var tableId = $('#tableId>option:selected').val();
        try {
            // var wb = XLSX.utils.table_to_book(HTMLCNT);
            var electron = window.nodeRequire('electron').remote;
            var o = electron.dialog.showSaveDialog({
                title: 'Save file as',
                filters: [{
                    name: "csv",
                    extensions: XTENSION
                }]
            });
            eMsg(o);
            if (o) {
                try {
                    if (!cDg) return;
                    if (!o) return;
                    /* convert canvas-datagrid data to worksheet */
                    var new_ws = XLSX.utils.aoa_to_sheet(this.prep(cDg.data));
                    /* build workbook */
                    var new_wb = XLSX.utils.book_new();
                    XLSX.utils.book_append_sheet(new_wb, new_ws, 'LetzteChance.Org');
                    /* write file and trigger a download */
                    XLSX.writeFile(new_wb, o, { bookSST: true });
                    // new HttpRequest().execCMD('exec.bat .\\resources\\cmd\\wsimport.bat "' + o + '" "' + tableName + '" ' + tableId, 'outcnt', true);                    
                    // var singleFileUploadInput = document.querySelector('#singleFileUploadInput');
                    // singleFileUploadInput.val = o;
                    // var files = singleFileUploadInput.files;
                    // if (files.length === 0) {
                    //     document.getElementById('outcnt').innerHTML += "Please select a file";
                    // }
                    // uploadSingleFile(files[0]);
                    this.export_postdata(o, tableId);
                    document.getElementById('outcnt').innerHTML += '<h1>Import done.</h1>';
                    return true;

                } catch (e) {
                    eMsg(e);
                }
                electron.dialog.showMessageBox({
                    message: "Exported data to " + o,
                    buttons: ["OK"]
                });
            } else {
                electron.dialog.showMessageBox({ message: "Export cancelled ", buttons: ["OK"] });
                return;
            }
        } catch (e) {
            eMsg(e);
        }
    };

    this.export_postdata = function(o, tableId) {
        const lineReader = window.nodeRequire('line-reader');

        lineReader.eachLine(o, function(line) {
            console.log(line);
            document.getElementById('outcnt').innerHTML += line + '<br>';
            // var ser = $("#insertForm").serialize();
            var ser = {
                value1: tableId,
                subject: line,
                // body: '[url]' + line + '[/url]',
                body: line,
                ebody: line,
            };
            // console.log('POST:'+ser);
            // $('#rsTitle').prop('title', isUpdate ? 'Update:' : 'Post:' + JSON.stringify(ser));
            var url = 'http://localhost/cms/webservices/client.php?q=doInsert';
            $.ajax({
                type: "POST",
                url: url,
                data: ser, // serializes the form's elements.
                contentType: "application/x-www-form-urlencoded; charset=utf-8",
                success: function(data) {
                    $('#outcnt').append(JSON.stringify(data));
                    $('#outcnt').append(url);

                }
            });
        });
        // alert('File:' + o);
        // fs = window.nodeRequire('fs');
        // fs.readFile(o, 'utf8', function(err, data) {
        //     if (err) {
        //         return console.log(err);
        //     }
        //     console.log(data);
        //     var formData = new FormData();
        //     // formData.append('file', data, {
        //     //     filepath: o,
        //     //     contentType: 'text/plain',
        //     // });
        //     formData.append("file", o);

        //     var xhr = new XMLHttpRequest();
        //     xhr.open("POST", "http://localhost:8081/uploadFile");

        //     xhr.onload = function() {
        //         console.log(xhr.responseText);
        //         var response = JSON.parse(xhr.responseText);
        //         if (xhr.status == 200) {
        //             // document.getElementById('outcnt').style.display = "none";
        //             document.getElementById('outcnt').innerHTML += "<p>File Uploaded Successfully.</p><p>DownloadUrl : <a href='" + response.fileDownloadUri + "' target='_blank'>" + response.fileDownloadUri + "</a></p>";
        //             // singleFileUploadSuccess.innerHTML = "<p>File Uploaded Successfully.</p><p>DownloadUrl : <a href='" + response.fileDownloadUri + "' target='_blank'>" + response.fileDownloadUri + "</a></p>";
        //             // document.getElementById('outcnt').style.display = "block";
        //         } else {
        //             // document.getElementById('outcnt').style.display = "none";                    
        //             document.getElementById('outcnt').innerHTML += (response && response.message) || "Some Error Occurred";
        //             document.getElementById('outcnt').innerHTML += xhr.responseText;
        //         }
        //     }
        //     xhr.send(formData);
        // });

    }

};
// function doit(type, fn, dl) {
//     var elt = document.getElementById('htmlout');
//     var wb = XLSX.utils.table_to_book(elt, {
//         sheet: "LetzteChance.Org"
//     });
//     return dl ?
//         XLSX.write(wb, {
//             bookType: type,
//             bookSST: true,
//             type: 'base64'
//         }) :
//         XLSX.writeFile(wb, fn || ('test.' + (type || 'xlsx')));
// }