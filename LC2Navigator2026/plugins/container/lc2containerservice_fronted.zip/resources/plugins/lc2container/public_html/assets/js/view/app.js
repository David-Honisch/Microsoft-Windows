'use strict';
var title = 'LC2Navigator Home - Application';

$.urlParam = function(name) {
    var results = new RegExp('[\?&]' + name + '=([^&#]*)').exec(window.location.href);
    if (results == null) {
        return null;
    }
    return decodeURI(results[1]) || 0;
}


window.onload = init();

function init() {

    // getHead();
    $('#out').append('INIT RUNNING...');
    $('#out').html('init successfully  done.');

    $('#submenu, #alertcnt').on('click', 'a[href^="http"]', function(event) {
        event.preventDefault();
        console.log(this.href + " opens...");
        shell.openExternal(this.href);
    });
    console.log('DONE.');
}

// function getHead() {
//     document.title = title;
//     var head = getHeader(cfg.local);
//     // console.log(JSON.stringify(head));    
//     $('#head').html(head);
//     $('#ptitle').html(title);
// }