select '<hr/><h2>lc2wsdl_client_app v.1.0</h2>';
select '<p>drop plugin tables</p>';
drop table IF EXISTS lc2wsdl_client_app;
drop table IF EXISTS lc2wsdl_client_app_main;
drop table IF EXISTS lc2wsdl_client_app_install;
drop table IF EXISTS lc2wsdl_client_app_help;
drop table IF EXISTS lc2wsdl_client_app_data;
drop table IF EXISTS lc2wsdl_client_app_info;
drop table IF EXISTS lc2wsdl_client_app_work;
drop table IF EXISTS lc2wsdl_client_app_procdata;
drop table IF EXISTS lc2wsdl_client_apptemp;
drop table IF EXISTS lc2wsdl_client_app_datatemp;
drop table IF EXISTS lc2wsdl_client_app_worktemp;
drop table IF EXISTS lc2wsdl_client_app_proc;
drop table IF EXISTS lc2wsdl_client_app_tests;
drop table IF EXISTS lc2wsdl_client_app_proctemp;
---------------------------------------------------------------
drop table IF EXISTS lc2wsdl_client_app_mysql;
drop table IF EXISTS lc2wsdl_client_app_mongodb;
drop table IF EXISTS lc2wsdl_client_app_oracle;
drop table IF EXISTS lc2wsdl_client_app_sqlserver;
drop table IF EXISTS lc2wsdl_client_app_postgressql;
drop table IF EXISTS lc2wsdl_client_app_sqlite;
---------------------------------------------------------------
select '<span>Creating tables</span>';
---------------------------------------------------------------
CREATE TABLE lc2wsdl_client_app( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,  "url" TEXT NULL);
CREATE TABLE lc2wsdl_client_app_main( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE lc2wsdl_client_app_install( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE lc2wsdl_client_app_help( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE lc2wsdl_client_app_data( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE lc2wsdl_client_app_info( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE lc2wsdl_client_app_work( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
--CREATE TABLE lc2wsdl_client_app_proc( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE lc2wsdl_client_app_proc( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
---------------------------------------------------------------
CREATE TABLE lc2wsdl_client_app_mysql( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE lc2wsdl_client_app_oracle( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE lc2wsdl_client_app_mongodb( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE lc2wsdl_client_app_postgressql( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE lc2wsdl_client_app_sqlserver( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE lc2wsdl_client_app_sqlite( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
---------------------------------------------------------------
CREATE TABLE lc2wsdl_client_app_tests( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE lc2wsdl_client_app_procdata( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
---------------------------------------------------------------
CREATE TABLE IF NOT EXISTS lc2wsdl_client_apptemp (
"name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "url" TEXT NULL
);
CREATE TABLE IF NOT EXISTS lc2wsdl_client_app_proctemp( "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "url" TEXT NULL);
---------------------------------------------------------------
-- import menu
select '<span>start import to plugin tables</span>';
---------------------------------------------------------------
.separator ";"
--.import .\\resources\\plugins\\lc2wsdl_client_app\\import\\import.csv lc2wsdl_client_apptemp
-- INSERT INTO lc2wsdl_client_app(first_name,name,zipcode, city, description) select first_name,name,zipcode, city, description  from lc2wsdl_client_apptemp;
.import .\\resources\\plugins\\lc2wsdl_client_app\\import\\import.csv lc2wsdl_client_app
.import .\\resources\\plugins\\lc2wsdl_client_app\\import\\main.csv lc2wsdl_client_app_main
.import .\\resources\\plugins\\lc2wsdl_client_app\\import\\install.csv lc2wsdl_client_app_install
.import .\\resources\\plugins\\lc2wsdl_client_app\\import\\help.csv lc2wsdl_client_app_help
.import .\\resources\\plugins\\lc2wsdl_client_app\\import\\info.csv lc2wsdl_client_app_info
.import .\\resources\\plugins\\lc2wsdl_client_app\\import\\data.csv lc2wsdl_client_app_data
.import .\\resources\\plugins\\lc2wsdl_client_app\\import\\work.csv lc2wsdl_client_app_work
.import .\\resources\\plugins\\lc2wsdl_client_app\\import\\proc.csv lc2wsdl_client_app_proc
.import .\\resources\\plugins\\lc2wsdl_client_app\\import\\tests.csv lc2wsdl_client_app_tests
---------------------------------------------------------------
.import .\\resources\\plugins\\lc2wsdl_client_app\\import\\mysql.csv lc2wsdl_client_app_mysql
.import .\\resources\\plugins\\lc2wsdl_client_app\\import\\mongodb.csv lc2wsdl_client_app_mongodb
.import .\\resources\\plugins\\lc2wsdl_client_app\\import\\oracle.csv lc2wsdl_client_app_oracle
.import .\\resources\\plugins\\lc2wsdl_client_app\\import\\postgressql.csv lc2wsdl_client_app_postgressql
.import .\\resources\\plugins\\lc2wsdl_client_app\\import\\sqlserver.csv lc2wsdl_client_app_sqlserver
.import .\\resources\\plugins\\lc2wsdl_client_app\\import\\sqlite.csv lc2wsdl_client_app_sqlite
-------------------------------------------------------------
-- import procs
-- select '<span>importing processes</span>';
-------------------------------------------------------------
-- .separator ","
-- .import '.\\resources\\plugins\\lc2wsdl_client_app\\import\\proc.csv' lc2wsdl_client_app_proctemp
-- .separator ";"
-- INSERT INTO lc2wsdl_client_app_proc(first_name,name,zipcode, description,url) select first_name,name,zipcode, description,url  from lc2wsdl_client_app_proctemp;
-- select 'lc2wsdl_client_app_work count:';
-- select count(*) from lc2wsdl_client_app_proc;
-- eof insert work data
-- eof insert work data
---------------------------------------------------------------
-- done
select '<span>import done</span>';
---------------------------------------------------------------
select 'lc2wsdl_client_app count:';
select count(*) from lc2wsdl_client_app;
select '<p>start data import to plugin tables</p>';
-- delete from lc2wsdl_client_app_datatemp;
--
select '<p>lc2wsdl_client_app count:';
select count(*) from lc2wsdl_client_app;
select '</br>lc2wsdl_client_app_data count:';
select count(*) from lc2wsdl_client_app_data;
select '</br>lc2wsdl_client_app_info count:';
select count(*) from lc2wsdl_client_app_info;
select '</br>lc2wsdl_client_app_help count:';
select count(*) from lc2wsdl_client_app_help;
select '</br>lc2wsdl_client_app_procdata count:';
select count(*) from lc2wsdl_client_app_procdata;
select '</br>lc2wsdl_client_app_work count:';
select count(*) from lc2wsdl_client_app_work;
select '</br>lc2wsdl_client_app_proc count:';
select count(*) from lc2wsdl_client_app_proc;
select '</br>lc2wsdl_client_app_proctemp count:';
select count(*) from lc2wsdl_client_app_proctemp;

select '</br>lc2wsdl_client_app_mysql count:';
select count(*) from lc2wsdl_client_app_mysql;
select '</br>lc2wsdl_client_app_mongodb count:';
select count(*) from lc2wsdl_client_app_mongodb;
select '</br>lc2wsdl_client_app_oracle count:';
select count(*) from lc2wsdl_client_app_oracle;
select '</br>lc2wsdl_client_app_sqlserver count:';
select count(*) from lc2wsdl_client_app_sqlserver;

drop table IF EXISTS lc2wsdl_client_apptemp;
-- drop table IF EXISTS lc2wsdl_client_app_proctemp;
-- select '<p>Import done</p>';
select '<h4>Import lc2wsdl_client_app processes done.</h4>';
.exit