select '<hr/><h2>Import lc2docker2exe processes</h2>';
select '<p>drop plugin tables</p>';
drop table IF EXISTS lc2docker2exe;
drop table IF EXISTS lc2docker2exe_main;
drop table IF EXISTS lc2docker2exe_install;
drop table IF EXISTS lc2docker2exe_help;
drop table IF EXISTS lc2docker2exe_data;
drop table IF EXISTS lc2docker2exe_info;
drop table IF EXISTS lc2docker2exe_work;
drop table IF EXISTS lc2docker2exe_procdata;
drop table IF EXISTS lc2docker2exetemp;
drop table IF EXISTS lc2docker2exe_datatemp;
drop table IF EXISTS lc2docker2exe_worktemp;
drop table IF EXISTS lc2docker2exe_proc;
drop table IF EXISTS lc2docker2exe_tests;
drop table IF EXISTS lc2docker2exe_proctemp;
---------------------------------------------------------------
select '<span>Creating tables</span>';
---------------------------------------------------------------
CREATE TABLE lc2docker2exe( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,  "url" TEXT NULL);
CREATE TABLE lc2docker2exe_main( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE lc2docker2exe_install( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE lc2docker2exe_help( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE lc2docker2exe_data( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE lc2docker2exe_info( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE lc2docker2exe_work( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
--CREATE TABLE lc2docker2exe_proc( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE lc2docker2exe_proc( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
---------------------------------------------------------------
CREATE TABLE lc2docker2exe_tests( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE lc2docker2exe_procdata( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
---------------------------------------------------------------
CREATE TABLE IF NOT EXISTS lc2docker2exetemp (
"name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "url" TEXT NULL
);
CREATE TABLE IF NOT EXISTS lc2docker2exe_proctemp( "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "url" TEXT NULL);
---------------------------------------------------------------
-- import menu
select '<span>start import to plugin tables</span>';
---------------------------------------------------------------
.separator ";"
--.import .\\resources\\plugins\\lc2docker2exe\\import\\import.csv lc2docker2exetemp
-- INSERT INTO lc2docker2exe(first_name,name,zipcode, city, description) select first_name,name,zipcode, city, description  from lc2docker2exetemp;
.import .\\resources\\plugins\\lc2docker2exe\\import\\import.csv lc2docker2exe
.import .\\resources\\plugins\\lc2docker2exe\\import\\main.csv lc2docker2exe_main
.import .\\resources\\plugins\\lc2docker2exe\\import\\install.csv lc2docker2exe_install
.import .\\resources\\plugins\\lc2docker2exe\\import\\help.csv lc2docker2exe_help
.import .\\resources\\plugins\\lc2docker2exe\\import\\info.csv lc2docker2exe_info
.import .\\resources\\plugins\\lc2docker2exe\\import\\data.csv lc2docker2exe_data
.import .\\resources\\plugins\\lc2docker2exe\\import\\work.csv lc2docker2exe_work
--.import .\\resources\\plugins\\lc2docker2exe\\import\\proc.csv lc2docker2exe_proc
.import .\\resources\\plugins\\lc2docker2exe\\import\\tests.csv lc2docker2exe_tests
---------------------------------------------------------------
-- import procs
-- select '<span>importing processes</span>';
-------------------------------------------------------------
-- .separator ","
-- .import '.\\resources\\plugins\\lc2docker2exe\\import\\proc.csv' lc2docker2exe_proctemp
-- .separator ";"
-- INSERT INTO lc2docker2exe_proc(first_name,name,zipcode, description,url) select first_name,name,zipcode, description,url  from lc2docker2exe_proctemp;
-- select 'lc2docker2exe_work count:';
-- select count(*) from lc2docker2exe_proc;
-- eof insert work data
-- eof insert work data
---------------------------------------------------------------
-- done
select '<span>import done</span>';
---------------------------------------------------------------
select 'lc2docker2exe count:';
select count(*) from lc2docker2exe;
select '<p>start data import to plugin tables</p>';
-- delete from lc2docker2exe_datatemp;
--
select '<p>lc2docker2exe count:';
select count(*) from lc2docker2exe;
select 'lc2docker2exe_data count:';
select count(*) from lc2docker2exe_data;
select 'lc2docker2exe_info count:';
select count(*) from lc2docker2exe_info;
select 'lc2docker2exe_help count:';
select count(*) from lc2docker2exe_help;
select 'lc2docker2exe_procdata count:';
select count(*) from lc2docker2exe_procdata;
select 'lc2docker2exe_work count:';
select count(*) from lc2docker2exe_work;
select 'lc2docker2exe_proc count:';
select count(*) from lc2docker2exe_proc;
select 'lc2docker2exe_proctemp count:';
select count(*) from lc2docker2exe_proctemp;

drop table IF EXISTS lc2docker2exetemp;
-- drop table IF EXISTS lc2docker2exe_proctemp;
-- select '<p>Import done</p>';
select '<h4>Import lc2docker2exe processes done.</h4>';
.exit