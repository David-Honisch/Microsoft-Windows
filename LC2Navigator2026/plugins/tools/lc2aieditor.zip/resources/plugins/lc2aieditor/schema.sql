select '<hr/><h2>Import lc2aieditor processes</h2>';
select '<p>drop plugin tables</p>';
drop table IF EXISTS lc2aieditor;
drop table IF EXISTS lc2aieditor_main;
drop table IF EXISTS lc2aieditor_install;
drop table IF EXISTS lc2aieditor_help;
drop table IF EXISTS lc2aieditor_data;
drop table IF EXISTS lc2aieditor_info;
drop table IF EXISTS lc2aieditor_work;
drop table IF EXISTS lc2aieditor_procdata;
drop table IF EXISTS lc2aieditortemp;
drop table IF EXISTS lc2aieditor_datatemp;
drop table IF EXISTS lc2aieditor_worktemp;
drop table IF EXISTS lc2aieditor_proc;
drop table IF EXISTS lc2aieditor_tests;
drop table IF EXISTS lc2aieditor_proctemp;
---------------------------------------------------------------
select '<span>Creating tables</span>';
---------------------------------------------------------------
CREATE TABLE lc2aieditor( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,  "url" TEXT NULL);
CREATE TABLE lc2aieditor_main( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE lc2aieditor_install( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE lc2aieditor_help( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE lc2aieditor_data( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE lc2aieditor_info( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE lc2aieditor_work( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
--CREATE TABLE lc2aieditor_proc( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE lc2aieditor_proc( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
---------------------------------------------------------------
CREATE TABLE lc2aieditor_tests( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE lc2aieditor_procdata( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
---------------------------------------------------------------
CREATE TABLE IF NOT EXISTS lc2aieditortemp (
"name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "url" TEXT NULL
);
CREATE TABLE IF NOT EXISTS lc2aieditor_proctemp( "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "url" TEXT NULL);
---------------------------------------------------------------
-- import menu
select '<span>start import to plugin tables</span>';
---------------------------------------------------------------
.separator ";"
--.import .\\resources\\plugins\\lc2aieditor\\import\\import.csv lc2aieditortemp
-- INSERT INTO lc2aieditor(first_name,name,zipcode, city, description) select first_name,name,zipcode, city, description  from lc2aieditortemp;
.import .\\resources\\plugins\\lc2aieditor\\import\\import.csv lc2aieditor
.import .\\resources\\plugins\\lc2aieditor\\import\\main.csv lc2aieditor_main
.import .\\resources\\plugins\\lc2aieditor\\import\\install.csv lc2aieditor_install
.import .\\resources\\plugins\\lc2aieditor\\import\\help.csv lc2aieditor_help
.import .\\resources\\plugins\\lc2aieditor\\import\\info.csv lc2aieditor_info
.import .\\resources\\plugins\\lc2aieditor\\import\\data.csv lc2aieditor_data
.import .\\resources\\plugins\\lc2aieditor\\import\\work.csv lc2aieditor_work
.import .\\resources\\plugins\\lc2aieditor\\import\\proc.csv lc2aieditor_proc
.import .\\resources\\plugins\\lc2aieditor\\import\\tests.csv lc2aieditor_tests
---------------------------------------------------------------
-- import procs
-- select '<span>importing processes</span>';
-------------------------------------------------------------
-- .separator ","
-- .import '.\\resources\\plugins\\lc2aieditor\\import\\proc.csv' lc2aieditor_proctemp
-- .separator ";"
-- INSERT INTO lc2aieditor_proc(first_name,name,zipcode, description,url) select first_name,name,zipcode, description,url  from lc2aieditor_proctemp;
-- select 'lc2aieditor_work count:';
-- select count(*) from lc2aieditor_proc;
-- eof insert work data
-- eof insert work data
---------------------------------------------------------------
-- done
select '<span>import done</span>';
---------------------------------------------------------------
select 'lc2aieditor count:';
select count(*) from lc2aieditor;
select '<p>start data import to plugin tables</p>';
-- delete from lc2aieditor_datatemp;
--
select '<p>lc2aieditor count:';
select count(*) from lc2aieditor;
select 'lc2aieditor_data count:';
select count(*) from lc2aieditor_data;
select 'lc2aieditor_info count:';
select count(*) from lc2aieditor_info;
select 'lc2aieditor_help count:';
select count(*) from lc2aieditor_help;
select 'lc2aieditor_procdata count:';
select count(*) from lc2aieditor_procdata;
select 'lc2aieditor_work count:';
select count(*) from lc2aieditor_work;
select 'lc2aieditor_proc count:';
select count(*) from lc2aieditor_proc;
select 'lc2aieditor_proctemp count:';
select count(*) from lc2aieditor_proctemp;

drop table IF EXISTS lc2aieditortemp;
-- drop table IF EXISTS lc2aieditor_proctemp;
-- select '<p>Import done</p>';
select '<h4>Import lc2aieditor processes done.</h4>';
.exit