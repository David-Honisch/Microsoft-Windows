select '<hr/><h2>Import LC2SteamAchievementManager processes</h2>';
select '<p>drop plugin tables</p>';
drop table IF EXISTS LC2SteamAchievementManager;
drop table IF EXISTS LC2SteamAchievementManager_main;
drop table IF EXISTS LC2SteamAchievementManager_install;
drop table IF EXISTS LC2SteamAchievementManager_help;
drop table IF EXISTS LC2SteamAchievementManager_data;
drop table IF EXISTS LC2SteamAchievementManager_info;
drop table IF EXISTS LC2SteamAchievementManager_work;
drop table IF EXISTS LC2SteamAchievementManager_procdata;
drop table IF EXISTS LC2SteamAchievementManagertemp;
drop table IF EXISTS LC2SteamAchievementManager_datatemp;
drop table IF EXISTS LC2SteamAchievementManager_worktemp;
drop table IF EXISTS LC2SteamAchievementManager_proc;
drop table IF EXISTS LC2SteamAchievementManager_tests;
drop table IF EXISTS LC2SteamAchievementManager_proctemp;
---------------------------------------------------------------
select '<span>Creating tables</span>';
---------------------------------------------------------------
CREATE TABLE LC2SteamAchievementManager( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,  "url" TEXT NULL);
CREATE TABLE LC2SteamAchievementManager_main( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE LC2SteamAchievementManager_install( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE LC2SteamAchievementManager_help( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE LC2SteamAchievementManager_data( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE LC2SteamAchievementManager_info( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE LC2SteamAchievementManager_work( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
--CREATE TABLE LC2SteamAchievementManager_proc( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE LC2SteamAchievementManager_proc( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
---------------------------------------------------------------
CREATE TABLE LC2SteamAchievementManager_tests( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE LC2SteamAchievementManager_procdata( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
---------------------------------------------------------------
CREATE TABLE IF NOT EXISTS LC2SteamAchievementManagertemp (
"name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "url" TEXT NULL
);
CREATE TABLE IF NOT EXISTS LC2SteamAchievementManager_proctemp( "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "url" TEXT NULL);
---------------------------------------------------------------
-- import menu
select '<span>start import to plugin tables</span>';
---------------------------------------------------------------
.separator ";"
--.import .\\resources\\plugins\\LC2SteamAchievementManager\\import\\import.csv LC2SteamAchievementManagertemp
-- INSERT INTO LC2SteamAchievementManager(first_name,name,zipcode, city, description) select first_name,name,zipcode, city, description  from LC2SteamAchievementManagertemp;
.import .\\resources\\plugins\\LC2SteamAchievementManager\\import\\import.csv LC2SteamAchievementManager
.import .\\resources\\plugins\\LC2SteamAchievementManager\\import\\main.csv LC2SteamAchievementManager_main
.import .\\resources\\plugins\\LC2SteamAchievementManager\\import\\install.csv LC2SteamAchievementManager_install
.import .\\resources\\plugins\\LC2SteamAchievementManager\\import\\help.csv LC2SteamAchievementManager_help
.import .\\resources\\plugins\\LC2SteamAchievementManager\\import\\info.csv LC2SteamAchievementManager_info
.import .\\resources\\plugins\\LC2SteamAchievementManager\\import\\data.csv LC2SteamAchievementManager_data
.import .\\resources\\plugins\\LC2SteamAchievementManager\\import\\work.csv LC2SteamAchievementManager_work
.import .\\resources\\plugins\\LC2SteamAchievementManager\\import\\proc.csv LC2SteamAchievementManager_proc
.import .\\resources\\plugins\\LC2SteamAchievementManager\\import\\tests.csv LC2SteamAchievementManager_tests
---------------------------------------------------------------
-- import procs
-- select '<span>importing processes</span>';
-------------------------------------------------------------
-- .separator ","
-- .import '.\\resources\\plugins\\LC2SteamAchievementManager\\import\\proc.csv' LC2SteamAchievementManager_proctemp
-- .separator ";"
-- INSERT INTO LC2SteamAchievementManager_proc(first_name,name,zipcode, description,url) select first_name,name,zipcode, description,url  from LC2SteamAchievementManager_proctemp;
-- select 'LC2SteamAchievementManager_work count:';
-- select count(*) from LC2SteamAchievementManager_proc;
-- eof insert work data
-- eof insert work data
---------------------------------------------------------------
-- done
select '<span>import done</span>';
---------------------------------------------------------------
select 'LC2SteamAchievementManager count:';
select count(*) from LC2SteamAchievementManager;
select '<p>start data import to plugin tables</p>';
-- delete from LC2SteamAchievementManager_datatemp;
--
select '<p>LC2SteamAchievementManager count:';
select count(*) from LC2SteamAchievementManager;
select 'LC2SteamAchievementManager_data count:';
select count(*) from LC2SteamAchievementManager_data;
select 'LC2SteamAchievementManager_info count:';
select count(*) from LC2SteamAchievementManager_info;
select 'LC2SteamAchievementManager_help count:';
select count(*) from LC2SteamAchievementManager_help;
select 'LC2SteamAchievementManager_procdata count:';
select count(*) from LC2SteamAchievementManager_procdata;
select 'LC2SteamAchievementManager_work count:';
select count(*) from LC2SteamAchievementManager_work;
select 'LC2SteamAchievementManager_proc count:';
select count(*) from LC2SteamAchievementManager_proc;
select 'LC2SteamAchievementManager_proctemp count:';
select count(*) from LC2SteamAchievementManager_proctemp;

drop table IF EXISTS LC2SteamAchievementManagertemp;
-- drop table IF EXISTS LC2SteamAchievementManager_proctemp;
-- select '<p>Import done</p>';
select '<h4>Import LC2SteamAchievementManager processes done.</h4>';
.exit