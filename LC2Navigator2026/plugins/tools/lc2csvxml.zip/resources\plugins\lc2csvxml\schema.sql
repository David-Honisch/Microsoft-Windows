select '<hr/><h2>Import lc2tts processes</h2>';
select '<p>drop plugin tables</p>';
drop table IF EXISTS lc2tts;
drop table IF EXISTS lc2tts_main;
drop table IF EXISTS lc2tts_install;
drop table IF EXISTS lc2tts_help;
drop table IF EXISTS lc2tts_data;
drop table IF EXISTS lc2tts_info;
drop table IF EXISTS lc2tts_work;
drop table IF EXISTS lc2tts_procdata;
drop table IF EXISTS lc2ttstemp;
drop table IF EXISTS lc2tts_datatemp;
drop table IF EXISTS lc2tts_worktemp;
drop table IF EXISTS lc2tts_proc;
drop table IF EXISTS lc2tts_tests;
drop table IF EXISTS lc2tts_proctemp;
---------------------------------------------------------------
select '<span>Creating tables</span>';
---------------------------------------------------------------
CREATE TABLE lc2tts( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,  "url" TEXT NULL);
CREATE TABLE lc2tts_main( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE lc2tts_install( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE lc2tts_help( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE lc2tts_data( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE lc2tts_info( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE lc2tts_work( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
--CREATE TABLE lc2tts_proc( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE lc2tts_proc( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
---------------------------------------------------------------
CREATE TABLE lc2tts_tests( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE lc2tts_procdata( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
---------------------------------------------------------------
CREATE TABLE IF NOT EXISTS lc2ttstemp (
"name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "url" TEXT NULL
);
CREATE TABLE IF NOT EXISTS lc2tts_proctemp( "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "url" TEXT NULL);
---------------------------------------------------------------
-- import menu
select '<span>start import to plugin tables</span>';
---------------------------------------------------------------
.separator ";"
--.import .\\resources\\plugins\\lc2tts\\import\\import.csv lc2ttstemp
-- INSERT INTO lc2tts(first_name,name,zipcode, city, description) select first_name,name,zipcode, city, description  from lc2ttstemp;
.import .\\resources\\plugins\\lc2tts\\import\\import.csv lc2tts
.import .\\resources\\plugins\\lc2tts\\import\\main.csv lc2tts_main
.import .\\resources\\plugins\\lc2tts\\import\\install.csv lc2tts_install
.import .\\resources\\plugins\\lc2tts\\import\\help.csv lc2tts_help
.import .\\resources\\plugins\\lc2tts\\import\\info.csv lc2tts_info
.import .\\resources\\plugins\\lc2tts\\import\\data.csv lc2tts_data
.import .\\resources\\plugins\\lc2tts\\import\\work.csv lc2tts_work
.import .\\resources\\plugins\\lc2tts\\import\\proc.csv lc2tts_proc
.import .\\resources\\plugins\\lc2tts\\import\\tests.csv lc2tts_tests
---------------------------------------------------------------
-- import procs
-- select '<span>importing processes</span>';
-------------------------------------------------------------
-- .separator ","
-- .import '.\\resources\\plugins\\lc2tts\\import\\proc.csv' lc2tts_proctemp
-- .separator ";"
-- INSERT INTO lc2tts_proc(first_name,name,zipcode, description,url) select first_name,name,zipcode, description,url  from lc2tts_proctemp;
-- select 'lc2tts_work count:';
-- select count(*) from lc2tts_proc;
-- eof insert work data
-- eof insert work data
---------------------------------------------------------------
-- done
select '<span>import done</span>';
---------------------------------------------------------------
select 'lc2tts count:';
select count(*) from lc2tts;
select '<p>start data import to plugin tables</p>';
-- delete from lc2tts_datatemp;
--
select '<p>lc2tts count:';
select count(*) from lc2tts;
select 'lc2tts_data count:';
select count(*) from lc2tts_data;
select 'lc2tts_info count:';
select count(*) from lc2tts_info;
select 'lc2tts_help count:';
select count(*) from lc2tts_help;
select 'lc2tts_procdata count:';
select count(*) from lc2tts_procdata;
select 'lc2tts_work count:';
select count(*) from lc2tts_work;
select 'lc2tts_proc count:';
select count(*) from lc2tts_proc;
select 'lc2tts_proctemp count:';
select count(*) from lc2tts_proctemp;

drop table IF EXISTS lc2ttstemp;
-- drop table IF EXISTS lc2tts_proctemp;
-- select '<p>Import done</p>';
select '<h4>Import lc2tts processes done.</h4>';
.exit