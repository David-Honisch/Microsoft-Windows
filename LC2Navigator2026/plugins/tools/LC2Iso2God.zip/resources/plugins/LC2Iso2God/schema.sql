select '<hr/><h2>Import LC2Iso2God processes</h2>';
-- select '<p>drop plugin tables</p>';
drop table IF EXISTS LC2Iso2God;
drop table IF EXISTS LC2Iso2God_main;
drop table IF EXISTS LC2Iso2God_install;
drop table IF EXISTS LC2Iso2God_help;
drop table IF EXISTS LC2Iso2God_data;
drop table IF EXISTS LC2Iso2God_info;
drop table IF EXISTS LC2Iso2God_work;
drop table IF EXISTS LC2Iso2God_procdata;
drop table IF EXISTS LC2Iso2Godtemp;
drop table IF EXISTS LC2Iso2God_datatemp;
drop table IF EXISTS LC2Iso2God_worktemp;
drop table IF EXISTS LC2Iso2God_proc;
drop table IF EXISTS LC2Iso2God_tests;
drop table IF EXISTS LC2Iso2God_proctemp;
---------------------------------------------------------------
select '<span>Creating tables</span>';
---------------------------------------------------------------
CREATE TABLE LC2Iso2God( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,  "url" TEXT NULL);
CREATE TABLE LC2Iso2God_main( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE LC2Iso2God_install( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE LC2Iso2God_help( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE LC2Iso2God_data( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE LC2Iso2God_info( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE LC2Iso2God_work( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE LC2Iso2God_proc( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
---------------------------------------------------------------
CREATE TABLE LC2Iso2God_tests( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE LC2Iso2God_procdata( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
---------------------------------------------------------------
CREATE TABLE IF NOT EXISTS LC2Iso2Godtemp (
"name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "url" TEXT NULL
);
CREATE TABLE IF NOT EXISTS LC2Iso2God_proctemp( "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "url" TEXT NULL);
---------------------------------------------------------------
-- import menu
select '<span>start import to plugin tables</span>';
---------------------------------------------------------------
.separator ";"
--.import .\\resources\\plugins\\LC2Iso2God\\import\\import.csv LC2Iso2Godtemp
-- INSERT INTO LC2Iso2God(first_name,name,zipcode, city, description) select first_name,name,zipcode, city, description  from LC2Iso2Godtemp;
.import .\\resources\\plugins\\LC2Iso2God\\import\\import.csv LC2Iso2God
.import .\\resources\\plugins\\LC2Iso2God\\import\\main.csv LC2Iso2God_main
.import .\\resources\\plugins\\LC2Iso2God\\import\\install.csv LC2Iso2God_install
.import .\\resources\\plugins\\LC2Iso2God\\import\\help.csv LC2Iso2God_help
.import .\\resources\\plugins\\LC2Iso2God\\import\\data.csv LC2Iso2God_data
.import .\\resources\\plugins\\LC2Iso2God\\import\\info.csv LC2Iso2God_info
.import .\\resources\\plugins\\LC2Iso2God\\import\\work.csv LC2Iso2God_work
.import .\\resources\\plugins\\LC2Iso2God\\import\\proc.csv LC2Iso2God_proc
.import .\\resources\\plugins\\LC2Iso2God\\import\\tests.csv LC2Iso2God_tests
---------------------------------------------------------------
-- import procs
select '<span>importing processes</span>';
---------------------------------------------------------------
-- .separator ","
-- .import '.\\resources\\plugins\\LC2Iso2God\\import\\proc.csv' LC2Iso2God_proctemp
-- .separator ";"
-- INSERT INTO LC2Iso2God_proc(first_name,name,zipcode, description,url) select first_name,name,zipcode, description,url  from LC2Iso2God_proctemp;
-- select 'LC2Iso2God_work count:';
-- select count(*) from LC2Iso2God_proc;
-- eof insert work data
-- eof insert work data
---------------------------------------------------------------
-- done
select '<span>import done</span>';
---------------------------------------------------------------
select 'LC2Iso2God count:';
select count(*) from LC2Iso2God;
select '<p>start data import to plugin tables</p>';
-- delete from LC2Iso2God_datatemp;
--
select '<p>LC2Iso2God count:';
select count(*) from LC2Iso2God;
select 'LC2Iso2God_data count:';
select count(*) from LC2Iso2God_data;
select 'LC2Iso2God_info count:';
select count(*) from LC2Iso2God_info;

select 'LC2Iso2God_procdata count:';
select count(*) from LC2Iso2God_procdata;
select 'LC2Iso2God_work count:';
select count(*) from LC2Iso2God_work;
select 'LC2Iso2God_proc count:';
select count(*) from LC2Iso2God_proc;
select 'LC2Iso2God_proctemp count:';
select count(*) from LC2Iso2God_proctemp;

drop table IF EXISTS LC2Iso2Godtemp;
-- drop table IF EXISTS LC2Iso2God_proctemp;
-- select '<p>Import done</p>';
select '<h4>Import LC2Iso2God processes done.</h4>';
.exit