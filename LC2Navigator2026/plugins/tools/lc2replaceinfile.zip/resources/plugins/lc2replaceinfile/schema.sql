select '<hr/><h2>Import lc2replaceinfile processes</h2>';
select '<p>drop plugin tables</p>';
drop table IF EXISTS lc2replaceinfile;
drop table IF EXISTS lc2replaceinfile_main;
drop table IF EXISTS lc2replaceinfile_install;
drop table IF EXISTS lc2replaceinfile_help;
drop table IF EXISTS lc2replaceinfile_data;
drop table IF EXISTS lc2replaceinfile_info;
drop table IF EXISTS lc2replaceinfile_work;
drop table IF EXISTS lc2replaceinfile_procdata;
drop table IF EXISTS lc2replaceinfiletemp;
drop table IF EXISTS lc2replaceinfile_datatemp;
drop table IF EXISTS lc2replaceinfile_worktemp;
drop table IF EXISTS lc2replaceinfile_proc;
drop table IF EXISTS lc2replaceinfile_tests;
drop table IF EXISTS lc2replaceinfile_proctemp;
---------------------------------------------------------------
select '<span>Creating tables</span>';
---------------------------------------------------------------
CREATE TABLE lc2replaceinfile( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,  "url" TEXT NULL);
CREATE TABLE lc2replaceinfile_main( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE lc2replaceinfile_install( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE lc2replaceinfile_help( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE lc2replaceinfile_data( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE lc2replaceinfile_info( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE lc2replaceinfile_work( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
--CREATE TABLE lc2replaceinfile_proc( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE lc2replaceinfile_proc( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
---------------------------------------------------------------
CREATE TABLE lc2replaceinfile_tests( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE lc2replaceinfile_procdata( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
---------------------------------------------------------------
CREATE TABLE IF NOT EXISTS lc2replaceinfiletemp (
"name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "url" TEXT NULL
);
CREATE TABLE IF NOT EXISTS lc2replaceinfile_proctemp( "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "url" TEXT NULL);
---------------------------------------------------------------
-- import menu
select '<span>start import to plugin tables</span>';
---------------------------------------------------------------
.separator ";"
--.import .\\resources\\plugins\\lc2replaceinfile\\import\\import.csv lc2replaceinfiletemp
-- INSERT INTO lc2replaceinfile(first_name,name,zipcode, city, description) select first_name,name,zipcode, city, description  from lc2replaceinfiletemp;
.import .\\resources\\plugins\\lc2replaceinfile\\import\\import.csv lc2replaceinfile
.import .\\resources\\plugins\\lc2replaceinfile\\import\\main.csv lc2replaceinfile_main
.import .\\resources\\plugins\\lc2replaceinfile\\import\\install.csv lc2replaceinfile_install
.import .\\resources\\plugins\\lc2replaceinfile\\import\\help.csv lc2replaceinfile_help
.import .\\resources\\plugins\\lc2replaceinfile\\import\\info.csv lc2replaceinfile_info
.import .\\resources\\plugins\\lc2replaceinfile\\import\\data.csv lc2replaceinfile_data
.import .\\resources\\plugins\\lc2replaceinfile\\import\\work.csv lc2replaceinfile_work
.import .\\resources\\plugins\\lc2replaceinfile\\import\\proc.csv lc2replaceinfile_proc
.import .\\resources\\plugins\\lc2replaceinfile\\import\\tests.csv lc2replaceinfile_tests
---------------------------------------------------------------
-- import procs
-- select '<span>importing processes</span>';
-------------------------------------------------------------
-- .separator ","
-- .import '.\\resources\\plugins\\lc2replaceinfile\\import\\proc.csv' lc2replaceinfile_proctemp
-- .separator ";"
-- INSERT INTO lc2replaceinfile_proc(first_name,name,zipcode, description,url) select first_name,name,zipcode, description,url  from lc2replaceinfile_proctemp;
-- select 'lc2replaceinfile_work count:';
-- select count(*) from lc2replaceinfile_proc;
-- eof insert work data
-- eof insert work data
---------------------------------------------------------------
-- done
select '<span>import done</span>';
---------------------------------------------------------------
select 'lc2replaceinfile count:';
select count(*) from lc2replaceinfile;
select '<p>start data import to plugin tables</p>';
-- delete from lc2replaceinfile_datatemp;
--
select '<p>lc2replaceinfile count:';
select count(*) from lc2replaceinfile;
select 'lc2replaceinfile_data count:';
select count(*) from lc2replaceinfile_data;
select 'lc2replaceinfile_info count:';
select count(*) from lc2replaceinfile_info;
select 'lc2replaceinfile_help count:';
select count(*) from lc2replaceinfile_help;
select 'lc2replaceinfile_procdata count:';
select count(*) from lc2replaceinfile_procdata;
select 'lc2replaceinfile_work count:';
select count(*) from lc2replaceinfile_work;
select 'lc2replaceinfile_proc count:';
select count(*) from lc2replaceinfile_proc;
select 'lc2replaceinfile_proctemp count:';
select count(*) from lc2replaceinfile_proctemp;

drop table IF EXISTS lc2replaceinfiletemp;
-- drop table IF EXISTS lc2replaceinfile_proctemp;
-- select '<p>Import done</p>';
select '<h4>Import lc2replaceinfile processes done.</h4>';
.exit