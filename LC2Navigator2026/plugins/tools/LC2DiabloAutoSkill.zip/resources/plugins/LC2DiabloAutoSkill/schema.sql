-- select '<h2>Import processes</h2>';
drop table IF EXISTS LC2DiabloAutoSkill;
drop table IF EXISTS LC2DiabloAutoSkill_data;
drop table IF EXISTS LC2DiabloAutoSkill_procdata;
drop table IF EXISTS LC2DiabloAutoSkilltemp;
drop table IF EXISTS LC2DiabloAutoSkill_datatemp;
CREATE TABLE LC2DiabloAutoSkill( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE LC2DiabloAutoSkill_data( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE LC2DiabloAutoSkill_procdata( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE IF NOT EXISTS LC2DiabloAutoSkilltemp (
"name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL
);
-- create table IF NOT EXISTS LC2DiabloAutoSkill_datatemp ( name varchar(255));
CREATE TABLE IF NOT EXISTS LC2DiabloAutoSkill_datatemp (
"name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL
);
-- import menu
-- select '<p>Import processes</p>';
.separator ";"
-- .import .\\resources\\plugins\\LC2DiabloAutoSkill\\import\\import.csv LC2DiabloAutoSkilltemp
-- INSERT INTO LC2DiabloAutoSkill(first_name,name,zipcode, city, description) select first_name,name,zipcode, city, description  from LC2DiabloAutoSkilltemp;
.import .\\resources\\plugins\\LC2DiabloAutoSkill\\import\\import.csv LC2DiabloAutoSkill
--
-- eof insert work data
select 'LC2DiabloAutoSkill count:';
select count(*) from LC2DiabloAutoSkill;
--.separator ';'
.separator ";"
--.import '.\\resources\\plugins\\LC2DiabloAutoSkill\\import\\menu.csv' LC2DiabloAutoSkill_datatemp
-- .import '.\\resources\\plugins\\LC2DiabloAutoSkill\\import\\menu.csv' LC2DiabloAutoSkill_datatemp
-- INSERT INTO LC2DiabloAutoSkill_data(first_name,name,zipcode, city, description) select first_name,name,zipcode, city, description  from LC2DiabloAutoSkill_datatemp;
.import '.\\resources\\plugins\\LC2DiabloAutoSkill\\import\\menu.csv' LC2DiabloAutoSkill_data
delete from LC2DiabloAutoSkill_datatemp;
--
-- .separator ","
-- .import '.\\resources\\plugins\\LC2DiabloAutoSkill\\import\\LC2DiabloAutoSkillwork.csv' LC2DiabloAutoSkill_datatemp
-- INSERT INTO LC2DiabloAutoSkill_procdata(first_name,name,zipcode, city, description) select first_name,name,zipcode, city, description  from LC2DiabloAutoSkill_datatemp;
--
select '<p>LC2DiabloAutoSkill count:';
select count(*) from LC2DiabloAutoSkill;
select 'LC2DiabloAutoSkill_data count:';
select count(*) from LC2DiabloAutoSkill_data;
select 'LC2DiabloAutoSkill_procdata count:';
select count(*) from LC2DiabloAutoSkill_procdata;
.separator ";"
drop table IF EXISTS LC2DiabloAutoSkilltemp;
-- select '<p>Import done</p>';
.exit