select '<hr/><h2>Import lc2memory processes</h2>';
select '<p>drop plugin tables</p>';
drop table IF EXISTS lc2memory;
drop table IF EXISTS lc2memory_main;
drop table IF EXISTS lc2memory_install;
drop table IF EXISTS lc2memory_help;
drop table IF EXISTS lc2memory_data;
drop table IF EXISTS lc2memory_info;
drop table IF EXISTS lc2memory_work;
drop table IF EXISTS lc2memory_procdata;
drop table IF EXISTS lc2memorytemp;
drop table IF EXISTS lc2memory_datatemp;
drop table IF EXISTS lc2memory_worktemp;
drop table IF EXISTS lc2memory_proc;
drop table IF EXISTS lc2memory_tests;
drop table IF EXISTS lc2memory_proctemp;
---------------------------------------------------------------
select '<span>Creating tables</span>';
---------------------------------------------------------------
CREATE TABLE lc2memory( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,  "url" TEXT NULL);
CREATE TABLE lc2memory_main( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE lc2memory_install( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE lc2memory_help( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE lc2memory_data( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE lc2memory_info( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE lc2memory_work( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
--CREATE TABLE lc2memory_proc( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE lc2memory_proc( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
---------------------------------------------------------------
CREATE TABLE lc2memory_tests( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE lc2memory_procdata( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
---------------------------------------------------------------
CREATE TABLE IF NOT EXISTS lc2memorytemp (
"name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "url" TEXT NULL
);
CREATE TABLE IF NOT EXISTS lc2memory_proctemp( "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "url" TEXT NULL);
---------------------------------------------------------------
-- import menu
select '<span>start import to plugin tables</span>';
---------------------------------------------------------------
.separator ";"
--.import .\\resources\\plugins\\lc2memory\\import\\import.csv lc2memorytemp
-- INSERT INTO lc2memory(first_name,name,zipcode, city, description) select first_name,name,zipcode, city, description  from lc2memorytemp;
.import .\\resources\\plugins\\lc2memory\\import\\import.csv lc2memory
.import .\\resources\\plugins\\lc2memory\\import\\main.csv lc2memory_main
.import .\\resources\\plugins\\lc2memory\\import\\install.csv lc2memory_install
.import .\\resources\\plugins\\lc2memory\\import\\help.csv lc2memory_help
.import .\\resources\\plugins\\lc2memory\\import\\info.csv lc2memory_info
.import .\\resources\\plugins\\lc2memory\\import\\data.csv lc2memory_data
.import .\\resources\\plugins\\lc2memory\\import\\work.csv lc2memory_work
.import .\\resources\\plugins\\lc2memory\\import\\proc.csv lc2memory_proc
.import .\\resources\\plugins\\lc2memory\\import\\tests.csv lc2memory_tests
---------------------------------------------------------------
-- import procs
-- select '<span>importing processes</span>';
-------------------------------------------------------------
-- .separator ","
-- .import '.\\resources\\plugins\\lc2memory\\import\\proc.csv' lc2memory_proctemp
-- .separator ";"
-- INSERT INTO lc2memory_proc(first_name,name,zipcode, description,url) select first_name,name,zipcode, description,url  from lc2memory_proctemp;
-- select 'lc2memory_work count:';
-- select count(*) from lc2memory_proc;
-- eof insert work data
-- eof insert work data
---------------------------------------------------------------
-- done
select '<span>import done</span>';
---------------------------------------------------------------
select 'lc2memory count:';
select count(*) from lc2memory;
select '<p>start data import to plugin tables</p>';
-- delete from lc2memory_datatemp;
--
select '<p>lc2memory count:';
select count(*) from lc2memory;
select 'lc2memory_data count:';
select count(*) from lc2memory_data;
select 'lc2memory_info count:';
select count(*) from lc2memory_info;
select 'lc2memory_help count:';
select count(*) from lc2memory_help;
select 'lc2memory_procdata count:';
select count(*) from lc2memory_procdata;
select 'lc2memory_work count:';
select count(*) from lc2memory_work;
select 'lc2memory_proc count:';
select count(*) from lc2memory_proc;
select 'lc2memory_proctemp count:';
select count(*) from lc2memory_proctemp;

drop table IF EXISTS lc2memorytemp;
-- drop table IF EXISTS lc2memory_proctemp;
-- select '<p>Import done</p>';
select '<h4>Import lc2memory processes done.</h4>';
.exit