package org.letztechance.domain.app;

import java.util.HashMap;
import java.util.Map;

import org.apache.logging.log4j.Logger;
import org.letztechance.domain.api.cli.config.Config;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;



@SpringBootApplication
@RestController
public class ApplicationSQLite3WinMain {
	private static final Class<ApplicationSQLite3WinMain> CLS = ApplicationSQLite3WinMain.class;
	private final static Logger LOG = Config.setLogManager(CLS);
	private static final String WELCOME_TO_LC_CMS = "Welcome to LetzteChance.Org Docker CMS" + "<br/>"
			+ getLink("/", "Home") + "<br/>" 
			+ getLink("/info/", "Info")
			+ getLink("/coredata/", "CoreData")
			;
	private static final String INFO_TEXT = "Info of LetzteChance.Org Docker CMS" + "<br/>" + getLink("/", "Home")
			+ "<br/>" + getLink("/info/", "Info");

	@RequestMapping("/")
	public String home() {
		LOG.debug(WELCOME_TO_LC_CMS);
		return WELCOME_TO_LC_CMS;
	}

	@RequestMapping("/info")
	public String info() {
		LOG.debug(INFO_TEXT);
		return INFO_TEXT;
	}
	
	@RequestMapping("/coredata")
	public Map<String, String> coredata() {
		LOG.debug(INFO_TEXT);
		return reservations;
	}

	public static String getLink(String src, String text) {
		return getLink(src, text, "_parent");
	}

	public static String getLink(String src, String text, String target) {
		LOG.debug(CLS + " reading:" + src);
		target = target != null ? target : "_parent";
		String result = "<a href=\"" + src + "\" target=\"" + target + "\">" + text + "</a>";

		return result;
	}

	private static final Map<String, String> reservations = new HashMap<String, String>() {
		{
			put("saturday", "No reservation");
			put("sunday", "No reservation");
		}
	};

	public static void main(String[] args) {
		LOG.debug(CLS + " running...");
		//startJavaLin();
		SpringApplication.run(ApplicationSQLite3WinMain.class, args);
	}

//	private static void startJavaLin() {
//		Javalin app = Javalin.create(config -> {
//			config.staticFiles.add("/public", Location.CLASSPATH);
//		});
//
//		app.post("/make-reservation", ctx -> {
//			reservations.put(ctx.formParam("day"), ctx.formParam("time"));
//			ctx.html("Your reservation has been saved");
//		});
//
//		app.get("/check-reservation", ctx -> {
//			ctx.html(reservations.get(ctx.queryParam("day")));
//		});
//
//		app.start();
//	}

}
