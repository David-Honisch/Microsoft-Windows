import {Component, OnInit} from '@angular/core';
import {HttpClient, HttpClientModule} from "@angular/common/http";

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  providers: [HttpClientModule]
})
export class AppComponent {
  constructor(private httpClient: HttpClient) {
  }

  serverMessage = this.httpClient.get<{title: string}>("api/message");
  serverLOG = this.httpClient.get<{message: string}>("api/log");
  aiServerLOG = this.httpClient.get<{message: string}>("api/watsonx/message");
  aiAuthMessage = this.httpClient.get<{message: string}>("api/watsonx/getAuth");
//  aitextToSpeechMessage = this.httpClient.get("api/watsonx/textToSpeech");
  
  aiServerLOGMessage = this.httpClient.get<{message: string}>("api/watsonx/log");
}
