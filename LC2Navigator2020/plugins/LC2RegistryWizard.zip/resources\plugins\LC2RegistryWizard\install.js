try {
    document.getElementById("appcnt").innerHTML = "";
    document.getElementById("modcnt").innerHTML = "";
    for (var v in installDirectories) {
        createDir(installDirectories[v]);
    }
    var path = window.nodeRequire('path');
    var modDir = path.join(__dirname, '../../../resources/');
    InstallModules(modDir);
    // InstallModules(targetDir);
    var downloadDir = path.join(__dirname, '../../../');
    doDownload(downloadUrls, downloadDir);
    for (v in execScripts) {
        alert('Test');
        // new HttpRequest().execCMD('.\\resources\\plugins\\graburls\\mvninstall.bat install', 'mvncnt');
        new HttpRequest().execCMD(execScripts[v]["file"], 'mvncnt');
    }

    // doUnzip(downloadUrls, targetDir);
} catch (e) {
    alert(e.stack);
}
// try {
//     // updateApp(links);
//     const targetDir = path.join(__dirname, '../../../../');
//     // alert(targetDir + " <strong>found.</strong>.<br>");
//     //downloadAppBinaries(downloadUrls[0], targetDir);
//     downloadAppBinaries(downloadUrls[0], targetDir);
//     // bulkDownloadAppBinaries(downloadUrls, targetDir);
// } catch (error) {
//     alert(error.stack);
// }