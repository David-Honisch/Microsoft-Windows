SELECT '<h1>apache-maven PLUGIN SQL SCRIPT IS RUNNING</h1>'; 
SELECT '<h5>Deleting import script</h5>'; 
SELECT '<h5>RUNNING IMPORT</h5>'; 
SELECT '<h4>SET CLEAR</h4>'; 
select count(*) as count from application; 
SELECT '<h4>DELETING application</h4>'; 
SELECT '<h1>UPDATE apache-maven SQL SCRIPT DONE</h1>'; 
INSERT OR REPLACE INTO application(person_id, name, first_name, description, zipcode, city, street, url)
VALUES(20,'apache-maven Plugin v.1.01a','apache-maven Plugin v.1.01a','','','','','exec .\\resources\\plugins\\apache-maven\\apache-maven.bat .\\resources\\plugins\\apache-maven\\menu.csv'); 
select count(*) as count from application; 
SELECT '<h5>SQL apache-maven IMPORT DONE</h5>'; 
