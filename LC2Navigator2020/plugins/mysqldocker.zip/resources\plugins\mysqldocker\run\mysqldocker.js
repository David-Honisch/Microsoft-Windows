// alert(__dirname+'..\\resources\\plugins\\mysqldocker\\run\\installmysqldocker.bat');
new HttpRequest().evalCMD('.\\resources\\plugins\\mysqldocker\\run\\installmysqldocker.bat');