SELECT '<h1>mysqldocker PLUGIN SQL SCRIPT IS RUNNING</h1>';
SELECT '<h5>Deleting import script</h5>';
--DELETE FROM importscripts;
SELECT '<h5>RUNNING IMPORT</h5>';
SELECT '<h4>SET CLEAR</h4>';
SELECT '<h4>DELETING application</h4>';
--INSERT OR REPLACE INTO importscripts (first_name,name,url) 
--values 
--('Grab Urls v.1.0','Grab Urls v.1.0','.\\resources\\plugins\\atari.bat atariemulator.zip');
--.separator "\t"
--.import .\\plugins.csv importscripts
--SELECT first_name, COUNT(*) c FROM importscripts GROUP BY first_name HAVING c > 1;

SELECT '<h1>UPDATE SQL SCRIPT DONE</h1>';
select count(*) as count from application;
SELECT '<h1>UPDATE LC2IRC SQL SCRIPT DONE</h1>'; 
INSERT OR REPLACE INTO application(person_id, name, first_name, description, zipcode, city, street, url)
VALUES(12,'mysqldocker v.1.01a','mysqldocker v.1.01a','','','','','exec .\\resources\\plugins\\mysqldocker\\mysqldocker.bat .\\resources\\plugins\\mysqldocker\\mysqldocker.menu.csv'); 
select count(*) as count from application;
SELECT '<h5>SQL IMPORT DONE</h5>';
