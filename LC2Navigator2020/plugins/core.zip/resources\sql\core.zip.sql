SELECT '<h1>CORE PLUGIN SQL SCRIPT IS RUNNING</h1>';
SELECT '<p>Deleting import script</p>';
--DELETE FROM importscripts;
SELECT '<h5>RUNNING IMPORT</h5>';
SELECT '<p>SET CLEAR</p>';
SELECT '<h4>DELETING application</h4>';
SELECT '<h4>DELETING application</h4>';
--INSERT OR REPLACE INTO importscripts (first_name,name,url) 
--values 
--('Grab Urls v.1.0','Grab Urls v.1.0','.\\resources\\plugins\\atari.bat atariemulator.zip');
--.separator "\t"
--.import .\\plugins.csv importscripts
--SELECT first_name, COUNT(*) c FROM importscripts GROUP BY first_name HAVING c > 1;

SELECT '<h1>UPDATE SQL SCRIPT DONE</h1>';

INSERT OR REPLACE INTO application (first_name,name,url) 
values 
('Core Plugin Menu v.0.1a','Core Plugin Menu v.0.1a','.\\resources\\plugins\\core\\core.bat .\\resources\\plugins\\core\\core.menu.csv');');
INSERT OR REPLACE INTO application (first_name,name,url) 
values 
('AllPlugins Menu v.1.01a','AllPlugins Menu v.1.01a','.\\resources\\plugins\\all\\all.bat .\\resources\\plugins\\all\\all.menu.csv');');

SELECT '<p>Applications imported'||count(*)||'</p>' from application;

SELECT '<h5>SQL IMPORT DONE</h5>';
