SELECT '<h1>core PLUGIN SQL SCRIPT IS RUNNING</h1>'; 
SELECT '<h5>Deleting import script</h5>'; 
SELECT '<h5>RUNNING IMPORT</h5>'; 
SELECT '<h4>SET CLEAR</h4>'; 
SELECT '<h4>DELETING application</h4>';
select count(*) as count from application;
SELECT '<h1>UPDATE core SQL SCRIPT DONE</h1>'; 
INSERT OR REPLACE INTO application(person_id, name, first_name, description, zipcode, city, street, url) 
VALUES(5,'core v.1.01a','core v.1.01a','','','','','exec .\\resources\\plugins\\core\\core.bat .\\resources\\plugins\\core\\menu.csv'); 
select count(*) as count from application;
SELECT '<h5>SQL core IMPORT DONE</h5>'; 
