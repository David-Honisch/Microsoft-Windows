SELECT '<h1>core PLUGIN SQL SCRIPT IS RUNNING</h1>'; 
SELECT '<h5>Deleting import script</h5>'; 
SELECT '<h5>RUNNING IMPORT</h5>'; 
SELECT '<h4>SET CLEAR</h4>'; 
SELECT '<h4>DELETING application</h4>'; 
SELECT '<h1>UPDATE core SQL SCRIPT DONE</h1>'; 
INSERT INTO application VALUES(25,'core v.1.01a','core v.1.01a','','','','','exec .\\resources\\plugins\\core\\core.bat .\\resources\\plugins\\core\\menu.csv'); 
SELECT '<h5>SQL core IMPORT DONE</h5>'; 
