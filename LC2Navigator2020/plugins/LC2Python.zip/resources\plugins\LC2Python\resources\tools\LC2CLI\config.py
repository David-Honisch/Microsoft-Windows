config = {
  "port": 9051,
  "title": "letztechance.org - Tor Proxy",
  "host": "https://www.letztechance.org"  
} 
person = {
  "name": "John",
  "age": 36,
  "country": "Norway"
} 
html = {
  "br" : "^<br^>",
  "name": "John",
  "age": 36,
  "country": "Norway"
} 
