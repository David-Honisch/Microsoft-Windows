import config
import JSONUtil as json
import CLIController as cli
import WebController as webCtrl
import requests
from stem import Signal
from stem.control import Controller
import os
br = config.html["br"]
print(cli.runPrint("echo "+br+""+config.config["title"]))
res = webCtrl.getContoller(9050)
print(cli.runPrint("echo "+br+" Result:"+br+""+res+"Done"))
# ctrl = webCtrl.getContollerFromPort(9050)
# print(cli.runPrint("echo "+br+" Result:"+br+""+res+"Done"))
# from fake_useragent import UserAgent
# headers = { 'User-Agent': UserAgent().random }
# requests.get(url, proxies=proxies, headers=headers).text
# print(cli.runPrint("echo "+br+"EOF"+br+""+config.config["title"]+" done."))
print(cli.runPrint("echo "+br+"eof"))