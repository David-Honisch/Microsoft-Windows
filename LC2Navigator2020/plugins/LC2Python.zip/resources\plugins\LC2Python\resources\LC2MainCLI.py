
import json


class Application():
    def create_widgets(self):
        print("creating out...")
        with open('cfg.json') as f:
            data = json.load(f)
            # Output: {'name': 'Bob', 'languages': ['English', 'Fench']}
            print(data["name"])

    def exec_process(self,proc):
        print("exec:"+proc)    
    
    def turn_red(self, event):
        event.widget["activeforeground"] = "red"    

    def say_HI(self):
        out = "Welcome to letztechance.org!"
        print(out)        

app = Application()
app.create_widgets()
app.exec_process("echo Welcome")
