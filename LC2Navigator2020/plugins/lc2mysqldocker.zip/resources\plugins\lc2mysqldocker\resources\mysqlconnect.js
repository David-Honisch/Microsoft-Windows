var mysql = require('mysql');

var con = mysql.createConnection({
  host: "localhost",
  port: "3307",
  user: "mysql",  
  password: "letztechance.org"
});

con.connect(function(err) {
  if (err) throw err;
  console.log("Connected!");
});