function utf8_encode(s) {
    return unescape(encodeURIComponent(s));
}

function utf8_decodee(s) {
    return decodeURIComponent(escape(s));
}

function utf8_decode(s) {
    var result;
    try {
        result = decodeURIComponent(escape(s));
    } catch (e) {
        // console.log(e);
    }
    result = (result !== null && result !== undefined && result.length > 0) ? result : s;
    return result;
}

function ifExists(obj) {
    return (obj !== "N/A" ? obj : "");
}

function toggle_visibility(className) {
    $('.' + className).toggle();
}

function scrollTo(scrollId, outputId, delay) {
    jQuery("html, body" + scrollId).delay(20).animate({
        scrollTop: jQuery(outputId).offset().top
    }, delay !== undefined ? delay : 20);
}

function eMsg(e) {
    alert(e);
    console.error(e);
    if (e.message !== undefined)
        alert(e.message);
    // electron.dialog.showMessageBox({ message: "Exception: " + e.message, message: ["OK"] });
    if (e.stack !== undefined)
        alert(e.stack);
    // electron.dialog.showMessageBox({ message: "Stack: " + e.stack, buttons: ["OK"] });
}

function HttpRequest() {
    this.token = '';
    this.anonymous = "anonymous";
    this.NotLoggedInText = "Invalid login. Please try again with different credentials.<br/>Result:";
    this.url = hostName + '/';
}

HttpRequest.prototype.getExtFile = function(url) {
    const electron = window.nodeRequire('electron');
    const BrowserWindow = electron.remote.BrowserWindow;
    const path = window.nodeRequire('path');
    const childWindow = new BrowserWindow({
        width: 800,
        height: 600
    });
    console.log("Loading" + url);
    childWindow.loadURL(url);
}
HttpRequest.prototype.getExtFile = function(url, w, h) {
    const electron = window.nodeRequire('electron');
    const BrowserWindow = electron.remote.BrowserWindow;
    const path = window.nodeRequire('path');
    const childWindow = new BrowserWindow({
        width: w,
        height: h
    });
    console.log("Loading" + url);
    childWindow.loadURL(url);
}
HttpRequest.prototype.getLocalFile = function(url) {
    const electron = window.nodeRequire('electron');
    const BrowserWindow = electron.remote.BrowserWindow;
    const path = window.nodeRequire('path');
    const childWindow = new BrowserWindow({
        width: 800,
        height: 600
    });
    console.log("file://" + __dirname + "/" + url);
    childWindow.loadURL("file://" + __dirname + "/" + url);
}
HttpRequest.prototype.execCMD = function(text, id) {
    const {
        exec
    } = window.nodeRequire('child_process');
    document.getElementById("error").innerHTML = "";
    document.getElementById(id).innerHTML = "<div class=\"preload\"></div>";
    // alert('OUT:'+text.length);
    exec('' + text, (err, stdout, stderr) => {

        if (err) {
            console.error(err);
            document.getElementById("error").innerHTML = "" + JSON.stringify(err);
            document.getElementById(id).innerHTML = stdout;
            return;
        }
        console.log('OUT:' + stdout);
        document.getElementById(id).innerHTML = stdout;
        $("html, body").delay(100).animate({
            scrollTop: $('#' + id).offset().top
        }, 30);
    });
}
HttpRequest.prototype.evalCMD = function(text) {
    const {
        exec
    } = window.nodeRequire('child_process');
    exec('' + text, (err, stdout, stderr) => {

        if (err) {
            console.error(err);
            return;
        }
        console.log('OUT:' + stdout);
        // document.getElementById(id).innerHTML = stdout;
        eval(stdout);
    });
}
HttpRequest.prototype.execFile = function(text, params, id) {
    const {
        execFile
    } = window.nodeRequire('child_process');
    document.getElementById("error").innerHTML = "";
    document.getElementById(id).innerHTML = "<div class=\"preload\"></div>";
    // alert('OUT:'+text.length);
    execFile('' + text, params, (err, stdout, stderr) => {

        if (err) {
            console.error(err);
            document.getElementById("error").innerHTML = "" + JSON.stringify(err);
            document.getElementById(id).innerHTML = stdout;
            return;
        }
        console.log(stdout);
        document.getElementById(id).innerHTML = stdout;
    });
}
HttpRequest.prototype._execCMD = function(text, id) {
    this.__execCMD(text, [], id)

}
HttpRequest.prototype.__execCMD = function(text, params, id) {
    var result = '';
    const { spawn } = require('child_process');
    document.getElementById("error").innerHTML = "";
    document.getElementById(id).innerHTML = "<div class=\"preload\"></div>";
    const ls = spawn('' + text, params);
    ls.stdout.on('data', (data) => {
        // console.log(`${data}`);
        document.getElementById(id).innerHTML += data;
    });
    ls.stderr.on('data', (data) => {
        document.getElementById(id).innerHTML = data;
        console.error(`stderr: ${data}`);
    });
    ls.on('close', (code) => {
        console.log(`child process exited with code ${code}`);
    });

}
HttpRequest.prototype.__execCMD = function(text, id) {
    const {
        exec
    } = require('child_process');
    document.getElementById("error").innerHTML = "";
    document.getElementById(id).innerHTML = "<div class=\"preload\"></div>";
    // alert('OUT:'+text.length);
    exec('' + text, (err, stdout, stderr) => {

        if (err) {
            console.error(err);
            document.getElementById("error").innerHTML = "" + JSON.stringify(err);
            document.getElementById(id).innerHTML = stdout;
            return;
        }
        console.log(stdout);
        document.getElementById(id).innerHTML = stdout;
    });
}
HttpRequest.prototype.printHTML = function(id, text) {
    document.getElementById(id).innerHTML = text;
}
HttpRequest.prototype.getIndex = function() {
    var request = window.nodeRequire("request");
    var url = hostName + '/indextools';
    request({
        url: url,
        json: true
    }, function(error, response, body) {

        if (!error && response.statusCode === 200) {
            var result = '';
            for (var v in body) {
                var s = utf8_decode(body[v]);
                result += "<a href=\"#out\" onclick=\"new HttpRequest().execCMD('" + s + "','homecnt')\" target=\"_parent\">" + s + "</a><br/>";
            }
            document.getElementById("homeresult").innerHTML = "" + result;
        }
    })
}
HttpRequest.prototype.getCheck = function() {
    var request = window.nodeRequire("request");
    var url = hostName + '/check';
    request({
        url: url,
        json: true
    }, function(error, response, body) {

        if (!error && response.statusCode === 200) {
            var result = '';
            for (var v in body) {
                var s = utf8_decode(body[v]);
                if (s.includes("check") || s.includes("verify"))
                    result += "<a href=\"#checkcnt\" onclick=\"new HttpRequest().execCMD('" + s + "','checkcnt')\" target=\"_parent\">" + s + "</a><br/>";
            }
            document.getElementById("out").innerHTML = "" + result;
        }
    })
}
HttpRequest.prototype.getSearch = function() {
    var request = window.nodeRequire("request");
    var url = hostName + '/index';
    request({
        url: url,
        json: true
    }, function(error, response, body) {

        if (!error && response.statusCode === 200) {
            var result = '';
            for (var v in body[0]) {
                result += "<a href=\"#\" target=\"_blank\">" + utf8_decode(body[0][v]) + "</a><br/>";
            }
            document.getElementById("searchresult").innerHTML += "" + result;
        }
    })
}
HttpRequest.prototype.getTools = function() {
    var request = window.nodeRequire("request");
    var url = hostName + '/tools';
    request({
        url: url,
        json: true
    }, function(error, response, body) {

        if (!error && response.statusCode === 200) {
            var result = '';
            for (var v in body) {
                var s = utf8_decode(body[v]);
                result += "<a href=\"#toolscnt\" onclick=\"new HttpRequest().execCMD('" + s + "','toolscnt')\" target=\"_parent\">" + s + "</a><br/>";
                // result += "<a href=\"cmd " + s + "\" target=\"_blank\">" + s + "</a><br/>";
            }
            document.getElementById("toolsresult").innerHTML = "" + result;
        }
    })
}
HttpRequest.prototype.getImport = function() {
    var request = window.nodeRequire("request");
    var url = hostName + '/importtools';
    request({
        url: url,
        json: true
    }, function(error, response, body) {

        if (!error && response.statusCode === 200) {
            var result = '';
            for (var v in body) {
                var s = utf8_decode(body[v]);
                result += "<a href=\"#toolscontent\" onclick=\"new HttpRequest().execCMD('" + s + "','importcnt')\" target=\"_parent\">" + s + "</a><br/>";
            }
            document.getElementById("importresult").innerHTML = "" + result;
        }
    })
}
HttpRequest.prototype.getDocs = function() {
    var request = window.nodeRequire("request");
    var url = hostName + '/docs';
    request({
        url: url,
        json: true
    }, function(error, response, body) {

        if (!error && response.statusCode === 200) {
            var result = '';
            for (var v in body) {
                var s = utf8_decode(body[v]);
                result += "<a href=\"#toolscontent\" onclick=\"new HttpRequest().execCMD('" + s + "','toolscontent')\" target=\"_parent\">x</a>|";
                result += "<a href=\"#toolscontent\" onclick=\"new HttpRequest().execCMD('" + s + "','importcnt')\" target=\"_parent\">s</a>|";
                result += "<a href=\"javascript:alert('" + s + "');javascript:createChild('" + s + "');\" target=\"_blank\">" + s + "</a><br/>";
            }
            document.getElementById("docsresult").innerHTML = "" + result;
        }
    })
}
HttpRequest.prototype.getFaq = function() {
    var request = window.nodeRequire("request");
    var url = hostName + '/faq';
    request({
        url: url,
        json: true
    }, function(error, response, body) {

        if (!error && response.statusCode === 200) {
            var result = '';
            for (var v in body) {
                var s = utf8_decode(body[v]);
                result += "<a href=\"#faqcontent\" onclick=\"new HttpRequest().execCMD('" + s + "','faqcontent')\" target=\"_parent\">x</a>|";
                result += "<a href=\"#faqscontent\" onclick=\"new HttpRequest().execCMD('" + s + "','faqcnt')\" target=\"_parent\">s</a>|";
                result += "<a href=\"javascript:createChild('" + s + "');\" target=\"_blank\">" + s + "</a><br/>";
            }
            document.getElementById("faqresult").innerHTML = "" + result;
        }
    })
}
HttpRequest.prototype.extractHTML = function(id) {
    var request = window.nodeRequire("request");
    var url = hostName + '/';
    request({
        url: url,
        json: true
    }, function(error, response, body) {
        if (!error && response.statusCode === 200) {
            var Extrator = window.nodeRequire("html-extractor");
            var myExtrator = new Extrator();
            var result = '';
            myExtrator.extract(body, function(err, data) {
                if (err) {
                    throw (err)
                } else {
                    console.log(JSON.stringify(data));
                    document.getElementById(id).innerHTML = "" + utf8_decode(data.body);
                }
            });



        }
    })
}
HttpRequest.prototype.getFullList = function() {
        var api = 'https://www.letztechance.org/webservices/client.php?q=getFullIndexJSON&value1=0&l=';
        console.log("get list by" + api);
        try {
            var p1 = this.getJSON_CR(api, 'GET', true, 'jsonp');
            // jQuery('#outcnt').html('Reading' + api);
            p1.then(function(data) {
                try {
                    var oJson = JSON.parse(data, false);
                    var result = "";
                    for (var i = 0; i < oJson.list.length; i++) {
                        var counter = oJson.list[i];
                        result += '<option value="' + counter.id + '">' + counter.name + '</option>';
                    }
                    $('#tableId').append(result);
                    // alert(result);
                } catch (e) {
                    $('#error').before('Error:<hr>' + e.stack);
                    $('#error').before(e);
                }
            });
        } catch (e) {
            $('#error').before('Error:<hr>' + e.stack);
            $('#error').before(e);
        }
        console.log("List done");
    }
    //data: {
    // 'ext_url': url
    //}
HttpRequest.prototype.getJSON_CR = function(url, methodType, dataType) {
    return new Promise((resolve, reject) => {
        $.ajax({
            method: methodType,
            url: url
                //data: {
                // 'ext_url': url
                //}
                ,
            success: function(data) {
                resolve(data);
            },
            error: function() {
                console.log('Error');
                reject('Error');
            }
        });
    });
}

function IOUtils() {
    this.doUnzip = function(link, target, filter) {
        console.log('Extract' + link);
        alert('Extract' + link);
        var DecompressZip = window.nodeRequire('decompress-zip');
        // for (var v in links) {
        var ZIP_FILE_PATH = link;
        var DESTINATION_PATH = target;
        var unzipper = new DecompressZip(ZIP_FILE_PATH);

        // Add the error event listener
        unzipper.on('error', function(err) {
            console.log('Caught an error' + link, err);
        });

        // Notify when everything is extracted
        unzipper.on('extract', function(log) {
            console.log('Finished extracting', log);
        });

        // Notify "progress" of the decompressed files
        unzipper.on('progress', function(fileIndex, fileCount) {
            console.log('Extracted file ' + (fileIndex + 1) + ' of ' + fileCount);
            document.getElementById("appcnt").innerHTML += 'Extracted file ' + (fileIndex + 1) + ' of ' + fileCount;
        });

        // Start extraction of the content
        unzipper.extract({
            path: DESTINATION_PATH,
            filter: filter
                // You can filter the files that you want to unpack using the filter option
                //filter: function (file) {
                //console.log(file);
                //return file.type !== "SymbolicLink";
                //}
        });
    }

    this.InstallModules = function(tmpDir) {
        try {
            const { npmImportAsync, npmInstallAsync } = window.nodeRequire('runtime-npm-install');
            npmInstallAsync(rlibs, tmpDir)
                .then(function() {
                    document.getElementById('modcnt').innerHTML += '<h1>Successfully Installed to:</h1>' + tmpDir + '<br>';
                    document.getElementById('modcnt').innerHTML += '<h2>Done. Close window now and start main plugin.</h2>';

                });
            printDir(path.join(tmpDir, 'node_modules'));
        } catch (error) {
            alert(error);
        }
    }

    this.printDir = function(dir_path) {
        const path = window.nodeRequire('path');
        const fs = window.nodeRequire('fs');
        console.log('DIR:' + dir_path);
        fs.readdir(dir_path, function(err, files) {
            //handling error
            if (err) {
                return console.log('Unable to find or open the directory: ' + err);
            }
            //Print the array of images at one go
            // console.log(files);
            //listing all files using forEach
            files.forEach(function(file) {
                var isValid = false;
                console.log(file);
                document.getElementById("modcnt").innerHTML += "<br>" + file;
                for (v in rlibs) {
                    if (file.includes(v)) {
                        isValid = true;
                    }
                }
                if (isValid) {
                    document.getElementById("modcnt").innerHTML += "<br>" + file + " <strong>found</strong>.";
                }
            });
        });
    }

    this.downloadAppBinaries = function(path, link, target) {
        // var target = path.join(appRoot, "download");
        document.getElementById("appcnt").innerHTML = "<h4>URL:<strong>" + path + link + "</strong> to " + target + "</h4>";
        const downloadManager = window.nodeRequire("electron").remote.require("electron-download-manager");
        downloadManager.register({ downloadFolder: target });
        downloadManager.downloadFolder = target; //.register({ downloadFolder: target });
        downloadManager.download({
            url: path + link,
            properties: { directory: target },
            filePath: target,
        }, function(error, info) {
            if (error) {
                console.log(error);
                document.getElementById("moappcntcnt").innerHTML += path + link + " <strong>NOT downloaded.</strong>.<br>";
                return;
            }
            console.log(JSON.stringify(info));
            document.getElementById("appcnt").innerHTML += "URL:" + info.url + " <strong>downloaded.</strong>.<br>";
            document.getElementById("appcnt").innerHTML += "FILE:" + info.filePath + " " + " <strong>written.</strong>.<br>";
            doUnzip(target + link, target);
            console.log("DONE: " + info.url);
        })
    }

    this.doDownload = function(links, target) {
        console.log("Target:" + target);
        for (var v in links) {
            getDownloadFile(links[v].path, links[v].file, target + links[v].file);
            // downloadAppBinaries(links[v].path, links[v].file, target);
            // bulkDownloadAppBinaries(links, target);
        }
    }


    this.getDownloadFile = function(baseUrl, link, target) {
        var request = window.nodeRequire('request');
        var fs = window.nodeRequire('fs');
        // Save variable to know progress
        var received_bytes = 0;
        var total_bytes = 0;
        var url = baseUrl + link;
        console.log('DL:' + url)
        var req = request({
            method: 'GET',
            uri: url
        });

        var out = fs.createWriteStream(target);
        req.pipe(out);

        req.on('response', function(data) {
            // Change the total bytes value to get progress later.
            total_bytes = parseInt(data.headers['content-length']);
        });

        req.on('data', function(chunk) {
            // Update the received bytes
            received_bytes += chunk.length;

            this.showProgress(received_bytes, total_bytes);
        });

        req.on('end', function() {
            // alert("File succesfully downloaded");
            document.getElementById("appcnt").innerHTML += "<br>" + url + "File succesfully downloaded";
            // doUnzip(target + link, target);
        });
    }

    this.showProgress = function(received, total) {
        var percentage = (received * 100) / total;
        console.log(percentage + "% | " + received + " bytes out of " + total + " bytes.");
        document.getElementById("appcntprogress").innerHTML = percentage + "% | " + received + " bytes out of " + total + " bytes.";
    }
}


// try {
//     var path = window.nodeRequire('path');
//     document.getElementById("appcnt").innerHTML = "";
//     document.getElementById("modcnt").innerHTML = "";
//     var modDir = path.join(__dirname, '../resources/');
//     InstallModules(modDir);
//     var downloadDir = path.join(__dirname, '../../../');
//     // InstallModules(targetDir);

//     doDownload(downloadUrls, downloadDir);

//     // doUnzip(downloadUrls, targetDir);
// } catch (e) {
//     alert(e.stack);
// }
// try {
//     // updateApp(links);
//     const targetDir = path.join(__dirname, '../../../../');
//     // alert(targetDir + " <strong>found.</strong>.<br>");
//     //downloadAppBinaries(downloadUrls[0], targetDir);
//     downloadAppBinaries(downloadUrls[0], targetDir);
//     // bulkDownloadAppBinaries(downloadUrls, targetDir);
// } catch (error) {
//     alert(error.stack);
// }