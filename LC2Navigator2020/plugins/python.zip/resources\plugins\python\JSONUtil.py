import config
import json


def getJSON(x, item):
    y = json.loads(x)
    print(y[item])


def getJson(x):
    y = json.loads(x)
    # the result is a Python dictionary:
    print(y["age"])


def getJsonDefault():
    x = '{ "name":"John", "age":30, "city":"New York"}'
    getJson(x)


def getJsonDumps(x):
    y = json.dumps(x)
    # the result is a JSON string:
    print(y)

def getJsonDumpsSep(x):
    y = json.dumps(x, indent=4, separators=(". ", " = "))
    # the result is a JSON string:
    print(y)

def getJsonSorted(x):
    y = json.dumps(x, indent=4, sort_keys=True)
    # the result is a JSON string:
    print(y)    