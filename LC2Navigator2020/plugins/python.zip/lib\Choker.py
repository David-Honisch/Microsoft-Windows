# Written by Bram Cohen and Jeremy Arendt
# see LICENSE.txt for license information

from random import randrange


class Choker(object):
    def __init__(self, max_uploads, schedule, friendfunc, infohash, done = lambda: False, min_uploads = None):
        self.max_uploads = max_uploads
        if min_uploads is None:
            min_uploads = max_uploads
        self.min_uploads = min_uploads
        self.schedule = schedule
        self.getfriends = friendfunc
        self.connections = []
        self.infohash = infohash
        self.count = 0
        self.done = done
        self.choke_delay = 10
        self.optimistic_uchoke_period = 3
        self.min_rate = 0.0
        self.drop_leechers = False
        self.leechers = {}
        self.SelectChokeAlgo(0, [10, 3, 0])
        schedule(self._OnChoke, self.choke_delay)
    
 
    def SelectChokeAlgo(self, s, d):
        self.choke_delay = d[0]
        self.min_rate = d[2]
        if self.choke_delay >= self.optimistic_uchoke_period:
            self.optimistic_uchoke_period = 1
        else:
            self.optimistic_uchoke_period = int(self.optimistic_uchoke_period / self.choke_delay)
        
        if s == 0:
            self._rechoke = self._g3_rechoke
            self._shuffler = self._round_robin
        elif s == 1:
            self._rechoke = self._BT34_rechoke
            self._shuffler = self._round_robin
        elif s == 2:
            self._rechoke = self._L33CH_rechoke
            self._shuffler = self._no_shuffle
        else:
            self._rechoke = self._BT34_rechoke
            self._shuffler = self._round_robin
        
    def _OnChoke(self):
        self.schedule(self._OnChoke, self.choke_delay)
        self.count += 1
        self._shuffler()        # call a shuffler
        self._rechoke()         # call a choker        

    def _no_shuffle(self):
        pass
                    
    def _round_robin(self):
        if self.count % self.optimistic_uchoke_period == 0:
            for i in xrange(len(self.connections)):
                u = self.connections[i].get_upload()
                if u.is_choked() and u.is_interested():
                    self.connections = self.connections[i:] + self.connections[:i]
                    break

    def isleecher(self, c):
        if c.get_time_connected() > 1200:
            dt = c.get_download().measure.total
            ut = c.get_upload().measure.total
            
            if (ut > (2*20) and float(dt)/ut < 0.334):
                print "dropping leecher", c.get_ip(), dt, ut, c.get_time_connected()
                return True
        return False
        
    
    def _g3_rechoke(self):
        preferred = []
        friends = []
        friends_ip, foes_ip = self.getfriends(self.infohash)
        
        if len(friends_ip) > 0:
            for c in self.connections:
                if not self._snubbed(c) and c.get_upload().is_interested():
                    try:
                        if friends_ip.has_key(c.get_ip()):
                            friends.append(c)
                    except:
                        print "DEBUG: could not get connection's ip"

        del friends[self.max_uploads-1:]
           
        for c in self.connections:
            if self.drop_leechers and self.isleecher(c):
                self.leechers[c.get_ip()] = True
                continue
            
            r = self._rate(c)
            if not self._snubbed(c) and c.get_upload().is_interested() and r >= self.min_rate:
                preferred.append((-r, c))
        preferred.sort()

        nperferred = max(0, self.max_uploads - (len(friends) + 1))
        del preferred[nperferred:]
        preferred = [x[1] for x in preferred]

        preferred = friends + preferred
        count = len(preferred)
        hit = False
        
        for c in self.connections:
            u = c.get_upload()
            if foes_ip.has_key(c.get_ip()) or self.leechers.has_key(c.get_ip()):
                self.close_connection(c)
                continue
            if c in preferred:
                u.unchoke()
            else:
                if count < self.min_uploads or not hit:
                    u.unchoke()
                    if u.is_interested():
                        count += 1
                        hit = True
                else:
                    u.choke()
        
    def _L33CH_rechoke(self):
        for c in self.connections:
            if self._snubbed(c) and c.get_upload().is_interested():
                self.close_connection(c)
                        
    def _BT34_rechoke(self):
        preferred = []
        for c in self.connections:
            if not self._snubbed(c) and c.get_upload().is_interested():
                preferred.append((-self._rate(c), c))
        preferred.sort()
        del preferred[self.max_uploads - 1:]
        preferred = [x[1] for x in preferred]
        count = len(preferred)
        hit = False
        for c in self.connections:
            u = c.get_upload()
            if c in preferred:
                u.unchoke()
            else:
                if count < self.min_uploads or not hit:
                    u.unchoke()
                    if u.is_interested():
                        count += 1
                        hit = True
                else:
                    u.choke()

    def _snubbed(self, c):
        if self.done():
            return False
        return c.get_download().is_snubbed()

    def _rate2(self, c):
        if self.done():
            return c.get_upload().measure.get_rate_hist()
        else:
            return c.get_download().measure.get_rate_hist()
        
    def _rate(self, c):
        u = max(1, c.get_upload().measure.total)
        d = max(1, c.get_download().measure.total)
        if self.done():
            return float(u)/d
        else:
            return float(d)/u

    def connection_made(self, connection, p = None):
        if p is None:
            p = randrange(-2, len(self.connections) + 1)
        self.connections.insert(max(p, 0), connection)
        self._rechoke()

    def connection_lost(self, connection):
        self.connections.remove(connection)
        if connection.get_upload().is_interested() and not connection.get_upload().is_choked():
            self._rechoke()

    def interested(self, connection):
        if not connection.get_upload().is_choked():
            self._rechoke()

    def not_interested(self, connection):
        if not connection.get_upload().is_choked():
            self._rechoke()

    def close_connection(self, c):
        def foo(self=self, c=c):
            c.close()
        self.schedule(foo, 0);
        
    def change_max_uploads(self, newval):
        def foo(self=self, newval=newval):
            self._change_max_uploads(newval)
        self.schedule(foo, 0);
    
    def rechoke(self):
        def foo(self=self):
            self._rechoke()
        self.schedule(foo, 0);
                
    def _change_max_uploads(self, newval):
        self.max_uploads = newval
        self.min_uploads = max(1, newval)
        #self._rechoke()

