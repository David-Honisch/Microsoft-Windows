import config
import CLIController as cli
import requests
from stem import Signal
from stem.control import Controller


def getContoller(_port):
    result = ""
    result += "Using port:"+str(_port)
    # print(cli.runPrint("Calling port:"+str(_port)))
    # controller = Controller.from_port(port=_port)
    # #controller.authenticate(password='your password set for tor controller port in torrc')
    # print(cli.runPrint("Calling port:"+str(_port)))
    # controller.authenticate(password='test1234')
    # print(cli.runPrint("Success!"))
    # controller.signal(Signal.NEWNYM)
    # print(cli.runPrint("New Tor connection processed"))
    # with Controller.from_port(port=_port) as controller:
    #     #controller.authenticate(password='your password set for tor controller port in torrc')
    #     print(cli.runPrint("Calling port:"+str(_port)))
    #     controller.authenticate(password='test1234')
    #     print(cli.runPrint("Success!"))
    #     controller.signal(Signal.NEWNYM)
    #     print(cli.runPrint("New Tor connection processed"))
    # return controller

    return result
