SELECT '<h1>org.letztechance.domain.web.GrabUrls PLUGIN SQL SCRIPT IS RUNNING</h1>'; 
SELECT '<h5>Deleting import script</h5>'; 
SELECT '<h5>RUNNING IMPORT</h5>'; 
SELECT '<h4>SET CLEAR</h4>'; 
SELECT '<h4>DELETING application</h4>'; 
SELECT '<h1>UPDATE org.letztechance.domain.web.GrabUrls SQL SCRIPT DONE</h1>'; 
INSERT INTO application VALUES(26,'org.letztechance.domain.web.GrabUrls v.1.01a','org.letztechance.domain.web.GrabUrls v.1.01a','','','','','exec .\\resources\\plugins\\org.letztechance.domain.web.GrabUrls\\org.letztechance.domain.web.GrabUrls.bat .\\resources\\plugins\\org.letztechance.domain.web.GrabUrls\\menu.csv'); 
SELECT '<h5>SQL org.letztechance.domain.web.GrabUrls IMPORT DONE</h5>'; 
