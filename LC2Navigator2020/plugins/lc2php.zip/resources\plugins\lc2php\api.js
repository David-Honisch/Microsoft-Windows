function utf8_encode(s) {
    return unescape(encodeURIComponent(s));
}

function utf8_decodee(s) {
    return decodeURIComponent(escape(s));
}

function utf8_decode(s) {
    var result;
    try {
        result = decodeURIComponent(escape(s));
    } catch (e) {
        // console.log(e);
    }
    result = (result !== null && result !== undefined && result.length > 0) ? result : s;
    return result;
}

function HttpRequest() {
    this.token = '';
    this.anonymous = "anonymous";
    this.NotLoggedInText = "Invalid login. Please try again with different credentials.<br/>Result:";
    this.url = hostName + '/';
}
HttpRequest.prototype.execCMD = function(text, id, isAppended) {
    const { exec } = window.nodeRequire('child_process');
    isAppended = isAppended !== undefined && isAppended === true ? isAppended : false
    document.getElementById("error" + id).innerHTML = "";
    document.getElementById(id).innerHTML = "<div class=\"preload\"></div>";
    // alert('OUT:'+text);
    exec('' + text, (err, stdout, stderr) => {
        if (err) {
            console.error(err);
            document.getElementById("error" + id).innerHTML = "" + JSON.stringify(err);
            return;
        }
        console.log(stdout);
        if (isAppended) {
            document.getElementById(id).innerHTML += "" + stdout;
        } else {
            document.getElementById(id).innerHTML = "" + stdout;
        }
    });
}
HttpRequest.prototype.printHTML = function(id, text) {
    document.getElementById(id).innerHTML = text;
}
HttpRequest.prototype.getIndex = function() {
    var request = require("request");
    var url = hostName + '/indextools';
    request({
        url: url,
        json: true
    }, function(error, response, body) {

        if (!error && response.statusCode === 200) {
            var result = '';
            for (var v in body) {
                var s = utf8_decode(body[v]);
                result += "<a href=\"#homecnt\" onclick=\"new HttpRequest().execCMD('" + s + "','homecnt')\" target=\"_parent\">" + s + "</a><br/>";
            }
            document.getElementById("homeresult").innerHTML = "" + result;
        }
    })
}
HttpRequest.prototype.getCheck = function() {
    var request = require("request");
    var url = hostName + '/check';
    request({
        url: url,
        json: true
    }, function(error, response, body) {

        if (!error && response.statusCode === 200) {
            var result = '';
            for (var v in body) {
                var s = utf8_decode(body[v]);
                if (s.includes("check") || s.includes("verify"))
                    result += "<a href=\"#checkcnt\" onclick=\"new HttpRequest().execCMD('" + s + "','checkcnt')\" target=\"_parent\">" + s + "</a><br/>";
            }
            document.getElementById("checkresult").innerHTML = "" + result;
        }
    })
}
HttpRequest.prototype.getSearch = function() {
    var request = require("request");
    var url = hostName + '/index';
    request({
        url: url,
        json: true
    }, function(error, response, body) {

        if (!error && response.statusCode === 200) {
            var result = '';
            for (var v in body[0]) {
                result += "<a href=\"#\" target=\"_blank\">" + utf8_decode(body[0][v]) + "</a><br/>";
            }
            document.getElementById("searchresult").innerHTML += "" + result;
        }
    })
}
HttpRequest.prototype.getTools = function() {
    var request = require("request");
    var url = hostName + '/tools';
    request({
        url: url,
        json: true
    }, function(error, response, body) {

        if (!error && response.statusCode === 200) {
            var result = '';
            for (var v in body) {
                var s = utf8_decode(body[v]);
                result += "<a href=\"#toolscnt\" onclick=\"new HttpRequest().execCMD('" + s + "','toolscnt')\" target=\"_parent\">" + s + "</a><br/>";
                // result += "<a href=\"cmd " + s + "\" target=\"_blank\">" + s + "</a><br/>";
            }
            document.getElementById("toolsresult").innerHTML = "" + result;
        }
    })
}
HttpRequest.prototype.getImport = function() {
    var request = require("request");
    var url = hostName + '/importtools';
    request({
        url: url,
        json: true
    }, function(error, response, body) {

        if (!error && response.statusCode === 200) {
            var result = '';
            for (var v in body) {
                var s = utf8_decode(body[v]);
                result += "<a href=\"#toolscontent\" onclick=\"new HttpRequest().execCMD('" + s + "','importcnt')\" target=\"_parent\">" + s + "</a><br/>";
            }
            document.getElementById("importresult").innerHTML = "" + result;
        }
    })
}
HttpRequest.prototype.getDocs = function() {
    var request = require("request");
    var url = hostName + '/docs';
    request({
        url: url,
        json: true
    }, function(error, response, body) {

        if (!error && response.statusCode === 200) {
            var result = '';
            for (var v in body) {
                var s = utf8_decode(body[v]);
                result += "<a href=\"#toolscontent\" onclick=\"new HttpRequest().execCMD('" + s + "','toolscontent')\" target=\"_parent\">x</a>|";
                result += "<a href=\"#toolscontent\" onclick=\"new HttpRequest().execCMD('" + s + "','importcnt')\" target=\"_parent\">s</a>|";
                result += "<a href=\"javascript:alert('" + s + "');javascript:createChild('" + s + "');\" target=\"_blank\">" + s + "</a><br/>";
            }
            document.getElementById("docsresult").innerHTML = "" + result;
        }
    })
}
HttpRequest.prototype.getFaq = function() {
    var request = require("request");
    var url = hostName + '/faq';
    request({
        url: url,
        json: true
    }, function(error, response, body) {

        if (!error && response.statusCode === 200) {
            var result = '';
            for (var v in body) {
                var s = utf8_decode(body[v]);
                result += "<a href=\"#faqcontent\" onclick=\"new HttpRequest().execCMD('" + s + "','faqcontent')\" target=\"_parent\">x</a>|";
                result += "<a href=\"#faqscontent\" onclick=\"new HttpRequest().execCMD('" + s + "','faqcnt')\" target=\"_parent\">s</a>|";
                result += "<a href=\"javascript:createChild('" + s + "');\" target=\"_blank\">" + s + "</a><br/>";
            }
            document.getElementById("faqresult").innerHTML = "" + result;
        }
    })
}
HttpRequest.prototype.extractHTML = function(id) {
    var request = require("request");
    var url = hostName + '/';
    request({
        url: url,
        json: true
    }, function(error, response, body) {
        if (!error && response.statusCode === 200) {
            var Extrator = require("html-extractor");
            var myExtrator = new Extrator();
            var result = '';
            myExtrator.extract(body, function(err, data) {
                if (err) {
                    throw (err)
                } else {
                    console.log(JSON.stringify(data));
                    document.getElementById(id).innerHTML = "" + utf8_decode(data.body);
                }
            });



        }
    })
}

function ifExists(obj) {
    return (obj !== "N/A" ? obj : "");
}

function toggle_visibility(className) {
    $('.' + className).toggle();
}

function doUnzip(link, target) {
    console.log('Extract' + link);
    // alert('Extract' + link);
    var DecompressZip = require('decompress-zip');
    // for (var v in links) {
    var ZIP_FILE_PATH = link;
    var DESTINATION_PATH = target;
    var unzipper = new DecompressZip(ZIP_FILE_PATH);

    // Add the error event listener
    unzipper.on('error', function(err) {
        console.log('Caught an error' + link, err);
    });

    // Notify when everything is extracted
    unzipper.on('extract', function(log) {
        console.log('Finished extracting', log);
    });

    // Notify "progress" of the decompressed files
    unzipper.on('progress', function(fileIndex, fileCount) {
        console.log('Extracted file ' + (fileIndex + 1) + ' of ' + fileCount);
        document.getElementById("appcnt").innerHTML += '<br>Extracted file ' + (fileIndex + 1) + ' of ' + fileCount;
    });

    // Start extraction of the content
    unzipper.extract({
        path: DESTINATION_PATH
            // You can filter the files that you want to unpack using the filter option
            //filter: function (file) {
            //console.log(file);
            //return file.type !== "SymbolicLink";
            //}
    });
    // }

}

function InstallModules(tmpDir) {
    try {
        const { npmImportAsync, npmInstallAsync } = require('runtime-npm-install');
        npmInstallAsync(rlibs, tmpDir)
            .then(function() {
                document.getElementById('modcnt').innerHTML += '<h1>Successfully Installed to:</h1>' + tmpDir + '<br>';
                document.getElementById('modcnt').innerHTML += '<h2>Done. Close window now and start main plugin.</h2>';

            });
        printDir(path.join(tmpDir, 'node_modules'));
    } catch (error) {
        alert(error);
    }
}

function printDir(dir_path) {
    const path = require('path');
    const fs = require('fs');
    console.log('DIR:' + dir_path);
    fs.readdir(dir_path, function(err, files) {
        //handling error
        if (err) {
            return console.log('Unable to find or open the directory: ' + err);
        }
        //Print the array of images at one go
        // console.log(files);
        //listing all files using forEach
        files.forEach(function(file) {
            var isValid = false;
            console.log(file);
            document.getElementById("modcnt").innerHTML += "<br>" + file;
            for (v in rlibs) {
                if (file.includes(v)) {
                    isValid = true;
                }
            }
            if (isValid) {
                document.getElementById("modcnt").innerHTML += "<br>" + file + " <strong>found</strong>.";
            }
        });
    });
}

function doDownload(links, target) {
    // console.log("Target:" + target);
    for (var v in links) {
        getDownloadFile(links[v].path, links[v].file, target + links[v].file, target);
        // downloadAppBinaries(links[v].path, links[v].file, target);
        // bulkDownloadAppBinaries(links, target);
    }
}


function getDownloadFile(baseUrl, link, targetFile, target) {
    var request = require('request');
    var fs = require('fs');
    // Save variable to know progress
    var received_bytes = 0;
    var total_bytes = 0;
    var url = baseUrl + link;
    console.log('DL:' + url)
    var req = request({
        method: 'GET',
        uri: url
    });

    var out = fs.createWriteStream(targetFile);
    req.pipe(out);

    req.on('response', function(data) {
        // Change the total bytes value to get progress later.
        total_bytes = parseInt(data.headers['content-length']);
    });

    req.on('data', function(chunk) {
        // Update the received bytes
        received_bytes += chunk.length;

        showProgress(received_bytes, total_bytes);
    });

    req.on('end', function() {
        // alert("File succesfully downloaded");
        document.getElementById("appcnt").innerHTML += "<br>" + url + " File succesfully downloaded";
        document.getElementById("appcnt").innerHTML += "<br>" + targetFile + " File succesfully written.";
        document.getElementById("appcnt").innerHTML += "<br>Path:" + target + ".";
        if (('' + link).includes('.zip'))
            doUnzip(targetFile, target);
    });
}

function showProgress(received, total) {
    var percentage = (received * 100) / total;
    console.log(percentage + "% | " + received + " bytes out of " + total + " bytes.");
    document.getElementById("appcntprogress").innerHTML = percentage + "% | " + received + " bytes out of " + total + " bytes.";
}
