var TITLE = 'LC2PHP';
var PLUGINTITLE = 'LC2PHP v.0.1a';
var hostName = "http://localhost:5000";
var downloadUrls = [{
        path: "https://www.letztechance.org/LC2Intro.v.4.0/assets/",
        file: "lclogo.png",
    },
    {
        path: "https://raw.githubusercontent.com/David-Honisch/Microsoft-Windows/master/LC2Navigator2020/plugins/",
        file: "all.zip",
    }

];
const rlibs = [
    'jquery',
    'fs',
    'request',
    'runtime-npm-install',
    'decompress-zip',
    // 'extract-zip',
    'csv',
    'jszip',
    'sax',
    'xlsx',
    'xlsx-to-json',
    'xlsx-to-json-lc',
    'xml2js',
    'xmlbuilder',
    'xmldom',
    'xml-js',
    'xmljson'
];