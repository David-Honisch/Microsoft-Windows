function getFullList() {
    var api = 'https://www.letztechance.org/webservices/client.php?q=getFullIndexJSON&value1=0&l=';
    console.log("get list by" + api);
    try {
        var p1 = getJSON_CR(api, true, 'jsonp', 'GET');
        jQuery('#outcnt').html('Reading' + api);
        p1.then(function(data) {
            try {
                var oJson = JSON.parse(data, false);
                var result = "";
                for (var i = 0; i < oJson.list.length; i++) {
                    var counter = oJson.list[i];
                    result += '<option value="' + counter.id + '">' + counter.name + '</option>';
                }
                jQuery('#tableId').append(result);
                scrollTo("html, body", "#outcnt", 200);
                jQuery('#outcnt').html('');
            } catch (e) {
                jQuery('#error').before('Error:<hr>' + e.stack);
                jQuery('#error').before(e);
            }
        });
    } catch (e) {
        jQuery('#error').before('Error:<hr>' + e.stack);
        jQuery('#error').before(e);
    }
    console.log("List done");
}

function scrollTo(scrollId, outputId, delay) {
    jQuery("html, body" + scrollId).delay(20).animate({
        scrollTop: jQuery(outputId).offset().top
    }, delay !== undefined ? delay : 20);
}



function parseUrl() {
    var pattern = document.getElementById('pattern').value;
    var tableId = document.getElementById('tableId').value;
    if (pattern != undefined && pattern.length > 0) {
        //alert('Searching:'+pattern);
        printParseUrl('Searching:' + pattern, 'outcnt');
    } else {
        alert('Search pattern is empty. Please enter a value');
        return
    }
    if (IsImportEndabled) {
        execCMD('call exec.bat .\\resources\\plugins\\grabandimporturls.html.bat ' + pattern + ' ' + tableId, 'outcnt')
    } else {
        execCMD('call exec.bat .\\resources\\plugins\\grabandimporturls.grab.only.html.bat ' + pattern + ' ' + tableId, 'outcnt')
    }

}

function printParseUrl(text, id) {
    document.getElementById(id).innerHTML = text;
    console.log(text);
}

function execCMD(text, id) {
    console.log('execCMD running...');
    printParseUrl("<h1>Searching...</h1>", id);
    const {
        exec
    } = window.nodeRequire('child_process');
    //document.getElementById("error").innerHTML = "";
    printParseUrl("", "error");
    printParseUrl("<div class=\"preload\"></div>", id);
    // alert('OUT:'+text.length);
    try {


        exec('' + text, (err, stdout, stderr) => {

            if (err) {
                console.error(err);
                printParseUrl("" + JSON.stringify(err), "error");
                printParseUrl("" + stdout, id);
                //document.getElementById(id).innerHTML = stdout;
                return;
            }
            //document.getElementById(id).innerHTML = stdout;
            printParseUrl("" + stdout, id);
            console.log('execCMD done.');
        });
    } catch (error) {
        printParseUrl("" + JSON.stringify(err), "error");
        console.error(JSON.stringify(err))


    }
}

function getJSON_CR(url, isAsync, dataType, methodType) {
    return new Promise((resolve, reject) => {
        jQuery.ajax({
            method: methodType,
            url: url
                //data: {
                // 'ext_url': url
                //}
                ,
            success: function(data) {
                //var jQueryh1 = jQuery(data).find('h1').html();
                //jQuery('h1').val(jQueryh1);
                //jQuery('#cnt').html(data);
                resolve(data);
            },
            error: function() {
                console.log('Error');
                reject('Error');
            }
        });
    });
}
var IsImportEndabled = false;

try {
    var jQuery = window.nodeRequire('jquery');
    //alert('Test');    
    console.log('Running now..');
    jQuery('#outcnt').html('Welcome');
    getFullList();
    console.log('Done.');
    //alert('Test 3');		
    window.jQuery('#outcnt').append('<hr>done.');
    // alert('Done');
    //add checkbox listener
    window.jQuery('input[type="checkbox"]').click(function() {
        if (window.jQuery(this).is(":checked")) {
            IsImportEndabled = true;
        } else if (jQuery(this).is(":not(:checked)")) {
            IsImportEndabled = false;
        }
    });

    // alert('Done');
} catch (e) {
    alert(e);
}