package org.letztechance.domain.quarkus.projects.hibernate.orm;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.ws.rs.Consumes;
import javax.ws.rs.FormParam;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.WebApplicationException;
import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.Entity;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.ext.ExceptionMapper;
import javax.ws.rs.ext.Provider;

import org.jboss.logging.Logger;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;

@Path("jaxrsclient")
@ApplicationScoped
@Produces("application/json")
@Consumes("application/json")
public class JaxRSClientResource {

    private static final String INDEX_WS_URL = "https://www.letztechance.org/webservices/client.php?q=getFullIndexJSON&value1=0&l=";
    private static final String LIST_WS_URL = "https://www.letztechance.org/webservices/client.php?q=getListJSON&value1=2&value1=1";

	private static final Logger LOGGER = Logger.getLogger(JaxRSClientResource.class.getName());

    @Inject
    EntityManager entityManager;
    
    Client client = ClientBuilder.newClient();
    
    @GET
    @Produces("application/json")
    @Consumes("application/json")
    @Path("index")
    public Response getIndex() {
        return client
        	      .target(INDEX_WS_URL)
        	      .request(MediaType.APPLICATION_JSON)
        	      .post(Entity.entity(String.class, MediaType.APPLICATION_JSON));
        
    }
    @GET
    @Produces("application/json")
    @Consumes("application/json")
    @Path("list")
    public Response getList() {
        return client
        	      .target(LIST_WS_URL)
        	      .request(MediaType.APPLICATION_JSON)
        	      .post(Entity.entity(String.class, MediaType.APPLICATION_JSON));
        
    }
    /**
     * 
     * @param url
     * @return
     */
    @GET
    @Produces("application/json")
//    @Consumes("application/json")
    @Path("geturl")
    public Response getURL(String url) {
        return client
        	      .target(url)
        	      .request(MediaType.APPLICATION_JSON)
        	      .post(Entity.entity(String.class, MediaType.APPLICATION_JSON));
        
    }

    
    @POST
    @Path("add")
    @Produces("text/html")
    public Response create(@FormParam("key")String key,
                @FormParam("value")String value)
    {    
//        service.addToList(key,value);    
        return Response.ok("OK").build();     

    } 
    

//    @GET
//    public List<Project> get() {
//        return entityManager.createNamedQuery("Projects.findAll", Project.class)
//                .getResultList();
//    }
//
//    @GET
//    @Path("{id}")
//    public Project getSingle(@PathParam Integer id) {
//    	Project entity = entityManager.find(Project.class, id);
//        if (entity == null) {
//            throw new WebApplicationException("Project with id of " + id + " does not exist.", 404);
//        }
//        return entity;
//    }
//
//    @POST
//    @Transactional
//    public Response create(Project project) {
//        if (project.getId() != null) {
//            throw new WebApplicationException("Id was invalidly set on request.", 422);
//        }
//
//        entityManager.persist(project);
//        return Response.ok(project).status(201).build();
//    }
//
//    @PUT
//    @Path("{id}")
//    @Transactional
//    public Project update(@PathParam Integer id, Project project) {
//        if (project.getName() == null) {
//            throw new WebApplicationException("Project Name was not set on request.", 422);
//        }
//
//        Project entity = entityManager.find(Project.class, id);
//
//        if (entity == null) {
//			throw new WebApplicationException("Project with id of " + id + " does not exist.", 404);
//        }
//
//        entity.setName(project.getName());
//        entity.setCustomerName(project.getCustomerName());
//
//        return entity;
//    }
//
//    @DELETE
//    @Path("{id}")
//    @Transactional
//    public Response delete(@PathParam Integer id) {
//    	Project entity = entityManager.getReference(Project.class, id);
//        if (entity == null) {
//            throw new WebApplicationException("Project with id of " + id + " does not exist.", 404);
//        }
//        entityManager.remove(entity);
//        return Response.status(204).build();
//    }

    @Provider
    public static class ErrorMapper implements ExceptionMapper<Exception> {

        @Inject
        ObjectMapper objectMapper;

        @Override
        public Response toResponse(Exception exception) {
            LOGGER.error("Failed to handle request", exception);

            int code = 500;
            if (exception instanceof WebApplicationException) {
                code = ((WebApplicationException) exception).getResponse().getStatus();
            }

            ObjectNode exceptionJson = objectMapper.createObjectNode();
            exceptionJson.put("exceptionType", exception.getClass().getName());
            exceptionJson.put("code", code);

            if (exception.getMessage() != null) {
                exceptionJson.put("error", exception.getMessage());
            }

            return Response.status(code)
                    .entity(exceptionJson)
                    .build();
        }

    }
}
