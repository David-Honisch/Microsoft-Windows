/**
 * 
 */
package org.letztechance.hibernate.orm.entities.persons;

import java.time.LocalDate;

import javax.persistence.Cacheable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.QueryHint;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.hibernate.engine.spi.Status;
import org.letztechance.hibernate.orm.entities.location.Location;

import io.quarkus.runtime.annotations.RegisterForReflection;

/**
 * @author B3y0nd3r aka David Honisch
 * 
 */

@Entity
@Table(name = "known_persons")
//@NamedQuery(name = "Persons.getByName", query = "from Person where name = :name")
@NamedQuery(name = "Persons.findAll", query = "SELECT f FROM Person f ORDER BY f.name", hints = @QueryHint(name = "org.hibernate.cacheable", value = "true"))
@Cacheable
public class Person {
	

    @Id
    @SequenceGenerator(name = "personsSequence", sequenceName = "known_persons_id_seq", allocationSize = 1, initialValue = 10)
    @GeneratedValue(generator = "personsSequence")
    private Integer id;

    @Column(length = 40, unique = true)
	public String name;
	public LocalDate birth;

	@ManyToOne
	public Location locations;

	public Status status;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Location getLocations() {
		return locations;
	}

	public void setLocations(Location locations) {
		this.locations = locations;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public LocalDate getBirth() {
		return birth;
	}

	public void setBirth(LocalDate birth) {
		this.birth = birth;
	}

	public Status getStatus() {
		return status;
	}

	public void setStatus(Status status) {
		this.status = status;
	}

//	public static Person findByName(String name) {
//		return find("name", name).firstResult();
//	}
//
//	public static List<Person> findAlive() {
//		return list("status", Status.Alive);
//	}
//
//	public static void deleteStefs() {
//		delete("name", "Stef");
//	}

	@RegisterForReflection
	public class PersonDto {		
		public String name;
		public LocalDate birth;
		public Location locations;


//		public PersonDto(String name, @ProjectedFieldName("owner.name") String ownerName) {
//			this.name = name;
//			this.ownerName = ownerName;
//		}
	}

//    public static Person findByName(String name){
//        return find("#Person.getByName", name).firstResult();
//    }

}
