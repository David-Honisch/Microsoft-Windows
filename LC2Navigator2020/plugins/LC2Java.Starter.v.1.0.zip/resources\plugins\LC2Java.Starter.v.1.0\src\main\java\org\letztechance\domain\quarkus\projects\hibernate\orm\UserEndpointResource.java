package org.letztechance.domain.quarkus.projects.hibernate.orm;

	import java.util.List;

	import javax.enterprise.context.ApplicationScoped;
	import javax.inject.Inject;
import javax.transaction.Transactional;
import javax.validation.Valid;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
	import javax.ws.rs.NotFoundException;
	import javax.ws.rs.POST;
	import javax.ws.rs.Path;
	import javax.ws.rs.PathParam;
	import javax.ws.rs.Produces;
import javax.ws.rs.WebApplicationException;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.ext.ExceptionMapper;
import javax.ws.rs.ext.Provider;

import org.jboss.logging.Logger;
import org.letztechance.domain.quarkus.hibernate.orm.entities.products.Product;
import org.letztechance.domain.quarkus.orm.entities.users.CreateUserRequest;
import org.letztechance.domain.quarkus.orm.entities.users.User;
import org.letztechance.domain.quarkus.orm.entities.users.Users;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;

	@Path("/users")
	@ApplicationScoped
	public class UserEndpointResource {
		
		private static final Logger LOGGER = Logger.getLogger(ProductResource.class.getName());

	    @Inject
	    Users users;

	    @GET
	    @Produces(MediaType.APPLICATION_JSON)
	    public List<User> findAll() {
	        return users.list();
	    }

	    @POST
	    @Produces(MediaType.APPLICATION_JSON)
	    public User create(@Valid CreateUserRequest request) {
	        return users.create(User.builder()
	                                .email(request.getEmail())
	                                .username(request.getUsername())
	                                .firstName(request.getFirstName())
	                                .lastName(request.getLastName()).admin(request.isAdmin())
	                                .hashedPassword(request.getHashedPassword())
	                                .build());
	    }

	    @GET
	    @Path("/{username}")
	    @Produces(MediaType.APPLICATION_JSON)
	    public User findByUsername(@PathParam("username") String username) {
	        return users.findByUsername(username)
	                    .orElseThrow(() -> new NotFoundException("User not found! username=" + username));
	    }
	    
	    
//	    @DELETE
//	    @Path("{id}")
//	    @Transactional
//	    public Response delete(@PathParam Integer id) {
//	        Product entity = entityManager.getReference(Product.class, id);
//	        if (entity == null) {
//	            throw new WebApplicationException("Product with id of " + id + " does not exist.", 404);
//	        }
//	        entityManager.remove(entity);
//	        return Response.status(204).build();
//	    }

	    @Provider
	    public static class ErrorMapper implements ExceptionMapper<Exception> {

	        @Inject
	        ObjectMapper objectMapper;

	        @Override
	        public Response toResponse(Exception exception) {
	            LOGGER.error("Failed to handle request", exception);

	            int code = 500;
	            if (exception instanceof WebApplicationException) {
	                code = ((WebApplicationException) exception).getResponse().getStatus();
	            }

	            ObjectNode exceptionJson = objectMapper.createObjectNode();
	            exceptionJson.put("exceptionType", exception.getClass().getName());
	            exceptionJson.put("code", code);

	            if (exception.getMessage() != null) {
	                exceptionJson.put("error", exception.getMessage());
	            }

	            return Response.status(code)
	                    .entity(exceptionJson)
	                    .build();
	        }

	    }
	}