/**
 * 
 */
package org.letztechance.hibernate.orm.entities.location;

import java.time.LocalDate;

import javax.persistence.Cacheable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.QueryHint;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.hibernate.engine.spi.Status;

/**
 * @author B3y0nd3r
 *
 */

@Entity
@Table(name = "known_locations")
@NamedQuery(name = "Location.findAll", query = "SELECT f FROM Location f ORDER BY f.name", hints = @QueryHint(name = "org.hibernate.cacheable", value = "true"))
@NamedQuery(name = "Location.getByName", query = "from Location where name = :name")
@Cacheable
public class Location {

	@Id
	@SequenceGenerator(name = "locationSequence", sequenceName = "known_location_id_seq", allocationSize = 1, initialValue = 10)
	@GeneratedValue(generator = "locationSequence")
	private Integer id;

	@Column(length = 255, unique = true)
	public String name;
	@Column(length = 255)
	public String country;
	@Column(length = 255)
	public String city;
	@Column(length = 255)
	public String street;
	@Column(length = 255)
	public String zip;
	@Column(length = 25, nullable = true)
	public long langtitude = 0;
	@Column(length = 25, nullable = true)
	public long longtitude = 0;

	public LocalDate birth;

	public Status status;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public LocalDate getBirth() {
		return birth;
	}

	public void setBirth(LocalDate birth) {
		this.birth = birth;
	}

	public Status getStatus() {
		return status;
	}

	public void setStatus(Status status) {
		this.status = status;
	}

	public long getLangtitude() {
		return langtitude;
	}

	public void setLangtitude(long langtitude) {
		this.langtitude = langtitude;
	}

	public long getLongtitude() {
		return longtitude;
	}

	public void setLongtitude(long longtitude) {
		this.longtitude = longtitude;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getStreet() {
		return street;
	}

	public void setStreet(String street) {
		this.street = street;
	}

	public String getZip() {
		return zip;
	}

	public void setZip(String zip) {
		this.zip = zip;
	}

//    public static Person findByName(String name){
//        return find("#Person.getByName", name).firstResult();
//    }

}
