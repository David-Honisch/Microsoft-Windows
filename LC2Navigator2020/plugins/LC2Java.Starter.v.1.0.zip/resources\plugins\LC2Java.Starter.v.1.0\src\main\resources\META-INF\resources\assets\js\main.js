//import { TopNavigationModule } from './TopNavigationModule';

var app = angular.module("PersonManagement", []);

//Controller Part
app.controller("PersonManagementController", function($scope, $http) {

	//Initialize page with default data which is blank in this example
	$scope.persons = [];
	$scope.products = [];

	$scope.form = {
		id: -1,
		name: "",
		customerName: "",
	};

	//Now load the data from server
	_refreshPageData();

	//HTTP POST/PUT methods for add/edit Persons
	$scope.update = function() {
		var method = "";
		var url = "";
		var data = {};
		if ($scope.form.id == -1) {
			//Id is absent so add Persons - POST operation
			method = "POST";
			url = '/users';
			data.name = $scope.form.name;
			data.customerName = $scope.form.customerName;
		} else {
			//If Id is present, it's edit operation - PUT operation
			method = "PUT";
			url = '/users/' + $scope.form.id;
			data.name = $scope.form.name;
			data.customerName = $scope.form.customerName;
		}

		$http({
			method: method,
			url: url,
			data: angular.toJson(data),
			headers: {
				'Content-Type': 'application/json'
			}
		}).then(_success, _error);
	};

	//HTTP DELETE- delete Person by id
	$scope.remove = function(Person) {
		$http({	method: 'DELETE',	url: '/users/' + Person.id	}).then(_success, _error);
	};

	//In case of edit Persons, populate form with Person data
	$scope.edit = function(Person) {
		$scope.form.name = Person.name;
		$scope.form.id = Person.id;
	};

	/* Private Methods */
	//HTTP GET- get all Persons collection
	function _refreshPageData() {
		$http({
			method: 'GET',	url: '/assets/data/nav.json'}).then(function successCallback(response) {
			$scope.products = response.data;
		}, function errorCallback(response) {
			console.log(response.statusText);
		});
		$http({
			method: 'GET',
			url: '/users'
		}).then(function successCallback(response) {
			$scope.persons = response.data;
		}, function errorCallback(response) {
			console.log(response.statusText);
		});
		$http({
			method: 'GET',	url: '/users'}).then(function successCallback(response) {
			$scope.products = response.data;
		}, function errorCallback(response) {
			console.log(response.statusText);
		});
	}

	function _success(response) {
		_refreshPageData();
		_clearForm()
	}

	function _error(response) {
		alert(response.data.message || response.statusText);
	}

	//Clear the form
	function _clearForm() {
		$scope.form.name = "";
		$scope.form.id = -1;
	}
});