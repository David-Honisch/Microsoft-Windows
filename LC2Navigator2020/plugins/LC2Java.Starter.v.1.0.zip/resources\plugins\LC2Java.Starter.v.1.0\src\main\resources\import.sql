--CREATE ROLE quarkus WITH LOGIN PASSWORD 'quarkus';
--CREATE DATABASE quarkus_test;
--GRANT ALL PRIVILEGES ON DATABASE quarkus_test TO quarkus;
--\c quarkus_test

CREATE TABLE test_user (
    id INT,
    username VARCHAR(255),
    password VARCHAR(255),
    role VARCHAR(255)
);
GRANT ALL PRIVILEGES ON TABLE  test_user TO quarkus;
INSERT INTO test_user (id, username, password, role) VALUES (1, 'admin', 'admin', 'admin');
INSERT INTO test_user (id, username, password, role) VALUES (2, 'user','user', 'user');


INSERT INTO known_fruits(id, name) VALUES (1, 'Cherry');
INSERT INTO known_fruits(id, name) VALUES (2, 'Apple');
INSERT INTO known_fruits(id, name) VALUES (3, 'Banana');

INSERT INTO known_projects(id, name) VALUES (1, 'Google');
INSERT INTO known_projects(id, name) VALUES (2, 'IBM');
INSERT INTO known_projects(id, name) VALUES (3, 'Amazon');
INSERT INTO known_projects(id, name) VALUES (4, 'Microsoft');
INSERT INTO known_projects(id, name) VALUES (5, 'Oracle');
INSERT INTO known_projects(id, name) VALUES (6, 'David Honisch');
INSERT INTO known_projects(id, name) VALUES (7, 'David Honisch2');
