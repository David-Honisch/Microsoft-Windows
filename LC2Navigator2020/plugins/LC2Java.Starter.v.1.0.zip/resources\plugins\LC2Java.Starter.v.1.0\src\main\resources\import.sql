--CREATE ROLE quarkus WITH LOGIN PASSWORD 'quarkus';
--CREATE DATABASE quarkus_test;
--GRANT ALL PRIVILEGES ON DATABASE quarkus_test TO quarkus;
--\c quarkus_test

CREATE TABLE test_user (
    id INT,
    username VARCHAR(255),
    password VARCHAR(255),
    role VARCHAR(255)
);
GRANT ALL PRIVILEGES ON TABLE  test_user TO quarkus;
INSERT INTO test_user (id, username, password, role) VALUES (1, 'admin', 'admin', 'admin');
INSERT INTO test_user (id, username, password, role) VALUES (2, 'user','user', 'user');


INSERT INTO known_products(id, name) VALUES (1, 'Cherry');
INSERT INTO known_products(id, name) VALUES (2, 'Apple');
INSERT INTO known_products(id, name) VALUES (3, 'Banana');
INSERT INTO known_products(id, name) VALUES (4, 'AMD Radeon RX 6600 XT');
INSERT INTO known_products(id, name) VALUES (5, 'Nvidias GeForce RTX 3060');
INSERT INTO known_products(id, name) VALUES (6, 'Ferrari F60');
INSERT INTO known_products(id, name) VALUES (7, 'Boeing 747');

INSERT INTO known_projects(id, name) VALUES (1, 'Google');
INSERT INTO known_projects(id, name) VALUES (2, 'IBM');
INSERT INTO known_projects(id, name) VALUES (3, 'Amazon');
INSERT INTO known_projects(id, name) VALUES (4, 'Microsoft');
INSERT INTO known_projects(id, name) VALUES (5, 'Oracle');
INSERT INTO known_projects(id, name) VALUES (6, 'David Honisch');
INSERT INTO known_projects(id, name) VALUES (7, 'David Honisch2');

insert into known_locations(id, name, langtitude, longtitude )values(1,'Germany',0,0);
insert into known_locations(id, name, langtitude, longtitude)values(2,'UK',0,0);
insert into known_locations(id, name, langtitude, longtitude)values(3,'USA',0,0);
insert into known_locations(id, name, langtitude, longtitude)values(4,'Russia',0,0);
insert into known_locations(id, name, langtitude, longtitude)values(5,'China',0,0);
insert into known_locations(id, name, langtitude, longtitude)values(6,'Japan',0,0);

insert into known_persons(id, name, locations_id,birth,   status)values(1,'Berlin',1,'2001-07-30', 2);
insert into known_persons(id, name, locations_id, birth,  status)values(2,'NY',1,'20021-07-30', 1);
insert into known_persons(id, name, locations_id, birth,  status)values(3,'London',1,'20021-07-30', 1);
insert into known_persons(id, name, locations_id, birth,  status)values(4,'Barcelona',1,'20021-07-30', 1);
