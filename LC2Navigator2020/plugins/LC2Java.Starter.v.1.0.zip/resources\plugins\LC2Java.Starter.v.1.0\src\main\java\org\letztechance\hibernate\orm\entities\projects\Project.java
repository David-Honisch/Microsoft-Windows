package org.letztechance.hibernate.orm.entities.projects;

import javax.persistence.Cacheable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.QueryHint;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name = "known_projects")
@NamedQuery(name = "Projects.findAll", query = "SELECT f FROM Project f ORDER BY f.name", hints = @QueryHint(name = "org.hibernate.cacheable", value = "true"))
@Cacheable
public class Project {

	@Id
	@SequenceGenerator(name = "projectsSequence", sequenceName = "known_projects_id_seq", allocationSize = 1, initialValue = 10)
	@GeneratedValue(generator = "projectsSequence")
	private Integer id;

	@Column(length = 40, unique = true)
	private String name;

	@Column(length = 40, unique = true)
	private String customerName;

	@Column(length = 40)
	private String customerFirstName;

	@Column(length = 40)
	private String customerLastName;

	public Project() {
	}

	public Project(String name) {
		this.name = name;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public String getCustomerFirstName() {
		return customerFirstName;
	}

	public void setCustomerFirstName(String customerFirstName) {
		this.customerFirstName = customerFirstName;
	}

	public String getCustomerLastName() {
		return customerLastName;
	}

	public void setCustomerLastName(String customerLastName) {
		this.customerLastName = customerLastName;
	}

}
