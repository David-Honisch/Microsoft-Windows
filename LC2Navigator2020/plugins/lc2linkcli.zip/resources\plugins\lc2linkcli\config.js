var hostName = "http://localhost:5000";
const installDirectories = [
    // 'lcwebclient_final_lib',
    // 'org.letztechance.domain.web.GrabUrls',
    // 'org.letztechance.domain.web.GrabUrls\\org.letztechance.domain.web.GrabUrls_lib',
    'resources\\plugins\\lcwebclient_final',
    'resources\\plugins\\lcwebclient_final\\lcwebclient_final_lib',
    'resources\\plugins\\org.letztechance.domain.web.GrabUrls',
    'resources\\plugins\\org.letztechance.domain.web.GrabUrls\\org.letztechance.domain.web.GrabUrls_lib',

];
const rlibs = [
    'jquery',
    'https',
    'stream',
    'line-reader',
    'fs',
    'request',
    'runtime-npm-install',
    'decompress-zip',
    // 'extract-zip',
    'csv',
    'jszip',
    'sax',
    'xlsx',
    'xlsx-to-json',
    'xlsx-to-json-lc',
    'xml2js',
    'xmlbuilder',
    'xmldom',
    'xml-js',
    'xmljson',
    'node-xlsx',
    'bluebird'
];

var downloadUrls = [{
    path: "https://www.letztechance.org/LC2Intro.v.4.0/assets/",
    file: "lclogo.png",
}];