SELECT '<h1>LC2LinkCLI PLUGIN SQL SCRIPT IS RUNNING</h1>'; 
SELECT '<h5>Deleting import script</h5>'; 
SELECT '<h5>RUNNING IMPORT</h5>'; 
SELECT '<h4>SET CLEAR</h4>'; 
SELECT '<h4>DELETING application</h4>'; 
SELECT '<h1>UPDATE LC2LinkCLI SQL SCRIPT DONE</h1>'; 
INSERT INTO application VALUES(25,'LC2LinkCLI v.1.01a','LC2LinkCLI v.1.01a','','','','','exec .\\resources\\plugins\\LC2LinkCLI\\LC2LinkCLI.bat .\\resources\\plugins\\LC2LinkCLI\\menu.csv'); 
SELECT '<h5>SQL LC2LinkCLI IMPORT DONE</h5>'; 
