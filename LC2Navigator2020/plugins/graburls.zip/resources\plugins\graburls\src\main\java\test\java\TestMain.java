//package org.letztechance.domain.spring.app.test;
///**
// * 
// */
//
//
//import static org.junit.Assert.assertEquals;
//import static org.junit.jupiter.api.Assertions.assertEquals;
//
//import org.apache.logging.log4j.LogManager;
//import org.apache.logging.log4j.Logger;
//import org.junit.jupiter.api.DisplayName;
//import org.junit.jupiter.api.Test;
//import org.junit.jupiter.params.ParameterizedTest;
//import org.junit.jupiter.params.provider.CsvSource;
//import org.junit.runner.RunWith;
//import org.letztechance.domain.cli.config.Config;
//
//
///**
// * @author David
// *
// */
//@DisplayName("Tests")
//public class TestMain {
//
//	private static final Class<TestMain> LCLASS = TestMain.class;
//	private static Logger log = Config.setLogManager(LCLASS);
//	@Test
//	@DisplayName("Test basics...")
//	public void TestLOG() {
//		System.out.println("Test log basics....");
//		assertEquals(true, true, "Yes it´s true");
//		log.trace("Test basics...");
//		if (log.isTraceEnabled()) {
//			log.trace("Trace enabled");
//		}
//		if (log.isInfoEnabled()) {
//			log.info("Info enabled");
//		}
//		if (log.isDebugEnabled()) {
//			log.debug("Debug enabled");
//		}
//		if (log.isWarnEnabled()) {
//			log.warn("Warn enabled");
//		}
//		if (log.isFatalEnabled()) {
//			log.fatal("Fatal enabled");
//			assertEquals(true, true, "Log should be enabled");
//		}
//
//        log.trace("Exiting application.");
//
//	}
//	
////	@ParameterizedTest(name = "{0} + {1} = {2}")
////	@CsvSource({
////			"0,    1,   1",
////			"1,    2,   3",
////			"49,  51, 100",
////			"1,  100, 101"
////	}) 
//
//	/**
//	 * @param args
//	 */
//	@Test
//	@DisplayName("TestMain Appliation")
//	void TestxxMain() {
//		// Set up a simple configuration that logs on the console.
//		System.out.println("Test running....");
//		log.trace("Entering application.");
//		if (log.isDebugEnabled()) {
//			log.debug("Debug enabled");
//		}
////        Bar bar = new Bar();
////        if (!bar.doIt()) {
////        	log.error("Didn't do it.");
////        }
//        log.trace("Exiting application.");
//
//	}
////	@Test
////	@DisplayName("1 + 1 = 2")
////	void addsTwoNumbers() {
////		Calculator calculator = new Calculator();
////		assertEquals(2, calculator.add(1, 1), "1 + 1 should equal 2");
////	}
//
////	@ParameterizedTest(name = "{0} + {1} = {2}")
////	@CsvSource({
////			"0,    1,   1",
////			"1,    2,   3",
////			"49,  51, 100",
////			"1,  100, 101"
////	})
////	void add(int first, int second, int expectedResult) {
////		Calculator calculator = new Calculator();
////		assertEquals(expectedResult, calculator.add(first, second),
////				() -> first + " + " + second + " should equal " + expectedResult);
////	} 
//
//}
