function execCMD(text, id) {
    console.log('execCMD running...');
    printParseUrl("<h1>Searching...</h1>", id);
    const {
        exec
    } = window.nodeRequire('child_process');
    //document.getElementById("error").innerHTML = "";
    printParseUrl("", "error");
    printParseUrl("<div class=\"preload\"></div>", id);
    // alert('OUT:'+text.length);
    try {


        exec('' + text, (err, stdout, stderr) => {

            if (err) {
                console.error(err);
                printParseUrl("" + JSON.stringify(err), "error");
                printParseUrl("" + stdout, id);
                //document.getElementById(id).innerHTML = stdout;
                return;
            }
            //document.getElementById(id).innerHTML = stdout;
            printParseUrl("" + stdout, id);
            console.log('execCMD done.');
        });
    } catch (error) {
        printParseUrl("" + JSON.stringify(err), "error");
        console.error(JSON.stringify(err))


    }
}

function parseUrl() {
    var pattern = document.getElementById('pattern').value;
    var tableId = document.getElementById('tableId').value;
    if (pattern != undefined && pattern.length > 0) {
        //alert('Searching:'+pattern);
        printParseUrl('Searching:' + pattern, 'outcnt');
    } else {
        alert('Search pattern is empty. Please enter a value');
        return
    }
    if (IsImportEndabled) {
        execCMD('call exec.bat .\\resources\\plugins\\grabandimporturls.html.bat ' + pattern + ' ' + tableId, 'outcnt')
    } else {
        execCMD('call exec.bat .\\resources\\plugins\\grabandimporturls.grab.only.html.bat ' + pattern + ' ' + tableId, 'outcnt')
    }

}

function printParseUrl(text, id) {
    document.getElementById(id).innerHTML = text;
    console.log(text);
}



var IsImportEndabled = false;

try {
    var jQuery = window.nodeRequire('jquery');
    //alert('Test');    
    console.log('Running now..');
    jQuery('#outcnt').html('Welcome');
    var httprequest = new HttpRequest();
    httprequest.getFullList();
    console.log('Done.');
    //alert('Test 3');		
    window.jQuery('#outcnt').append('<hr>done.');
    // alert('Done');
    //add checkbox listener
    window.jQuery('input[type="checkbox"]').click(function() {
        if (window.jQuery(this).is(":checked")) {
            IsImportEndabled = true;
        } else if (jQuery(this).is(":not(:checked)")) {
            IsImportEndabled = false;
        }
    });

    // alert('Done');
} catch (e) {
    alert(e);
}