//org.letztechance.domain.spring.app.Application
package org.letztechance.domain.spring.app;

import java.util.Arrays;

import org.apache.logging.log4j.Logger;
import org.letztechance.domain.cli.config.Config;
import org.letztechance.domain.spring.app.controllers.property.FileStorageProperties;
import org.letztechance.domain.spring.app.controllers.service.FileStorageService;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.ApplicationContext;


@SpringBootApplication
@EnableConfigurationProperties({
		FileStorageProperties.class
})
public class Application {
	
	private static final Logger log = Config.setLogManager(FileStorageService.class);

	public static void main(String[] args) {
		ApplicationContext ctx = SpringApplication.run(Application.class, args);

		log.debug("Spring Boot running...");

		String[] beanNames = ctx.getBeanDefinitionNames();
		Arrays.sort(beanNames);
		for (String beanName : beanNames) {
			System.out.println(beanName);
		}
	}
	
}
