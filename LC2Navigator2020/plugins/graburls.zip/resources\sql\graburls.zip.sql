SELECT '<h1>graburls PLUGIN SQL SCRIPT IS RUNNING</h1>'; 
SELECT '<h5>Deleting import script</h5>'; 
SELECT '<h5>RUNNING IMPORT</h5>'; 
SELECT '<h4>SET CLEAR</h4>'; 
SELECT '<h4>DELETING application</h4>'; 
SELECT '<h1>UPDATE graburls SQL SCRIPT DONE</h1>'; 
INSERT INTO application VALUES(25,'graburls v.1.01a','graburls v.1.01a','','','','','exec .\\resources\\plugins\\graburls\\graburls.bat .\\resources\\plugins\\graburls\\menu.csv'); 
SELECT '<h5>SQL graburls IMPORT DONE</h5>'; 
