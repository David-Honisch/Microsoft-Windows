//alert('Done.');
//setTimeout(new HttpRequest().execCMD('echo lc2graburls.js.bat initializing...', 'lc2graburls_cnt'), 3000)
window.GrabUrlsPlugin = function GrabUrlsPlugin() {
    this.parseUrl = function parseUrl() {
        var pattern = document.getElementById('pattern').value;
        if (pattern != undefined && pattern.length > 0) {
            //alert('Searching:'+pattern);
            print('Searching:' + pattern, 'lc2graburls_cnt');
        } else {
            alert('Search pattern is empty. Please enter a value');
            return
        }
        //new HttpRequest().execCMD('call java -jar .\\resources\\plugins\\lc2graburls\\org.letztechance.domain.web.GrabUrls.jar ' + pattern, 'lc2graburls_cnt')
        new HttpRequest().execCMD('call .\\resources\\plugins\\lc2graburls\\lc2graburls.work.bat ' + pattern, 'lc2graburls_cnt');

    }

    this.submitForm = function submitForm() {
        // alert('TEST');
        try {
            $("#btnparseUrl").click(function(event) {
                // alert('TEST');
                new window.GrabUrlsPlugin().parseUrl();
            });
        } catch (error) {
            console.error(error);
            console.error(error.stack);
        }
    }

    this.print = function print(text, id) {
        document.getElementById(id).innerHTML = text;
        console.log(text);
    }


}
try {

    new HttpRequest().execCMD('type .\\resources\\plugins\\lc2graburls\\lc2graburls.view.html', 'lc2graburls_cnt_out');
    setTimeout(() => {
        new window.GrabUrlsPlugin().submitForm();
    }, 300);

} catch (error) {
    console.error(error);
    console.error(error.stack);
}