SELECT '<h1>LC2IRC PLUGIN SQL SCRIPT IS RUNNING</h1>';
SELECT '<h5>Deleting import script</h5>';
--DELETE FROM importscripts;
SELECT '<h5>RUNNING IMPORT</h5>';
SELECT '<h4>SET CLEAR</h4>';
SELECT '<h4>DELETING application</h4>';
select count(*) as count from application;
SELECT '<h1>UPDATE LC2IRC SQL SCRIPT DONE</h1>'; 
INSERT OR REPLACE INTO application(person_id, name, first_name, description, zipcode, city, street, url)
VALUES(11,'LC2IRC v.1.01a','LC2IRC v.1.01a','','','','','exec .\\resources\\plugins\\lc2irc\\lc2irc.bat .\\resources\\plugins\\lc2irc\\menu.csv'); 
select count(*) as count from application;
SELECT '<h1>UPDATE SQL SCRIPT DONE</h1>';
SELECT '<h5>SQL IMPORT DONE</h5>';
