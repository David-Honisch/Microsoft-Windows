function getXDCCPack(host, port, nickName, chan, path, retry, timeout, isVerbose, israndomizedNick, passivePort, isSecure, bot, pack) {
    try {
        const XDCC = window.nodeRequire('xdccjs').default;
        // alert('Damn');

        $("#outcnt").append('<br>RUNNING...');

        // or
        // import XDCC from 'xdccjs'
        const opts = {
            host: host, // 'irc.dal.net', // IRC hostname                                                   - required
            port: port, //6660, // IRC port                                                                   - default: 6667
            nickname: nickName, //'ItsMeJiPaix', // Nickname                                                          - default: xdccJS + random
            chan: chan, //['#chat', '#fruits'], // Array of channels                                         - default : [ ]
            path: path, //'downloads', // Download path or 'false'                                            - default: false (which enables piping)
            retry: retry, //2 Nb of retries before skip                                                    - default: 1
            timeout: timeout, //50 Nb of seconds before a download is considered timed out                   - default: 30
            verbose: isVerbose, //true // Display download progress and jobs status                               - default: false
            randomizeNick: israndomizedNick, //false // Add random numbers at end of nickname                            - default: true
            passivePort: passivePort, //[5000, 5001, 5002], // Array of port(s) to use with Passive DCC              - default: [5001]
            secure: isSecure, // Allow/Deny files sent by bot with different name than the one requested - default: true
        }
        $("#outcnt").append('INIT...<br>');
        const xdccJS = new XDCC(opts);
        //const job1 = xdccJS.download(bot, [pack])
        // const job1 = xdccJS.download(bot, [23]);
        // Start VLC
        const { spawn } = require('child_process')
        const vlcPath = path.normalize('C:\\Program Files\\VideoLAN\\VLC\\vlc.exe')
        const vlc = spawn(vlcPath, ['-'])

        xdccJS.on('ready', () => {
            $("#outcnt").append('xdccJs is ready...');
            const Job = xdccJS.download('bot', 155)
        })

        // send data to VLC that plays the file
        Job.on('pipe', stream => {
            stream.pipe(vlc.stdin)
        })

    } catch (error) {
        alert(error);
        alert(error.stack);
    }
    $("#outcnt").append('Starting Download progress done.<br>');
}
$("#ircsubmit").on("click", function(e) {
    e.preventDefault();
    e.stopPropagation();
    var host = $('#host').val();
    var port = $('#port').val();
    var nickName = $('#nickName').val();
    var chan = $('#chan').val();
    var path = $('#path').val();
    var retry = $('#retry').val();
    var timeout = $('#timeout').val();
    var isVerbose = $('#isVerbose').val();
    var israndomizedNick = $('#israndomizedNick').val();
    var passivePort = $('#passivePort').val();
    var isSecure = $('#isSecure').val();
    $("#outcnt").append('Downloading from<br>' + host + '<br> ' + port + '<br> ' + nickName + '<br> ' + chan + '<br> ' + path + '<br>' + retry + '<br> ' + timeout + '<br> ' + isVerbose + '<br> ' + israndomizedNick + '<br>' + passivePort + '<br>' + isSecure);
    getXDCCPack(host, port, nickName, chan, path, retry, timeout, isVerbose, israndomizedNick, passivePort, isSecure);
});
// alert('Damn');
// alert('Damn');
// var utils = new XLSXUtils(XLSX);

// $("#outcnt").append('RUNNING...');

// /* <input type="submit" value="Import to SQLite" id="dbimport" onclick="export_db();" disabled="false"></input> */
// $("#xlsxport").on("click", function(e) {
//     alert('Debug');
//     e.preventDefault();
//     e.stopPropagation();
//     utils.export_all();
// });
// $("#csvxport").on("click", function(e) {
//     e.preventDefault();
//     e.stopPropagation();
//     utils.export_csv();
// });
// $("#xmlxport").on("click", function(e) {
//     e.preventDefault();
//     e.stopPropagation();
//     utils.export_xml();
// });
// $("#jsonxport").on("click", function(e) {
//     e.preventDefault();
//     e.stopPropagation();
//     utils.export_json();
// });
// $("#btngraburls").on("click", function(e) {
//     e.preventDefault();
//     e.stopPropagation();
//     // alert('Debug');
//     utils.grab_urls();
// });
// $("#dbimport").on("click", function(e) {
//     e.preventDefault();
//     e.stopPropagation();
//     // alert('Debug');
//     utils.export_db();
// });
// $("#wsxport").on("click", function(e) {
//     e.preventDefault();
//     e.stopPropagation();
//     // alert('Debug');
//     utils.export_ws();
// });
// $("#runserver").on("click", function(e) {
//     e.preventDefault();
//     e.stopPropagation();
//     try {
//         // alert('Debug');
//         new HttpRequest().execCMD('.\\resources\\plugins\\graburls\\runserver.bat', 'outcnt');
//         // alert('Debug');
//     } catch (error) {
//         alert(error);
//         alert(error.stack);
//     }
// });



// //var httprequest = new HttpRequest();
// //httprequest.getFullList();