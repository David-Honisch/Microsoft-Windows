try {
    // alert('Damn');

    $("#outcnt").append('RUNNING...');
    const XDCC = window.nodeRequire('xdccjs').default
        // or
        // import XDCC from 'xdccjs'
    const opts = {
        host: 'irc.dal.net', // IRC hostname                                                   - required
        port: 6660, // IRC port                                                                   - default: 6667
        nickname: 'ItsMeJiPaix', // Nickname                                                          - default: xdccJS + random
        chan: ['#chat', '#fruits'], // Array of channels                                         - default : [ ]
        path: 'downloads', // Download path or 'false'                                            - default: false (which enables piping)
        retry: 2, // Nb of retries before skip                                                    - default: 1
        timeout: 50, // Nb of seconds before a download is considered timed out                   - default: 30
        verbose: true, // Display download progress and jobs status                               - default: false
        randomizeNick: false, // Add random numbers at end of nickname                            - default: true
        passivePort: [5000, 5001, 5002], // Array of port(s) to use with Passive DCC              - default: [5001]
        secure: false, // Allow/Deny files sent by bot with different name than the one requested - default: true
    }
    $("#outcnt").append('INIT...');
    const xdccJS = new XDCC(opts);
    const job1 = xdccJS.download('a-bot', [33, 50, 62, 98])
    const job2 = xdccJS.download('XDCC|RED', [1, 3, 10, 20])
    xdccJS.on('downloading', (fileInfo, received, percentage) => {
        console.log(fileInfo) //=> { file: 'filename.pdf', filePath: '/path/to/filename.pdf', length: 5844849 }
        console.log(`downloading: '${fileInfo.file}'`) //=> downloading: 'your file.pdf'
        $("#outcnt").append(`downloading: '${fileInfo.file}'`);
    })
    let status = job1.show();
    $("#outcnt").append(status);

    let status2 = job2.show();
    $("#outcnt").append(status2);
    job1.on('downloading', (fileInfo, received, percentage) => {
        console.log(percentage) //=> 10.55
        $("#percent").html(percentage);
    });
    //
    xdccJS.on('ready', () => {
        xdccJS.download('XDCC|BLUE', '1-3, 8, 55')
        xdccJS.download('XDCC|YELLOW', 4)
        xdccJS.download('XDCC|RED', [12, 7, 10, 20])
        xdccJS.download('XDCC|PURPLE', ['1', '3', '10', '20'])
    })
} catch (error) {
    alert(error);
    alert(error.stack);
}
// alert('Damn');
// alert('Damn');
// var utils = new XLSXUtils(XLSX);

// $("#outcnt").append('RUNNING...');

// /* <input type="submit" value="Import to SQLite" id="dbimport" onclick="export_db();" disabled="false"></input> */
// $("#xlsxport").on("click", function(e) {
//     alert('Debug');
//     e.preventDefault();
//     e.stopPropagation();
//     utils.export_all();
// });
// $("#csvxport").on("click", function(e) {
//     e.preventDefault();
//     e.stopPropagation();
//     utils.export_csv();
// });
// $("#xmlxport").on("click", function(e) {
//     e.preventDefault();
//     e.stopPropagation();
//     utils.export_xml();
// });
// $("#jsonxport").on("click", function(e) {
//     e.preventDefault();
//     e.stopPropagation();
//     utils.export_json();
// });
// $("#btngraburls").on("click", function(e) {
//     e.preventDefault();
//     e.stopPropagation();
//     // alert('Debug');
//     utils.grab_urls();
// });
// $("#dbimport").on("click", function(e) {
//     e.preventDefault();
//     e.stopPropagation();
//     // alert('Debug');
//     utils.export_db();
// });
// $("#wsxport").on("click", function(e) {
//     e.preventDefault();
//     e.stopPropagation();
//     // alert('Debug');
//     utils.export_ws();
// });
// $("#runserver").on("click", function(e) {
//     e.preventDefault();
//     e.stopPropagation();
//     try {
//         // alert('Debug');
//         new HttpRequest().execCMD('.\\resources\\plugins\\graburls\\runserver.bat', 'outcnt');
//         // alert('Debug');
//     } catch (error) {
//         alert(error);
//         alert(error.stack);
//     }
// });



// //var httprequest = new HttpRequest();
// //httprequest.getFullList();