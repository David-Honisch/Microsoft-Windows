var httprequest = new HttpRequest();

function getXDCCPack(bot, pack, host, port, nickName, chan, path, retry, timeout, isVerbose, israndomizedNick, passivePort, isSecure) {
    try {
        const XDCC = window.nodeRequire('xdccjs').default;
        // alert('Damn');

        $("#outcnt").append('<br>RUNNING...');

        // or
        // import XDCC from 'xdccjs'
        const opts = {
            host: host, // 'irc.dal.net', // IRC hostname                                                   - required
            port: port, //6660, // IRC port                                                                   - default: 6667
            nickname: nickName, //'ItsMeJiPaix', // Nickname                                                          - default: xdccJS + random
            chan: chan, //['#chat', '#fruits'], // Array of channels                                         - default : [ ]
            path: path, //'downloads', // Download path or 'false'                                            - default: false (which enables piping)
            retry: retry, //2 Nb of retries before skip                                                    - default: 1
            timeout: timeout, //50 Nb of seconds before a download is considered timed out                   - default: 30
            verbose: isVerbose, //true // Display download progress and jobs status                               - default: false
            randomizeNick: israndomizedNick, //false // Add random numbers at end of nickname                            - default: true
            passivePort: passivePort, //[5000, 5001, 5002], // Array of port(s) to use with Passive DCC              - default: [5001]
            secure: isSecure, // Allow/Deny files sent by bot with different name than the one requested - default: true
        }
        $("#outcnt").append('INIT...<br>');
        const xdccJS = new XDCC(opts);
        //const job1 = xdccJS.download(bot, [pack])
        // const job1 = xdccJS.download(bot, [23]);
        var job1;
        xdccJS.on('ready', () => {
                $("#outcnt").append('xdccJs is ready. Calling:' + bot + " with pack:" + pack);
                job1 = xdccJS.download(bot, pack);
                // if (job1 !== undefined) {
                let status = job1.show()
                $("#outcnt").append('Status' + JSON.stringify(status));


                xdccJS.on('downloading', (fileInfo, received, percentage) => {
                    $("#outcnt").append(fileInfo) //=> { file: 'filename.pdf', filePath: '/path/to/filename.pdf', length: 5844849 }
                    $("#outcnt").append(`downloading: '${fileInfo.file}'`) //=> downloading: 'your file.pdf'
                    console.log(percentage) //=> 10.55
                    $("#percent").html(percentage);
                })



                job1.on('downloading', (fileInfo, received, percentage) => {
                    console.log(percentage) //=> 10.55
                    $("#percent").html(percentage);
                });
                xdccJS.on('done', (job) => {
                    $("#outcnt").append(job.show())
                        //=> { name: 'a-bot', queue: [98], now: 62, sucess: ['file.txt'], failed: [50] }
                });
                $("#outcnt").append('Status done');

                // }
            })
            // const job1 = xdccJS.download(bot, 23);
            // // const job2 = xdccJS.download('XDCC|RED', [1, 3, 10, 20])
            // xdccJS.on('downloading', (fileInfo, received, percentage) => {
            //     console.log(fileInfo) //=> { file: 'filename.pdf', filePath: '/path/to/filename.pdf', length: 5844849 }
            //     console.log(`downloading: '${fileInfo.file}'`) //=> downloading: 'your file.pdf'
            //     $("#outcnt").append(`downloading: '${fileInfo.file}'`);
            // })
            // let status = job1.show();
            // $("#outcnt").append(status);

        // // let status2 = job2.show();
        // $("#outcnt").append(status1);


        // //
        // xdccJS.on('ready', () => {
        //     xdccJS.download(bot, pack)
        //         // xdccJS.download('XDCC|YELLOW', 4)
        //         // xdccJS.download('XDCC|RED', [12, 7, 10, 20])
        //         // xdccJS.download('XDCC|PURPLE', ['1', '3', '10', '20'])
        // })
    } catch (error) {
        alert(error);
        alert(error.stack);
    }
    $("#outcnt").append('Starting Download progress done.<br>');
}

function getXDCCForm(httprequest) {
    var bot = $('#bot').val();
    var pack = $('#pack').val();
    var host = $('#host').val();
    var port = $('#port').val();
    var nickName = $('#nickName').val();
    var chan = $('#chan').val();
    var path = $('#path').val();
    var retry = $('#retry').val();
    var timeout = $('#timeout').val();
    var isVerbose = $('#isVerbose').val();
    var israndomizedNick = $('#israndomizedNick').val();
    var passivePort = $('#passivePort').val();
    var isSecure = $('#isSecure').val();
    var params = '"' + bot + '" ' + pack + ' ' + host + ' ' + port + ' ' + nickName + ' "' + chan + '" ' + path + ' ' + retry + ' ' + timeout + ' ' + isVerbose + ' ' + israndomizedNick + ' ' + passivePort + ' ' + isSecure + '';
    $("#outcnt").append('Downloading from<br>' + JSON.stringify(params));
    // getXDCCPack(bot, pack, host, port, nickName, chan, path, retry, timeout, isVerbose, israndomizedNick, passivePort, isSecure);
    // new HttpRequest().execCMD('.\\resources\\plugins\\lc2irc\\xdcc.bat bot pack host port nickName chan path retry timeout isVerbose israndomizedNick passivePort isSecure', 'outcnt');
    $("#outcnt").append('<hr>executing...<hr>');
    httprequest.execCMD('exec .\\resources\\plugins\\lc2irc\\xdcc.bat ' + params, 'outcnt');
    $("#outcnt").append('<hr>Done.');
}

$("#ircsubmit").on("click", function(e) {
    e.preventDefault();
    e.stopPropagation();
    try {
        getXDCCForm(httprequest);


    } catch (error) {
        alert(error);
        alert(error.stack);
    }
});
// //var httprequest = new HttpRequest();
// //httprequest.getFullList();