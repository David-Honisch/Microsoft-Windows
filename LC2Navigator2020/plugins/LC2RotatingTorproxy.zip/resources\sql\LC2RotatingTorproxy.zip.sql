SELECT '<h1>LC2RotatingTorproxy PLUGIN SQL SCRIPT IS RUNNING</h1>'; 
SELECT '<h5>Deleting import script</h5>'; 
SELECT '<h5>RUNNING IMPORT</h5>'; 
SELECT '<h4>SET CLEAR</h4>'; 
SELECT '<h4>DELETING application</h4>'; 
select count(*) as count from application;
SELECT '<h1>UPDATE LC2RotatingTorproxy SQL SCRIPT DONE</h1>'; 
INSERT OR REPLACE INTO application(person_id, name, first_name, description, zipcode, city, street, url)
VALUES(7,'LC2RotatingTorproxy v.1.01b','LC2RotatingTorproxy v.1.01b','','','','','exec .\\resources\\plugins\\LC2RotatingTorproxy\\index.bat .\\resources\\plugins\\LC2RotatingTorproxy\\menu.csv'); 
select count(*) as count from application;
SELECT '<h5>SQL LC2RotatingTorproxy IMPORT DONE</h5>'; 
