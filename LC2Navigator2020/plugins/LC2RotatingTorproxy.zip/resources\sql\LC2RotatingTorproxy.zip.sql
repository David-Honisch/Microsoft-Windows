SELECT '<h1>LC2RotatingTorproxy PLUGIN SQL SCRIPT IS RUNNING</h1>'; 
SELECT '<h5>Deleting import script</h5>'; 
SELECT '<h5>RUNNING IMPORT</h5>'; 
SELECT '<h4>SET CLEAR</h4>'; 
SELECT '<h4>DELETING application</h4>'; 
SELECT '<h1>UPDATE LC2RotatingTorproxy SQL SCRIPT DONE</h1>'; 
INSERT INTO application VALUES('LC2RotatingTorproxy v.1.01b','LC2RotatingTorproxy v.1.01b','','','','','exec .\\resources\\plugins\\LC2RotatingTorproxy\\index.bat .\\resources\\plugins\\LC2RotatingTorproxy\\menu.csv'); 
SELECT '<h5>SQL LC2RotatingTorproxy IMPORT DONE</h5>'; 
