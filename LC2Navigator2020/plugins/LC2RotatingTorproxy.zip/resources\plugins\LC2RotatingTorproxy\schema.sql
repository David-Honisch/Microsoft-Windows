select '<h4>LC2RotatingTorproxy Plugin SQL Import</h4>';
drop table IF EXISTS LC2RotatingTorproxy;
drop table IF EXISTS LC2RotatingTorproxytemp;
CREATE TABLE LC2RotatingTorproxy ( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
create table IF NOT EXISTS LC2RotatingTorproxytemp ( name varchar(255), menu TEXT, url varchar(255), subtext TEXT);
-- select 'Create table LC2RotatingTorproxy Import';
-- .separator "\t"
-- .import .\\import.csv LC2RotatingTorproxytemp
.separator ";"
.import .\\resources\\plugins\\LC2RotatingTorproxy\\import\\import.csv LC2RotatingTorproxytemp
--.import ..\\import\\materialnohead.csv url
--INSERT INTO person VALUES (4, 'Alice', '351246233');
-- DELETE FROM url where url.name = '';
-- select '<p>LC2RotatingTorproxytemp count:';
-- select count(*) from LC2RotatingTorproxytemp;
-- select '</p>';
-- select '<p>SQL Import successfully done</p>';
-- select '<p>LC2RotatingTorproxy count:'+count(*)+'</p>' from LC2RotatingTorproxytemp;
-- select * from LC2RotatingTorproxytemp limit 1;
-- select '<p>temp table COUNT:'+count(*)+'</p>' from LC2RotatingTorproxytemp;
INSERT INTO LC2RotatingTorproxy (first_name,name, description,url) select name,name, menu,url  from LC2RotatingTorproxytemp;
select '<p>LC2RotatingTorproxy count:';
select count(*) from LC2RotatingTorproxy;
select '</p>';
-- select '<p>COUNT:'+count(*)+'</p>' from LC2RotatingTorproxy;
-- select '<p>SQL Menu:</p><br>';
-- select '';
-- select '<hr>';
-- select '<a href="'+url+'">'+name+'</a>' from LC2RotatingTorproxy;
-- select '<hr>';
-- select '<p>LC2RotatingTorproxy count:'+count(*)+' successfully imported.</p>' from LC2RotatingTorproxy;
.exit