import config
import re
def getDefaultRegex(txt):
    return getRegex("^The.*Spain$", txt)
    
def getRegex(regex, txt):
    x = re.search(regex, txt)
    return x