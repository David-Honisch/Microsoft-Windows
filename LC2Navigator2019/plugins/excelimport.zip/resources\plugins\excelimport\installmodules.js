const rlibs = [
    'csv',
    'jszip',
    'sax',
    'xlsx',
    'xlsx-to-json',
    'xlsx-to-json-lc',
    'xml2js',
    'xmlbuilder',
    'xmldom',
    'xml-js',
    'xmljson'
];

function InstallModules() {
    try {
        alert('Install modules');
        // const { npmInstallAsync } = require('../');
        const { npmImportAsync, npmInstallAsync } = require('runtime-npm-install');
        const path = require('path');
        // const tmpDir = path.join(require('os').tmpdir(), 'my-app')
        const tmpDir = path.join(__dirname, '../../../');
        // alert(tmpDir);
        document.getElementById("pout").innerHTML = '<h1>Installing modules to:</h1>' + tmpDir;
        npmInstallAsync(rlibs, tmpDir)
            .then(function() {
                console.log;
                document.getElementById('pout').innerHTML = '<h1>Successfully Installed to:</h1>' + tmpDir;
                document.getElementById('pout').innerHTML += '<h2>Done. Close window now and start main plugin.</h2>';
            });
        printDir(path.join(tmpDir, 'node_modules'));
    } catch (error) {
        alert(error);
    }
}

function AddModules() {
    try {
        alert('Install modules');
        // const { npmInstallAsync } = require('../');
        const { npmImportAsync, npmInstallAsync } = require('runtime-npm-install');
        const path = require('path');
        // const tmpDir = path.join(require('os').tmpdir(), 'my-app')
        // const tmpDir = path.join(__dirname, '');
        npmInstallAsync([
                'csv',
                'jszip',
                'sax',
                'xlsx-to-json',
                'xlsx-to-json-lc',
                'xml2js',
                'xmlbuilder',
                'xmldom',
                'xml-js',
                'xmljson'
            ])
            .then(console.log)
    } catch (error) {
        alert(error);
    }
}

function printDir(dir_path) {
    const path = require('path');
    const fs = require('fs');
    fs.readdir(dir_path, function(err, files) {
        //handling error
        if (err) {
            return console.log('Unable to find or open the directory: ' + err);
        }
        //Print the array of images at one go
        console.log(files);
        //listing all files using forEach
        files.forEach(function(file) {
            var isValid = false;
            console.log(file);
            document.getElementById("pout").innerHTML += file + "<br>";
            for (v in rlibs) {
                if (file.includes(v)) {
                    isValid = true;
                }
            }
            if (isValid) {
                document.getElementById("pout").innerHTML += file + " <strong>found</strong>.<br>";
            }
        });
    });
}
InstallModules();



// function InstallModules2() {
//     try {
//         alert('Install modules');
//         const { npmImportAsync } = require('runtime-npm-install');
//         (async() => {
//             const [treis, installMod, R] = await npmImportAsync([
//                 'csv',
//                 'jszip',
//                 'sax',
//                 'xlsx-to-json',
//                 'xlsx-to-json-lc',
//                 'xml2js',
//                 'xmlbuilder',
//                 'xmldom',
//                 'xml-js',
//                 'xmljson'
//             ])

//             R.add(1, installMod.add(5, 1)) // 7
//         })();
//     } catch (error) {
//         alert(error);
//     }
// }