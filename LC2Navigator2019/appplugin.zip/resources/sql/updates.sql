SELECT '<h1>SQL SCRIPT IS RUNNING</h1>';
SELECT '<h5>Deleting import script</h5>';
--DELETE FROM importscripts;
SELECT '<h5>INSERT import script</h5>';
SELECT '<h4>SET CLEAR</h4>';
-- INSERT OR REPLACE INTO importscripts (first_name,name,url) 
-- values 
-- ('Clear','Clear','echo .');
SELECT '<h4>INSERT MENU</h4>';
INSERT OR REPLACE INTO importscripts (first_name,name,url) 
values 
('Menu v.0.01a','.\\menu.bat','.\\menu.bat');
SELECT '<h4>INSERT UPDATES</h4>';
INSERT OR REPLACE INTO importscripts (first_name,name,url) 
values 
('Core Update v.0.01a','Core Update v.0.01a','.\\resources\\cmd\\updates.bat');
INSERT INTO importscripts (first_name,name,url) 
VALUES('Config v.0.0.1a','Config v.0.0.1a','exec.bat .\\resources\\cmd\\showconfig.bat');
-- SELECT '<h4>FireFox Import profile backup application</h4>';
-- DELETE FROM application;
-- SELECT '<h5>INSERT import script</h5>';
-- INSERT OR REPLACE INTO application (first_name,name,url) 
-- values 
-- ('backupprofile.bat','backupprofile.bat','backupprofile.bat');
-- INSERT OR REPLACE INTO application (first_name,name,url) 
-- values 
-- ('.\resources\cmd\updates.bat','.\resources\cmd\updates.bat','.\\resources\\cmd\\updates.bat');
-- SELECT '<h4>Importing plugins</h4>';
-- SELECT '<h5>INSERT PLUGINS</h5>';
-- INSERT OR REPLACE INTO importscripts (first_name,name,url) 
-- values 
-- ('Core v.0.001 Plugin Downloader','Core v.0.001 Plugin Downloader','.\\resources\\cmd\\getupdates.bat /plugins/core.zip core.zip');

-- INSERT OR REPLACE INTO importscripts (first_name,name,url) 
-- values 
-- ('Grab Url v.0.001 Plugin Downloader','Grab Url v.0.001 Plugin Downloader','.\\resources\\cmd\\getupdates.bat /plugins/graburls.zip graburls.zip');
-- INSERT OR REPLACE INTO importscripts (first_name,name,url) 
-- values 
-- ('Atari JS Emulator Plugin Downloader','Atari JS Emulator Plugin Downloader','.\\resources\\cmd\\getupdates.bat /plugins/atariemulator.zip atariemulator.zip');
--.separator "\t"
--.import .\\plugins.csv importscripts
--SELECT first_name, COUNT(*) c FROM importscripts GROUP BY first_name HAVING c > 1;
SELECT '<h4>DROP plugins</h4>';
DROP TABLE plugins
SELECT '<h4>CREATE plugins</h4>';
CREATE TABLE "plugins" (
	 "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
	 "name" TEXT(255,0) NOT NULL,
	 "first_name" TEXT(255,0) NULL,	 
	 "description" TEXT(255,0) NULL,
	 "zipcode" TEXT(255,0) NULL,
	 "city" TEXT(255,0) NULL,
	 "street" TEXT(255,0) NULL,
	 "url" TEXT(255,0) NULL
);
SELECT '<h4>IMPORTING plugins</h4>';
delete from plugins;
INSERT INTO plugins VALUES('Core Updates v.0.001','Core Updates v.0.001',NULL,NULL,NULL,NULL,'.\\resources\\cmd\\updates.bat');
INSERT INTO plugins VALUES('Core Plugin Downloader v.0.001','Core v.0.001 Plugin Downloader',NULL,NULL,NULL,NULL,'.\\resources\\cmd\\getupdates.bat /plugins/core.zip core.zip');
INSERT INTO plugins VALUES('Grab Url Plugin Downloader v.0.001','Grab Url v.0.001 Plugin Downloader',NULL,NULL,NULL,NULL,'.\\resources\\cmd\\getupdates.bat /plugins/graburls.zip graburls.zip');
INSERT INTO plugins VALUES('GrabAndImportUrls Plugin Downloader v.0.001','GrabAndImportUrls',NULL,NULL,NULL,NULL,'.\\resources\\cmd\\getupdates.bat /plugins/grabandimporturls.zip grabandimporturls.zip');
INSERT INTO plugins VALUES('Excel Import/Export Plugin Downloader v.0.001','ExcelExportImport',NULL,NULL,NULL,NULL,'.\\resources\\cmd\\getupdates.bat /plugins/excelimport.zip excelimport.zip');
INSERT INTO plugins VALUES('Python Plugin Downloader v.0.001','Python',NULL,NULL,NULL,NULL,'.\\resources\\cmd\\getupdates.bat /plugins/python.zip python.zip');
INSERT INTO plugins VALUES('Emulator Plugin Downloader v.0.001 Ultra Alpha','Atari JS Emulator Plugin Downloader',NULL,NULL,NULL,NULL,'.\\resources\\cmd\\getupdates.bat /plugins/atariemulator.zip atariemulator.zip');

SELECT '<h5>INSERT PLUGINS DONE v.0.001</h5>';
SELECT '<h4>'||(SELECT COUNT(*) FROM plugins)||' plugin added...</h4>';
SELECT '<h1>UPDATE SQL SCRIPT DONE</h1>';