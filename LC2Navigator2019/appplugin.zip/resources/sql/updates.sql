SELECT '<h1>SQL SCRIPT IS RUNNING</h1>';
SELECT '<h5>Deleting import script</h5>';
DELETE FROM importscripts;
SELECT '<h5>INSERT import script</h5>';
SELECT '<h4>SET CLEAR</h4>';
INSERT OR REPLACE INTO importscripts (first_name,name,url) 
values 
('Clear','Clear','echo .');
SELECT '<h4>INSERT MENU</h4>';
INSERT OR REPLACE INTO importscripts (first_name,name,url) 
values 
('.\\menu.bat','.\\menu.bat','.\\menu.bat');
SELECT '<h4>INSERT UPDATES</h4>';
INSERT OR REPLACE INTO importscripts (first_name,name,url) 
values 
('Core Update','Core Update','.\\resources\\cmd\\updates.bat');

SELECT '<h4>DELETING application</h4>';
DELETE FROM application;
SELECT '<h5>INSERT import script</h5>';
INSERT OR REPLACE INTO application (first_name,name,url) 
values 
('backupprofile.bat','backupprofile.bat','backupprofile.bat');
INSERT OR REPLACE INTO application (first_name,name,url) 
values 
('.\resources\cmd\updates.bat','.\resources\cmd\updates.bat','.\\resources\\cmd\\updates.bat');
INSERT OR REPLACE INTO application (first_name,name,url) 
values 
('.\resources\cmd\updates.bat','.\resources\cmd\updates.bat','.\\resources\\cmd\\updates.bat');
--.separator "\t"
--.import .\\plugins.csv importscripts
--SELECT first_name, COUNT(*) c FROM importscripts GROUP BY first_name HAVING c > 1;

SELECT '<h1>UPDATE SQL SCRIPT DONE</h1>';