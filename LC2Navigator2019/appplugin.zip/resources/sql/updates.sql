SELECT '<h1>SQL SCRIPT IS RUNNING</h1>';
SELECT '<h5>Deleting import script</h5>';
--DELETE FROM importscripts;
SELECT '<h5>INSERT import script</h5>';
SELECT '<h4>SET CLEAR</h4>';
-- INSERT OR REPLACE INTO importscripts (first_name,name,url) 
-- values 
-- ('Clear','Clear','echo .');
SELECT '<h4>INSERT MENU</h4>';
INSERT OR REPLACE INTO importscripts (first_name,name,url) 
values 
('Menu v.0.01a','.\\menu.bat','.\\menu.bat');
SELECT '<h4>INSERT UPDATES</h4>';
INSERT OR REPLACE INTO importscripts (first_name,name,url) 
values 
('Core Update v.0.01a','Core Update v.0.01a','.\\resources\\cmd\\updates.bat');
-- SELECT '<h4>FireFox Import profile backup application</h4>';
-- DELETE FROM application;
-- SELECT '<h5>INSERT import script</h5>';
-- INSERT OR REPLACE INTO application (first_name,name,url) 
-- values 
-- ('backupprofile.bat','backupprofile.bat','backupprofile.bat');
-- INSERT OR REPLACE INTO application (first_name,name,url) 
-- values 
-- ('.\resources\cmd\updates.bat','.\resources\cmd\updates.bat','.\\resources\\cmd\\updates.bat');
-- SELECT '<h4>Importing plugins</h4>';
-- SELECT '<h5>INSERT PLUGINS</h5>';
-- INSERT OR REPLACE INTO importscripts (first_name,name,url) 
-- values 
-- ('Core v.0.001 Plugin Downloader','Core v.0.001 Plugin Downloader','.\\resources\\cmd\\getupdates.bat /plugins/core.zip core.zip');

-- INSERT OR REPLACE INTO importscripts (first_name,name,url) 
-- values 
-- ('Grab Url v.0.001 Plugin Downloader','Grab Url v.0.001 Plugin Downloader','.\\resources\\cmd\\getupdates.bat /plugins/graburls.zip graburls.zip');
-- INSERT OR REPLACE INTO importscripts (first_name,name,url) 
-- values 
-- ('Atari JS Emulator Plugin Downloader','Atari JS Emulator Plugin Downloader','.\\resources\\cmd\\getupdates.bat /plugins/atariemulator.zip atariemulator.zip');
--.separator "\t"
--.import .\\plugins.csv importscripts
--SELECT first_name, COUNT(*) c FROM importscripts GROUP BY first_name HAVING c > 1;
SELECT '<h4>DROP plugins</h4>';
DROP TABLE "plugins"
SELECT '<h4>CREATE plugins</h4>';
CREATE TABLE "plugins" (
	 "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
	 "name" TEXT(255,0) NOT NULL,
	 "first_name" TEXT(255,0) NULL,	 
	 "description" TEXT(255,0) NULL,
	 "zipcode" TEXT(255,0) NULL,
	 "city" TEXT(255,0) NULL,
	 "street" TEXT(255,0) NULL,
	 "url" TEXT(255,0) NULL
);
SELECT '<h4>IMPORTING plugins</h4>';
-- INSERT INTO plugins VALUES(1,'import.bat','import.bat','import.bat','','','','import.bat');
-- INSERT INTO plugins VALUES(2,'_Clear','echo.','echo.','','','','echo.');
-- INSERT INTO plugins VALUES(3,'Import.Games.v.1.0111a','Import.Games.v.1.0111a','Import.Games.v.1.0111a','','','','exec .\\resources\\cmd\\import.from.csv.to.sqlite.bat games.csv appgames');
-- INSERT INTO plugins VALUES(4,'Filme.CSV.Import.v.1.01a','Filme.CSV.Import.v.1.01a','Filme.CSV.Import.v.1.01a','','','','exec .\\resources\\cmd\\import.from.csv.to.sqlite.bat x.csv Filme');
-- INSERT INTO plugins VALUES(5,'Clear','Clear','','','','','echo .');
-- INSERT INTO plugins VALUES(6,'.\\menu.bat','Menu',NULL,NULL,NULL,NULL,'.\\menu.bat');
INSERT INTO plugins VALUES(1,'Core Updates v.0.001','Core Updates v.0.001',NULL,NULL,NULL,NULL,'.\\resources\\cmd\\updates.bat');
INSERT INTO plugins VALUES(2,'Core Plugin Downloader v.0.001','Core v.0.001 Plugin Downloader',NULL,NULL,NULL,NULL,'.\\resources\\cmd\\getupdates.bat /plugins/core.zip core.zip');
INSERT INTO plugins VALUES(3,'Grab Url Plugin Downloader v.0.001','Grab Url v.0.001 Plugin Downloader',NULL,NULL,NULL,NULL,'.\\resources\\cmd\\getupdates.bat /plugins/graburls.zip graburls.zip');
INSERT INTO plugins VALUES(4,'Emulator Plugin Downloader v.0.001','Atari JS Emulator Plugin Downloader',NULL,NULL,NULL,NULL,'.\\resources\\cmd\\getupdates.bat /plugins/atariemulator.zip atariemulator.zip');
-- INSERT INTO plugins VALUES(10,'Atari JS Emulator Plugin Downloader','Atari JS Emulator Plugin Downloader',NULL,NULL,NULL,NULL,'.\\resources\\cmd\\getupdates.bat /plugins/atariemulator.zip atariemulator.zip');
-- INSERT INTO plugins VALUES(11,'movies','movies','movies','','','','exec .\\resources\\cmd\\import.from.csv.to.sqlite.bat x.csv movies');
-- INSERT INTO plugins VALUES(12,'Clear','Clear',NULL,NULL,NULL,NULL,'echo .');
-- INSERT INTO plugins VALUES(13,'.\\menu.bat','Menu',NULL,NULL,NULL,NULL,'.\\menu.bat');
-- INSERT INTO plugins VALUES(14,'Core Update','Core Update',NULL,NULL,NULL,NULL,'.\\resources\\cmd\\updates.bat');
-- INSERT INTO plugins VALUES(15,'Core v.0.001 Plugin Downloader','Core v.0.001 Plugin Downloader',NULL,NULL,NULL,NULL,'.\\resources\\cmd\\getupdates.bat /plugins/core.zip core.zip');
-- INSERT INTO plugins VALUES(16,'Grab Url v.0.001 Plugin Downloader','Grab Url v.0.001 Plugin Downloader',NULL,NULL,NULL,NULL,'.\\resources\\cmd\\getupdates.bat /plugins/graburls.zip graburls.zip');
-- INSERT INTO plugins VALUES(17,'Atari JS Emulator Plugin Downloader','Atari JS Emulator Plugin Downloader',NULL,NULL,NULL,NULL,'.\\resources\\cmd\\getupdates.bat /plugins/atariemulator.zip atariemulator.zip');

SELECT '<h5>INSERT PLUGINS DONE v.0.001</h5>';
SELECT '<h4>1 plugin added...</h4>';
SELECT '<h1>UPDATE SQL SCRIPT DONE</h1>';