SELECT '<h4>INSERT SQLITE INTO importscripts</h4>';
INSERT OR REPLACE INTO importscripts (first_name,name,url) 
values 
('.\resources\cmd\updates.bat','.\resources\app\app\sqlite\SQLite3.exe','.\\resources\\cmd\app\sqlite\SQLite3.exe');
SELECT '<h1>DONE</h1>';
--.separator "\t"
--.import .\\plugins.csv importscripts
--SELECT first_name, COUNT(*) c FROM importscripts GROUP BY first_name HAVING c > 1;

