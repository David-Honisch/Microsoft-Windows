alert('Done');

<input id="btnClear" type="button" value="Import SQLITE CLI and get Updates and Plugins" onclick="new HttpRequest().execCMD('call exec.bat .\\resources\\cmd\\updates.bat', 'cnt')"></input>