.separator "\t"
.import .\\plugins.csv importscripts
--.import ..\\import\\materialnohead.csv url
--INSERT INTO person VALUES (4, 'Alice', '351246233');
--DELETE FROM general where url.name = '';
.exit