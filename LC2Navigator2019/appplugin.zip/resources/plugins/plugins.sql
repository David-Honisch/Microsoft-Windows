SELECT '<h1>DELETING</h1>'
--delete from importscripts where person_id > 3
SELECT '<h1>PLUGINS IMPORT SCRIPT IS RUNNING</h1>'
SELECT '<h1>INSERTING APPLICATION</h1>'
INSERT INTO application (first_name,name,url) values 
('importapplications.bat','importapplications.bat','importapplications.bat');"
SELECT '<h1>PLUGINS IMPORTING SCRIPTS RUNNING</h1>'
INSERT INTO importscripts (first_name,name,url) values 
('importapplications.bat','importapplications.bat','importapplications.bat');"
SELECT '<h1>IMPORT PLUGINS</h1>'
--.separator "\t"
--.import ..\\plugins.csv importscripts
SELECT '<h1>PLUGINS IMPORT SCRIPT IS RUNNING</h1>'

--.import ..\\import\\materialnohead.csv url
--INSERT INTO person VALUES (4, 'Alice', '351246233');
--DELETE FROM general where url.name = '';
SELECT '<h1>PLUGINS IMPORT SCRIPT DONE</h1>'
.exit