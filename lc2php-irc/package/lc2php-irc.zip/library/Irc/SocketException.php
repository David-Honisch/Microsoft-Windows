<?php

namespace Irc;

class SocketException extends Exception {}