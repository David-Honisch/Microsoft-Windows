<?php

namespace Irc;

class Bot extends Client {

    //@TODO: Need a really great, easy and light-weight plugin system here!
}