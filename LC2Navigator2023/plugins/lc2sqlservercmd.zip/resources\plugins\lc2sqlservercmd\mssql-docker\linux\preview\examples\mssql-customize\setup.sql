/*

Enter custom T-SQL here that would run after SQL Server has started up. 

*/

CREATE DATABASE HelloWorld;
GO
