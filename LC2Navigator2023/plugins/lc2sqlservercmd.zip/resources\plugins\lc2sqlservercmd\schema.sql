-- select '<h2>Import processes</h2>';
drop table IF EXISTS lc2sqlservercmd;
drop table IF EXISTS lc2sqlservercmd_data;
drop table IF EXISTS lc2sqlservercmd_work;
drop table IF EXISTS lc2sqlservercmdtemp;
drop table IF EXISTS lc2sqlservercmd_datatemp;
CREATE TABLE lc2sqlservercmd( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE lc2sqlservercmd_data( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "last_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE lc2sqlservercmd_work( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "last_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE IF NOT EXISTS lc2sqlservercmdtemp (
"name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL
);
-- create table IF NOT EXISTS lc2sqlservercmd_datatemp ( name varchar(255));
CREATE TABLE IF NOT EXISTS lc2sqlservercmd_datatemp ("name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE IF NOT EXISTS lc2sqlservercmd_worktemp ("name" TEXT NOT NULL, "first_name" TEXT NULL, "last_name" TEXT NULL,"description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
-- import menu
-- select '<p>Import processes</p>';
.separator ";"
.import .\\resources\\plugins\\lc2sqlservercmd\\import\\import.csv lc2sqlservercmdtemp
-- insert menu data
INSERT INTO lc2sqlservercmd(first_name,name,zipcode, city, description) select first_name,name,zipcode, city, description  from lc2sqlservercmdtemp;
-- eof insert work data
select 'lc2sqlservercmd count:';
select count(*) from lc2sqlservercmd;
-- insert menu additional data
.separator ';'
.import '.\\resources\\plugins\\lc2sqlservercmd\\import\\menu.csv' lc2sqlservercmd_datatemp
INSERT INTO lc2sqlservercmd_data(first_name,name,zipcode, city, description) select first_name,name,zipcode, city, description  from lc2sqlservercmd_datatemp;
-- insert work data
.separator ','
.import '.\\resources\\plugins\\lc2sqlservercmd\\import\\lc2sqlservercmdwork.csv' lc2sqlservercmd_worktemp
INSERT INTO lc2sqlservercmd_work(first_name,last_name,name,zipcode, city, description) select first_name,last_name,name,zipcode, city, description  from lc2sqlservercmd_worktemp;
select 'lc2sqlservercmd count:';
select count(*) from lc2sqlservercmd;
select '<p>lc2sqlservercmd_work count:';
select count(*) from lc2sqlservercmd_work;
select 'lc2sqlservercmd_data count:';
select count(*) from lc2sqlservercmd_data;
drop table IF EXISTS lc2sqlservercmdtemp;
drop table IF EXISTS lc2sqlservercmd_worktemp;
-- select '<p>Import done</p>';
.exit