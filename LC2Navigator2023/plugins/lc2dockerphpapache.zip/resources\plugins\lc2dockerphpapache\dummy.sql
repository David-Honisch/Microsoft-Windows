select 'RUNNING';
create database dbtest;
create database upload;
create database uploads;