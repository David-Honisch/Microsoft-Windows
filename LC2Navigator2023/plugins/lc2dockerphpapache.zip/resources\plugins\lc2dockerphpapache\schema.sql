-- select '<h2>Import processes</h2>';
drop table IF EXISTS lc2dockerphpapache;
drop table IF EXISTS lc2dockerphpapache_Data;
drop table IF EXISTS lc2dockerphpapache_data;
drop table IF EXISTS lc2dockerphpapachetemp;
drop table IF EXISTS lc2dockerphpapache_datatemp;
CREATE TABLE lc2dockerphpapache( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE lc2dockerphpapache_data( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE IF NOT EXISTS lc2dockerphpapachetemp (
"name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL
);
-- create table IF NOT EXISTS lc2dockerphpapache_datatemp ( name varchar(255));
CREATE TABLE IF NOT EXISTS lc2dockerphpapache_datatemp (
"name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL
);
-- import menu
-- select '<p>Import processes</p>';
.separator ";"
.import .\\resources\\plugins\\lc2dockerphpapache\\import\\import.csv lc2dockerphpapachetemp
-- INSERT INTO lc2dockerphpapache(first_name,name,zipcode, city, description) select name,name, pid,ftype,tpid  from lc2dockerphpapachetemp;
-- insert work data
INSERT INTO lc2dockerphpapache(first_name,name,zipcode, city, description) select first_name,name,zipcode, city, description  from lc2dockerphpapachetemp;
-- eof insert work data
select 'lc2dockerphpapache count:';
select count(*) from lc2dockerphpapache;
-- select '<p>Import working data processes</p>';
-- .separator ";"
--.import .\\resources\\plugins\\lc2dockerphpapache\\import\\lc2dockerphpapachework.csv lc2dockerphpapachetemp
-- .import .\\resources\\plugins\\lc2dockerphpapache\\import\\lc2dockerphpapachework.csv lc2dockerphpapachetemp
-- .import .\\resources\\plugins\\lc2dockerphpapache\\blz-aktuell-txt-data.txt  lc2dockerphpapachetemp
-- select 'COUNT:'+count(*) from lc2dockerphpapachetemp;
-- INSERT INTO lc2dockerphpapache_data(first_name,name,zipcode, city, description) select first_name,name,zipcode, city, description  from lc2dockerphpapachetemp;
.separator ';'
.import '.\\resources\\plugins\\lc2dockerphpapache\\import\\menu.csv' lc2dockerphpapache_datatemp
-- select '<h6>Main menu importing done</h6>'; 
-- select '<p>lc2dockerphpapache_datatemp count:';
-- select count(*)  from lc2dockerphpapache_datatemp;
-- select '</p>';
-- INSERT INTO lc2dockerphpapache_Data (first_name,name, description,url) select name,name, menu,url  from lc2dockerphpapache_Datatemp;
-- INSERT INTO lc2dockerphpapache_data (first_name,name,zipcode, city, description,url) select substr( name, 0, 9 ),rtrim(substr( name, 10, 58 )), substr(name,68,71), substr(name,73,78), name,trim(substr( name, 140, 169))  from lc2dockerphpapache_datatemp;
INSERT INTO lc2dockerphpapache_data(first_name,name,zipcode, city, description) select first_name,name,zipcode, city, description  from lc2dockerphpapache_datatemp;
select '<p>lc2dockerphpapache count:';
select count(*) from lc2dockerphpapache;
select 'lc2dockerphpapache_data count:';
select count(*) from lc2dockerphpapache_data;
drop table IF EXISTS lc2dockerphpapachetemp;
-- select '<p>Import done</p>';
.exit