// David Honisch
// Feb 16, 2023
// illustrate how to call external function defined in a DLL

use dll_syringe::{Syringe, process::OwnedProcess};

#![allow(non_snake_case)]

#[link(name = "DllExample", kind = "static")]
extern {
    fn fooBar(arg: i64) -> i64;
}

fn main() {
    println!("LC2RustInject");
	
	
	println!("About to call function in DLL...");
    unsafe {
        println!("fooBar value = {0}", fooBar(5));
    };
}

fn dllInject() {
    println!("LC2RustInject");
	let target_process = OwnedProcess::find_first_by_name("LC2Search").unwrap();
    // create a new syringe for the target process
    let syringe = Syringe::for_process(target_process);

    // inject the payload into the target process
    let injected_payload = syringe.inject("injection_payload.dll").unwrap();

    // do something else

    // eject the payload from the target (optional)
    syringe.eject(injected_payload).unwrap();
}

