mod lib;
use crate::lib::*;

fn main() {
	lib_printTitle();
    lib_printInfo();
}