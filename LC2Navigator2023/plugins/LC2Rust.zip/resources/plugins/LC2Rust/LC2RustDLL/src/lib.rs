#[no_mangle]
pub extern fn lib_printTitle() {
    println!("Welcome to LetzteChance.Org!");
}
pub extern fn lib_printInfo() {
    println!("Info by lib.dll");
}