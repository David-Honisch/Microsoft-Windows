// Rangarajan Krishnamoorthy
// May 3, 2022
// Define a function that will be called from Rust
 
#include "pch.h"

// This is the function we will export from the DLL for use in Rust
extern "C" __declspec(dllexport) int fooBar(int arg)
{
    return arg * 2;
}



