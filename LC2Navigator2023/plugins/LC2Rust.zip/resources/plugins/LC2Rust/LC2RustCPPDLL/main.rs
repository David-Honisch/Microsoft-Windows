// Rangarajan Krishnamoorthy
// May 3, 2022
// Example to illustrate how to call external function defined in a DLL

#![allow(non_snake_case)]

#[link(name = "DllExample", kind = "static")]
extern {
    fn fooBar(arg: i64) -> i64;
}

fn main() {
    println!("About to call function in DLL...");
    unsafe {
        println!("fooBar value = {0}", fooBar(5));
    };
}

