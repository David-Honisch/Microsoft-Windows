// Rangarajan Krishnamoorthy, March 21, 2023
// C++ Program to access the Vlang DLL
//

#include <windows.h>
#include <iostream>

using namespace std;

template<typename T>
using FNPTR = T(*) (T);

template<typename T>
FNPTR<T> loadFunctionFromDll(HINSTANCE hDll, string func_name)
{
	using FPTR = FNPTR<T>;
	FPTR fptr = (FPTR)GetProcAddress(hDll, func_name.c_str());
	if (!fptr) {
		cout << "Error locating the function: " << func_name << endl;
		return nullptr;
	}

	return fptr;
}


int main()
{
	auto hDll = LoadLibrary(L"dllfns.dll");
	if (!hDll) {
		cout << "Error loading DLL" << endl;
		return -1;
	}

	auto pfn_fib = loadFunctionFromDll<int>(hDll, "fibonacci");
	auto pfn_lucas = loadFunctionFromDll<int>(hDll, "lucas");

	if(pfn_fib && pfn_lucas)
		cout << "Result: " << pfn_fib(10) + pfn_lucas(11) << endl;

	return 0;
}

