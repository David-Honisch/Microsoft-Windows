var hostName = "http://localhost:5000";
var pluginName = "LC2Rust";
const installDirectories = [
    'resources\\plugins\\lcwebclient_final',
    'resources\\plugins\\lcwebclient_final\\lcwebclient_final_lib',
    'resources\\plugins\\org.letztechance.domain.web.GrabUrls',
    'resources\\plugins\\org.letztechance.domain.web.GrabUrls\\org.letztechance.domain.web.GrabUrls_lib',

];
const rlibs = [
    'jquery',
    'https',
    'stream',
    'line-reader',
    'fs',
    'request',
    'runtime-npm-install',
    'decompress-zip',
    // 'extract-zip',
    'csv',
    'jszip',
    'sax',
    'xlsx',
    'xlsx-to-json',
    'xlsx-to-json-lc',
    'xml2js',
    'xmlbuilder',
    'xmldom',
    'xml-js',
    'xmljson'
];

var downloadUrls = [{
        path: "https://www.letztechance.org/LC2Intro.v.4.0/assets/",
        file: "lclogo.png",
    },
    {
        path: "https://static.rust-lang.org/rustup/dist/x86_64-pc-windows-msvc/",
        file: "rustup-init.exe",
    }
    

];