mod lib;
use crate::lib::*;

fn main() {
    lib_test();
}