#[no_mangle]
pub extern fn lib_welcome() {
    println!("Welcome to LETZTECHANCE.ORG");
}
pub extern fn lib_test() {
    println!("Welcome to LETZTECHANCE.ORG from the dll library!");
}