-- select '<h2>Import processes</h2>';
drop table IF EXISTS LC2Rust;
drop table IF EXISTS LC2Rust_data;
drop table IF EXISTS LC2Rusttemp;
CREATE TABLE LC2Rust( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE LC2Rust_data( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE IF NOT EXISTS LC2Rusttemp (
"name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL
);
-- import menu
-- select '<p>Import processes</p>';
.separator ";"
.import .\\resources\\plugins\\LC2Rust\\import\\import.csv LC2Rust
-- INSERT INTO LC2Rust(first_name,name,zipcode, city, description) select name,name, pid,ftype,tpid  from LC2Rusttemp;
-- insert work data
INSERT INTO LC2Rust(first_name,name,zipcode, city, description) select first_name,name,zipcode, city, description  from LC2Rusttemp;
-- eof insert work data
select 'LC2Rust count:';
select count(*) from LC2Rust;
-- select '<p>Import working data processes</p>';
.separator ";"
--.import .\\resources\\plugins\\LC2Rust\\import\\LC2Rustwork.csv LC2Rusttemp
.import .\\resources\\plugins\\LC2Rust\\import\\LC2Rustwork.csv LC2Rusttemp
-- select 'COUNT:'+count(*) from LC2Rusttemp;
INSERT INTO LC2Rust_data(first_name,name,zipcode, city, description) select first_name,name,zipcode, city, description  from LC2Rusttemp;
select 'LC2Rust_data count:';
select count(*) from LC2Rust_data;
drop table IF EXISTS LC2Rusttemp;
-- select '<p>Import done</p>';
.exit