-- select '<h2>Import processes</h2>';
drop table IF EXISTS LC2Rust;
drop table IF EXISTS LC2Rust_data;
drop table IF EXISTS LC2Rusttemp;
drop table IF EXISTS LC2Rust_datatemp;
CREATE TABLE LC2Rust( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE LC2Rust_data( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
-- CREATE TABLE IF NOT EXISTS LC2Rusttemp ("name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
-- create table IF NOT EXISTS LC2Rust_datatemp ( name varchar(255));
-- import menu
-- select '<p>Import processes</p>';
select '<span>Import main menu data</span>';
.separator ";"
.import .\\resources\\plugins\\LC2Rust\\import\\import.csv LC2Rust
select '<span>Import sub menu data</span>';
.import '.\\resources\\plugins\\LC2Rust\\import\\menu.csv' LC2Rust_data
-- INSERT INTO LC2Rust(first_name,name,zipcode, city, description) select name,name, pid,ftype,tpid  from LC2Rusttemp;
-- INSERT INTO LC2Rust(first_name,name,zipcode, city, description) select first_name,name,zipcode, city, description  from LC2Rusttemp;
-- INSERT INTO LC2Rust_data (first_name,name,zipcode, city, description,url) select substr( name, 0, 9 ),rtrim(substr( name, 10, 58 )), substr(name,68,71), substr(name,73,78), name,trim(substr( name, 140, 169))  from LC2Rust_datatemp;
-- eof insert work data
select 'LC2Rust count:';
select count(*) from LC2Rust;



select 'LC2Rust_data count:';
select count(*) from LC2Rust_data;
--------------------------------------------
--------------------------------------------
drop table IF EXISTS LC2Rusttemp;
drop table IF EXISTS LC2Rust_datatemp;
-- INSERT OR REPLACE INTO systables(name, first_name, description, zipcode, city, street, url)VALUES('LC2Rust_data v.1.01a','LC2Rust_data v.1.01a','','','','','execCMD(''exec .\\resources\\plugins\\LC2Rust\\index.bat .\\resources\\plugins\\LC2Rust\\menu.csv'', ''out'');');  
-- select '<p>Import done</p>';
.exit