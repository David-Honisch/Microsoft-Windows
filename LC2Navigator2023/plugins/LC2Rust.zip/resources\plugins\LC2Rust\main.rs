mod lib;
use crate::lib::*;

fn main() {
	lib_welcome();
    lib_test();
}