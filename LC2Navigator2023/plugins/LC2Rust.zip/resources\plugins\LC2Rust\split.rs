// This declaration will look for a file named `my.rs` and will
// insert its contents inside a module named `my` under this scope
mod lcmymod;

fn function() {
    println!("called `function()`");
}

fn main() {
    lcmymod::function();

    function();

    lcmymod::indirect_access();

    lcmymod::nested::function();
}
