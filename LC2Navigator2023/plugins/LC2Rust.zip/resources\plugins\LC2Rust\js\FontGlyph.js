/**
 *
 * @param {string} name
 * @param {number} unicode
 */
export class FontGlyph {
    constructor(name, unicode)
    {
        this.name = name;
        this.unicode = unicode;
    }
}