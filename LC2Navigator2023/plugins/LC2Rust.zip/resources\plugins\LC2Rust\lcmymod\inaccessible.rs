#[allow(dead_code)]
pub fn public_function() {
    println!("called `my::inaccessible::public_function()`");
}