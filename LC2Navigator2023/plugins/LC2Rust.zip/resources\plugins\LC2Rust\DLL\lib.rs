#[no_mangle]
pub extern fn lib_test() {
    println!("Hello from the library!");
}