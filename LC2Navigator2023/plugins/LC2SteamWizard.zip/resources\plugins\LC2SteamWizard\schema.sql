select '<h4>LC2SteamWizard Plugin SQL Import</h4>'; 
drop table IF EXISTS LC2SteamWizard;
drop table IF EXISTS LC2SteamWizardtemp;
CREATE TABLE LC2SteamWizard ( 'person_id' INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, 'created' TIMESTAMP DEFAULT CURRENT_TIMESTAMP NULL, 'modified' TIMESTAMP DEFAULT CURRENT_TIMESTAMP NULL, 'enddate' TIMESTAMP DEFAULT CURRENT_TIMESTAMP NULL, 'name' TEXT NOT NULL, 'first_name' TEXT NULL, 'description' TEXT NULL, 'zipcode' TEXT NULL, 'city' TEXT NULL,	 'street' TEXT NULL,	 'url' TEXT NULL);
create table IF NOT EXISTS LC2SteamWizardtemp ( name varchar(255), menu TEXT, url varchar(255), subtext TEXT);
.separator ';'
.import .\\resources\\plugins\\LC2SteamWizard\\import\\import.csv LC2SteamWizardtemp
INSERT INTO LC2SteamWizard (first_name,name, description,url) select name,name, menu,url  from LC2SteamWizardtemp;
select '<p>LC2SteamWizard count:';
select count(*) from LC2SteamWizard;
select '</p>';
.exit
