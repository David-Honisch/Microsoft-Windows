-- select '<h2>Import processes</h2>';
drop table IF EXISTS LC2SteamWizard;
drop table IF EXISTS LC2SteamWizard_data;
drop table IF EXISTS LC2SteamWizard_procdata;
-- drop table IF EXISTS LC2SteamWizardtemp;
-- drop table IF EXISTS LC2SteamWizard_datatemp;
CREATE TABLE LC2SteamWizard( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE LC2SteamWizard_data( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
-- CREATE TABLE LC2SteamWizard_procdata( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
-- CREATE TABLE IF NOT EXISTS LC2SteamWizardtemp (
-- "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL
-- );
-- create table IF NOT EXISTS LC2SteamWizard_datatemp ( name varchar(255));
-- CREATE TABLE IF NOT EXISTS LC2SteamWizard_datatemp (
-- "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL
-- );
-- import menu
-- select '<p>Import processes</p>';
.separator ";"
.import .\\resources\\plugins\\LC2SteamWizard\\import\\import.csv LC2SteamWizard
.import '.\\resources\\plugins\\LC2SteamWizard\\import\\menu.csv' LC2SteamWizard_data
-- delete from LC2SteamWizard_datatemp;
--
-- .separator ","
-- .import '.\\resources\\plugins\\LC2SteamWizard\\import\\LC2SteamWizardwork.csv' LC2SteamWizard_datatemp
-- INSERT INTO LC2SteamWizard_procdata(first_name,name,zipcode, city, description) select first_name,name,zipcode, city, description  from LC2SteamWizard_datatemp;

select '<p>LC2SteamWizard count:';
select count(*) from LC2SteamWizard;
select 'LC2SteamWizard_data count:';
select count(*) from LC2SteamWizard_data;
select 'LC2SteamWizard_procdata count:';
select count(*) from LC2SteamWizard_procdata;
.separator ";"
drop table IF EXISTS LC2SteamWizardtemp;
-- select '<p>Import done</p>';
.exit