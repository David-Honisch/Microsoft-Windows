// alert('TEST2');
function getArg(arguments, pattern) {
    var argparts = (arguments + "").split(',');
    var i = 0;
    var query = "";
    for (var s in argparts) {
        var v = argparts[s];
        if (v.startsWith(pattern+"=")) {
            query = v.replace(pattern+"=",'');
            break;
        }
        i++;
    }
    return query;
}
function pluginINIT() {
	var remote = window.nodeRequire('electron').remote;
    arguments = remote.getGlobal('sharedObject').prop1;
    console.log(arguments);
    var query = getArg(arguments, "--query");
    console.log(query);
    $("#inputKey").val(query);
    document.getElementById("inputKey").value = query;
    // document.getElementById("app_cnt").innerHTML += arguments;
    // document.getElementById("app_cnt").innerHTML += arguments;
    
    // alert(arguments);
    // alert(arguments["arg1"]);
    // alert(arguments["--query"]);
}
setTimeout(() => {
    pluginINIT();    
}, 3000);
