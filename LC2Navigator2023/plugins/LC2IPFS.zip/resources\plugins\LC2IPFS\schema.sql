select '<h4>LC2IPFS Plugin SQL Import</h4>'; 
drop table IF EXISTS LC2IPFS;
drop table IF EXISTS LC2IPFStemp;
CREATE TABLE LC2IPFS ( 'person_id' INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, 'created' TIMESTAMP DEFAULT CURRENT_TIMESTAMP NULL, 'modified' TIMESTAMP DEFAULT CURRENT_TIMESTAMP NULL, 'enddate' TIMESTAMP DEFAULT CURRENT_TIMESTAMP NULL, 'name' TEXT NOT NULL, 'first_name' TEXT NULL, 'description' TEXT NULL, 'zipcode' TEXT NULL, 'city' TEXT NULL,	 'street' TEXT NULL,	 'url' TEXT NULL);
create table IF NOT EXISTS LC2IPFStemp ( name varchar(255), menu TEXT, url varchar(255), subtext TEXT);
.separator ';'
.import .\\resources\\plugins\\LC2IPFS\\import\\import.csv LC2IPFStemp
INSERT INTO LC2IPFS (first_name,name, description,url) select name,name, menu,url  from LC2IPFStemp;
select '<p>LC2IPFS count:';
select count(*) from LC2IPFS;
select '</p>';
.exit
