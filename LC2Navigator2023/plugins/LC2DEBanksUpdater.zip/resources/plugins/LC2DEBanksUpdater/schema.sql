-- select '<h2>Import processes</h2>';
drop table IF EXISTS LC2DEBanksUpdater;
drop table IF EXISTS LC2DEBanksUpdater_Data;
drop table IF EXISTS LC2DEBanksUpdater_data;
drop table IF EXISTS LC2DEBanksUpdatertemp;
drop table IF EXISTS LC2DEBanksUpdater_datatemp;
CREATE TABLE LC2DEBanksUpdater( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE LC2DEBanksUpdater_data( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE IF NOT EXISTS LC2DEBanksUpdatertemp (
"name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL
);
create table IF NOT EXISTS LC2DEBanksUpdater_datatemp ( name varchar(255));
-- import menu
-- select '<p>Import processes</p>';
.separator ";"
.import .\\resources\\plugins\\LC2DEBanksUpdater\\import\\import.csv LC2DEBanksUpdater
-- INSERT INTO LC2DEBanksUpdater(first_name,name,zipcode, city, description) select name,name, pid,ftype,tpid  from LC2DEBanksUpdatertemp;
-- insert work data
INSERT INTO LC2DEBanksUpdater(first_name,name,zipcode, city, description) select first_name,name,zipcode, city, description  from LC2DEBanksUpdatertemp;
-- eof insert work data
select 'LC2DEBanksUpdater count:';
select count(*) from LC2DEBanksUpdater;
-- select '<p>Import working data processes</p>';
-- .separator ";"
--.import .\\resources\\plugins\\LC2DEBanksUpdater\\import\\LC2DEBanksUpdaterwork.csv LC2DEBanksUpdatertemp
-- .import .\\resources\\plugins\\LC2DEBanksUpdater\\import\\LC2DEBanksUpdaterwork.csv LC2DEBanksUpdatertemp
-- .import .\\resources\\plugins\\LC2DEBanksUpdater\\blz-aktuell-txt-data.txt  LC2DEBanksUpdatertemp
-- select 'COUNT:'+count(*) from LC2DEBanksUpdatertemp;
-- INSERT INTO LC2DEBanksUpdater_data(first_name,name,zipcode, city, description) select first_name,name,zipcode, city, description  from LC2DEBanksUpdatertemp;
.separator ';'
.import '.\\resources\\plugins\\LC2DEBanksUpdater\\blz-aktuell-txt-data.txt' LC2DEBanksUpdater_Datatemp
select '<h6>Main menu importing done</h6>'; 
select '<p>LC2DEBanksUpdater_Datatemp count:';
select count(*)  from LC2DEBanksUpdater_Datatemp;
select '</p>';
-- INSERT INTO LC2DEBanksUpdater_Data (first_name,name, description,url) select name,name, menu,url  from LC2DEBanksUpdater_Datatemp;
INSERT INTO LC2DEBanksUpdater_data (first_name,name,zipcode, city, description,url) select substr( name, 0, 9 ),rtrim(substr( name, 10, 58 )), substr(name,68,71), substr(name,73,78), name,trim(substr( name, 140, 169))  from LC2DEBanksUpdater_datatemp;
select '<p>LC2DEBanksUpdater count:';
select count(*) from LC2DEBanksUpdater;
select 'LC2DEBanksUpdater_data count:';
select count(*) from LC2DEBanksUpdater_data;
drop table IF EXISTS LC2DEBanksUpdatertemp;
INSERT OR REPLACE INTO systables(name, first_name, description, zipcode, city, street, url)VALUES('LC2DEBanksUpdater_data v.1.01a','LC2DEBanksUpdater_data v.1.01a','','','','','execCMD(''exec .\\resources\\plugins\\LC2DEBanksUpdater\\index.bat .\\resources\\plugins\\LC2DEBanksUpdater\\menu.csv'', ''out'');');  
-- select '<p>Import done</p>';
.exit