-- select '<h2>Import processes</h2>';
drop table IF EXISTS LC2Gradle;
drop table IF EXISTS LC2Gradle_data;
drop table IF EXISTS LC2Gradle_work;
drop table IF EXISTS LC2Gradletemp;
drop table IF EXISTS LC2Gradle_datatemp;
CREATE TABLE LC2Gradle( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE LC2Gradle_data( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "last_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE LC2Gradle_work( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "last_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE IF NOT EXISTS LC2Gradletemp (
"name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL
);
-- create table IF NOT EXISTS LC2Gradle_datatemp ( name varchar(255));
CREATE TABLE IF NOT EXISTS LC2Gradle_datatemp ("name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE IF NOT EXISTS LC2Gradle_worktemp ("name" TEXT NOT NULL, "first_name" TEXT NULL, "last_name" TEXT NULL,"description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
-- import menu
-- select '<p>Import processes</p>';
.separator ";"
.import .\\resources\\plugins\\LC2Gradle\\import\\import.csv LC2Gradletemp
-- insert menu data
INSERT INTO LC2Gradle(first_name,name,zipcode, city, description) select first_name,name,zipcode, city, description  from LC2Gradletemp;
-- eof insert work data
select 'LC2Gradle count:';
select count(*) from LC2Gradle;
-- insert menu additional data
.separator ';'
.import '.\\resources\\plugins\\LC2Gradle\\import\\menu.csv' LC2Gradle_datatemp
INSERT INTO LC2Gradle_data(first_name,name,zipcode, city, description) select first_name,name,zipcode, city, description  from LC2Gradle_datatemp;
-- insert work data
.separator ','
.import '.\\resources\\plugins\\LC2Gradle\\import\\LC2Gradlework.csv' LC2Gradle_worktemp
INSERT INTO LC2Gradle_work(first_name,last_name,name,zipcode, city, description) select first_name,last_name,name,zipcode, city, description  from LC2Gradle_worktemp;
select 'LC2Gradle count:';
select count(*) from LC2Gradle;
select '<p>LC2Gradle_work count:';
select count(*) from LC2Gradle_work;
select 'LC2Gradle_data count:';
select count(*) from LC2Gradle_data;
drop table IF EXISTS LC2Gradletemp;
drop table IF EXISTS LC2Gradle_worktemp;
-- select '<p>Import done</p>';
.exit