sap.ui.define([
	"./controller/App.controller"
]);
