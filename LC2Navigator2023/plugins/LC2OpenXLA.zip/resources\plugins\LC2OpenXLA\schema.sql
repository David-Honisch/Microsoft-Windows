select '<h4>LC2OpenXLA Plugin SQL Import</h4>'; 
drop table IF EXISTS LC2OpenXLA;
drop table IF EXISTS LC2OpenXLAtemp;
CREATE TABLE LC2OpenXLA ( 'person_id' INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, 'created' TIMESTAMP DEFAULT CURRENT_TIMESTAMP NULL, 'modified' TIMESTAMP DEFAULT CURRENT_TIMESTAMP NULL, 'enddate' TIMESTAMP DEFAULT CURRENT_TIMESTAMP NULL, 'name' TEXT NOT NULL, 'first_name' TEXT NULL, 'description' TEXT NULL, 'zipcode' TEXT NULL, 'city' TEXT NULL,	 'street' TEXT NULL,	 'url' TEXT NULL);
create table IF NOT EXISTS LC2OpenXLAtemp ( name varchar(255), menu TEXT, url varchar(255), subtext TEXT);
.separator ';'
.import .\\resources\\plugins\\LC2OpenXLA\\import\\import.csv LC2OpenXLAtemp
INSERT INTO LC2OpenXLA (first_name,name, description,url) select name,name, menu,url  from LC2OpenXLAtemp;
select '<p>LC2OpenXLA count:';
select count(*) from LC2OpenXLA;
select '</p>';
.exit
