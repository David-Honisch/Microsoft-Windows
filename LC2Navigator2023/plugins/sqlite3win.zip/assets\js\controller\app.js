var remote = window.nodeRequire('electron').remote;
//arguments = remote.getGlobal('sharedObject').prop1;
//console.log(arguments);
//alert(arguments);
//LC2Navigator 2022
var app = angular.module('app', ['ui.bootstrap']);

// const APPCFG = "application.config.json";
const path = window.nodeRequire('path');
const jQuery = window._PAGE_.jQuery;
const { readFileSync, fs } = window.nodeRequire('fs');
const cfg = window.nodeRequire(path.join(__dirname, 'assets', 'js', 'config.json'));
const model = window.nodeRequire(path.join(__dirname, 'app', 'model.js'));
const cpath = path.join(__dirname);
const dbPath = path.join(__dirname, '..', 'lc.db'); // remote.getGlobal('sharedObj').dbPath; // remote.getGlobal('sharedObj').dbPath;
const gelectron = window.nodeRequire('electron');
const shell = gelectron.shell;
const OPEN_LINK = "https://www.letztechance.org/openlink?";
// -var remote = window.nodeRequire('electron').remote;
// const rootLib = window.nodeRequire('app-root-path');
// const appRoot = path.dirname(('' + rootLib).replace("app.asar", ""));
// console.log('rootLib:' + rootLib);
var dialogProperties = {
    // appendTo: "#dialog",
    show: "puff",
    hide: "explode",
    top: 140,
    resizable: true,
    closeOnEscape: true,
    minWidth: 150,
    minHeight: 150,
    // position: { my: "left top", of: "left top" },
    height: "auto",
    width: "auto"
};

function AppController($scope, $http, $filter) {
    const APPCFG = "application.config.json";
    const path = window.nodeRequire('path');
    // default values for pagination and filtering
    $scope.cfg = [];
    $scope.pageSize = 10;
    $scope.maxSize = 15;
    $scope.start = 0;
    $scope.end = 0;
    $scope.currentPage = 0;
    $scope.numOfPages = 0;
    $scope.filteredItems = [];
    $scope.startItems = [];
    $scope.pagedItems = [];
    $scope.currentTable = $.urlParam('db') !== undefined ? $.urlParam('db') : "systables";
    $scope.data = [];
    $scope.dataplugins = [];
    $scope.query = { name: "" };
    $scope.index = [];
    $scope.news = [];
    $scope.security = [];
    $scope.menu = [];
    $scope.log = [];

    $scope.downloads = [];
    $scope.otherdownloads = [];

    console.log(APPCFG);
    $scope.cfg = getAppConfig(APPCFG);
    $scope.menu = $scope.cfg.topmenu;

    var dlPath = $scope.cfg.api.xmlnews;
    var resDir = path.join(__dirname, '../../');
    console.log("resdir:" + resDir);
    get_DownloadFile(dlPath, "app.xml", resDir + "app.xml", resDir, "out_cnt");
    get_DownloadFile(dlPath, "app.xslt", resDir + "app.xslt", resDir, "out_cnt");
    console.log("Download to resdir:" + resDir + " done.");
    // setTimeout(() => {
    // // getNewsXML(resDir.replace(/\\/g, "//") + "app.xml", resDir.replace(/\\/g, "//") + "app.xslt");

    // }, 5000);
    // console.log('DONE.');

    // get the data
    // $http.get('assets/js/data/mainmenu.json')
    //     .success(function(data) {
    //         $scope.menu = data;
    //     });


    document.title = $scope.cfg.productname;
    var head = getHeader(cfg.local);
    // console.log(JSON.stringify(head));    
    $('#head').html(head);
    $('#ptitle').html(title);

    // alert($scope.cfg.apiexternal[0].url);
    $http.get($scope.cfg.apiexternal[0].url)
        .success(function (data) {
            $scope.index = data.list;
        });

    $http.get($scope.cfg.apiexternal[1].url)
        .success(function (data) {
            $scope.news = data.row;
        });

    $http.get($scope.cfg.apiexternal[2].url)
        .success(function (data) {
            $scope.security = data.row;
        });

    $http.get($scope.cfg.apiexternal[3].url)
        .success(function (data) {
            $scope.downloads = data.row;
        });
    $http.get($scope.cfg.apiexternal[4].url)
        .success(function (data) {
            $scope.otherdownloads = data.row;
        });
    $http.get($scope.cfg.apiexternal[5].url)
        .success(function (data) {
            $scope.log = data;
        });





    // model.initDb('' + webRoot, //app.getPath('userData'),
    //     // Load a DOM stub here. See renderer.js for the fully composed DOM.
    //     //mainWindow.loadURL(`file:${__dirname}/app/html/index.html`)
    //     console.log('Init Database')
    // );
    $scope.data = getSQLQuery('select * from systables order by person_id asc, name asc', dbPath);
    $scope.other = getSQLQuery('select * from other order by person_id asc, name asc', dbPath);
    $scope.dataplugins = getSQLQuery('select * from plugins order by person_id asc, name asc', dbPath);
    $scope.dropdowns = getSQLQuery('select * from dropdowns order by person_id asc, name asc', dbPath);
    var query = remote.getGlobal('sharedObject').query;
    $scope.loadedplugin = getSQLQuery('select * from application where first_name like \'%' + query + '%\' or name like \'%' + query + '%\' order by person_id asc, name asc limit 1', dbPath);
    if ($scope.loadedplugin !== undefined) {
        console.log(JSON.stringify($scope.loadedplugin));
        eval($scope.loadedplugin["0"]["url"]);
    }
    document.getElementById('appplugins').innerHTML += '<input type="button" value="Get Update" onclick="getXML(\'app.xml\', \'app.xslt\',\'out_cnt\');"></input>';
    setTimeout(() => {
        getXML("app.xml", "app.xslt", "out_cnt");
    }, 3000);

    // getXML("app.xml", "app.xslt", "carouselpanel");
    getOpenDialog('#importGUI_cnt', '.\\resources\\html\\start.html', 'Start', { top: 100, minWidth: 250, margin: 0, minHeight: 150, width: 420, height: 480 });
    //getOpenDialog('#alertcnt','.\\resources\\html\\intro.html','Intro',{ top: 100,minWidth: 250, margin:0,  minHeight: 600, width: 640, height:600});    
    loadFile('file:///./resources/plugins/LC2Intro/v.1.3/index.html', { width: 800, height: 600 });
    // loadFileContent('#carouselpanel','./carousel.html');
    setTimeout(() => {
        $('#out_cnt').load('calendar.html');
    }, 4000);
    setTimeout(() => {
        initScheduler();
    }, 5000);


    // when the data is altered, filter the items and set the page
    $scope.$watch('data', function (data, old) {
        $scope.filteredItems = $filter('filter')(data, $scope.query);
        if (old === null) setPage();
    });

    // when the query value changes, refilter the data
    $scope.$watch('query|json', function () {
        $scope.filteredItems = $filter('filter')($scope.data, $scope.query);
    });


    // when the current page is changed by the pagination control, update the list of items
    $scope.$watch('currentPage', function (page) {
        console.log('currentPage');
        setPage();
    });

    // when the filtered items are set, recalculate the number of pages
    $scope.$watch('filteredItems', function (items, old) {
        console.log('filteredItems');
        $scope.currentPage = -1;
        if (items !== undefined && items.length !== undefined)
            $scope.numOfPages = Math.ceil(items.length / $scope.pageSize);
    });

    // when the page start is changed, update the list of paged items
    $scope.$watch('startItems', function (items) {
        console.log('startItems');
        $scope.pagedItems = $filter('limitTo')(items, $scope.pageSize);
        $scope.end = ($scope.currentPage -0) * $scope.pageSize + $scope.pagedItems.length;
    });
    // set the pagination for the filtered items
    function setPage() {
        console.log('setPage');
        $scope.start = ($scope.currentPage - 1) * $scope.pageSize + ($scope.filteredItems === undefined && $scope.filteredItems.length ? 1 : 0);
        $scope.startItems = $filter('startFrom')($scope.filteredItems, $scope.start - 1);
    }
    function getSQLQuery(sql, dbPath) {
        var res = model.GetQuery(dbPath, sql);
        var list = {
            "Data": []
        };
        for (var v in res) {
            var t = {
                "id": res[v]['person_id'],
                "created": res[v]['created'],
                "enddate": res[v]['enddate'],
                "name": res[v]['name'],
                "sname": shortName(res[v]['name']),
                "first_name": res[v]['first_name'],
                "last_name": res[v]['last_name'],
                "city": res[v]['city'],
                "street": res[v]['street'],
                "zipcode": res[v]['zipcode'],
                "description": res[v]['description'],
                "url": res[v]['url'],
            };
            list['Data'].push(t);
        }
        return list.Data;

    }
    function getXML(source, target, id) {
        var outXmlString = "";
        try {
            outXmlString = getXsltFileProcess(source, target);
            document.getElementById(id).innerHTML += outXmlString;
        } catch (e) {
            console.error(e);
            console.error(e.stack);
        }

    }
    function getAppConfig(appConfigFileName) {
        const fs = window.nodeRequire('fs');
        let rawdata = fs.readFileSync(appConfigFileName);
        let appConfig = JSON.parse(rawdata);
        console.log(appConfig);
        return appConfig;
    }
    function initScheduler() {
        // window.addEventListener("DOMContentLoaded", function () {
        console.log('scheduler running...');
        scheduler.plugins({
            recurring: true,
            minical: true
        });

        scheduler.config.multi_day = true;
        scheduler.config.event_duration = 35;
        scheduler.config.occurrence_timestamp_in_utc = true;
        scheduler.config.include_end_by = true;
        scheduler.config.repeat_precise = true;
        scheduler.config.repeat_date = "%d-%m-%Y";

        scheduler.attachEvent("onLightbox", function () {
            var lightbox_form = scheduler.getLightbox(); // this will generate lightbox form
            var inputs = lightbox_form.getElementsByTagName('input');
            var date_of_end = null;
            for (var i = 0; i < inputs.length; i++) {
                if (inputs[i].name == "date_of_end") {
                    date_of_end = inputs[i];                    
                    break;
                }
            }

            var repeat_end_date_format = scheduler.date.date_to_str(scheduler.config.repeat_date);
            var show_minical = function () {
                if (scheduler.isCalendarVisible())
                    scheduler.destroyCalendar();
                else {
                    scheduler.renderCalendar({
                        position: date_of_end,
                        date: scheduler.getState().date,
                        navigation: true,
                        handler: function (date, calendar) {
                            date_of_end.value = repeat_end_date_format(date);
                            getSQLQuery('UPDATE `OTHER` (NAME, FIRST_NAME, URL  ) VALUES ( "Menu v.1.0", "Menu v.1.0","test");', dbPath);
                            scheduler.destroyCalendar();
                        }
                    });
                }
            };
            date_of_end.onclick = show_minical;
            console.log('scheduler done.');
        });

        scheduler.config.lightbox.sections = [
            { name: "description", height: 50, map_to: "text", type: "textarea", focus: true },
            { name: "recurring", type: "recurring", map_to: "rec_type", button: "recurring" },
            { name: "time", height: 72, type: "calendar_time", map_to: "auto" }
        ];
        scheduler.init('lc2scheduler', new Date(), "day");
        // for (var i = 0;i<10;i++){            
        // }
        var result = '{ "data": [';
        result += '{ "id": "10000", "start_date": "2000-01-10 00:00:00", "end_date": "2030-01-16 00:00:00", "text": "Welcome to LC", "details": "LetzteChance.Org Siegburg, DE"},';
        //result += '{ "id": "10001", "start_date": "2023-01-10 07:00:00", "end_date": "2300-01-16 08:00:00", "text": "Welcome to LC", "details": "LetzteChance.Org Siegburg, DE"},';
        result += concatTableToJSON($scope.data,0);
        result += concatTableToJSON($scope.loadedplugin,15);
        result += concatTableToJSON($scope.other,41);
        
        result += '{ "id": "1002", "start_date": "2023-01-10 23:00:00", "end_date": "2300-01-16 23:00:00", "text": "Welcome to LC", "details": "LetzteChance.Org Siegburg, DE"}';
        result += "]  }";
        var eventsFile = "../../assets/js/events.json";
        var eventsOutFile = "./assets/js/events.json";
        var fs = window.nodeRequire('fs');
        fs.writeFileSync(eventsOutFile, result);
        scheduler.load(eventsFile, function () {
            //scheduler.showLightbox(10000);
        });

        // });

    }
    function concatTableToJSON(table, add){
        var result ="";
        for (var s in table) {            
            var ID =  +($scope.data[s]["id"])+add;
            var name = $scope.data[s]["name"];
            var desc = $scope.data[s]["description"];
            var created = (""+$scope.data[s]["created"]).substring(0,13)+":00:00";
            var enddate = (""+$scope.data[s]["enddate"]).substring(0,13)+":30:00";
            //console.log(""+ID+"-"+name + "=" + created + "=" + enddate);
            
            result += '{ "id": "'+ID+'", "start_date": "' + created + '", "end_date": "' + enddate+'", "text": "'+name + '", "details": "'+name+" Descripion:"+desc + '"},';

        }
        return result;

    }



}

// angular directive to change default behavior from processing input change immediately to on blur or enter
app.directive('ngModelBlur', function () {
    return {
        restrict: 'A',
        require: 'ngModel',
        link: function (scope, elm, attr, ngModelCtrl) {
            if (attr.type === 'radio' || attr.type === 'checkbox') { return; }

            elm.unbind('input').unbind('keydown').unbind('change');
            elm.bind('blur keydown', function (e) {
                if (e.type === 'keydown' && e.which !== 13) { return; }

                scope.$apply(function () {
                    ngModelCtrl.$setViewValue(elm.val());
                });
            });
        }
    };
});

// angular filter to take array items starting from provided index
app.filter('startFrom', function () {
    return function (input, start) {
        if (angular.isArray(input)) {
            var st = parseInt(start, 10);
            if (isNaN(st)) st = 0;
            return input.slice(st);
        }
        return input;
    };
});