SELECT '<h1>SQL SQLite3 SCRIPT IS RUNNING</h1>';
SELECT '<h5>Init import script</h5>';
--DELETE FROM importscripts;
SELECT '<h5>INSERT import script</h5>';
SELECT '<h4>SET CLEAR</h4>';
-- INSERT OR REPLACE INTO importscripts (first_name,name,url) 
-- values 
-- ('Clear','Clear','echo .');
SELECT '<h4>INSERT SQLITE3 to applications</h4>';
INSERT OR REPLACE INTO application (first_name,name,url) 
values ('SQLite3','start .\\resources\\app\\sqlite\\SQLite3.exe','start .\\resources\\app\\sqlite\\SQLite3.exe');
-- 
-- INSERT OR REPLACE INTO application(name, first_name, description, zipcode, city, street, url)VALUES('sqlite3win Plugin v.1.12a','sqlite3win Plugin v.1.2b','','','','','execCMD(''exec .\\resources\\plugins\\sqlite3win\\index.bat .\\resources\\plugins\\sqlite3win\\csv\\default.csv'', ''out'');');
INSERT OR REPLACE INTO application(name, first_name, description, zipcode, city, street, url)VALUES('sqlite3win Plugin v.1.2','sqlite3win Plugin v.1.01a','','','','','execPluginCMD(''out'',''sqlite3win'');');  
-- INSERT OR REPLACE INTO plugins VALUES('All Plugins Downloader v.1.1 Final (install requirements)','all.zip all.zip Download',NULL,NULL,NULL,NULL,'exec .\\resources\\cmd\\getupdates.bat /plugins/all.zip all.zip all.zip all.zip');

-- 
SELECT '<h5>INSERT PLUGINS DONE v.0.001</h5>';
SELECT '<h4>'||(SELECT COUNT(*) FROM application)||' plugin added...</h4>';
SELECT '<h1>UPDATE SQL SCRIPT DONE</h1>';