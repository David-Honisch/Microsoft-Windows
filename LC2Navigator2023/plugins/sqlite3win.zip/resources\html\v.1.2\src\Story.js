class Story extends Phaser.Scene {
    constructor() {
        var sceneConfig = {
            type: Phaser.AUTO,
            parent: 'content',
            key: 'Story',
            isAutoRedirected: false,
            pixelArt: true,
            dom: {
                createContainer: true
            },
            input: {
                gamepad: true
            },

            scale: {
                mode: Phaser.Scale.FIT,
                parent: 'content',
                autoCenter: Phaser.Scale.CENTER_BOTH,
                width: 1900,
                height: 1080
            },
            physics: {
                default: 'arcade',
                arcade: {
                    gravity: { y: 0.0 },
                    fps: 60,
                    debug: false
                }
            },
            scene: {
                init: "init",
                preload: "preload",
                create: "create",
                update: "update",
                extend: {
                    checkBulletVsEnemy: "checkBulletVsEnemy",
                    launchEnemy: "launchEnemy",
                    hitShip: "hitShip",
                    hitEnemy: "hitEnemy"
                }
            }
        };
        super(sceneConfig);
    }
    preload() {     
        this.load.htmlTexture('storyHTML', 'assets/html/story.html', 640, 960);
    }
    create() {
        var shader = create_Shader(this, 640, 480,'BufferShader1', 'BufferShader2', 'BufferShader3',fragmentShader4, fragmentShader3, fragmentShader3_1);
        shader.setAlpha(0.9);        
        this.bg = this.add.tileSprite(0, 0, 0, 0, "bg").setOrigin(0).setScale(1).setSize(640, 960).setAlpha(0.9);



        var particles = this.add.particles('flares');
		var emitter = particles.createEmitter(this.cache.json.get('emitter'));
        emitter.setAlpha(0.5);

        var sun = this.add.image(300, 300, 'sun').setScale(0.1);
        LC2.getTween(this, sun,'Quad.easeInOut','Cubic.easeInOut', 10000,3.0,3.0,0, false);
        var raster = createAlphaRasterY(this, 900, getGameHeight(this) - 30, getGameWidth(this), 1, 8, 4500, 1000, false, 0.8);

        var html = this.add.image(3, 400, 'storyHTML').setOrigin(0);
        var h1 = { title: 'LETZTECHANCE', style: 'chrome120', x: 10, y: 100 };
		var h2 = { title: 'Intro', style: 'dreams', x: 70, y: 18 };
		var h3 = { title: 'David Honisch', style: 'chrome36', x: 10, y: 160 };
		var tw = { y: 200, duration: 3000, loop: -1, ease: 'Sine.easeInOut', yoyo: true };
		getDOMTween(this, h1, h2, h3, tw);
        var style = {
            // 'background-color': 'lime',
            'width': '220px',
            'height': '50px',
            'font': '12px Arial',
            'font-weight': 'bold'
        };
        var element = this.add.dom(10, 10, 'div', style, '<h1>Done by David Honisch</h1>');
        

        var fontStory = { font: '48px ' + LC2.text['FONT'], fill: '#ffde00', stroke: '#000', strokeThickness: 7, align: 'center' };
        // var textStory = this.add.text(LC2.world.centerX, 200, LC2.text['screen-story-howto'], fontStory);
        var textStory = this.add.text(LC2.world.centerX, 10, LC2.text['screen-story-howto'], fontStory);
        textStory.setOrigin(0.5, 0);

        var buttonContinue = new Button(LC2.world.width - 20, LC2.world.height - 20, 'button-continue', this.clickContinue, this);
        buttonContinue.setOrigin(1, 1);

        buttonContinue.x = LC2.world.width + buttonContinue.width + 20;
        this.tweens.add({ targets: buttonContinue, x: LC2.world.width - 20, duration: 500, ease: 'Back' });

        this.keyEnter = this.input.keyboard.addKey(Phaser.Input.Keyboard.KeyCodes.ENTER);
        this.keyEnter.on('down', function(key, event) { this.clickContinue(); }, this);

        this.cameras.main.fadeIn(250, 0, 0, 0);
    }
    clickContinue() {
        LC2.Sfx.play('click');
        LC2.fadeOutScene('Game', this);
    }
    update(){
        this.bg.tilePositionY += +1;
    }
};