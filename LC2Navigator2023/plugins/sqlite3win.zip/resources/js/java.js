/*
#! /usr/bin/env node
"use strict"
   This file does not need to be updated, only java-caller-config.json must be !
*/
const { JavaCaller,JavaCallerCli } = window.nodeRequire("java-caller");
const spawn = window.nodeRequire("child_process").spawn;

$("#app_cnt").html("");
function printJavaResult(text) {
  var java = window.nodeRequire('java');
  var javaLangSystem = java.import('java.lang.System');
  javaLangSystem.out.printlnSync(text);
}
function getJavaClass(className,numbers) {
  let result = "";
  let args = [];
  args.push(className); // remove first argument
  // Push the numbers other arguments
  numbers.forEach((element) => {
    args.push(element);
  });

  // Starting our worker
  console.log("Starting work");
  let spawn = getSpawn();
  let worker = spawn("java", args);
  printWorker(worker); 
}

function getSpawn() {
  return window.nodeRequire("child_process").spawn;
}
function printWorker(worker) {
  let result = "Result:";
  // let worker = spawn("java", args);
  worker.stdout.on("data", function (data) {
    console.log("response: " + data);
    // $("#app_cnt").append("<h1>Data:"+data+"</h1>");
    result += "<h1>Data:"+data+"</h1>";
  });
  worker.on("close", function (code, signal) {
    console.log("Java finished with exit code of " + code);
    // $("#app_cnt").append("Code:"+code);
    result += "<p>process returncode:"+code+"</p>";
    $("#app_cnt").append(result);
  });
  
}

getJavaClass("SumOfNumbers",[3,1, 2, 3]);
getJavaClass("SumOfNumbers",[1, 2, 3,4]);
// printResult('Done');






// // Run asynchronously to use the returned status for process.exit
// // (async () => {
// //     console.log(__dirname);
// //     await new JavaCallerCli(__dirname).process();
// // })();

// const java = new JavaCaller({
//     classPath: 'resources/java',
//     mainClass: 'com.nvuillam.javacaller.JavaCallerTester'
// });
// //const { status, stdout, stderr } = java.run();
// const { status, stdout, stderr } = java.run(['-Xms256m', '-Xmx2048m', '--customarg nico']);
// let worker = java.run(['-Xms256m', '-Xmx2048m', '--customarg nico']);
//   worker.stdout.on("data", function (data) {
//     console.log("The sum is : " + data);
//     $("#app_cnt").append("<h1>Data:"+data+"</h1>");
//   });
//   worker.on("close", function (code, signal) {
//     console.log("Java finished with exit code of " + code);
//     $("#app_cnt").append("Code:"+code);
//   });  
// // console.log(stdout);
// // var spawn = require('child_process').spawn;
// // var proc = spawn('test.exe');
// stdout.on('data', function(data) {
//   process.stdout.write(data);
// });
// stderr.on('data', function(data) {
//   process.stderr.write(data);
// });
// // proc.on('close', function(code, signal) {
// //   console.log('test.exe closed');
// // });
// var java = require("java");
// java.classpath.push("commons-lang3-3.1.jar");
// java.classpath.push("commons-io.jar");

// var list1 = java.newInstanceSync("java.util.ArrayList");
// console.log(list1.sizeSync()); // 0
// list1.addSync('item1');
// console.log(list1.sizeSync()); // 1

// java.newInstance("java.util.ArrayList", function(err, list2) {
//   list2.addSync("item1");
//   list2.addSync("item2");
//   console.log(list2.toStringSync()); // [item1, item2]
// });

// var ArrayList = java.import('java.util.ArrayList');
// var list3 = new ArrayList();
// list3.addSync('item1');
// list3.equalsSync(list1); // true