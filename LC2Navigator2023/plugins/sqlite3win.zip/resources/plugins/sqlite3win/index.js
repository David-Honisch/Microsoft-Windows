// alert('TEST2');
function pluginINIT() {
    try {
        var remote = window.nodeRequire('electron').remote;
        arguments = remote.getGlobal('sharedObject').prop1;
        console.log(arguments);
        // $('#pnav').load('..\\..\\resources\\plugins\\' + pluginName + '\\launch.html');
        execCMD('.\\resources\\plugins\\' + pluginName + '\\index.bat', 'pnavmenu');
    } catch (e) {
        alert(e.stack);
    }
    // var argparts = arguments.split(' ');
    // var i = 0;
    // var query = "";
    // for (var s in argparts)
    // {
    // console.log(s);
    // if (s == "--query"){
    // query = argparts[i+1]
    // }
    // i++;
    // }
    // alert(query);
    // document.getElementById("app_cnt").innerHTML += arguments;
    // document.getElementById("inputKey").value =inputKey
    // alert(arguments);
    // alert(arguments["arg1"]);
    // alert(arguments["--query"]);
	// try {
    // $('#mout').load('..\\..\\resources\\plugins\\' + pluginName + '\\launch.html');
	// execCMD('.\\resources\\plugins\\' + pluginName + '\\index.bat', 'moutnav');
// } catch (e) {
    // alert(e.stack);
// }
}
pluginINIT();