-- select '<h2>Import processes</h2>';
drop table IF EXISTS sqlite3win;
drop table IF EXISTS sqlite3win_data;
drop table IF EXISTS sqlite3win_procdata;
-- drop table IF EXISTS sqlite3wintemp;
-- drop table IF EXISTS sqlite3win_datatemp;
CREATE TABLE sqlite3win( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE sqlite3win_data( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
-- CREATE TABLE sqlite3win_procdata( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
-- CREATE TABLE IF NOT EXISTS sqlite3wintemp (
-- "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL
-- );
-- create table IF NOT EXISTS sqlite3win_datatemp ( name varchar(255));
-- CREATE TABLE IF NOT EXISTS sqlite3win_datatemp (
-- "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL
-- );
-- import menu
-- select '<p>Import processes</p>';
.separator ";"
.import .\\resources\\plugins\\sqlite3win\\import\\import.csv sqlite3win
.import '.\\resources\\plugins\\sqlite3win\\import\\menu.csv' sqlite3win_data
-- delete from sqlite3win_datatemp;
--
-- .separator ","
-- .import '.\\resources\\plugins\\sqlite3win\\import\\sqlite3winwork.csv' sqlite3win_datatemp
-- INSERT INTO sqlite3win_procdata(first_name,name,zipcode, city, description) select first_name,name,zipcode, city, description  from sqlite3win_datatemp;

select '<p>sqlite3win count:';
select count(*) from sqlite3win;
select 'sqlite3win_data count:';
select count(*) from sqlite3win_data;
select 'sqlite3win_procdata count:';
select count(*) from sqlite3win_procdata;
.separator ";"
drop table IF EXISTS sqlite3wintemp;
-- select '<p>Import done</p>';
.exit