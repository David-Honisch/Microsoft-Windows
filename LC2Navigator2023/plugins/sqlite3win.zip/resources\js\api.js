function eMsg(v) {
    alert(v);
    if (e.stack !== undefined) console.error(e.stack);
}

function getJSON_CR(url, urlext, isAsync, dataType, callBack) {
    return new Promise(function(resolve, reject) {
        $.ajax({
            method: 'POST',
            url: url,
            data: {
                // url where our server will send request which can't be done by AJAX
                'ext_url': urlext
            },
            success: function(data) {
                // try {
                //     // var $h1 = $(data).find('h1').html();
                //     // $('h1').val($h1);
                // } catch (error) {
                //     console.error(error);
                //     console.error(error.stack);
                // }
                //$('#cnt').html(data);
                resolve(data);
            },
            error: function() {
                console.log('Error');
                reject('Error');
            }
        });
    });
}


function getFullIndexList(id, api, apiext) {
    // var api = 'https://www.letztechance.org/webservices/client.php?q=getFullIndexJSON&value1=0&l=';
    console.log("get list by" + api);
    try {
        var p1 = getJSON_CR(api, apiext, 'GET', true, 'jsonp');
        // jQuery('#outcnt').html('Reading' + api);
        p1.then(function(data) {
            try {
                var oJson = JSON.parse(data, false);
                var result = "";
                for (var i = 0; i < oJson.list.length; i++) {
                    var counter = oJson.list[i];
                    result += '<option value="' + counter.name + '">' + counter.id + '</option>';
                }
                // $('#tableId').append(result);
                $(id).append(result);
            } catch (e) {
                $('#error').before('Error:<hr>' + e.stack);
                $('#error').before(e);
            }
        });
    } catch (e) {
        $('#error').before('Error:<hr>' + e.stack);
        $('#error').before(e);
    }
    console.log("List done");
}

function createDir(dir) {
    const fs = window.nodeRequire('fs');
    if (!fs.existsSync(dir)) {
        fs.mkdirSync(dir);
    }
}

function doUnzip(link, target) {
    console.log('Extract' + link);
    alert('Extract' + link);
    var DecompressZip = window.nodeRequire('decompress-zip');
    // for (var v in links) {
    var ZIP_FILE_PATH = link;
    var DESTINATION_PATH = target;
    var unzipper = new DecompressZip(ZIP_FILE_PATH);

    // Add the error event listener
    unzipper.on('error', function(err) {
        console.log('Caught an error' + link, err);
    });

    // Notify when everything is extracted
    unzipper.on('extract', function(log) {
        console.log('Finished extracting', log);
    });

    // Notify "progress" of the decompressed files
    unzipper.on('progress', function(fileIndex, fileCount) {
        console.log('Extracted file ' + (fileIndex + 1) + ' of ' + fileCount);
        document.getElementById("app_cnt").innerHTML += 'Extracted file ' + (fileIndex + 1) + ' of ' + fileCount;
    });

    // Start extraction of the content
    unzipper.extract({
        path: DESTINATION_PATH
            // You can filter the files that you want to unpack using the filter option
            //filter: function (file) {
            //console.log(file);
            //return file.type !== "SymbolicLink";
            //}
    });
    // }

}

function InstallModules(tmpDir) {
    Install_Modules(corelibs,tmpDir,'modcnt');
}
function Install_Modules(libs, tmpDir,id) {
    try {
        const { npmImportAsync, npmInstallAsync } = window.nodeRequire('runtime-npm-install');
        npmInstallAsync(libs, tmpDir)
            .then(function() {
                document.getElementById(id).innerHTML += '<h1>Successfully Installed to:</h1>' + tmpDir + '<br>';
                document.getElementById(id).innerHTML += '<h2>Done. Close window now and start main plugin.</h2>';

            });
        printDir(path.join(tmpDir, 'node_modules'));
    } catch (error) {
        alert(error);
        document.getElementById(id).innerHTML += '<h2>ERROR:</h2>'+error;
    }
}

function printDir(dir_path) {
    const path = window.nodeRequire('path');
    const fs = window.nodeRequire('fs');
    console.log('DIR:' + dir_path);
    fs.readdir(dir_path, function(err, files) {
        //handling error
        if (err) {
            return console.log('Unable to find or open the directory: ' + err);
        }
        //Print the array of images at one go
        // console.log(files);
        //listing all files using forEach
        files.forEach(function(file) {
            var isValid = false;
            console.log(file);
            document.getElementById("modcnt").innerHTML += "<br>" + file;
            for (v in rlibs) {
                if (file.includes(v)) {
                    isValid = true;
                }
            }
            if (isValid) {
                document.getElementById("modcnt").innerHTML += "<br>" + file + " <strong>found</strong>.";
            }
        });
    });
}

function downloadAppBinaries(path, link, target) {
    // var target = path.join(appRoot, "download");
    document.getElementById("appcnt").innerHTML = "<h4>URL:<strong>" + path + link + "</strong> to " + target + "</h4>";
    const downloadManager = window.nodeRequire("electron").remote.require("electron-download-manager");
    downloadManager.register({ downloadFolder: target });
    downloadManager.downloadFolder = target; //.register({ downloadFolder: target });
    downloadManager.download({
        url: path + link,
        properties: { directory: target },
        filePath: target,
    }, function(error, info) {
        if (error) {
            console.log(error);
            document.getElementById("moappcntcnt").innerHTML += path + link + " <strong>NOT downloaded.</strong>.<br>";
            return;
        }
        console.log(JSON.stringify(info));
        document.getElementById("appcnt").innerHTML += "URL:" + info.url + " <strong>downloaded.</strong>.<br>";
        document.getElementById("appcnt").innerHTML += "FILE:" + info.filePath + " " + " <strong>written.</strong>.<br>";
        doUnzip(target + link, target);
        console.log("DONE: " + info.url);
    })
}

function bulkDownloadAppBinaries(links, target) {
    // var target = path.join(appRoot, "download");
    // window.nodeRequire("electron").remote.require("electron-download-manager").bulkDownload({
    //     url: links,
    //     // properties: { directory: target },
    //     filePath: target,
    // }, function(error, finished, errors) {
    //     if (error) {
    //         console.log(error);
    //         document.getElementById("appcnt").innerHTML += error + " <strong>NOT downloaded.</strong>.<br>";
    //         return;
    //     }
    //     document.getElementById("appcnt").innerHTML += "URL:" + finished.url + " <strong>downloaded.</strong>.<br>";
    //     document.getElementById("appcnt").innerHTML += "FILE:" + finished.path + "-" + finished.files + " <strong>written.</strong>.<br>";
    //     console.log("DONE: " + finished.url);
    // })
}


function doDownload(links, target) {
    console.log("Target:" + target);
    for (var v in links) {
        getDownloadFile(links[v].path, links[v].file, target + links[v].file);
        // downloadAppBinaries(links[v].path, links[v].file, target);
        // bulkDownloadAppBinaries(links, target);
    }
}


function getDownloadFile(baseUrl, link, target) {
    var request = window.nodeRequire('request');
    var fs = window.nodeRequire('fs');
    // Save variable to know progress
    var received_bytes = 0;
    var total_bytes = 0;
    var url = baseUrl + link;
    console.log('DL:' + url)
    var req = request({
        method: 'GET',
        uri: url
    });

    var out = fs.createWriteStream(target);
    req.pipe(out);

    req.on('response', function(data) {
        // Change the total bytes value to get progress later.
        total_bytes = parseInt(data.headers['content-length']);
    });

    req.on('data', function(chunk) {
        // Update the received bytes
        received_bytes += chunk.length;

        showProgress(received_bytes, total_bytes);
    });

    req.on('end', function() {
        // alert("File succesfully downloaded");
        document.getElementById("appcnt").innerHTML += "<br>" + url + "File succesfully downloaded";
        // doUnzip(target + link, target);
    });
}

function showProgress(received, total) {
    var percentage = (received * 100) / total;
    console.log(percentage + "% | " + received + " bytes out of " + total + " bytes.");
    document.getElementById("appcntprogress").innerHTML = percentage + "% | " + received + " bytes out of " + total + " bytes.";
}