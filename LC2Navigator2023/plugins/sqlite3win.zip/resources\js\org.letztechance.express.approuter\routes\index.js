var express = require('express');
var router = express.Router();

/* GET home page. */
router.get('/', function(req, res, next) {
  // res.render('index', { title: 'LC2Navigator2022' });
  handlePublicRequest(req, res)
});
function handlePublicRequest(req, res) {
  var fs = require('fs');
  var path = require('path');
  const publicPath = path.dirname(__dirname);
  try {
      var file = path.join(publicPath, 'public', req.url);
      console.log('Loading:' + file);

      fs.exists(file, function (exists) {
          if (exists && fs.lstatSync(file).isFile()) {
              try {
                  // res.setHeader("Content-Type", mime.lookup(file));
                  res.writeHead(200, {
                      'Access-Control-Allow-Origin': '*'
                  });
                  fs.createReadStream(file).pipe(res);
              } catch (e) {
                  console.error(e);
                  console.error(e.stack);
              }
              return;
          }

          res.writeHead(404);
          res.write('404 Not Found');
          res.end();
      });
  } catch (e) {
      console.error(e);
      console.error(e.stack);
  }
}
module.exports = router;