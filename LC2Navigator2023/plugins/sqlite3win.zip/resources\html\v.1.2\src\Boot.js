class Boot extends Phaser.Scene {
    constructor() {
        super('Boot');
    }
    preload() {
        this.load.pack('pack1', '../../resources/html/v.1.2/assets/img/level.json', 'general');
		this.load.pack('packLevel', '../../resources/html/v.1.2/assets/img/level.json', 'level');
        // this.load.image('background', 'img/background.png');
        // this.load.image('logo', 'img/logo.png');
        // this.load.image('goldrunner', 'img/gr.png');
        // this.load.image('loading-background', 'img/loading-background.png');
        this.load.atlas('space', '../../resources/html/v.1.2/assets/img/space.png', '../../resources/html/v.1.2/assets/img/space.json');
        this.load.atlas('explosion', '../../resources/html/v.1.2/assets/img/explosion2.png', '../../resources/html/v.1.2/assets/img/explosion2.json');

        // this.load.spritesheet('invader', '../../resources/html/v.1.2/assets/img/invader1.png', { frameWidth: 32, frameHeight: 32 });
        // this.load.spritesheet('boom', '../../resources/html/v.1.2/assets/img/explosion.png', { frameWidth: 64, frameHeight: 64, endFrame: 23 });

        this.load.atlas('flares', '../../resources/html/v.1.2/assets/img/flares.png', '../../resources/html/v.1.2/assets/img/flares.json');
        this.load.json('emitter', '../../resources/html/v.1.2/assets/img/emitter.json');

        this.load.css('css', '../../resources/html/v.1.2/assets/css/loader/80stypography.css');
        WebFont.load({ custom: { families: ['Berlin'], urls: ['../../resources/html/v.1.2/assets/fonts/BRLNSDB.css'] } });
        // this.load.htmlTexture('homeHTML', '../../resources/html/v.1.2/assets/html/home.html', 640, 960);
        // this.load.glsl('bundle', '../../../resources/html/v.1.2/assets/shaders/bundle.glsl.js');
        // this.load.glsl('bundle2', '../../../resources/html/v.1.2/assets/shaders/bundle2.glsl.js');
        this.load.bitmapFont('desyrel', '../../resources/html/v.1.2/assets/fonts/bitmap/desyrel.png', '../../resources/html/v.1.2/assets/fonts/bitmap/desyrel.xml');
		this.load.bitmapFont('atari', '../../resources/html/v.1.2/assets/fonts/bitmap/atari-smooth.png', '../../resources/html/v.1.2/assets/fonts/bitmap/atari-smooth.xml');
		this.load.bitmapFont('ice', '../../resources/html/v.1.2/assets/fonts/bitmap/iceicebaby.png', '../../resources/html/v.1.2/assets/fonts/bitmap/iceicebaby.xml');
		this.load.bitmapFont('gothic', '../../resources/html/v.1.2/assets/fonts/bitmap/gothic.png', '../../resources/html/v.1.2/assets/fonts/bitmap/gothic.xml');
		this.load.bitmapFont('hyper', '../../resources/html/v.1.2/assets/fonts/bitmap/hyperdrive.png', '../../resources/html/v.1.2/assets/fonts/bitmap/hyperdrive.xml');
        this.load.css('css', '../../resources/html/v.1.2/assets/css/loader/80stypography.css');
    }
    create() {
        LC2.world = {
            width: this.cameras.main.width,
            height: this.cameras.main.height,
            centerX: this.cameras.main.centerX,
            centerY: this.cameras.main.centerY
        };
        LC2.Lang.updateLanguage('de');
        LC2.text = LC2.Lang.text[LC2.Lang.current];
        this.scene.start('Preloader');
    }
}