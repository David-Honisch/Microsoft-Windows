// Code goes here
var remote = require('electron').remote;
arguments = remote.getGlobal('sharedObject').prop1;
console.log(arguments);
alert(arguments);
const model = window.nodeRequire(path.join(__dirname, 'app', 'model.js'));
var app = angular.module('app', ['ui.bootstrap']);

function MyController($scope, $http, $filter) {
    const path = window.nodeRequire('path');
    // default values for pagination and filtering
    $scope.pageSize = 5;
    $scope.maxSize = 5;
    $scope.start = 0;
    $scope.end = 0;
    $scope.currentPage = 0;
    $scope.numOfPages = 0;
    $scope.filteredItems = [];
    $scope.startItems = [];
    $scope.pagedItems = [];
    $scope.data = null;
    $scope.query = { name: "" };

    $scope.menu = [{
            name: "Home",
            url: "index.html"

        },
        {
            name: "HomePage",
            url: "index.html"

        }
    ];

    // get the data
    // $http.get('assets/js/data/data.json')
    //     .success(function(data) {
    //         // set the data
    //         $scope.data = data.Data;
    //     });

    // model.initDb('' + webRoot, //app.getPath('userData'),
    //     // Load a DOM stub here. See renderer.js for the fully composed DOM.
    //     //mainWindow.loadURL(`file:${__dirname}/app/html/index.html`)
    //     console.log('Init Database')
    // );
    var res = model.GetQuery(path.join(__dirname, 'lc.db'), 'select * from systables');
    // console.log(JSON.stringify(res));
    var list = {
        "Data": []
    };

    for (var v in res) {
        // console.log(JSON.stringify(v));
        var t = {
            "id": res[v]['person_id'],
            "name": res[v]['name'],
            "first_name": res[v]['first_name'],
            "last_name": res[v]['last_name'],
            "zipcode": res[v]['zipcode'],
            "url": res[v]['url'],
        };
        // console.log(JSON.stringify(t));
        list['Data'].push(t);
    }
    // console.log(JSON.stringify(list.Data));
    $scope.data = list.Data;

	    // getOpenDialog('#importGUI_cnt','.\\resources\\html\\intro.html','Intro',{ top: 400,minWidth: 250, margin:0,  minHeight: 800, width: 640, height:960});    
    getOpenDialog('#importGUI_cnt','.\\resources\\html\\start.html','Start',{ top: 100,minWidth: 250, margin:0,  minHeight: 150, width: 420, height:480});
    getOpenDialog('#alertcnt','.\\resources\\html\\intro.html','Intro',{ top: 100,minWidth: 250, margin:0,  minHeight: 600, width: 640, height:600});
    // loadFile('file:///./resources/html/v.1.2/local.html',{ width: 800, height: 600});
    loadFile('file:///./resources/html/v.1.3/index.html',{ width: 800, height: 600});


    // when the data is altered, filter the items and set the page
    $scope.$watch('data', function(data, old) {
        $scope.filteredItems = $filter('filter')(data, $scope.query);
        if (old === null) setPage();
    });

    // when the query value changes, refilter the data
    $scope.$watch('query|json', function() {
        $scope.filteredItems = $filter('filter')($scope.data, $scope.query);
    });

    // set the pagination for the filtered items
    function setPage() {
        $scope.start = ($scope.currentPage - 1) * $scope.pageSize + ($scope.filteredItems === undefined && $scope.filteredItems.length ? 1 : 0);
        $scope.startItems = $filter('startFrom')($scope.filteredItems, $scope.start - 2);
    }

    // when the current page is changed by the pagination control, update the list of items
    $scope.$watch('currentPage', function(page) {
        setPage();
    });

    // when the filtered items are set, recalculate the number of pages
    $scope.$watch('filteredItems', function(items, old) {
        $scope.currentPage = 1;
        if (items !== undefined && items.length !== undefined)
            $scope.numOfPages = Math.ceil(items.length / $scope.pageSize);
    });

    // when the page start is changed, update the list of paged items
    $scope.$watch('startItems', function(items) {
        $scope.pagedItems = $filter('limitTo')(items, $scope.pageSize);
        $scope.end = ($scope.currentPage - 2) * $scope.pageSize + $scope.pagedItems.length;
    });



}

// angular directive to change default behavior from processing input change immediately to on blur or enter
app.directive('ngModelBlur', function() {
    return {
        restrict: 'A',
        require: 'ngModel',
        link: function(scope, elm, attr, ngModelCtrl) {
            if (attr.type === 'radio' || attr.type === 'checkbox') { return; }

            elm.unbind('input').unbind('keydown').unbind('change');
            elm.bind('blur keydown', function(e) {
                if (e.type === 'keydown' && e.which !== 13) { return; }

                scope.$apply(function() {
                    ngModelCtrl.$setViewValue(elm.val());
                });
            });
        }
    };
});

// angular filter to take array items starting from provided index
app.filter('startFrom', function() {
    return function(input, start) {
        if (angular.isArray(input)) {
            var st = parseInt(start, 10);
            if (isNaN(st)) st = 0;
            return input.slice(st);
        }
        return input;
    };
});

function createDatabase() {
    var table = $("#newdb").val();
    alert('Create Database:' + table);
    var res = model.GetQuery(path.join(__dirname, 'lc.db'), 'CREATE TABLE ' + table + ' ( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT(255,0) NOT NULL, "first_name" TEXT(255,0) NULL, "description" TEXT(255,0) NULL, "zipcode" TEXT(255,0) NULL, "city" TEXT(255,0) NULL,	 "street" TEXT(255,0) NULL,	 "url" TEXT NULL);');
    document.getElementById("newdbcnt").innerHTML = JSON.stringify(res) + " done.";
    res = model.GetQuery(path.join(__dirname, 'lc.db'), 'INSERT INTO systables (name,first_name, description,url)VALUES(\'' + table + '\',\'menu.bat\',\'menu.bat\',\'menu.bat\');');
    document.getElementById("newdbcnt").innerHTML += JSON.stringify(res) + " done.";
}

function deleteItem(id) {
    var table = $("#newdb").val();
    alert('Realy delete:' + id);
    var res = model.GetQuery(path.join(__dirname, 'lc.db'), 'DELETE from \'systables\' WHERE person_id = \'' + id + '\';');
    document.getElementById("newdbcnt").innerHTML = JSON.stringify(res) + " done.";
}


function goToTable() {
    var t = $("#database").val();
    window.location = 'list.html?db=' + t;
}

function openFile(t) {
    window.location = t;
}

function readFile(t, id) {
    var childProcess = window.nodeRequire("child_process");
    // This line initiates
    var script_process = childProcess.spawn(t, [], { env: process.env });
    // Echoes any command output
    script_process.stdout.on('data', function(data) {
        console.log('stdout: ' + data);
        document.getElementById(id).innerHTML = data;

    });
    // Error output
    script_process.stderr.on('data', function(data) {
        document.getElementById(id).innerHTML = 'stderr: ' + data;
        console.log('stderr: ' + data);

    });
    // Process exit
    script_process.on('close', function(code) {
        console.log('child process exited with code ' + code);
    });
}