// // const APPCFG = "application.config.json";
// const path = window.nodeRequire('path');
// const jQuery = window._PAGE_.jQuery;
// const { readFileSync, fs } = window.nodeRequire('fs');
// const cfg = window.nodeRequire(path.join(__dirname, 'assets', 'js', 'config.json'));
// const model = window.nodeRequire(path.join(__dirname, 'app', 'model.js'));
// const cpath = path.join(__dirname);
// const dbPath = path.join(__dirname, '..', 'lc.db'); // remote.getGlobal('sharedObj').dbPath; // remote.getGlobal('sharedObj').dbPath;
// const gelectron = window.nodeRequire('electron');
// const shell = gelectron.shell;
// const OPEN_LINK = "https://www.letztechance.org/openlink?";
// // -var remote = window.nodeRequire('electron').remote;
// // const rootLib = window.nodeRequire('app-root-path');
// // const appRoot = path.dirname(('' + rootLib).replace("app.asar", ""));
// // console.log('rootLib:' + rootLib);
// var dialogProperties = {
//     // appendTo: "#dialog",
//     show: "puff",
//     hide: "explode",
//     top: 140,
//     resizable: true,
//     closeOnEscape: true,
//     minWidth: 150,
//     minHeight: 150,
//     // position: { my: "left top", of: "left top" },
//     height: "auto",
//     width: "auto"
// };

$.urlParam = function (name) {
    var results = new RegExp('[\?&]' + name + '=([^&#]*)').exec(window.location.href);
    if (results == null) {
        return null;
    }
    return decodeURI(results[1]) || 0;
}
function encode_utf8(s) {
    return unescape(encodeURIComponent(s));
}

function decode_utf8(s) {
    return decodeURIComponent(escape(s));
}

function print(t, isAppend) {
    if (!isAppend) {
        out.html(t);
    } else {
        out.append(t);
    }
}

function msg(t) {
    return t;
}


function createDatabase() {
    var table = $("#newdb").val();
    alert('Create Database:' + table);
    var res = model.GetQuery(dbPath, 'CREATE TABLE ' + table + ' ( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT(255,0) NOT NULL, "first_name" TEXT(255,0) NULL, "description" TEXT(255,0) NULL, "zipcode" TEXT(255,0) NULL, "city" TEXT(255,0) NULL,	 "street" TEXT(255,0) NULL,	 "url" TEXT NULL);');
    document.getElementById("newdbcnt").innerHTML = JSON.stringify(res) + " done.";
    res = model.GetQuery(dbPath, 'INSERT INTO systables (name,first_name, description,url)VALUES(\'' + table + '\',\'menu.bat\',\'menu.bat\',\'menu.bat\');');
    document.getElementById("newdbcnt").innerHTML += JSON.stringify(res) + " done.";
}

function readItem(table, id) {
    return model.GetQuery(dbPath, 'SELECT * FROM ' + table + ' WHERE person_id=' + id + ';');
}

function addItem() {
    var res;
    var table = $.urlParam('db');
    var name = $("#name").val();
    var first_name = $("#first_name").val();
    var last_name = $("#last_name").val();
    var zipcode = $("#zipcode").val();
    var description = $("#description").val();
    var url = $("#url").val();

    res = model.GetQuery(dbPath, 'INSERT INTO ' + table +
        ' (name,first_name, zipcode,description,url)VALUES' +
        '(\'' + name + '\',\'' + first_name + '\',\'' + zipcode + '\',\'' + description + '\',\'' + url + '\');' +
        '');
    document.getElementById("out").innerHTML += JSON.stringify(res) + " done.";
}

function addItem2() {
    var res;
    var table = $.urlParam('db');
    var name = $("#name").val();
    var first_name = $("#first_name").val();
    var last_name = $("#last_name").val();
    var zipcode = $("#zipcode").val();
    var description = $("#description").val();
    var url = $("#url").val();
    $("#conformdialog").attr("title", "Add");
    $("#conformdialog").dialog({
        // appendTo: "#dialog",
        show: "puff",
        hide: "explode",
        resizable: true,
        closeOnEscape: false,
        minWidth: 150,
        minHeight: 150,
        // position: { my: "left top", of: "left top" },
        height: "auto",
        width: "auto",
        modal: true,
        buttons: {
            "Yes": function () {
                res = model.GetQuery(dbPath, 'INSERT INTO ' + table +
                    ' (name,first_name, zipcode,description,url)VALUES' +
                    '(\'' + name + '\',\'' + first_name + '\',\'' + zipcode + '\',\'' + description + '\',\'' + url + '\');' +
                    '');
                document.getElementById("out_cnt").innerHTML += JSON.stringify(res) + " done.";
                $(this).dialog("close");
            },
            Cancel: function () {
                document.getElementById("out_cnt").innerHTML += JSON.stringify(res) + "Not done.";
                $(this).dialog("close");
            }
        }
    });
}

function updateItem() {
    var table = $.urlParam('db');
    var keyValue = {
        "columns": ["person_id", "name", "first_name", "zipcode", "city", "street", "description", "url"],
        "values": [$.urlParam('id'), $("#name").val(), $("#first_#name").val(), $("#zipcode").val(), $("#city").val(), $("#street").val(), $("#description").val(), $("#url").val()],
    };
    var columns = keyValue.columns;
    var values = keyValue.values;
    model.saveData(dbPath, table, columns, values, function () {
        model.getQuery(dbPath, table, 'SELECT * FROM `' + table + '` ORDER BY `person_id` ASC', '#app_cnt');
    });

    document.getElementById("newdbcnt").innerHTML += JSON.stringify(keyValue) + " done.";
}


function deleteItem(id) {
    var table = $.urlParam('db');
    var query = 'SELECT * FROM `' + table + '` ORDER BY `person_id` ASC';
    document.getElementById("newdbcnt").innerHTML = 'Realy delete:' + id + " from " + table;
    // var res = model.GetQuery(dbPath, 'DELETE from \'systables\' WHERE person_id = \'' + id + '\';');
    var res = model.deletePerson(dbPath, table, id, function () {
        model.getQuery(dbPath, table, query, '#app_cnt');
    });
    document.getElementById("newdbcnt").innerHTML = JSON.stringify(res) + " done.";
    location.reload();
}
function shortName(v) {
    if (v.length > 50) {
        return v.substring(0, 50) + "...";
    }
    else {
        return v;
    }
}


function goToTable() {
    var t = $("#database").val();
    window.location = 'list.html?db=' + t;
}

function goToItem() {
    var t = $("#database").val();
    var id = $("#database").val();
    window.location = 'edit.html?db=' + t + '&id=' + id;
}

function openPage(s) {
    window.location = s;
}

function openPage(s) {
    window.open(s);
}

function openAddTable() {
    var t = $.urlParam('db');
    var url = 'edit.html?db=' + t;
    // openDialog("#dialog", url + " #addPage", t, { minWidth: 250, minHeight: 150, width: 400 });
    // getOpenDialog('#dialog', url, 'Install', { minWidth: 250, minHeight: 150, width: 400 });
    getExtFile(url, 'blank', { minWidth: 250, minHeight: 150, width: 400 });
}

function openAddPage() {
    var t = $.urlParam('db');
    var url = 'edit.html?db=' + t;
    window.open(url, '_blank', 'top=500,left=200,frame=true,nodeIntegration=yes, contextIsolation: false,enableRemoteModule: true');
}

function openPage(url, target, props) {
    window.open(url, target, props);
}

function getAppConfig(appConfigFileName) {
    const fs = window.nodeRequire('fs');
    let rawdata = fs.readFileSync(appConfigFileName);
    let appConfig = JSON.parse(rawdata);
    console.log(appConfig);
    return appConfig;
}

function setAppConfig(appConfigFileName, appConfig) {
    let data = JSON.stringify(appConfig, null, 2);
    fs.writeFileSync(appConfigFileName, data);
}

function getFileContent(id, url) {
    document.getElementById(id).innerHTML = get_FileData(url);
    $(id).load(f);
}

function loadFileContent(id, url) {
    $(id).load(url);
}

function openBrowser(t) {
    require("shell").openExternal(t);
}

function openFile(t) {
    window.location = t;
}

function getReadFileWindow(t, id) {
    var childProcess = window.nodeRequire("child_process");
    // This line initiates
    var script_process = childProcess.spawn(t, [], { env: process.env });
    // Echoes any command output
    script_process.stdout.on('data', function (data) {
        console.log('stdout: ' + data);
        document.getElementById(id).innerHTML = data;

    });
    // Error output
    script_process.stderr.on('data', function (data) {
        document.getElementById(id).innerHTML = 'stderr: ' + data;
        console.log('stderr: ' + data);

    });
    // Process exit
    script_process.on('close', function (code) {
        console.log('child process exited with code ' + code);
    });
}

function getLocalFile(url) {
    const electron = window.nodeRequire('electron');
    const BrowserWindow = electron.remote.BrowserWindow;
    //	const url = require('url');

    const childWindow = new BrowserWindow({
        width: 800,
        height: 600
    });
    console.log("file://" + __dirname + "/" + url);
    childWindow.loadURL("file://" + __dirname + "/" + url);
}

function readLocalFile(url) {
    // const { readFileSync } = window.nodeRequire('fs')
    return readFileSync(url)
}

function execCMD(text, id) {
    const {
        exec
    } = window.nodeRequire('child_process');
    document.getElementById(id).innerHTML = "<div class=\"preload\"></div>";
    // alert('OUT:'+text.length);
    exec('' + text, (err, stdout, stderr) => {

        if (err) {
            console.error(err);
            document.getElementById(id).innerHTML = "" + JSON.stringify(err);
            document.getElementById(id).innerHTML = stdout;
            return;
        }
        //console.log('OUT:' + stdout);
        //console.log('id:' + id);
        document.getElementById(id).innerHTML = stdout;

        $("html, body").delay(100).animate({
            scrollTop: $('#' + id).offset().top
        }, 30);
    });
}
/**
 * '.\\resources\\plugins\\LC2DEBanksUpdater\\install.html'
 * @param {*} text 
 * @param {*} id 
 */
function execPluginCMD(id, url) {
    try {
        execCMD('.\\resources\\plugins\\'+url+'\\index.bat', id);
        getOpenDialog('#'+id,'.\\resources\\plugins\\'+url+'\\index.html',''+url,{ minWidth: 250,  minHeight: 150, width: 400});
    } catch (error) {
        console.error(error);
        console.error(error.stack);
    }
}
function extExecCMD(text, id) {
    const {
        exec
    } = window.nodeRequire('child_process');
    document.getElementById(id).innerHTML = "";
    document.getElementById(id).innerHTML = "<div class=\"preload\"></div>";
    text = decode_utf8(text);
    text = text.split("\\").join("\\\\");

    // alert('OUT:'+text.length);
    exec('\"' + text + "\"", (err, stdout, stderr) => {

        if (err) {
            console.error(err);
            document.getElementById(id).innerHTML = "" + JSON.stringify(err);
            document.getElementById(id).innerHTML = stdout;
            return;
        }
        console.log('OUT:' + stdout);
        document.getElementById(id).innerHTML = stdout;
        $("html, body").delay(100).animate({
            scrollTop: $('#' + id).offset().top
        }, 30);
    });
}
function execPlugin(text, id) {
    execlugin(text, id);
    if (pluginINIT !== undefined) {
        pluginINIT();
    }
}

function evalCMD(text) {
    const {
        exec
    } = window.nodeRequire('child_process');
    // alert('OUT:'+text.length);
    exec('' + text, (err, stdout, stderr) => {

        if (err) {
            console.error(err);
            return;
        }
        // console.log('OUT:' + stdout);
        // document.getElementById(id).innerHTML = stdout;
        try {

            eval(stdout);
        } catch (error) {
            alert(error);
            console.error(error.stack);
        }
    });
}

function openBrowser(url) {
    openBrowser(url, false);
}

function openBrowser(url, isOpen) {
    if (isOpen) {
        window.nodeRequire("electron").shell.openExternal("https://www.letztechance.org/openlink?" + url);
    } else {
        window.nodeRequire("electron").shell.openExternal(url);
    }
}

function getExtFile(url, target, props) {
    // window.open(url, '_blank', 'top=500,left=200,frame=false,nodeIntegration=no');
    console.log('open:' + url);
    window.open(url, target, props);
}

function getFile(url, target, props) {
    const childWindow = window.open(url, '_blank');
    // childWindow.document.write('<h1>Hello</h1>');
    childWindow.document.write('<h1>Hello</h1>');
}

function get_FileData(url) {
    // const { readFileSync } = window.nodeRequire('fs');
    return readFileSync(url);
}

function getLocalFile(url, props) {
    var props = props !== undefined ? props : { width: 800, height: 600 };
    const electron = window.nodeRequire('electron');
    const BrowserWindow = electron.remote.BrowserWindow;
    //	const url = require('url');
    const path = window.nodeRequire('path');
    const childWindow = new BrowserWindow(prop);
    console.log("file://" + __dirname + "/" + url);
    childWindow.loadURL("file://" + __dirname + "/" + url);

}

function loadFile(url, props) {
    var prop = props !== undefined ? props : {
        width: 800,
        height: 600
    };
    const electron = window.nodeRequire('electron');
    const BrowserWindow = electron.remote.BrowserWindow;
    const path = window.nodeRequire('path');
    const childWindow = new BrowserWindow(prop);
    childWindow.loadURL(url);
    // childWindow.readFile(get_FileData(path.join(url)));

}

function getTextWindow(t, props) {
    var prop = props !== undefined ? props : {
        width: 800,
        height: 600
    };
    const electron = window.nodeRequire('electron');
    const BrowserWindow = electron.remote.BrowserWindow;
    const path = window.nodeRequire('path');
    const childWindow = new BrowserWindow(prop);
    // childWindow.loadFileContent("file://" + __dirname + "/" + url);
    childWindow.loadURL('data:text/html;charset=utf-8,' + get_FileData(path.join(t)));
}

function openDialog(id, f, title, props) {
    var prop = props !== undefined ? prop : {
        // appendTo: "#dialog",
        show: "puff",
        hide: "explode",
        resizable: true,
        closeOnEscape: false,
        minWidth: 150,
        minHeight: 150,
        // position: { my: "left top", of: "left top" },
        height: "auto",
        width: "auto"
    };
    $(function () {
        $(id).attr("title", title);
        $(id).dialog(prop);
        console.log(f);
        $(id + "cnt").load(f);
    });
}

function getOpenDialog(id, f, title, props) {
    // $.noConflict();
    dialogProperties = props !== undefined ? props : dialogProperties;
    var res = get_FileData(path.join(f));
    $(id).attr("title", title);
    console.log(f);
    $(id + "cnt").html('Loading now...');
    $(id).append('Loading...');
    $(id).html('' + res);
    $(id).dialog(dialogProperties);
}

function getOpenDialogText(id, t, title, props) {
    // $.noConflict();
    dialogProperties = props !== undefined ? props : dialogProperties;
    $(id).attr("title", title);
    $(id + "cnt").html('Loading now...');
    $(id).append('Loading...');
    $(id).html('' + t);
    $(id).dialog(dialogProperties);
}
function getConfirmation(title) {
    return confirm(title);
}
function getShowConfirmDialog(id, message, title, props, callback) {
    if (ConfirmDialog(id, message, title, props)) {
        alert('Thanks for confirming');
        callback;
    } else {
        alert('Why did you press cancel? You should have confirmed');
    }
}
function show_ConfirmDialog(id, message, title, props, callback) {
    var isDialogValid = false;
    $('<div></div>').appendTo(id)
        .html('<div><h6>' + message + '?</h6></div>')
        .dialog({
            modal: true,
            title: title,
            zIndex: 10000,
            autoOpen: true,
            width: 'auto',
            resizable: false,
            buttons: {
                Yes: function () {
                    // $(obj).removeAttr('onclick');                                
                    // $(obj).parents('.Parent').remove();

                    $('body').append('<h1>Confirm Dialog Result: <i>Yes</i></h1>');
                    //{alert('taskkill /f /PID %%b','menu_cnt');}else{alert('Bye');}                
                    isDialogValid = true;
                    $(this).dialog("close");
                    $(this).data("callback")(true);
                    // processDialogResult(true, callback);

                },
                No: function () {
                    $('body').append('<h1>Confirm Dialog Result: <i>No</i></h1>');
                    $(this).dialog("close");
                    $(this).data("callback")(false);
                }
            },
            close: function (event, ui) {
                $(this).remove();
            }
        });
};
function processDialogResult(result, callback) {
    if (isDialogValid) {
        callback;
    }
    else {
        alert('Cancelled.');
    }
}
function SimpleConfirmDialog(id, message, title, props, callback) {
    $('<div></div>').appendTo(id)
        .html('<div><h6>' + message + '?</h6></div>')
        .dialog({
            modal: true,
            title: title,
            zIndex: 10000,
            autoOpen: true,
            width: 'auto',
            resizable: false,
            buttons: {
                Yes: function () {
                    // $(obj).removeAttr('onclick');                                
                    // $(obj).parents('.Parent').remove();

                    $('body').append('<h1>Confirm Dialog Result: <i>Yes</i></h1>');
                    //{alert('taskkill /f /PID %%b','menu_cnt');}else{alert('Bye');}
                    // callback;
                    $(this).dialog("close");

                },
                No: function () {
                    $('body').append('<h1>Confirm Dialog Result: <i>No</i></h1>');

                    $(this).dialog("close");
                }
            },
            close: function (event, ui) {
                $(this).remove();
            }
        });
};
function conFirmDialog(id, title, props) {
    var isValid = false;
    dialogProperties.buttons = {
        "Yes": function () {
            isValid = true;
            $(this).dialog("close");
        },
        Cancel: function () {
            $(this).dialog("close");
        }
    };
    dialogProperties = props !== undefined ? props : dialogProperties;
    // $(function() {
    $(id).attr("title", title);
    // alert(title);
    //$(id).dialog(dialogProperties);
    $(id).dialog({
        // appendTo: "#dialog",
        show: "puff",
        hide: "explode",
        resizable: true,
        closeOnEscape: false,
        minWidth: 150,
        minHeight: 150,
        // position: { my: "left top", of: "left top" },
        height: "auto",
        width: "auto",
        modal: true,
        buttons: {
            "Yes": function () {
                isValid = true;
                return isValid;
                $(this).dialog("close");
            },
            Cancel: function () {
                $(this).dialog("close");
            }
        }
    });
    // // });
    // return isValid;
}
// import { xsltProcess, xmlParse } from 'xslt-processor'
function getXsltFileProcess(source, target) {
    const path = window.nodeRequire('path');
    const fs = window.nodeRequire('fs');
    const xmlString = _readFile(source, { encoding: 'utf8', flag: 'r' });
    const xsltString = _readFile(target, { encoding: 'utf8', flag: 'r' });
    return getXsltProcess(xmlString, xsltString);
}

function getXsltProcess(xmlString, xsltString) {
    const { xsltProcess, xmlParse } = window.nodeRequire('xslt-processor');
    return outXmlString = xsltProcess(
        xmlParse(xmlString),
        xmlParse(xsltString)
    );
}
function getXML(source, target, id) {
    var outXmlString = "";
    try {
        outXmlString = getXsltFileProcess(source, target);
        document.getElementById(id).innerHTML += outXmlString;
    } catch (e) {
        console.error(e);
        console.error(e.stack);
    }

}
function _readFile(source, prop) {
    const path = window.nodeRequire('path');
    const fs = window.nodeRequire('fs');
    return fs.readFileSync(source, { encoding: 'utf8', flag: 'r' });

}
function toBase(file) {
    return new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.readAsDataURL(file);
        reader.onload = () => resolve(reader.result.toString().substr(reader.result.toString().indexOf(',') + 1));
        reader.onerror = error => reject(error);
    });
}
//'#files > input[type="file"]'
function getToBase(selector, id) {
    file = document.querySelector(selector).files[0]
    getFile(file).then((customJsonFile) => {
        console.log(customJsonFile);
        $(id).html(JSON.stringify(customJsonFile));
    });
}
function getFiles(files) {
    return Promise.all(files.map(getFile));
}

//take a single JavaScript File object
function getFile(file) {
    const reader = new FileReader();
    return new Promise((resolve, reject) => {
        reader.onerror = () => { reader.abort(); reject(new Error("Error parsing file")); }
        reader.onload = function () {
            //This will result in an array that will be recognized by C#.NET WebApi as a byte[]
            let bytes = Array.from(new Uint8Array(this.result));

            //if you want the base64encoded file you would use the below line:
            let base64StringFile = btoa(bytes.map((item) => String.fromCharCode(item)).join(""));

            //Resolve the promise with your custom file structure
            resolve({
                bytes,
                base64StringFile,
                fileName: file.name,
                fileType: file.type
            });
        }
        reader.readAsArrayBuffer(file);
    });
}
function getBase64ToFile(file) {
    return atob(file);
}


function getHeader(page) {
    var result = "<div id=\"cm-menu\">";
    result += "<nav id=\"top\" class=\"cm-navbar cm-navbar-primary lc-header\"> ";
    result += "<div class=\"cm-flex\"><a href=\"index.html\" class=\"cm-logo\"></a></div> ";
    result += "<div class=\"btn btn-primary md-menu-white lc-header\" data-toggle=\"cm-menu\" id=\"cm-menu\"></div> ";
    result += "</nav>";

    result += "<div id=\"ctop\"></div>";

    result += "<div id=\"cm-menu-content\"> ";
    result += "<div id=\"cm-menu-items-wrapper\"> ";
    result += "<div id=\"cm-menu-scroller\"> ";
    result += "<ul class=\"cm-menu-items\"> ";

    result += "<li class=\"cm_submenu\"><a href=\"index.html\">Application</a></li> ";
    result += "<li ><a href=\"index.html\">Application</a></li> ";
    // result += "<li ><a href=\"index.html\">Application</a></li> ";
    result += "</ul> ";
    result += "</div> ";
    result += "</div> ";
    result += "</div> ";
    result += "</div> ";
    result += " <header id=\"cm-header\"> ";
    result += " <nav class=\"cm-navbar cm-navbar-primary lc-header\"> ";
    result += "<div class=\"btn btn-primary md-menu-white hidden-md hidden-lg lc-header\" data-toggle=\"cm-menu\">";
    result += "</div> ";
    result += " <div class=\"cm-flex\"> ";
    result += " <div class=\"cm-breadcrumb-container\"> ";
    // result += " <ol class=\"breadcrumb\"> ";
    // result += " <li><a href=\"index.html\">" + msg('indexpage') + "</a></li> ";
    // result += " <li><a href=\"start.html\" class=\"active\">" + msg('startpage') + "</a></li> ";
    // result += " </ol> ";
    result += "</div> ";
    result += "<form id=\"cm-search\" action=\"" + page.host + "\" method=\"get\"> ";
    result += "<input type=\"search\" id=\"btnquery\" name=\"query\" autocomplete=\"on\" placeholder=\"" + msg('search') + "\"> ";
    result += "<input type=\"hidden\" name=\"q\" value=\"search\">";

    result += "</form> ";
    result += "</div> ";

    result += "</ul> ";

    result += "</div> ";
    result += "</nav> ";
    result += "</header> ";
    return result;
}
//
function createDir(dir, id) {
    const fs = window.nodeRequire('fs');
    if (!fs.existsSync(dir)) {
        fs.mkdirSync(dir);
        document.getElementById(id).innerHTML += dir + "created.<br>";
    }
}

function do_Unzip(link, target, id) {
    const path = window.nodeRequire('path');
    const fs = window.nodeRequire('fs');
    target = path.join(target);
    link = path.join(link);
    if (link.includes(".zip")) {
        document.getElementById(id).innerHTML += '<br><h4>Extracting:</h4><p>' + link + ' to:' + target + '</p>';
        try {
            execCMD('extract ' + link, 'modcnt');
        } catch (error) {
            alert(error);
            console.error(error.stack);
        }
    } else {
        document.getElementById(id).innerHTML += '<p> ' + link + ' <strong>NOT</strong> extracted to:' + target + '</p>';
    }
    document.getElementById(id).innerHTML += '<hr><strong>DONE</strong>';
    console.log('Extraction complete')

}

function InstallModules(corelibs, tmpDir, id) {
    Install_Modules(corelibs, tmpDir, id);
}
function Install_Modules(libs, tmpDir, id) {
    try {
        const { npmImportAsync, npmInstallAsync } = window.nodeRequire('runtime-npm-install');
        npmInstallAsync(libs, tmpDir)
            .then(function () {
                document.getElementById(id).innerHTML += '<h1>Successfully Installed to:</h1>' + tmpDir + '<br>';
                document.getElementById(id).innerHTML += '<h2>Done. Close window now and start main plugin.</h2>';

            });
        printDir(path.join(tmpDir, 'node_modules', id));
    } catch (error) {
        alert(error);
        document.getElementById(id).innerHTML += '<h2>ERROR:</h2>' + error;
    }
}

function printDir(dir_path, id) {
    const path = window.nodeRequire('path');
    const fs = window.nodeRequire('fs');
    console.log('DIR:' + dir_path);
    fs.readdir(dir_path, function (err, files) {
        //handling error
        if (err) {
            return console.log('Unable to find or open the directory: ' + err);
        }
        //Print the array of images at one go
        // console.log(files);
        //listing all files using forEach
        files.forEach(function (file) {
            var isValid = false;
            console.log(file);
            document.getElementById(id).innerHTML += "<br>" + file;
            for (v in rlibs) {
                if (file.includes(v)) {
                    isValid = true;
                }
            }
            if (isValid) {
                document.getElementById(id).innerHTML += "<br>" + file + " <strong>found</strong>.";
            }
        });
    });
}

function doDownload(links, target) {
    for (var v in links) {
        getDownloadFile(links[v].path, links[v].file, target + links[v].file, target);
    }
}

function getDownloadFile(baseUrl, link, targetFile, target) {
    get_DownloadFile(baseUrl, link, targetFile, target, "out_cnt");
}

function get_DownloadFile(baseUrl, link, targetFile, target, id) {
    var request = window.nodeRequire('request');
    var fs = window.nodeRequire('fs');
    var received_bytes = 0;
    var total_bytes = 0;
    var url = baseUrl + link;
    console.log('DL:' + url)
    var req = request({
        method: 'GET',
        uri: url
    });
    var out = fs.createWriteStream(targetFile);
    req.pipe(out);
    req.on('response', function (data) {
        // Change the total bytes value to get progress later.
        total_bytes = parseInt(data.headers['content-length']);
    });
    req.on('data', function (chunk) {
        // Update the received bytes
        received_bytes += chunk.length;
        //showProgress(id, received_bytes, total_bytes);
    });
    req.on('end', function () {
        // alert("File succesfully downloaded");
        document.getElementById(id).innerHTML += "<br>" + url + " File succesfully downloaded";
        document.getElementById(id).innerHTML += "<br>" + targetFile + " File succesfully written.";
        document.getElementById(id).innerHTML += "<br>Path:" + target + ".";
        document.getElementById(id).innerHTML += "<br>Link:" + link + ".";
        if (('' + targetFile).includes(".zip")) {
            do_Unzip(targetFile, target, id);
            document.getElementById(id).innerHTML += "<br>Unzip:" + targetFile + ".";
        }
    });
}

function showProgress(id, received, total) {
    try {
        console.log("ID:" + id);
        var percentage = (received * 100) / total;
        console.log(percentage + "% | " + received + " bytes out of " + total + " bytes.");
        //document.getElementById(id).innerHTML += percentage + "% | " + received + " bytes out of " + total + " bytes.";
        document.getElementById(id + "_progress").innerHTML = percentage + "% | " + received + " bytes out of " + total + " bytes.";
    } catch (error) {
        console.err(error);
        console.err(error.stack);

    }

}