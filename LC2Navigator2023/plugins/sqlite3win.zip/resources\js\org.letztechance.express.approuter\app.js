var createError = require('./lib/http-errors');
var express = require('express');
var path = require('path');
var cookieParser = require('cookie-parser');
var logger = require('morgan');

var homeRouter = require('./routes/home');
var indexRouter = require('./routes/index');
var usersRouter = require('./routes/users');

var app = express();

// view engine setup
var views = path.join(__dirname, 'views');
console.log("View:"+views);
app.set('views', views);
app.set('view engine', 'pug');

app.use(logger('dev'));
app.use(express.json());
app.use(express.urlencoded({ extended: false }));
app.use(cookieParser());
app.use(express.static(path.join(__dirname, 'public')));

app.use('/', indexRouter);
app.use('/info', homeRouter);
app.use('/users', usersRouter);
app.use('/users', usersRouter);
// catch 404 and forward to error handler
app.use(function(req, res, next) {
  handlePublicRequest(req, res);
});

// error handler
// app.use(function(err, req, res, next) {
//   // set locals, only providing error in development
//   res.locals.message = err.message;
//   res.locals.error = req.app.get('env') === 'development' ? err : {};

//   // render the error page
//   res.status(err.status || 500);
//   res.render('error');
// });
function handlePublicRequest(req, res) {
  var fs = require('fs');
  var path = require('path');
  const publicPath = path.dirname(__dirname);
  try {
      var file = path.join(publicPath, 'public', req.url);
      console.log('Loading:' + file);

      fs.exists(file, function (exists) {
          if (exists && fs.lstatSync(file).isFile()) {
              try {
                  // res.setHeader("Content-Type", mime.lookup(file));
                  res.writeHead(200, {
                      'Access-Control-Allow-Origin': '*'
                  });
                  fs.createReadStream(file).pipe(res);
              } catch (e) {
                  console.error(e);
                  console.error(e.stack);
              }
              return;
          }

          res.writeHead(404);
          res.write('404 Not Found');
          res.end();
      });
  } catch (e) {
      console.error(e);
      console.error(e.stack);
  }
}
module.exports = app;
