select '<h4>LC2Xmas2021 Plugin SQL Import</h4>'; 
drop table IF EXISTS LC2Xmas2021;
drop table IF EXISTS LC2Xmas2021temp;
CREATE TABLE LC2Xmas2021 ( 'person_id' INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, 'created' TIMESTAMP DEFAULT CURRENT_TIMESTAMP NULL, 'modified' TIMESTAMP DEFAULT CURRENT_TIMESTAMP NULL, 'enddate' TIMESTAMP DEFAULT CURRENT_TIMESTAMP NULL, 'name' TEXT NOT NULL, 'first_name' TEXT NULL, 'description' TEXT NULL, 'zipcode' TEXT NULL, 'city' TEXT NULL,	 'street' TEXT NULL,	 'url' TEXT NULL);
create table IF NOT EXISTS LC2Xmas2021temp ( name varchar(255), menu TEXT, url varchar(255), subtext TEXT);
.separator ';'
.import .\\resources\\plugins\\LC2Xmas2021\\import\\import.csv LC2Xmas2021temp
INSERT INTO LC2Xmas2021 (first_name,name, description,url) select name,name, menu,url  from LC2Xmas2021temp;
select '<p>LC2Xmas2021 count:';
select count(*) from LC2Xmas2021;
select '</p>';
.exit
