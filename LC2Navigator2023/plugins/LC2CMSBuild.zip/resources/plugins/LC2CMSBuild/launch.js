// execCMD('.\\resources\\plugins\\' + pluginName + '\\launch.bat', 'LC2CMSBuild');
// call %~dp0setregvalue.bat "hkey_current_user\software\letztechance.org\LC2Navigator2021" "user" "%username%" > nul
$('#lc_user').val(process.env.lc_user);
$('#lc_pwd').val(process.env.lc_password);