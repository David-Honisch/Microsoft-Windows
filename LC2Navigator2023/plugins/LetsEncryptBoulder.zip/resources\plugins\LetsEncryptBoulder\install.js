try {
    document.getElementById("appcnt").innerHTML = "";
    document.getElementById("modcnt").innerHTML = "";
    for (var v in installDirectories) {
        createDir(installDirectories[v]);
    }
    var opath = window.nodeRequire('path');
    var resDir = opath.join(__dirname, '../../resources/');
    var pluginDir = opath.join(__dirname, '../../resources/plugins/' + pluginName + '/');
    var downloadDir = opath.join(__dirname, '../../');
    console.log(resDir);
    console.log(pluginDir);
    console.log(downloadDir);
    InstallModules(resDir);
    // doDownload(downloadUrls, pluginDir);
	//
	document.getElementById("build").innerHTML += "<h1>Cloning git repository</h1>";
    execCMD('.\\resources\\plugins\\' + pluginName + '\\gitinstall.bat', 'build');	
	document.getElementById("build").innerHTML += "<h1>"+pluginName+" cloning git repository</h1>";
    document.getElementById("mvn_cnt").innerHTML += "<h1>Maven Build</h1>";
    execCMD('.\\resources\\plugins\\' + pluginName + '\\mvninstall.bat install', 'mvn_cnt');
    document.getElementById("build").innerHTML += "<h1>Build</h1>";
    execCMD('.\\resources\\plugins\\' + pluginName + '\\build.bat install', 'build');
    document.getElementById("appcnt").innerHTML += "<h1>Build successfully done</h1>";
    doUnzip(downloadUrls, targetDir);
} catch (e) {
    alert(e.stack);
}