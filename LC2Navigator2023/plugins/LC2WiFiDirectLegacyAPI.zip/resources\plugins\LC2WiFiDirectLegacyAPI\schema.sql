select '<h4>LC2WiFiDirectLegacyAPI Plugin SQL Import</h4>'; 
drop table IF EXISTS LC2WiFiDirectLegacyAPI;
drop table IF EXISTS LC2WiFiDirectLegacyAPItemp;
CREATE TABLE LC2WiFiDirectLegacyAPI ( 'person_id' INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, 'created' TIMESTAMP DEFAULT CURRENT_TIMESTAMP NULL, 'modified' TIMESTAMP DEFAULT CURRENT_TIMESTAMP NULL, 'enddate' TIMESTAMP DEFAULT CURRENT_TIMESTAMP NULL, 'name' TEXT NOT NULL, 'first_name' TEXT NULL, 'description' TEXT NULL, 'zipcode' TEXT NULL, 'city' TEXT NULL,	 'street' TEXT NULL,	 'url' TEXT NULL);
create table IF NOT EXISTS LC2WiFiDirectLegacyAPItemp ( name varchar(255), menu TEXT, url varchar(255), subtext TEXT);
.separator ';'
.import .\\resources\\plugins\\LC2WiFiDirectLegacyAPI\\import\\import.csv LC2WiFiDirectLegacyAPItemp
INSERT INTO LC2WiFiDirectLegacyAPI (first_name,name, description,url) select name,name, menu,url  from LC2WiFiDirectLegacyAPItemp;
select '<p>LC2WiFiDirectLegacyAPI count:';
select count(*) from LC2WiFiDirectLegacyAPI;
select '</p>';
.exit
