select '<h4>LC2OpenAI Plugin SQL Import</h4>'; 
drop table IF EXISTS LC2OpenAI;
drop table IF EXISTS LC2OpenAItemp;
CREATE TABLE LC2OpenAI ( 'person_id' INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, 'created' TIMESTAMP DEFAULT CURRENT_TIMESTAMP NULL, 'modified' TIMESTAMP DEFAULT CURRENT_TIMESTAMP NULL, 'enddate' TIMESTAMP DEFAULT CURRENT_TIMESTAMP NULL, 'name' TEXT NOT NULL, 'first_name' TEXT NULL, 'description' TEXT NULL, 'zipcode' TEXT NULL, 'city' TEXT NULL,	 'street' TEXT NULL,	 'url' TEXT NULL);
create table IF NOT EXISTS LC2OpenAItemp ( name varchar(255), menu TEXT, url varchar(255), subtext TEXT);
.separator ';'
.import .\\resources\\plugins\\LC2OpenAI\\import\\import.csv LC2OpenAItemp
INSERT INTO LC2OpenAI (first_name,name, description,url) select name,name, menu,url  from LC2OpenAItemp;
select '<p>LC2OpenAI count:';
select count(*) from LC2OpenAI;
select '</p>';
.exit
