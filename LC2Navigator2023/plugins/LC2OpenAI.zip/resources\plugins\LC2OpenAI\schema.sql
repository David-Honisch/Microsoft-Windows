-- select '<h2>Import processes</h2>';
drop table IF EXISTS LC2OpenAI;
drop table IF EXISTS LC2OpenAI_data;
drop table IF EXISTS LC2OpenAI_procdata;
drop table IF EXISTS LC2OpenAItemp;
drop table IF EXISTS LC2OpenAI_datatemp;
CREATE TABLE LC2OpenAI( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE LC2OpenAI_data( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE LC2OpenAI_procdata( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE IF NOT EXISTS LC2OpenAItemp (
"name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL
);
-- create table IF NOT EXISTS LC2OpenAI_datatemp ( name varchar(255));
CREATE TABLE IF NOT EXISTS LC2OpenAI_datatemp (
"name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL
);
-- import menu
-- select '<p>Import processes</p>';
.separator ";"
.import .\\resources\\plugins\\LC2OpenAI\\import\\import.csv LC2OpenAItemp
INSERT INTO LC2OpenAI(first_name,name,zipcode, city, description) select first_name,name,zipcode, city, description  from LC2OpenAItemp;
--
-- eof insert work data
select 'LC2OpenAI count:';
select count(*) from LC2OpenAI;
--.separator ';'
.separator ";"
--.import '.\\resources\\plugins\\LC2OpenAI\\import\\menu.csv' LC2OpenAI_datatemp
.import '.\\resources\\plugins\\LC2OpenAI\\import\\menu.csv' LC2OpenAI_datatemp
INSERT INTO LC2OpenAI_data(first_name,name,zipcode, city, description) select first_name,name,zipcode, city, description  from LC2OpenAI_datatemp;
delete from LC2OpenAI_datatemp;
--
.separator ","
.import '.\\resources\\plugins\\LC2OpenAI\\import\\LC2OpenAIwork.csv' LC2OpenAI_datatemp
INSERT INTO LC2OpenAI_procdata(first_name,name,zipcode, city, description) select first_name,name,zipcode, city, description  from LC2OpenAI_datatemp;
--
select '<p>LC2OpenAI count:';
select count(*) from LC2OpenAI;
select 'LC2OpenAI_data count:';
select count(*) from LC2OpenAI_data;
select 'LC2OpenAI_procdata count:';
select count(*) from LC2OpenAI_procdata;
.separator ";"
drop table IF EXISTS LC2OpenAItemp;
-- select '<p>Import done</p>';
.exit