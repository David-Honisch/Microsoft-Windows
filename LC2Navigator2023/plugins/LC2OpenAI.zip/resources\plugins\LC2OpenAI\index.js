// alert('TEST')
$('#cnt').html('');
  var fileInput = document.getElementById('pluginFile');
  var btnSubmit = document.getElementById('pluginSubmit');
  var aiengine = document.getElementById('aiengine').value;
  
  var pattern = fileInput.innerHTML;
  // console.log("Reading scripts running...");
  // document.getElementById('app_cnt').innerHTML = "running...";
  // for (var v in window._PAGE_.cfg.CRYPT.scripts) {
  //   console.log(window._PAGE_.cfg.CRYPT.scripts[v]);
  //   window._PAGE_.html.addScript(window._PAGE_.cfg.CRYPT.scripts[v], "head");
  // }
  var CFG = {
    "api": document.getElementById('apiengine').value,// "https://api.openai.com/v1/completions",
    "key": "LC2OpenAI",
    "apiKey": process.env.OPENAI_API_KEY,
    "presence": 0
  }
  //alert(CFG.api);
  var DEFAULT_PARAMS = {
    "model": aiengine,
    //"prompt": "### Postgres SQL tables, with their properties:\n#\n# Employee(id, name, department_id)\n# Department(id, name, address)\n# Salary_Payments(id, employee_id, amount, date)\n#\n### A query to list the names of the departments which employed more than 10 employees in the last 12 months\nSELECT",
    "prompt": pattern,
    "temperature": 0,
    "max_tokens": 150,
    "top_p": 1.0,
    "frequency_penalty": 0.0,
    "presence_penalty": 0.0,
    "stop": ["#", ";"]
  }
  var DEFAULT_TEMPERATURE = {
    "model": aiengine,
    "temperature": 0.7,
    "max_tokens": 256,
    "top_p": 1,
    "frequency_penalty": 0,
    "presence_penalty": 0
  }
  async function query(apiKey, params = {}) {
    const params_ = {
      ...DEFAULT_PARAMS,
      ...params
    };
    const requestOptions = {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer ' + String(apiKey)
      },
      body: JSON.stringify(params_)
    };
    document.getElementById('app_cnt').innerHTML += DEFAULT_PARAMS.prompt;
    const response = await fetch(CFG.api, requestOptions);
    const data = await response.json();
    document.getElementById('app_cnt').innerHTML += JSON.stringify(data);
    $("html, body").delay(100).animate({
      scrollTop: $('#app_cnt').offset().top
    }, 30);
    return data.choices[0].text;
  }
  fileInput.addEventListener('change', (e) => {
    console.log(e.target.value);
  });
  btnSubmit.addEventListener('click', (e) => {        
    aiengine = document.getElementById('aiengine').value;
    DEFAULT_PARAMS.model = document.getElementById('aiengine').value;
    DEFAULT_PARAMS.prompt = document.getElementById('pluginFile').value;
    //alert(JSON.stringify(DEFAULT_PARAMS));
    query(apiKey, DEFAULT_PARAMS);
  });
  
  
  document.getElementById('app_cnt').innerHTML += window._PAGE_.cpage.html._getBoxFluid("running..." + CFG.api);

  

  try {
    console.log("running...");
    
    var apiKey = process.env.OPENAI_API_KEY;
    var q = window._PAGE_.cpage.html.getSearchQuery();
    $('#app_cnt').html('Query:' + q);
    // $('.modal-title').html('Encryption running...');
    var result = "<hr>" + CFG.api + "<hr>";
    // eIndex.forEach(function (s, i, o) {
    //   console.log(CryptoJS.AES.decrypt(s.toString(), CFG.key).toString(CryptoJS.enc.Utf8) + '<br>');
    // });
    $('#app_cnt').append(window._PAGE_.cpage.html._getBoxFluid(result));
  } catch (error) {
    console.error(error);
    console.error(error.stack);
  }