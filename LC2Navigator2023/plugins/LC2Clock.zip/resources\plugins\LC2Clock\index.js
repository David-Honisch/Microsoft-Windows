try {
    $('#mout').load('..\\..\\resources\\plugins\\' + pluginName + '\\launch.html');
	execCMD('.\\resources\\plugins\\' + pluginName + '\\index.bat', 'moutnav');
} catch (e) {
    alert(e.stack);
}