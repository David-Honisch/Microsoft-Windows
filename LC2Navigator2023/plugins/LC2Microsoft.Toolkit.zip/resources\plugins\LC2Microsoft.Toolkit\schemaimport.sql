-- nothing to do
drop table IF EXISTS LC2Microsoft_Toolkit_cpl;
drop table IF EXISTS LC2Microsoft_Toolkit_msc;
-- CREATE TABLE LC2Microsoft_Toolkit_msc( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE LC2Microsoft_Toolkit_cpl( "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE LC2Microsoft_Toolkit_msc( "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
.separator ";"
.import .\\resources\\plugins\\LC2Microsoft.Toolkit\\import\\cpl.csv LC2Microsoft_Toolkit_cpl
.import .\\resources\\plugins\\LC2Microsoft.Toolkit\\import\\msc.csv LC2Microsoft_Toolkit_msc
select '<p>LC2Microsoft_Toolkit_msc count:';
select count(*) from LC2Microsoft_Toolkit_msc;
select '<p>LC2Microsoft_Toolkit_cpl count:';
select count(*) from LC2Microsoft_Toolkit_cpl;
