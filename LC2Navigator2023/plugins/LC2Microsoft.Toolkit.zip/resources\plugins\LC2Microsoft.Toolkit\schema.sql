-- select '<h2>Import processes</h2>';
drop table IF EXISTS LC2Microsoft_Toolkit;
drop table IF EXISTS LC2Microsoft_Toolkit_data;
drop table IF EXISTS LC2Microsoft_Toolkit_procdata;
-- drop table IF EXISTS LC2Microsoft_Toolkittemp;
-- drop table IF EXISTS LC2Microsoft_Toolkit_datatemp;
CREATE TABLE LC2Microsoft_Toolkit( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE LC2Microsoft_Toolkit_data( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
-- CREATE TABLE LC2Microsoft_Toolkit_procdata( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
-- CREATE TABLE IF NOT EXISTS LC2Microsoft_Toolkittemp (
-- "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL
);
-- create table IF NOT EXISTS LC2Microsoft_Toolkit_datatemp ( name varchar(255));
-- CREATE TABLE IF NOT EXISTS LC2Microsoft_Toolkit_datatemp (
-- "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL
-- );
-- import menu
-- select '<p>Import processes</p>';
.separator ";"
.import .\\resources\\plugins\\LC2Microsoft.Toolkit\\import\\import.csv LC2Microsoft_Toolkit
-- .import .\\resources\\plugins\\LC2Microsoft_Toolkit\\import\\import.csv LC2Microsoft_Toolkittemp
-- INSERT INTO LC2Microsoft_Toolkit(first_name,name,zipcode, city, description) select first_name,name,zipcode, city, description  from LC2Microsoft_Toolkittemp;

--
-- eof insert work data
-- select 'LC2Microsoft_Toolkit count:';
-- select count(*) from LC2Microsoft_Toolkit;
--.separator ';'
.separator ";"
--.import '.\\resources\\plugins\\LC2Microsoft_Toolkit\\import\\menu.csv' LC2Microsoft_Toolkit_datatemp
-- .import '.\\resources\\plugins\\LC2Microsoft_Toolkit\\import\\menu.csv' LC2Microsoft_Toolkit_datatemp
-- INSERT INTO LC2Microsoft_Toolkit_data(first_name,name,zipcode, city, description) select first_name,name,zipcode, city, description  from LC2Microsoft_Toolkit_datatemp;
.import '.\\resources\\plugins\\LC2Microsoft.Toolkit\\import\\menu.csv' LC2Microsoft_Toolkit_data
-- delete from LC2Microsoft_Toolkit_datatemp;
--
-- .separator ","
-- .import '.\\resources\\plugins\\LC2Microsoft_Toolkit\\import\\LC2Microsoft_Toolkitwork.csv' LC2Microsoft_Toolkit_datatemp
-- INSERT INTO LC2Microsoft_Toolkit_procdata(first_name,name,zipcode, city, description) select first_name,name,zipcode, city, description  from LC2Microsoft_Toolkit_datatemp;
--
select '<p>LC2Microsoft_Toolkit count:';
select count(*) from LC2Microsoft_Toolkit;
select 'LC2Microsoft_Toolkit_data count:';
select count(*) from LC2Microsoft_Toolkit_data;
-- select 'LC2Microsoft_Toolkit_procdata count:';
-- select count(*) from LC2Microsoft_Toolkit_procdata;
-- .separator ";"
-- drop table IF EXISTS LC2Microsoft_Toolkittemp;
-- select '<p>Import done</p>';
.exit