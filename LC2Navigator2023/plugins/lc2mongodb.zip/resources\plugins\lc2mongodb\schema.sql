select '<h4>lc2mongodb Plugin SQL Import</h4>';
drop table IF EXISTS lc2mongodb;
drop table IF EXISTS lc2mongodbtemp;
CREATE TABLE lc2mongodb ( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL,"created" TIMESTAMP DEFAULT CURRENT_TIMESTAMP NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
create table IF NOT EXISTS lc2mongodbtemp ( name varchar(255), menu TEXT, url varchar(255), subtext TEXT);
-- .separator "\t"
.separator ";"
.import .\\resources\\plugins\\lc2mongodb\\import\\import.csv lc2mongodbtemp
INSERT INTO lc2mongodb (first_name,name, description,url) select name,name, menu,url  from lc2mongodbtemp;
select '<p>lc2mongodb count:';
select count(*) from lc2mongodb;
select '</p>';
.exit