-- select '<h2>Import processes</h2>';
drop table IF EXISTS LC2JSVideoPlayer;
drop table IF EXISTS LC2JSVideoPlayer_Data;
drop table IF EXISTS LC2JSVideoPlayer_data;
drop table IF EXISTS LC2JSVideoPlayertemp;
drop table IF EXISTS LC2JSVideoPlayer_datatemp;
CREATE TABLE LC2JSVideoPlayer( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE LC2JSVideoPlayer_data( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE IF NOT EXISTS LC2JSVideoPlayertemp (
"name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL
);
create table IF NOT EXISTS LC2JSVideoPlayer_datatemp ( name varchar(255));
-- import menu
-- select '<p>Import processes</p>';
.separator ";"
.import .\\resources\\plugins\\LC2JSVideoPlayer\\import\\import.csv LC2JSVideoPlayer
-- INSERT INTO LC2JSVideoPlayer(first_name,name,zipcode, city, description) select name,name, pid,ftype,tpid  from LC2JSVideoPlayertemp;
-- insert work data
INSERT INTO LC2JSVideoPlayer(first_name,name,zipcode, city, description) select first_name,name,zipcode, city, description  from LC2JSVideoPlayertemp;
-- eof insert work data
select 'LC2JSVideoPlayer count:';
select count(*) from LC2JSVideoPlayer;
-- select '<p>Import working data processes</p>';
-- .separator ";"
--.import .\\resources\\plugins\\LC2JSVideoPlayer\\import\\LC2JSVideoPlayerwork.csv LC2JSVideoPlayertemp
-- .import .\\resources\\plugins\\LC2JSVideoPlayer\\import\\LC2JSVideoPlayerwork.csv LC2JSVideoPlayertemp
-- .import .\\resources\\plugins\\LC2JSVideoPlayer\\blz-aktuell-txt-data.txt  LC2JSVideoPlayertemp
-- select 'COUNT:'+count(*) from LC2JSVideoPlayertemp;
-- INSERT INTO LC2JSVideoPlayer_data(first_name,name,zipcode, city, description) select first_name,name,zipcode, city, description  from LC2JSVideoPlayertemp;
.separator ';'
.import '.\\resources\\plugins\\LC2JSVideoPlayer\\import\\menu.csv' LC2JSVideoPlayer_Datatemp
select '<h6>Main menu importing done</h6>'; 
select '<p>LC2JSVideoPlayer_Datatemp count:';
select count(*)  from LC2JSVideoPlayer_Datatemp;
select '</p>';
INSERT INTO LC2JSVideoPlayer_Data (first_name,name, description,url) select name,name, menu,url  from LC2JSVideoPlayer_Datatemp;
-- INSERT INTO LC2JSVideoPlayer_data (first_name,name,zipcode, city, description,url) select substr( name, 0, 9 ),rtrim(substr( name, 10, 58 )), substr(name,68,71), substr(name,73,78), name,trim(substr( name, 140, 169))  from LC2JSVideoPlayer_datatemp;
select '<p>LC2JSVideoPlayer count:';
select count(*) from LC2JSVideoPlayer;
select 'LC2JSVideoPlayer_data count:';
select count(*) from LC2JSVideoPlayer_data;
drop table IF EXISTS LC2JSVideoPlayertemp;
INSERT OR REPLACE INTO systables(name, first_name, description, zipcode, city, street, url)VALUES('LC2JSVideoPlayer_data v.1.01a','LC2JSVideoPlayer_data v.1.01a','','','','','execCMD(''exec .\\resources\\plugins\\LC2JSVideoPlayer\\index.bat .\\resources\\plugins\\LC2JSVideoPlayer\\menu.csv'', ''out'');');  
-- select '<p>Import done</p>';
.exit