-- select '<h2>Import processes</h2>';
drop table IF EXISTS LC2JSVideoPlayer;
drop table IF EXISTS LC2JSVideoPlayer_data;
drop table IF EXISTS LC2JSVideoPlayer_procdata;
-- drop table IF EXISTS LC2JSVideoPlayertemp;
-- drop table IF EXISTS LC2JSVideoPlayer_datatemp;
CREATE TABLE LC2JSVideoPlayer( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE LC2JSVideoPlayer_data( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
-- CREATE TABLE LC2JSVideoPlayer_procdata( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
-- CREATE TABLE IF NOT EXISTS LC2JSVideoPlayertemp (
-- "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL
-- );
-- create table IF NOT EXISTS LC2JSVideoPlayer_datatemp ( name varchar(255));
-- CREATE TABLE IF NOT EXISTS LC2JSVideoPlayer_datatemp (
-- "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL
-- );
-- import menu
-- select '<p>Import processes</p>';
.separator ";"
.import .\\resources\\plugins\\LC2JSVideoPlayer\\import\\import.csv LC2JSVideoPlayer
.import '.\\resources\\plugins\\LC2JSVideoPlayer\\import\\menu.csv' LC2JSVideoPlayer_data
-- delete from LC2JSVideoPlayer_datatemp;
--
-- .separator ","
-- .import '.\\resources\\plugins\\LC2JSVideoPlayer\\import\\LC2JSVideoPlayerwork.csv' LC2JSVideoPlayer_datatemp
-- INSERT INTO LC2JSVideoPlayer_procdata(first_name,name,zipcode, city, description) select first_name,name,zipcode, city, description  from LC2JSVideoPlayer_datatemp;

select '<p>LC2JSVideoPlayer count:';
select count(*) from LC2JSVideoPlayer;
select 'LC2JSVideoPlayer_data count:';
select count(*) from LC2JSVideoPlayer_data;
select 'LC2JSVideoPlayer_procdata count:';
select count(*) from LC2JSVideoPlayer_procdata;
.separator ";"
drop table IF EXISTS LC2JSVideoPlayertemp;
-- select '<p>Import done</p>';
.exit