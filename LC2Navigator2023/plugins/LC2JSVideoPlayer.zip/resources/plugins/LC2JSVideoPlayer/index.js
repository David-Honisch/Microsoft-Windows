function getArg(arguments, pattern) {
    var argparts = (arguments + "").split(',');
    var i = 0;
    var query = "";
    for (var s in argparts) {
        var v = argparts[s];
        if (v.startsWith(pattern + "=")) {
            query = v.replace(pattern + "=", '');
            break;
        }
        i++;
    }
    return query;
}
function pluginINIT(pluginName) {
    try {
        var remote = window.nodeRequire('electron').remote;
        arguments = remote.getGlobal('sharedObject').prop1;
        console.log(arguments);
        // $('#playout').load('..\\..\\resources\\plugins\\' + pluginName + '\\launch.html');
        execCMD('.\\resources\\plugins\\' + pluginName + '\\index.bat', 'pnavmenu');
        arguments = remote.getGlobal('sharedObject').prop1;
        console.log(arguments);
        var query = getArg(arguments, "--query");
        console.log(query);
        setTimeout(() => {
            $("#inputKey").val(query);
            document.getElementById("inputKey").value = query;            
        }, 4000);

    } catch (e) {
        alert(e.stack);
    }
}