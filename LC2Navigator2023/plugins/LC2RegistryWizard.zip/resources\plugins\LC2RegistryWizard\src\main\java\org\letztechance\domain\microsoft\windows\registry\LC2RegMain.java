package org.letztechance.domain.microsoft.windows.registry;

public class LC2RegMain  {

	private static final Class<LC2RegMain> CLASS = LC2RegMain.class;

	public static void main(String[] args) {
		System.out.println(""+CLASS+" running...");

	}

}
