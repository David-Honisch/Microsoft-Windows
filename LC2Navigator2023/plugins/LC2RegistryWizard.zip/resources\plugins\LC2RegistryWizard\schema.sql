select '<h4>LC2RegistryWizard Plugin SQL Import</h4>';
drop table IF EXISTS LC2RegistryWizard;
drop table IF EXISTS LC2RegistryWizardtemp;
CREATE TABLE LC2RegistryWizard ( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
create table IF NOT EXISTS LC2RegistryWizardtemp ( name varchar(255), menu TEXT, url varchar(255), subtext TEXT);
-- select 'Create table LC2RegistryWizard Import';
-- .separator "\t"
-- .import .\\import.csv LC2RegistryWizardtemp
.separator ";"
.import .\\resources\\plugins\\LC2RegistryWizard\\import\\import.csv LC2RegistryWizardtemp
--.import ..\\import\\materialnohead.csv url
--INSERT INTO person VALUES (4, 'Alice', '351246233');
-- DELETE FROM url where url.name = '';
-- select '<p>LC2RegistryWizardtemp count:';
-- select count(*) from LC2RegistryWizardtemp;
-- select '</p>';
-- select '<p>SQL Import successfully done</p>';
-- select '<p>LC2RegistryWizard count:'+count(*)+'</p>' from LC2RegistryWizardtemp;
-- select * from LC2RegistryWizardtemp limit 1;
-- select '<p>temp table COUNT:'+count(*)+'</p>' from LC2RegistryWizardtemp;
INSERT INTO LC2RegistryWizard (first_name,name, description,url) select name,name, menu,url  from LC2RegistryWizardtemp;
select '<p>LC2RegistryWizard count:';
select count(*) from LC2RegistryWizard;
select '</p>';
-- select '<p>COUNT:'+count(*)+'</p>' from LC2RegistryWizard;
-- select '<p>SQL Menu:</p><br>';
-- select '';
-- select '<hr>';
-- select '<a href="'+url+'">'+name+'</a>' from LC2RegistryWizard;
-- select '<hr>';
-- select '<p>LC2RegistryWizard count:'+count(*)+' successfully imported.</p>' from LC2RegistryWizard;
.exit