-- select '<h2>Import processes</h2>';
drop table IF EXISTS LC2RegistryWizard;
drop table IF EXISTS LC2RegistryWizard_data;
drop table IF EXISTS LC2RegistryWizard_procdata;
-- drop table IF EXISTS LC2RegistryWizardtemp;
-- drop table IF EXISTS LC2RegistryWizard_datatemp;
CREATE TABLE LC2RegistryWizard( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE LC2RegistryWizard_data( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
-- CREATE TABLE LC2RegistryWizard_procdata( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
-- CREATE TABLE IF NOT EXISTS LC2RegistryWizardtemp (
-- "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL
-- );
-- create table IF NOT EXISTS LC2RegistryWizard_datatemp ( name varchar(255));
-- CREATE TABLE IF NOT EXISTS LC2RegistryWizard_datatemp (
-- "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL
-- );
-- import menu
-- select '<p>Import processes</p>';
.separator ";"
.import .\\resources\\plugins\\LC2RegistryWizard\\import\\import.csv LC2RegistryWizard
.import '.\\resources\\plugins\\LC2RegistryWizard\\import\\menu.csv' LC2RegistryWizard_data
-- delete from LC2RegistryWizard_datatemp;
--
-- .separator ","
-- .import '.\\resources\\plugins\\LC2RegistryWizard\\import\\LC2RegistryWizardwork.csv' LC2RegistryWizard_datatemp
-- INSERT INTO LC2RegistryWizard_procdata(first_name,name,zipcode, city, description) select first_name,name,zipcode, city, description  from LC2RegistryWizard_datatemp;

select '<p>LC2RegistryWizard count:';
select count(*) from LC2RegistryWizard;
select 'LC2RegistryWizard_data count:';
select count(*) from LC2RegistryWizard_data;
select 'LC2RegistryWizard_procdata count:';
select count(*) from LC2RegistryWizard_procdata;
.separator ";"
drop table IF EXISTS LC2RegistryWizardtemp;
-- select '<p>Import done</p>';
.exit