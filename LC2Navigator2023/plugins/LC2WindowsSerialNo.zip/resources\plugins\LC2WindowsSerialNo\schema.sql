-- select '<h2>Import processes</h2>';
drop table IF EXISTS LC2WindowsSerialNo;
drop table IF EXISTS LC2WindowsSerialNo_data;
drop table IF EXISTS LC2WindowsSerialNo_procdata;
drop table IF EXISTS LC2WindowsSerialNotemp;
drop table IF EXISTS LC2WindowsSerialNo_datatemp;
CREATE TABLE LC2WindowsSerialNo( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE LC2WindowsSerialNo_data( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE LC2WindowsSerialNo_procdata( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE IF NOT EXISTS LC2WindowsSerialNotemp (
"name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL
);
-- create table IF NOT EXISTS LC2WindowsSerialNo_datatemp ( name varchar(255));
CREATE TABLE IF NOT EXISTS LC2WindowsSerialNo_datatemp (
"name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL
);
-- import menu
-- select '<p>Import processes</p>';
.separator ";"
-- .import .\\resources\\plugins\\LC2WindowsSerialNo\\import\\import.csv LC2WindowsSerialNotemp
-- INSERT INTO LC2WindowsSerialNo(first_name,name,zipcode, city, description) select first_name,name,zipcode, city, description  from LC2WindowsSerialNotemp;
.import .\\resources\\plugins\\LC2WindowsSerialNo\\import\\import.csv LC2WindowsSerialNo
--
-- eof insert work data
select 'LC2WindowsSerialNo count:';
select count(*) from LC2WindowsSerialNo;
--.separator ';'
.separator ";"
--.import '.\\resources\\plugins\\LC2WindowsSerialNo\\import\\menu.csv' LC2WindowsSerialNo_datatemp
-- .import '.\\resources\\plugins\\LC2WindowsSerialNo\\import\\menu.csv' LC2WindowsSerialNo_datatemp
-- INSERT INTO LC2WindowsSerialNo_data(first_name,name,zipcode, city, description) select first_name,name,zipcode, city, description  from LC2WindowsSerialNo_datatemp;
.import '.\\resources\\plugins\\LC2WindowsSerialNo\\import\\menu.csv' LC2WindowsSerialNo_data
delete from LC2WindowsSerialNo_datatemp;
--
-- .separator ","
-- .import '.\\resources\\plugins\\LC2WindowsSerialNo\\import\\LC2WindowsSerialNowork.csv' LC2WindowsSerialNo_datatemp
-- INSERT INTO LC2WindowsSerialNo_procdata(first_name,name,zipcode, city, description) select first_name,name,zipcode, city, description  from LC2WindowsSerialNo_datatemp;
--
select '<p>LC2WindowsSerialNo count:';
select count(*) from LC2WindowsSerialNo;
select 'LC2WindowsSerialNo_data count:';
select count(*) from LC2WindowsSerialNo_data;
select 'LC2WindowsSerialNo_procdata count:';
select count(*) from LC2WindowsSerialNo_procdata;
.separator ";"
drop table IF EXISTS LC2WindowsSerialNotemp;
-- select '<p>Import done</p>';
.exit