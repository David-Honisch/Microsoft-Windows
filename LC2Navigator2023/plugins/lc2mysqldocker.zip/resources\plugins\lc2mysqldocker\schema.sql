select '<h4>lc2mysqldocker Plugin SQL Import</h4>';
drop table IF EXISTS lc2mysqldocker;
drop table IF EXISTS lc2mysqldockertemp;
CREATE TABLE lc2mysqldocker ( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
create table IF NOT EXISTS lc2mysqldockertemp ( name varchar(255), menu TEXT, url varchar(255), subtext TEXT);
-- select 'Create table lc2mysqldocker Import';
-- .separator "\t"
-- .import .\\import.csv lc2mysqldockertemp
.separator ";"
.import .\\resources\\plugins\\lc2mysqldocker\\import\\import.csv lc2mysqldockertemp
--.import ..\\import\\materialnohead.csv url
--INSERT INTO person VALUES (4, 'Alice', '351246233');
-- DELETE FROM url where url.name = '';
-- select '<p>lc2mysqldockertemp count:';
-- select count(*) from lc2mysqldockertemp;
-- select '</p>';
-- select '<p>SQL Import successfully done</p>';
-- select '<p>lc2mysqldocker count:'+count(*)+'</p>' from lc2mysqldockertemp;
-- select * from lc2mysqldockertemp limit 1;
-- select '<p>temp table COUNT:'+count(*)+'</p>' from lc2mysqldockertemp;
INSERT INTO lc2mysqldocker (first_name,name, description,url) select name,name, menu,url  from lc2mysqldockertemp;
select '<p>lc2mysqldocker count:';
select count(*) from lc2mysqldocker;
select '</p>';
-- select '<p>COUNT:'+count(*)+'</p>' from lc2mysqldocker;
-- select '<p>SQL Menu:</p><br>';
-- select '';
-- select '<hr>';
-- select '<a href="'+url+'">'+name+'</a>' from lc2mysqldocker;
-- select '<hr>';
-- select '<p>lc2mysqldocker count:'+count(*)+' successfully imported.</p>' from lc2mysqldocker;
.exit