// alert('Fuck');
divId.innerHTML += 'Launching...';
try {
var WebTorrent= window.nodeRequire('webtorrent');
/*
var client = new WebTorrent();
client.add(torrentId, function (torrent) {
  const file = torrent.files.find(function (file) {
    return file.name.endsWith('.mp4')
  })
  file.appendTo('body')
})
*/
} catch (e) {
    // alert(e.stack);
	divId.innerHTML += 'Error:'+e.stack;
}
divId.innerHTML += 'Done.';
//alert('Bye');