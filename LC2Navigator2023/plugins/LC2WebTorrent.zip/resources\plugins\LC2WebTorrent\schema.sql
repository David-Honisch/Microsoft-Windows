-- select '<h2>Import processes</h2>';
drop table IF EXISTS LC2WebTorrent;
drop table IF EXISTS LC2WebTorrent_data;
drop table IF EXISTS LC2WebTorrent_procdata;
drop table IF EXISTS LC2WebTorrenttemp;
drop table IF EXISTS LC2WebTorrent_datatemp;
CREATE TABLE LC2WebTorrent( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE LC2WebTorrent_data( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE LC2WebTorrent_procdata( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE IF NOT EXISTS LC2WebTorrenttemp (
"name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL
);
-- create table IF NOT EXISTS LC2WebTorrent_datatemp ( name varchar(255));
CREATE TABLE IF NOT EXISTS LC2WebTorrent_datatemp (
"name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL
);
-- import menu
-- select '<p>Import processes</p>';
.separator ";"
.import .\\resources\\plugins\\LC2WebTorrent\\import\\import.csv LC2WebTorrenttemp
INSERT INTO LC2WebTorrent(first_name,name,zipcode, city, description) select first_name,name,zipcode, city, description  from LC2WebTorrenttemp;
--
-- eof insert work data
select 'LC2WebTorrent count:';
select count(*) from LC2WebTorrent;
--.separator ';'
.separator ";"
--.import '.\\resources\\plugins\\LC2WebTorrent\\import\\menu.csv' LC2WebTorrent_datatemp
.import '.\\resources\\plugins\\LC2WebTorrent\\import\\menu.csv' LC2WebTorrent_datatemp
INSERT INTO LC2WebTorrent_data(first_name,name,zipcode, city, description) select first_name,name,zipcode, city, description  from LC2WebTorrent_datatemp;
delete from LC2WebTorrent_datatemp;
--
.separator ","
.import '.\\resources\\plugins\\LC2WebTorrent\\import\\LC2WebTorrentwork.csv' LC2WebTorrent_datatemp
INSERT INTO LC2WebTorrent_procdata(first_name,name,zipcode, city, description) select first_name,name,zipcode, city, description  from LC2WebTorrent_datatemp;
--
select '<p>LC2WebTorrent count:';
select count(*) from LC2WebTorrent;
select 'LC2WebTorrent_data count:';
select count(*) from LC2WebTorrent_data;
select 'LC2WebTorrent_procdata count:';
select count(*) from LC2WebTorrent_procdata;
.separator ";"
drop table IF EXISTS LC2WebTorrenttemp;
-- select '<p>Import done</p>';
.exit