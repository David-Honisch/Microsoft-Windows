'use strict';
var appConfig;
window.onload = init();

function init() {
    getHead();
    $('#out').append('RUNNING DONE.');
    console.log('INIT RUNNING...');
    $('#out').append('INIT RUNNING...');

    if (fs.existsSync(APPCFG)) {
        console.log(APPCFG + " file exists.");
        appConfig = getAppConfig(APPCFG);

    } else {
        console.log(APPCFG + ' file does not exist.\nCreating new Configuration file.' + APPCFG);

        //  setAppConfig(APPCFG, appConfig);
    }
    if ($.urlParam('db') !== undefined) {
        console.log($.urlParam('db') + " exists.");
        var item = readItem($.urlParam('db'), $.urlParam('id'));
        console.log(item);
        if (item[0] !== undefined && item[0]['name'] !== undefined) {
            $('#name').val(item[0]['name']);
            $('#first_name').val(item[0]['first_name']);
            $('#last_name').val(item[0]['last_name']);
            $('#street').val(item[0]['street']);
            $('#zipcode').val(item[0]['zipcode']);
            $('#description').val(item[0]['description']);
            $('#url').val(item[0]['url']);
        }


    } else {
        console.log(tableName + " does not exists.");

        //  setAppConfig(APPCFG, appConfig);
    }
    $('#submenu, #alertcnt').on('click', 'a[href^="http"]', function(event) {
        event.preventDefault();
        console.log(this.href + " opens...");
        shell.openExternal(this.href);
    });
    $('#out').html('Successfully done.');


    $('#out').html('Successfully done.');

    console.log('DONE.');
}

function getHead() {
    document.title = 'LETZECHANCE.ORG - Edit Item';
    var head = getHeader(cfg.local);
    // console.log(JSON.stringify(head));    
    $('#head').html(head);
    $('#ptitle').html('LC2Navigator Home - Edit Item');
}