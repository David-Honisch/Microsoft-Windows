<?php
function setUnauthorized()
{
    header('WWW-Authenticate: Basic realm="Test Authentication System"');
    header('HTTP/1.0 401 Unauthorized');
    echo "Bitte geben Sie eine gültige Login-ID und das Passwort für den
        Zugang ein\n";
    exit;
}
function  require_auth2()
{


    if (
        !isset($_SERVER['PHP_AUTH_USER']) ||
        ($_POST['Gesehen'] == 1 && $_POST['AlteAuth'] == $_SERVER['PHP_AUTH_USER'])
    ) {
        setUnauthorized();
    } else {
        echo "<p>Willkommen: " . htmlspecialchars($_SERVER['PHP_AUTH_USER']) . "<br />";
        echo "Alt: " . htmlspecialchars($_REQUEST['AlteAuth']);
        echo "<form action='' method='post'>\n";
        echo "<input type='hidden' name='Gesehen' value='1' />\n";
        echo "<input type='hidden' name='AlteAuth' value=\"" . htmlspecialchars($_SERVER['PHP_AUTH_USER']) . "\" />\n";
        echo "<input type='submit' value='Erneut Anmelden' />\n";
        echo "</form></p>\n";
    }
}
function require_digest_auth()
{
    $realm = 'Geschützter Bereich';

    // Benutzer => Passwort
    $benutzer = array('admin' => 'rootpassword', 'gast' => 'gast');

    if (empty($_SERVER['PHP_AUTH_DIGEST'])) {
        header('HTTP/1.1 401 Unauthorized');
        header('WWW-Authenticate: Digest realm="' . $realm .
            '",qop="auth",nonce="' . uniqid() . '",opaque="' . md5($realm) . '"');

        die('Text, der gesendet wird, falls der Benutzer auf Abbrechen drückt');
    }

    // Analysieren der Variable PHP_AUTH_DIGEST
    if (
        !($daten = http_digest_parse($_SERVER['PHP_AUTH_DIGEST'])) ||
        !isset($benutzer[$daten['username']])
    )
        die('Falsche Zugangsdaten!');

    // Erzeugen einer gültigen Antwort
    $A1 = md5($daten['username'] . ':' . $realm . ':' . $benutzer[$daten['username']]);
    $A2 = md5($_SERVER['REQUEST_METHOD'] . ':' . $daten['uri']);
    $gueltige_antwort = md5($A1 . ':' . $daten['nonce'] . ':' . $daten['nc'] .
        ':' . $daten['cnonce'] . ':' . $daten['qop'] . ':' . $A2);

    if ($daten['response'] != $gueltige_antwort)
        die('Falsche Zugangsdaten!');

    // OK, gültige Benutzername & Passwort
    echo 'Sie sind angemeldet als: ' . $daten['username'];
}

// Funktion zum analysieren der HTTP-Auth-Header
function http_digest_parse($txt)
{
    // gegen fehlende Daten schützen
    $noetige_teile = array(
        'nonce' => 1, 'nc' => 1, 'cnonce' => 1, 'qop' => 1,
        'username' => 1, 'uri' => 1, 'response' => 1
    );
    $daten = array();
    $schluessel = implode('|', array_keys($noetige_teile));

    preg_match_all(
        '@(' . $schluessel . ')=(?:([\'"])([^\2]+?)\2|([^\s,]+))@',
        $txt,
        $treffer,
        PREG_SET_ORDER
    );

    foreach ($treffer as $t) {
        $daten[$t[1]] = $t[3] ? $t[3] : $t[4];
        unset($noetige_teile[$t[1]]);
    }

    return $noetige_teile ? false : $daten;
}
