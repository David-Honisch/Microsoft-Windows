<?php

class CURLHelper
{
    // $userName = 'postman';
    // $password = 'password';
    //'https://postman-echo.com/basic-auth',
    function getCURL($userNamem, $password, $url)
    {
        $curlHandler = curl_init();
        curl_setopt_array($curlHandler, [
            CURLOPT_URL =>  $url, 
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_HTTPAUTH => CURLAUTH_BASIC,
            CURLOPT_USERPWD => $userNamem . ':' . $password,
        ]);

        $res = curl_exec($curlHandler);
        echo $res;
        curl_close($curlHandler);
    }
}
