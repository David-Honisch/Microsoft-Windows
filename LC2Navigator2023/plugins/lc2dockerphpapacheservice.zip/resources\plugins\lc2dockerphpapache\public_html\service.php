<?php  
$cfgScript = './config/const.cls.php';
if (file_exists($cfgScript)) {
	require_once ($cfgScript);
} else {
	echo "503 - Page Configuration not found.";
	die();
}
?>
<!DOCTYPE html>
<html lang="de" ng-app="app">

<head>
    <meta charset="utf-8">
    <!-- <meta http-equiv="Content-Security-Policy" content="script-src 'self';"> -->
    <!-- <meta http-equiv="Content-Security-Policy" content="default-src 'unsafe-inline'; style-src 'unsafe-inline'"> -->
    <title><?php echo $env["hptitle"]; ?></title>
    <base href="./">
    <link rel="stylesheet" type="text/css" href="assets/js/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/js/angular/bootstrap-combined.min.css" />
    <link rel="stylesheet" type="text/css" href="assets/css/bootstrap-clearmin.min.css">
    <link rel="stylesheet" type="text/css" href="assets/js/jquery/ui/jquery-ui.css">
    <link rel="stylesheet" type="text/css" href="assets/css/material-design.css">
    <link rel="stylesheet" type="text/css" href="assets/css/small-n-flat.css">
    <link rel="stylesheet" type="text/css" href="assets/css/summernote.css">
    <link rel="stylesheet" type="text/css" href="assets/css/core.css">

    <script src="assets/js/controller/electron.js "></script>
    <script src="assets/js/jquery/jquery.min.js"></script>
    <script src="assets/js/jquery/ui/jquery-ui.min.js"></script>
    <script src="assets/js/bootstrap.min.js"></script>
    <script src="assets/js/angular/angular.min.js"></script>
    <script src="assets/js/angular/ui-bootstrap-tpls-0.4.0.min.js"></script>
    <script src="assets/js/jquery.cookie/js.cookie.min.js"></script>
    
    <script src="assets/js/jquery.mousewheel.min.js"></script>
    <script src="assets/js/fastclick.min.js"></script>
    <script src="assets/summernote.min.js   "></script>
    <script src="assets/clearmin/clearmin.min.js"></script>

    
</head>

<body class="cm-no-transition cm-1-navbar" ng-controller='AppController'>
    <div id="cm-menu">
        <nav class="cm-navbar cm-navbar-primary">
            <div class="cm-flex">
                <a href="index.php" class="cm-logo"></a>
            </div>
            <div class="btn btn-primary md-menu-white" data-toggle="cm-menu"></div>
        </nav>
        <div id="cm-menu-content">
            <div id="cm-menu-items-wrapper">
                <div id="cm-menu-scroller">
                    <ul class="cm-menu-items">
                    <li><a href="/" target="_blank"  class="sf-house">Home</a></li>
                        <li class="cm-submenu">
                            <a class="sf-lock">Login<span class="caret"></span></a>
                            <ul id="submenu">
                                <li><a href="./index.php?q=login" target="_parent">Login</a></li>
                                <li><a href="./index.php?q=logout" target="_parent">Logout</a></li>
                            </ul>
                        </li>

                        <li ng-repeat="item in menu"><a href="{{item.url}}" onclick="{{item.click}}" class="{{item.icon}}">{{item.name}}</a></li>

                        <li class="cm-submenu">
                            <a class="sf-window-layout">Tables<span class="caret"></span></a>
                            <ul>
                                <li ng-repeat="item in data"><a href="list.html?db={{item.name}}">{{item.name}}</a></li>
                            </ul>
                        </li>

                        <li class="cm-submenu">
                            <a class="sf-window-layout">Online<span class="caret"></span></a>
                            <ul id="submenu">
                                <li ng-repeat="item in index"><a href="https://www.letztechance.org/list-{{item.id}}-1.html" target="_blank">{{item.name}}</a></li>
                            </ul>
                        </li>

                    </ul>
                </div>
            </div>
        </div>
    </div>
    <header id="cm-header">
        <nav id="headcnt" class="cm-navbar cm-navbar-primary">
            <div class="btn btn-primary md-menu-white hidden-md hidden-lg" data-toggle="cm-menu"></div>
            <div class="cm-flex">
                <h1 id="ptitle"><?php echo $env["hptitle"]; ?></h1>
                <form id="cm-search" action="index.php" method="get">
                    <input type="search" name="q" autocomplete="off" placeholder="Search...">
                </form>
            </div>
            <div class="pull-right">
                <div id="cm-search-btn" class="btn btn-primary md-search-white" data-toggle="cm-search"></div>
            </div>
            <div class="dropdown pull-right">
                <button class="btn btn-primary md-notifications-white" data-toggle="dropdown"> <span class="label label-danger">{{news.length}}</span> </button>
                <div class="popover cm-popover bottom">
                    <div class="arrow"></div>
                    <div class="popover-content">
                        <div class="list-group" id="alertcnt">
                            <a href="index.php" class="list-group-item">
                                <h4 class="list-group-item-heading">
                                    <i class="fa fa-fw fa-warning"></i><?php echo $env["hptitle"]; ?>
                                </h4>
                                <p class="list-group-item-text">Application.</p>
                            </a>

                            <a ng-repeat="item in news" href="https://www.letztechance.org/read-{{item.table}}-{{item.id}}.html" target="_blank" class="list-group-item">
                                <h4 class="list-group-item-heading">
                                    <i class="fa fa-fw fa-warning"></i>{{item.subject}}
                                </h4>
                                <p class="list-group-item-text">{{item.datestamp}}.</p>
                            </a>

                        </div>
                        <div style="padding:10px"><a class="btn btn-success btn-block" href="index.php#news">Show me more...</a></div>
                    </div>
                </div>
            </div>
            <div class="dropdown pull-right">
                <button class="btn btn-primary md-account-circle-white" data-toggle="dropdown"></button>
                <ul class="dropdown-menu">
                    <li class="disabled text-center">
                        <a style="cursor:default;"><strong>Anoymous</strong></a>
                    </li>
                    <!-- <li class="divider"></li>
                    <li>
                        <a href="#"><i class="fa fa-fw fa-user"></i> Profile</a>
                    </li>
                    <li>
                        <a href="#"><i class="fa fa-fw fa-cog"></i> Settings</a>
                    </li>
                    <li>
                        <a href="login.html"><i class="fa fa-fw fa-sign-out"></i> Sign out</a>
                    </li> -->
                </ul>
            </div>
        </nav>
    </header>
    <div id="global">
        <div class="container-fluid cm-container-white">
        <a href="/" target="_parent"><h2 style="margin-top:0;">Welcome to LetzteChance.Org</h2></a>
            <p>Search and find.</p>
            <fieldset>
                <ul class="hlistul">
                    <li ng-repeat="item in menu"><a href="{{item.url}}" onclick="{{item.click}}" target="{{item.target}}">{{item.name}}</a></li>
                </ul>
            </fieldset>          

           
            <fieldset>
                <legend id="golegend">{{pageName}}</legend>
                <?php 
                $script = $env["include"] .'/page/page.cls.php';
                if (file_exists($script)) {
                    require_once ($script);
                } else {
                    echo "404 - Page not found.";
                    die();
                }
                
                ?>
                <div id="out"></div>
                
            </fieldset>
        </div>
        <div class="container-fluid ">

            <div class="panel panel-default">
                <div class="panel-heading ">History:</div>
                <div class="panel-body " id="fw-buttons">
                    <div class="row">
                        <!-- Node.js <span id="node-version"></span>, Chromium <span id="chrome-version"></span>, and Electron <span id="electron-version"></span>. -->

                        <div class="col-xs-6 col-sm-4 col-md-3 col-lg-2" style="min-width:120px;width:auto;">
                            <button class="btn btn-block btn-primary" data-switch-color="primary" onclick="history.back();">Back</button>
                            <br>
                        </div>
                        <div class="col-xs-6 col-sm-4 col-md-3 col-lg-2" style="min-width:120px;width:auto;">
                            <button class="btn btn-block btn-success" data-switch-color="success" onclick="history.go(-1);">Previous</button>
                            <br>
                            <span id="chrome-version"></span>
                        </div>
                    </div>

                </div>
            </div>

            <div class="row cm-fix-height ">
                <div class="col-sm-4" ng-repeat="item in pagedItems">
                    <div class="panel panel-default">
                        <div class="panel-body ">
                            <img src="assets/img/sf/star.svg" alt="Responsive across devices" class="img-responsive">
                            <br>
                            <p>{{item.name}}</p>
                            <a href="list.html?db={{item.subject}}" class="panel panel-default thumbnail cm-thumbnail">
                                <div class="panel-body text-center">
                                    <span class="svg-48">
                                            <img src="assets/img/sf/dashboard.svg" alt="{{item.subject}}">
                                        </span>
                                    <h4>{{item.subject}}</h4> <small>{{item.body}}</small>

                                </div>
                            </a>
                        </div>
                    </div>
                </div>
                <div class="panel panel-default ">
                    <div class="panel-heading ">Currently used based frameworks:</div>
                    <div class="panel-body " id="fw-buttons">
                        <div class="row">


                            <div class="col-xs-6 col-sm-4 col-md-3 col-lg-2" style="min-width:120px;width:auto;">
                                <button class="btn btn-block btn-primary" data-switch-color="primary">Node.js</button>
                                <br>
                                <span id="node-version"></span>
                            </div>
                            <div class="col-xs-6 col-sm-4 col-md-3 col-lg-2" style="min-width:120px;width:auto;">
                                <button class="btn btn-block btn-success" data-switch-color="success">Chromium</button>
                                <br>
                                <span id="chrome-version"></span>
                            </div>
                            <div class="col-xs-6 col-sm-4 col-md-3 col-lg-2" style="min-width:120px;width:auto;">
                                <button class="btn btn-block btn-info " data-switch-color="info">Electron</button>
                                <br>
                                <span id="electron-version"></span>
                            </div>
                        </div>

                    </div>
                </div>
            </div>


        </div>
        <!-- <button type="button" onclick="loadXMLDoc('out','/webservices/menu.xml','CD', ['PARENT', 'TITLE'])">START</button>
        <input id="importGUI" type="button" value="Show Import GUI" onclick="getOpenDialog('#importGUI_cnt','.\\resources\\html\\import.html','Install',{ minWidth: 250,  minHeight: 150, width: 400});"></input>
        <div id="importGUI_cnt"></div>
        <input type="button" name="addItem" id="addItem" value="Confirm" onClick="conFirmDialog('#dialog','Test','Add now ?',{})" />
        <div id="dialog" title="Dialog">
            <div id="dialogcnt" title="Dialog">
            </div>
        </div> -->

        <footer class="cm-footer "><span class="pull-left ">Connected as anonymous</span><span class="pull-right ">&copy; David Honisch</span></footer>
    </div>

    <script src="assets/js/jquery/jquery.min.js"></script>
    <script src="assets/js/jquery.cookie/js.cookie.min.js"></script>
    <script src="assets/js/controller/api.js "></script>
    <script src="assets/js/actions/api.js"></script>
    
    <script src="assets/js/clearmin/clearmin.min.js "></script>
    <!-- <script src="assets/js/controller/app.js "></script> -->

    <!-- <script src="assets/js/actions/main.js"></script> -->
</body>
</html>