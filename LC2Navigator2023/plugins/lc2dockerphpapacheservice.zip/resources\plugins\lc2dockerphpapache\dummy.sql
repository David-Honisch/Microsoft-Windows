select 'RUNNING';
create database upload;
create database uploads;