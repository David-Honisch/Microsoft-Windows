
<fieldset>
<input type="text" value="admin" name="user" id="user">
<input type="text" value="rootpassword" name="password" id="password">
<input type="button" value="Submit" name="postbutton" id="postbutton">
</fieldset>
<?PHP
// 	"http://localhost/admin/?login" - for Login,
	// "http://localhost/admin/?logout" - for Logout,
	// "http://localhost/admin/?logout&login" - for Re-Login.
	$AUTH_USER = 'admin';
	$AUTH_PASS = 'rootpassword';

	session_start();

	$authorized = false;

	# LOGOUT
	if (isset($_GET['logout']) && !isset($_GET["login"]) && isset($_SESSION['auth'])) {
		$_SESSION = array();
		unset($_COOKIE[session_name()]);
		session_destroy();
		echo "logging out...";
	}

	# checkup login and password
	if (isset($_REQUEST['user']) && isset($_REQUEST['password'])) {
		 if (($AUTH_USER == $_REQUEST['user']) && ($AUTH_PASS == ($_REQUEST['password'])) && isset($_SESSION['auth'])) {
			$authorized = true;
		 }
	}


echo "Logging in...";
?>