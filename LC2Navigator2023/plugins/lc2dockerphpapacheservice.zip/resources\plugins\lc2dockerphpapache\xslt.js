// import { xsltProcess, xmlParse } from 'xslt-processor'
function getXsltProcess(source, target) {
    const path = window.nodeRequire('path');
    const fs = window.nodeRequire('fs');
    const { xsltProcess, xmlParse } = window.nodeRequire('xslt-processor');
    // var source = ".\\resources\\plugins\\LC2JXMLTransform\\xml\\urls.xml";
    // var target = ".\\resources\\plugins\\LC2JXMLTransform\\xml\\urlsext.xslt";
    const xmlString = fs.readFileSync(source, { encoding: 'utf8', flag: 'r' });
    const xsltString = fs.readFileSync(target, { encoding: 'utf8', flag: 'r' });
    return outXmlString = xsltProcess(
        xmlParse(xmlString),
        xmlParse(xsltString)
    );
}
// var source = ".\\resources\\plugins\\LC2JXMLTransform\\xml\\urls.xml";
// var target = ".\\resources\\plugins\\LC2JXMLTransform\\xml\\urlsext.xslt";
// var outXmlString = getXsltProcess(source, target);
// console.log(outXmlString);
// document.getElementById('app_cnt').innerHTML += outXmlString;
// alert('Done');