try {
    document.getElementById("appcnt").innerHTML = "";
    document.getElementById("build").innerHTML = "<div class=\"preload\"></div>";

    execCMD('.\\resources\\plugins\\' + pluginName + '\\build.bat install', 'build');
    document.getElementById("appcnt").innerHTML += "<h1>Build successfully done</h1>";

    // doUnzip(downloadUrls, targetDir);
} catch (e) {
    alert(e.stack);
}