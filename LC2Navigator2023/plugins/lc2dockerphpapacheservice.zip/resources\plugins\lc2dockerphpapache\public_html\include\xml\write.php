<?
# This file is part of Web-XML

# Web-XML is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.

# Web-XML is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.

# You should have received a copy of the GNU General Public License
# along with Web-XML; if not, write to the Free Software
# Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA

# This work is Copyright (C)2006 by Ryan Kelley
# Individual portions may be copyright by individual contributors, and
# are included in this collective work with permission of the copyright
# owners.

include("class.inc.php");

if(empty($_POST['xml']))
{
	kill();
	exit();
}
?>
<html>
<head>
	<title>NETS - XML Editor</title>
	<link rel='stylesheet' href='http://www.uri.edu/security/news.css' type='text/css' media='screen'>
</head>
<body>
<div align="center">The output of file is located <a href="<?print(pull($_POST['id']));?>">here</a>.</div>
<?
$key = array();
//$key = $_POST['xml'];
//write(pull($_POST['id']),$key);
$key = $_GET['xml'];
write(pull($_GET['id']),$key);
?>

</body>
</html>
