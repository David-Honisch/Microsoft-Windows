-- select '<h2>Import processes</h2>';
drop table IF EXISTS LC2OpenSSH;
drop table IF EXISTS LC2OpenSSH_data;
drop table IF EXISTS LC2OpenSSH_procdata;
drop table IF EXISTS LC2OpenSSHtemp;
drop table IF EXISTS LC2OpenSSH_datatemp;
CREATE TABLE LC2OpenSSH( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE LC2OpenSSH_data( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE LC2OpenSSH_procdata( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE IF NOT EXISTS LC2OpenSSHtemp (
"name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL
);
-- create table IF NOT EXISTS LC2OpenSSH_datatemp ( name varchar(255));
CREATE TABLE IF NOT EXISTS LC2OpenSSH_datatemp (
"name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL
);
-- import menu
-- select '<p>Import processes</p>';
.separator ";"
-- .import .\\resources\\plugins\\LC2OpenSSH\\import\\import.csv LC2OpenSSHtemp
-- INSERT INTO LC2OpenSSH(first_name,name,zipcode, city, description) select first_name,name,zipcode, city, description  from LC2OpenSSHtemp;
.import .\\resources\\plugins\\LC2OpenSSH\\import\\import.csv LC2OpenSSH
--
-- eof insert work data
select 'LC2OpenSSH count:';
select count(*) from LC2OpenSSH;
--.separator ';'
.separator ";"
--.import '.\\resources\\plugins\\LC2OpenSSH\\import\\menu.csv' LC2OpenSSH_datatemp
-- .import '.\\resources\\plugins\\LC2OpenSSH\\import\\menu.csv' LC2OpenSSH_datatemp
-- INSERT INTO LC2OpenSSH_data(first_name,name,zipcode, city, description) select first_name,name,zipcode, city, description  from LC2OpenSSH_datatemp;
.import '.\\resources\\plugins\\LC2OpenSSH\\import\\menu.csv' LC2OpenSSH_data
delete from LC2OpenSSH_datatemp;
--
-- .separator ","
-- .import '.\\resources\\plugins\\LC2OpenSSH\\import\\LC2OpenSSHwork.csv' LC2OpenSSH_datatemp
-- INSERT INTO LC2OpenSSH_procdata(first_name,name,zipcode, city, description) select first_name,name,zipcode, city, description  from LC2OpenSSH_datatemp;
--
select '<p>LC2OpenSSH count:';
select count(*) from LC2OpenSSH;
select 'LC2OpenSSH_data count:';
select count(*) from LC2OpenSSH_data;
select 'LC2OpenSSH_procdata count:';
select count(*) from LC2OpenSSH_procdata;
.separator ";"
drop table IF EXISTS LC2OpenSSHtemp;
-- select '<p>Import done</p>';
.exit