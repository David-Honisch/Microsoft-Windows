-- select '<h2>Import current process data</h2>';
-- drop table IF EXISTS LC2OpenSSH;
-- drop table IF EXISTS LC2OpenSSH_data;
drop table IF EXISTS LC2OpenSSH_procdata;
drop table IF EXISTS LC2OpenSSH_procdatatemp;
-- CREATE TABLE LC2OpenSSH( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
-- CREATE TABLE LC2OpenSSH_data( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE LC2OpenSSH_procdata( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE IF NOT EXISTS LC2OpenSSH_procdatatemp (
"name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL
);
-- import menu
-- select '<p>Import processes</p>';

-- delete from LC2OpenSSH_datatemp;
--
.separator ","
.import '.\\resources\\plugins\\LC2OpenSSH\\import\\LC2OpenSSHwork.csv' LC2OpenSSH_procdatatemp
INSERT INTO LC2OpenSSH_procdata(first_name,name,zipcode, city, description) select first_name,name,zipcode, city, description  from LC2OpenSSH_procdatatemp;
--
select 'LC2OpenSSH_procdata count:';
select count(*) from LC2OpenSSH_procdata;
.separator ";"
drop table IF EXISTS LC2OpenSSH_procdatatemp;
-- select '<p>Import done</p>';
.exit