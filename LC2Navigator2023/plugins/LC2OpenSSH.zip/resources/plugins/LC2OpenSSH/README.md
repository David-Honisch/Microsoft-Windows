# LC2OpenSSH Documents and Examples

## LC2OpenSSH Cookbook

The LC2OpenSSH Cookbook shares example code for accomplishing common tasks with the [openssh API].

To run these examples, you'll need an openssh configuration.
more coming soon...

[![Open in GitHub Codespaces

[openssh]: https://www.openssh.com/portable.html


[chatgpt]: https://chat.openai.com/
[openai api]: https://openai.com/api/
[api signup]: https://beta.openai.com/signup
[openai playground]: https://beta.openai.com/playground
[openai documentation]: https://beta.openai.com/docs/introduction
[openai community forum]: https://community.openai.com/top?period=monthly
[openai discord channel]: https://discord.com/invite/openai
[openai help center]: https://help.openai.com/en/
[openai examples]: https://beta.openai.com/examples
[openai blog]: https://openai.com/blog/
[issues page]: https://github.com/openai/openai-cookbook/issues
