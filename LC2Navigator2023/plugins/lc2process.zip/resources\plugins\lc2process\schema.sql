-- select '<h2>Import processes</h2>';
drop table IF EXISTS lc2process;
drop table IF EXISTS lc2process_data;
drop table IF EXISTS lc2process_procdata;
drop table IF EXISTS lc2processtemp;
drop table IF EXISTS lc2process_datatemp;
CREATE TABLE lc2process( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE lc2process_data( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE lc2process_procdata( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE IF NOT EXISTS lc2processtemp (
"name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL
);
-- create table IF NOT EXISTS lc2process_datatemp ( name varchar(255));
CREATE TABLE IF NOT EXISTS lc2process_datatemp (
"name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL
);
-- import menu
-- select '<p>Import processes</p>';
.separator ";"
.import .\\resources\\plugins\\lc2process\\import\\import.csv lc2processtemp
INSERT INTO lc2process(first_name,name,zipcode, city, description) select first_name,name,zipcode, city, description  from lc2processtemp;
--
-- eof insert work data
select 'lc2process count:';
select count(*) from lc2process;
--.separator ';'
.separator ";"
--.import '.\\resources\\plugins\\lc2process\\import\\menu.csv' lc2process_datatemp
.import '.\\resources\\plugins\\lc2process\\import\\menu.csv' lc2process_datatemp
INSERT INTO lc2process_data(first_name,name,zipcode, city, description) select first_name,name,zipcode, city, description  from lc2process_datatemp;
delete from lc2process_datatemp;
--
.separator ","
.import '.\\resources\\plugins\\lc2process\\import\\lc2processwork.csv' lc2process_datatemp
INSERT INTO lc2process_procdata(first_name,name,zipcode, city, description) select first_name,name,zipcode, city, description  from lc2process_datatemp;
--
select '<p>lc2process count:';
select count(*) from lc2process;
select 'lc2process_data count:';
select count(*) from lc2process_data;
select 'lc2process_procdata count:';
select count(*) from lc2process_procdata;
.separator ";"
drop table IF EXISTS lc2processtemp;
-- select '<p>Import done</p>';
.exit