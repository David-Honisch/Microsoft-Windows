select '<h2>PROCESSIMPORT</h2>';
drop table IF EXISTS lc2process;
drop table IF EXISTS lc2processtemp;
CREATE TABLE lc2process( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE IF NOT EXISTS lc2processtemp (
 name TEXT,
 --pid DECIMAL(10,5),
 pid TEXT,
 ftype TEXT,
 tpid TEXT,
 mem TEXT
);
.separator ","
.import .\\resources\\plugins\\lc2process\\lc2processwork.csv lc2processtemp
select 'COUNT:'+count(*) from lc2processtemp;
INSERT INTO lc2process(first_name,name,zipcode, city, description) select name,name, pid,ftype,tpid  from lc2processtemp;
select 'Process count:';
select 'COUNT:'+count(*) from lc2process;
.exit