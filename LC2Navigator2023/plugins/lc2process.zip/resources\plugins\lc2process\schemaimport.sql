select '<h2>Import current process data</h2>';
-- drop table IF EXISTS lc2process;
-- drop table IF EXISTS lc2process_data;
drop table IF EXISTS lc2process_procdata;
drop table IF EXISTS lc2process_procdatatemp;
-- CREATE TABLE lc2process( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
-- CREATE TABLE lc2process_data( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE lc2process_procdata( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE IF NOT EXISTS lc2process_procdatatemp (
"name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL
);
-- import menu
-- select '<p>Import processes</p>';

-- delete from lc2process_datatemp;
--
.separator ","
.import '.\\resources\\plugins\\lc2process\\import\\lc2processwork.csv' lc2process_procdatatemp
INSERT INTO lc2process_procdata(first_name,name,zipcode, city, description) select first_name,name,zipcode, city, description  from lc2process_procdatatemp;
--
select 'lc2process_procdata count:';
select count(*) from lc2process_procdata;
.separator ";"
drop table IF EXISTS lc2process_procdatatemp;
-- select '<p>Import done</p>';
.exit