var hostName = "http://localhost:5000";
var pluginName = "lc2process";
const installDirectories = [
    'resources\\plugins\\lcwebclient_final',
    'resources\\plugins\\lcwebclient_final\\lcwebclient_final_lib',
    'resources\\plugins\\org.letztechance.domain.web.GrabUrls',
    'resources\\plugins\\org.letztechance.domain.web.GrabUrls\\org.letztechance.domain.web.GrabUrls_lib',

];
var corelibs = [
    'jquery',
    'https',
    'stream',
    'line-reader',
    'fs',
    'request',
    'runtime-npm-install',
    'decompress-zip',
    // 'extract-zip',
    'csv',
    'jszip',
    'sax',
    'xlsx',
    'xlsx-to-json',
    'xlsx-to-json-lc',
    'xml2js',
    'xmlbuilder',
    'xmldom',
    'xml-js',
    'xmljson'
];
const rlibs = corelibs;

var downloadUrls = [
	{
        path: "https://www.letztechance.org/img.png?width=400&height=400&image=logo.png&text=lc2process&r=20&g=20&b=20&test=.",
        file: "logo.png"
    }

];