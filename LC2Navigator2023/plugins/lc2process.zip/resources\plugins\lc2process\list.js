// var app = angular.module('app', ['ui.bootstrap']);
app.controller('InsideCtrl', ['$scope', function($scope) {
    var vm = this;
    vm.states2 = ["NY", "CA", "WA"];
}]);
// app.controller('PluginListController', [function($scope, $http, $filter) {
//     var vm = this;
//     vm.pluginData = null;
//     vm.states2 = ["NY", "CA", "WA"];
//     var pres = model.GetQuery(dbPath, 'select * from lc2process');
//     // console.log(JSON.stringify(res));
//     var plist = {
//         "Data": []
//     };

//     for (var v in pres) {
//         // console.log(JSON.stringify(v));
//         var t = {
//             "id": pres[v]['person_id'],
//             "name": pres[v]['name'],
//             "first_name": pres[v]['first_name'],
//             "last_name": pres[v]['last_name'],
//             "zipcode": pres[v]['zipcode'],
//             "url": pres[v]['url']
//         };
//         // console.log(JSON.stringify(t));
//         plist['Data'].push(t);
//     }
//     // console.log(JSON.stringify(list.Data));
//     vm.pluginData = plist.Data;

// }]);

function PluginListController($scope, $http, $filter) {
    var vm = $scope;
    //     const path = window.nodeRequire('path');
    //     // default values for pagination and filtering
    vm.pluginSize = 20;
    vm.pmaxSize = 25;
    vm.pstart = 0;
    vm.pend = 0;
    vm.pcurrentPage = 0;
    vm.pnumOfPages = 0;
    vm.pfilteredItems = [];
    vm.pstartItems = [];
    vm.pluginItems = [];
    vm.pcurrentTable = "lc2process";
    vm.pluginData = null;
    //     vm.pquery = { pbrowser: "" };


    //     var q = '';
    var pres = model.GetQuery(dbPath, 'select * from lc2process');
    // console.log(JSON.stringify(res));
    var plist = {
        "Data": []
    };

    for (var v in pres) {
        // console.log(JSON.stringify(v));
        var t = {
            "id": pres[v]['person_id'],
            "name": pres[v]['name'],
            "first_name": pres[v]['first_name'],
            "last_name": pres[v]['last_name'],
            "zipcode": pres[v]['zipcode'],
            "url": pres[v]['url']
        };
        // console.log(JSON.stringify(t));
        plist['Data'].push(t);
    }
    // console.log(JSON.stringify(list.Data));
    vm.pluginData = plist.Data;


    // when the data is altered, filter the items and set the page
    vm.$watch('pluginData', function(pluginData, old) {
        vm.pfilteredItems = $filter('filter')(pluginData, vm.pquery);
        if (old === null) _setPage();
    });

    // when the query value changes, refilter the data
    vm.$watch('query|json', function() {
        vm.pfilteredItems = $filter('filter')(vm.pluginData, vm.pquery);
    });

    // set the pagination for the filtered items
    function _setPage() {
        vm.pstart = (vm.pcurrentPage - 1) * vm.pluginSize + (vm.pfilteredItems === undefined && vm.pfilteredItems.length ? 1 : 0);
        vm.pstartItems = $filter('pstartFrom')(vm.pfilteredItems, vm.pstart - 1);
    }

    // when the current page is changed by the pagination control, update the list of items
    vm.$watch('pcurrentPage', function(page) {
        _setPage();
    });

    // when the filtered items are set, recalculate the number of pages
    vm.$watch('pfilteredItems', function(pitems, old) {
        vm.pcurrentPage = 0;
        if (pitems !== undefined && pitems.length !== undefined)
            vm.pnumOfPages = Math.ceil(pitems.length / vm.pluginSize);
    });

    // when the page start is changed, update the list of paged items
    vm.$watch('pstartItems', function(pitems) {
        vm.pluginItems = $filter('limitTo')(pitems, vm.pluginSize);
        vm.pend = (vm.pcurrentPage - 1) * vm.pluginSize + vm.pluginItems.length;
    });



}

// angular directive to change default behavior from processing input change immediately to on blur or enter
// app.directive('ngModelBlur', function() {
//     return {
//         restrict: 'A',
//         require: 'ngModel',
//         link: function(scope, elm, attr, ngModelCtrl) {
//             if (attr.type === 'radio' || attr.type === 'checkbox') { return; }

//             elm.unbind('input').unbind('keydown').unbind('change');
//             elm.bind('blur keydown', function(e) {
//                 if (e.type === 'keydown' && e.which !== 13) { return; }

//                 scope.$apply(function() {
//                     ngModelCtrl.$setViewValue(elm.val());
//                 });
//             });
//         }
//     };
// });

// angular filter to take array items starting from provided index
// app.filter('pstartFrom', function() {
//     return function(pinput, pstart) {
//         if (angular.isArray(pinput)) {
//             var st = parseInt(pstart, 10);
//             if (isNaN(st)) st = 0;
//             return pinput.slice(st);
//         }
//         return pinput;
//     };
// });