select '<h4>lc2kubernetes Plugin SQL Import</h4>'; 
drop table IF EXISTS lc2kubernetes;
drop table IF EXISTS lc2kubernetestemp;
CREATE TABLE lc2kubernetes ( 'person_id' INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, 'created' TIMESTAMP DEFAULT CURRENT_TIMESTAMP NULL, 'modified' TIMESTAMP DEFAULT CURRENT_TIMESTAMP NULL, 'enddate' TIMESTAMP DEFAULT CURRENT_TIMESTAMP NULL, 'name' TEXT NOT NULL, 'first_name' TEXT NULL, 'description' TEXT NULL, 'zipcode' TEXT NULL, 'city' TEXT NULL,	 'street' TEXT NULL,	 'url' TEXT NULL);
create table IF NOT EXISTS lc2kubernetestemp ( name varchar(255), menu TEXT, url varchar(255), subtext TEXT);
.separator ';'
.import .\\resources\\plugins\\lc2kubernetes\\import\\import.csv lc2kubernetestemp
INSERT INTO lc2kubernetes (first_name,name, description,url) select name,name, menu,url  from lc2kubernetestemp;
select '<p>lc2kubernetes count:';
select count(*) from lc2kubernetes;
select '</p>';
.exit
