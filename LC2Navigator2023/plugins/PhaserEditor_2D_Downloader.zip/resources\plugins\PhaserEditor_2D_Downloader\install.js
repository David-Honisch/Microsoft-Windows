try {
    document.getElementById("appcnt").innerHTML = "";
    document.getElementById("modcnt").innerHTML = "";
    for (var v in installDirectories) {
        createDir(installDirectories[v]);
    }
    var opath = window.nodeRequire('path');
    var resDir = opath.join(__dirname, '../../resources/');
    var pluginDir = opath.join(__dirname, '../../resources/plugins/' + pluginName + '/');
    var downloadDir = opath.join(__dirname, '../../');
    console.log(resDir);
    console.log(pluginDir);
    console.log(downloadDir);
    InstallModules(resDir);


    doDownload(downloadUrls, pluginDir);
    execCMD('.\\resources\\plugins\\' + pluginName + '\\mvninstall.bat install', 'mvncnt');
	// execCMD('.\\resources\\plugins\\' + pluginName + '\\extract.bat', 'mvncnt');
	
	// execCMD('copy LC2ZIP.dll .\\resources\\plugins\\' + pluginName + '\\', 'mvncnt');
	// execCMD('copy ICSharpCode.SharpZipLib.dll .\\resources\\plugins\\' + pluginName + '\\', 'mvncnt');
	// execCMD('copy extract.exe .\\resources\\plugins\\' + pluginName + '\\', 'mvncnt');
	
	// execCMD('.\\resources\\plugins\\' + pluginName + '\\extract.exe .\\resources\\plugins\\' + pluginName + '\\PhaserEditor2D-allInOne-3.36.2-windows.zip', 'mvncnt');

    // doUnzip(downloadUrls, targetDir);
} catch (e) {
    alert(e.stack);
}