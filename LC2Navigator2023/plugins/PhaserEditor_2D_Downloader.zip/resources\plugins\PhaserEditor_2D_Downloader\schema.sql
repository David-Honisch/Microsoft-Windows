-- select '<h2>Import processes</h2>';
drop table IF EXISTS PhaserEditor_2D_Downloader;
drop table IF EXISTS PhaserEditor_2D_Downloader_data;
drop table IF EXISTS PhaserEditor_2D_Downloader_procdata;
drop table IF EXISTS PhaserEditor_2D_Downloadertemp;
drop table IF EXISTS PhaserEditor_2D_Downloader_datatemp;
CREATE TABLE PhaserEditor_2D_Downloader( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE PhaserEditor_2D_Downloader_data( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE PhaserEditor_2D_Downloader_procdata( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE IF NOT EXISTS PhaserEditor_2D_Downloadertemp (
"name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL
);
-- create table IF NOT EXISTS PhaserEditor_2D_Downloader_datatemp ( name varchar(255));
CREATE TABLE IF NOT EXISTS PhaserEditor_2D_Downloader_datatemp (
"name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL
);
-- import menu
-- select '<p>Import processes</p>';
.separator ";"
.import .\\resources\\plugins\\PhaserEditor_2D_Downloader\\import\\import.csv PhaserEditor_2D_Downloadertemp
INSERT INTO PhaserEditor_2D_Downloader(first_name,name,zipcode, city, description) select first_name,name,zipcode, city, description  from PhaserEditor_2D_Downloadertemp;
--
-- eof insert work data
select 'PhaserEditor_2D_Downloader count:';
select count(*) from PhaserEditor_2D_Downloader;
--.separator ';'
.separator ";"
--.import '.\\resources\\plugins\\PhaserEditor_2D_Downloader\\import\\menu.csv' PhaserEditor_2D_Downloader_datatemp
.import '.\\resources\\plugins\\PhaserEditor_2D_Downloader\\import\\menu.csv' PhaserEditor_2D_Downloader_datatemp
INSERT INTO PhaserEditor_2D_Downloader_data(first_name,name,zipcode, city, description) select first_name,name,zipcode, city, description  from PhaserEditor_2D_Downloader_datatemp;
delete from PhaserEditor_2D_Downloader_datatemp;
--
.separator ","
.import '.\\resources\\plugins\\PhaserEditor_2D_Downloader\\import\\PhaserEditor_2D_Downloaderwork.csv' PhaserEditor_2D_Downloader_datatemp
INSERT INTO PhaserEditor_2D_Downloader_procdata(first_name,name,zipcode, city, description) select first_name,name,zipcode, city, description  from PhaserEditor_2D_Downloader_datatemp;
--
select '<p>PhaserEditor_2D_Downloader count:';
select count(*) from PhaserEditor_2D_Downloader;
select 'PhaserEditor_2D_Downloader_data count:';
select count(*) from PhaserEditor_2D_Downloader_data;
select 'PhaserEditor_2D_Downloader_procdata count:';
select count(*) from PhaserEditor_2D_Downloader_procdata;
.separator ";"
drop table IF EXISTS PhaserEditor_2D_Downloadertemp;
-- select '<p>Import done</p>';
.exit