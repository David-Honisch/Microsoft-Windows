select '<h4>LC2Python Plugin SQL Import</h4>';
drop table IF EXISTS LC2Python;
drop table IF EXISTS LC2Pythontemp;
CREATE TABLE LC2Python ( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
create table IF NOT EXISTS LC2Pythontemp ( name varchar(255), menu TEXT, url varchar(255), subtext TEXT);
-- select 'Create table LC2Python Import';
-- .separator "\t"
-- .import .\\import.csv LC2Pythontemp
.separator ";"
.import .\\resources\\plugins\\LC2Python\\import\\import.csv LC2Pythontemp
--.import ..\\import\\materialnohead.csv url
--INSERT INTO person VALUES (4, 'Alice', '351246233');
-- DELETE FROM url where url.name = '';
-- select '<p>LC2Pythontemp count:';
-- select count(*) from LC2Pythontemp;
-- select '</p>';
-- select '<p>SQL Import successfully done</p>';
-- select '<p>LC2Python count:'+count(*)+'</p>' from LC2Pythontemp;
-- select * from LC2Pythontemp limit 1;
-- select '<p>temp table COUNT:'+count(*)+'</p>' from LC2Pythontemp;
INSERT INTO LC2Python (first_name,name, description,url) select name,name, menu,url  from LC2Pythontemp;
select '<p>LC2Python count:';
select count(*) from LC2Python;
select '</p>';
-- select '<p>COUNT:'+count(*)+'</p>' from LC2Python;
-- select '<p>SQL Menu:</p><br>';
-- select '';
-- select '<hr>';
-- select '<a href="'+url+'">'+name+'</a>' from LC2Python;
-- select '<hr>';
-- select '<p>LC2Python count:'+count(*)+' successfully imported.</p>' from LC2Python;
.exit