import platform

x = platform.system()
print(x) 