var cacheName = 'LC2-v3';
var appShellFiles = [
    './',
    './index.html',
    './favicon.ico',
    './assets/fonts/BRLNSDB.css',
    './assets/fonts/BRLNSDB.eot',
    './assets/fonts/BRLNSDB.otf',
    './assets/fonts/BRLNSDB.svg',
    './assets/fonts/BRLNSDB.ttf',
    './assets/fonts/BRLNSDB.woff',
    './assets/sfx/audio-button.m4a',
    './assets/sfx/audio-button.mp3',
    './assets/sfx/audio-button.ogg',
    './assets/sfx/music-bitsnbites-liver.m4a',
    './assets/sfx/music-bitsnbites-liver.mp3',
    './assets/sfx/music-bitsnbites-liver.ogg',
    './assets/img/icons/icon-32.png',
    './assets/img/icons/icon-64.png',
    './assets/img/icons/icon-96.png',
    './assets/img/icons/icon-128.png',
    './assets/img/icons/icon-168.png',
    './assets/img/icons/icon-192.png',
    './assets/img/icons/icon-256.png',
    './assets/img/icons/icon-512.png',
    './assets/js/phaser.3.18.1.min.js',
    './assets/js/plugins/webfont.js',
    './assets/js/start.js',
    './assets/js/Boot.js',
    './assets/js/Preloader.js',
    './assets/js/MainMenu.js',
    './assets/js/Settings.js',
    './assets/js/Story.js',
    './assets/js/Game.js',
    './assets/img/background.png',
    './assets/img/banner-beer.png',
    './assets/img/button-achievements.png',
    './assets/img/button-back.png',
    './assets/img/button-beer.png',
    './assets/img/button-continue.png',
    './assets/img/button-credits.png',
    './assets/img/button-home.png',
    './assets/img/button-mainmenu.png',
    './assets/img/button-music-off.png',
    './assets/img/button-music-on.png',
    './assets/img/button-pause.png',
    './assets/img/button-settings.png',
    './assets/img/button-sound-off.png',
    './assets/img/button-sound-on.png',
    './assets/img/button-start.png',
    './assets/img/button-tryagain.png',
    './assets/img/clickme.png',
    './assets/img/enclave-phaser-template.png',
    './assets/img/fork.png',
    './assets/img/loading-background.png',
    './assets/img/logo-enclave.png',
    './assets/img/overlay.png',
    './assets/img/particle.png',
    './assets/img/pattern.png',
    './assets/img/title.png'
];

self.addEventListener('install', function(e) {
    e.waitUntil(
        caches.open(cacheName).then(function(cache) {
            return cache.addAll(appShellFiles);
        })
    );
});

self.addEventListener('fetch', function(e) {
    e.respondWith(
        caches.match(e.request).then(function(r) {
            return r || fetch(e.request).then(function(response) {
                return caches.open(cacheName).then(function(cache) {
                    cache.put(e.request, response.clone());
                    return response;
                });
            });
        })
    );
});