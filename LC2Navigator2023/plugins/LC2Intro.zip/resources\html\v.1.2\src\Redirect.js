class Redirect extends Phaser.Scene {
    q;
    bullets;
    textQuery;
    redirectscene;
    progressCount = 0;
    redirectRepeatcount = 100;
    cursorKeys;// = this.input.keyboard.createCursorKeys();// = Phaser.Types.Input.Keyboard.CursorKeys;

    constructor() {
        var sceneConfig = {
            type: Phaser.AUTO,
            parent: 'content',
            key: 'Redirect',
            isAutoRedirected: true,
            pixelArt: true,
            width: 1900,
            height: 1080,
            dom: {
                createContainer: true
            },
            input: {
                gamepad: true
            },

            scale: {
                mode: Phaser.Scale.FIT,
                parent: 'content',
                autoCenter: Phaser.Scale.CENTER_BOTH,
                width: 1900,
                height: 1080
            },
            physics: {
                default: 'arcade',
                arcade: {
                    gravity: { y: 0.0 },
                    fps: 60,
                    debug: false
                }
            },
            scene: {
                preload: "preload",
                create: "create",
                update: "update",
                extend: {
                    checkBulletVsEnemy: "checkBulletVsEnemy",
                    launchEnemy: "launchEnemy",
                    hitShip: "hitShip",
                    hitEnemy: "hitEnemy"
                }
            }
        };
        super(sceneConfig);
        this.bgFilesLoaded = false;
    }
    isRedirect(s) {
        //TODO:check other scenes !!
        if (s.length>=3) {
            return true;
        }
        else if (s.includes('http') || s.includes('.html')) {
            return true;
        }        
        else {
            return false;
        }
    }
    preload(){
        this.q = LC2.getUrlVars();
        this.load.htmlTexture('redirectHTML', 'assets/html/redirect.cls.php?q='+this.q, 640, 960);
    }
    create() {
        this.q = LC2.getUrlVars();
        this.cursorKeys = this.input.keyboard.createCursorKeys();
        var fontHighscore = { font: '38px ' + LC2.text['FONT'], fill: '#ffde00', stroke: '#000', strokeThickness: 5 };

        var shader = create_Shader(this, 640, 480,'BufferShader1', 'BufferShader2', 'BufferShader3',fragmentShader4, fragmentShader3, fragmentShader3_1);
        shader.setAlpha(0.9);
        this.bg = this.add.tileSprite(0, 0, 0, 0, "bg").setOrigin(0).setScale(1).setSize(640, 960);

        

        // var particles = this.add.particles('flares');
		// var emitter = particles.createEmitter(this.cache.json.get('emitter'));
        // emitter.setAlpha(0.5);

        
        // var planet = this.add.image(200, 200, 'space', 'purple-planet').setOrigin(0).setScale(0.2);
        // LC2.getTween(this, planet,'Quad.easeInOut','Cubic.easeInOut', 4000,0.5,0.5,-1, true);
        var sun = this.add.image(300, 300, 'space', 'sun2').setScale(0.1);
        LC2.getTween(this, sun,'Quad.easeInOut','Cubic.easeInOut', 10000,2.5,2.50,-1, true);

        var raster = createAlphaRasterY(this, 900, getGameHeight(this) - 30, getGameWidth(this), 1, 8, 4500, 1000, false, 0.8);
        var html = this.add.image(3, 400, 'redirectHTML').setOrigin(0);
        var h1 = { title: 'LETZTECHANCE', style: 'chrome120', x: 10, y: 100 };
        var h2 = { title: 'Intro', style: 'dreams', x: 70, y: 18 };
        var h3 = { title: 'David Honisch', style: 'chrome36', x: 10, y: 160 };
        var tw = { y: 200, duration: 3000, loop: -1, ease: 'Sine.easeInOut', yoyo: true };
        getDOMTween(this, h1, h2, h3, tw);
        var style = {
            // 'background-color': 'lime',
            'width': '220px',
            'height': '50px',
            'font': '12px Arial',
            'font-weight': 'bold'
        };
        var element = this.add.dom(10, 300, 'div', style, 'Done by David Honisch');
        
        

        //LC2.createRetroFont(this,"Welcome...", 0,400);


        // this.ship = this.add.image(Math.round(300), Math.round(600),'goldrunner');//.setDepth(2);
        this.ship = this.physics.add.image(Math.round(300), Math.round(600), 'goldrunner');//.setDepth(2);
        this.ship.rotation = 0.0;
        this.ship.setCollideWorldBounds(true);
        this.ship.setDamping(true);
        this.ship.setDrag(0.95);
        this.ship.setMaxVelocity(400);

        LC2.easeInOutTween(this, this.ship,'Cubic.easeInOut', 2000, -1, true);



        LC2.Storage.initUnset('LC2-highscore', 0);
        var highscore = LC2.Storage.get('LC2-highscore');

        this.waitingForSettings = false;

        //var title = this.add.sprite(LC2.world.centerX, LC2.world.centerY - 50, 'title');

        var buttonLogo = new Button(800, 270, 'logo', this.clickLogo, this, 'static');
        buttonLogo.setOrigin(0, 1.0);

        var title = this.add.sprite(LC2.world.centerX, 250, 'title');
        title.setOrigin(0.5);
        this.tweens.add({ targets: title, angle: title.angle - 2, duration: 1000, ease: 'Sine.easeInOut' });
        this.tweens.add({ targets: title, angle: title.angle + 4, duration: 2000, ease: 'Sine.easeInOut', yoyo: 1, loop: -1, delay: 1000 });
        // var buttonEnclave = new Button(20, LC2.world.height - 40, 'logo', this.clickEnclave, this, 'static');
        // this.bullets = this.physics.add.group({
		// 	classType: Bullet,
		// 	maxSize: 30,
		// 	runChildUpdate: true
		// });
        



        this.input.keyboard.on('keydown', this.handleKey, this);
        var isRedirecting = false;
        this.textQuery = this.add.text(LC2.world.centerX - 200, LC2.world.centerY - 150, this.q, fontHighscore);
        this.textQuery.setOrigin(0, 0);
        
        //var model = new ConfigModel();
        // var menu = getMainMenu(this, new ConfigModel().model().mainMenu, 'menu', 0, 200, 0, 0, 280, 350, false, true);
        var menu = getMainMenu(this, LC2ConfigModel.mainMenu, 'menu', 0, 200, 0, 0, 280, 350, false, true);

        this.tweens.add({ targets: this.textQuery, angle: this.textQuery.angle - 2, duration: 1000, ease: 'Sine.easeInOut' });
        this.tweens.add({ targets: this.textQuery, angle: this.textQuery.angle + 4, duration: 2000, ease: 'Sine.easeInOut', yoyo: 1, loop: -1, delay: 1000 });

        this.buttonSettings = new Button(20, 20, 'button-settings', this.clickSettings, this);
        this.buttonSettings.setOrigin(0, 0);


        this.buttonStart = new Button(LC2.world.width - 20, LC2.world.height - 20, 'button-start', this.clickStart, this);
        this.buttonStart.setOrigin(1, 1);


        var textHighscore = this.add.text(LC2.world.width - 30, 60, LC2.text['menu-highscore'] + highscore, fontHighscore);
        textHighscore.setOrigin(1, 0);



        this.buttonStart.x = LC2.world.width + this.buttonStart.width + 20;
        this.tweens.add({ targets: this.buttonStart, x: LC2.world.width - 20, duration: 500, ease: 'Back' });

        buttonLogo.x = -buttonLogo.width - 20;
        this.tweens.add({ targets: buttonLogo, x: 20, duration: 500, ease: 'Back' });

        this.buttonSettings.y = -this.buttonSettings.height - 20;
        this.tweens.add({ targets: this.buttonSettings, y: 20, duration: 500, ease: 'Back' });

        textHighscore.y = -textHighscore.height - 30;
        this.tweens.add({ targets: textHighscore, y: 40, duration: 500, delay: 100, ease: 'Back' });

        this.cameras.main.fadeIn(250);

        if (!this.bgFilesLoaded) {
            this.time.addEvent({
                delay: 500,
                callback: function () {
                    this.startPreloadInTheBackground();
                },
                callbackScope: this
            }, this);
        }

        // if (this.q !== undefined) {
        //     alert(this.q);
        //     this.scene.start("Redirect");
        // }
        if (this.isRedirect(this.q)) {
            isRedirecting = true;
            this.textQuery.setText('Redirecting:\n' + this.q + '.');

            console.log('RUNNING REDIRECTION...');
            // this.redirectscene = redirect[0]['scene'];
            // textList = [
            // 	redirect[0]['scene'],
            // 	this.qs
            // ];
            this.textQuery.setText('Redirecting now to:\n' + this.q + '.');
            this.timedEvent = this.time.addEvent({ delay: 100, callback: this.onEvent, callbackScope: this, repeat: this.redirectRepeatcount });
            this.timedRedirectEvent = this.time.addEvent({ delay: 10000, callback: this.onRedirectEvent, callbackScope: this, repeat: 0 });
        }
    }
    handleKey(e) {
        switch (e.code) {
            case 'KeyS':
                {
                    this.clickSettings();
                    break;
                }
            case 'Enter':
                {
                    this.clickStart();
                    break;
                }
            default:
                { }
        }
    }
    clickLogo() {
        LC2.Sfx.play('click');
        window.top.location.href = 'https://www.letztechance.org/';
    }
    clickSettings() {
        if (this.bgFilesLoaded) {
            LC2.Sfx.play('click');
            if (this.loadImage) {
                this.loadImage.destroy();
            }
            LC2.fadeOutScene('Settings', this);
        } else {
            var animationFrames = this.anims.generateFrameNumbers('loader');
            animationFrames.pop();
            this.waitingForSettings = true;
            this.buttonSettings.setAlpha(0.1);
            var loadAnimation = this.anims.create({
                key: 'loading',
                frames: animationFrames,
                frameRate: 12,
                repeat: -1
            });
            this.loadImage = this.add.sprite(30, 30, 'loader').setOrigin(0, 0).setScale(1.25);
            this.loadImage.play('loading');
        }
    }
    clickStart() {
        if (this.bgFilesLoaded) {
            LC2.Sfx.play('click');
            if (this.loadImage) {
                this.loadImage.destroy();
            }
            LC2.fadeOutScene('Story', this);
        } else {
            var animationFrames = this.anims.generateFrameNumbers('loader');
            animationFrames.pop();
            this.waitingForStart = true;
            this.buttonStart.setAlpha(0.1);
            var loadAnimation = this.anims.create({
                key: 'loading',
                frames: animationFrames,
                frameRate: 12,
                repeat: -1
            });
            this.loadImage = this.add.sprite(LC2.world.width - 85, LC2.world.height - 85, 'loader').setOrigin(1, 1).setScale(1.25);
            this.loadImage.play('loading');
        }
    }
    startPreloadInTheBackground() {
        console.log('[LC2] Starting background loading...');
        this.load.image('assets/img/clickme');
        this.load.once('filecomplete', this.addFiles, this);
        this.load.start();
    }
    addFiles() {
        var resources = {
            'image': [
                ['clickme', 'assets/img/clickme.png'],
                ['goldrunner', 'assets/img/gr.png'],
                ['overlay', 'assets/img/overlay.png'],
                ['button-beer', 'assets/img/button-beer.png'],
                ['banner-beer', 'assets/img/banner-beer.png'],
                ['particle', 'assets/img/particle.png']
            ],
            'spritesheet': [
                ['invader', 'assets/img/invader1.png', { frameWidth: 32, frameHeight: 32 }],
                ['boom', 'assets/img/explosion.png', { frameWidth: 64, frameHeight: 64, endFrame: 23 }],

                ['button-continue', 'assets/img/button-continue.png', { frameWidth: 180, frameHeight: 180 }],
                ['button-mainmenu', 'assets/img/button-mainmenu.png', { frameWidth: 180, frameHeight: 180 }],
                ['button-restart', 'assets/img/button-tryagain.png', { frameWidth: 180, frameHeight: 180 }],
                ['button-achievements', 'assets/img/button-achievements.png', { frameWidth: 110, frameHeight: 110 }],
                ['button-pause', 'assets/img/button-pause.png', { frameWidth: 80, frameHeight: 80 }],
                ['button-credits', 'assets/img/button-credits.png', { frameWidth: 80, frameHeight: 80 }],
                ['button-sound-on', 'assets/img/button-sound-on.png', { frameWidth: 80, frameHeight: 80 }],
                ['button-sound-off', 'assets/img/button-sound-off.png', { frameWidth: 80, frameHeight: 80 }],
                ['button-music-on', 'assets/img/button-music-on.png', { frameWidth: 80, frameHeight: 80 }],
                ['button-music-off', 'assets/img/button-music-off.png', { frameWidth: 80, frameHeight: 80 }],
                ['button-back', 'assets/img/button-back.png', { frameWidth: 70, frameHeight: 70 }]
            ],
            'audio': [
                ['sound-click', ['assets/sfx/audio-button.m4a', 'assets/sfx/audio-button.mp3', 'assets/sfx/audio-button.ogg']],
                ['sound-points', ['assets/sfx/points.mp3']],
                ['sound-shoot', ['assets/sfx/shoot.mp3']],
                ['sound-explodedbl', ['assets/sfx/explodedbl.mp3']],
                ['music-theme', ['assets/sfx/music-bitsnbites-liver.m4a', 'assets/sfx/music-bitsnbites-liver.mp3', 'assets/sfx/music-bitsnbites-liver.ogg']]
            ]
        };
        for (var method in resources) {
            resources[method].forEach(function (args) {
                var loader = this.load[method];
                loader && loader.apply(this.load, args);
            }, this);
        };
        this.load.on('complete', function () {
            console.log('[LC2] All files loaded in the background.');
            this.bgFilesLoaded = true;
            LC2.Sfx.manage('music', 'init', this);
            LC2.Sfx.manage('sound', 'init', this);
            if (this.waitingForSettings) {
                this.clickSettings();
            }
            if (this.waitingForStart) {
                this.clickStart();
            }
        }, this);
    }


    //events
    onEvent() {

        this.textQuery.setText('Redirect to:\n' + this.q + '\nin ' + this.progressCount + '/' + this.redirectRepeatcount + '%.');
        this.progressCount++;
        // this.ship.scaleX *= 0.90;
        // this.ship.scaleY *= 0.90;
        // this.ship.rotation += 0.4;
    }
    onRedirectEvent() {
        this.textQuery.setText('Redirect\nrunning now to:\n' + this.q + '.');
        //this.isRedirecting = true;
        //this.bmptext.setText('Redirecting now to:\n' + this.qs + '.');
        this.time.addEvent({ delay: 30, callback: this.onRedirectScene, callbackScope: this, repeat: 100 });
    }
    onRedirectScene() {
        // this.bmptext.setText('Redirecting now to:\n' + this.qs + '.\nBye and have fun.');
        this.textQuery.setText('Redirecting scene\nor\nurl running now to:\n' + this.q + '.');
        this.time.addEvent({ delay: 3000, callback: this.onRedirectSceneFinally, callbackScope: this, repeat: 0 });
    }
    onRedirectSceneFinally() {
        if (this.music !== undefined) this.music.stop();
        if (this.sidPlayer !== undefined) this.sidPlayer.stop();
        // this.bmptext.setText('Bye and have fun.');
        this.textQuery.setText('Bye and have fun.\nRedirecting now to:\n' + this.q + '.');
        if (this.isRedirect(this.q)) {
            window.location = this.q;
        }
        else {
            this.scene.start(this.redirectscene);
        }
    }
    fireBullet(time) {
        if (this.bullets !== undefined) {
            var bullet = this.bullets.get();
            if (bullet) {
                bullet.fire(this.ship);
                this.lastFired = time + 100;
            }
        }
    }
    update() {
        LC2.setCursorControls(this, this.ship, this.cursorKeys);
        this.bg.tilePositionY += +1;
        // if (this.cursorKeys !== undefined) {
        //     //left
        //     if (this.cursorKeys.left.isDown) {
        //         // velocity.x -= 1;
        //         // this.bgScroll.tilePositionX += -2;
        //         // this.physics.velocityFromRotation(this.ship.rotation, Math.abs(-100), this.ship.body.acceleration);
        //         if (this.ship !== undefined) this.ship.rotation += -0.1;
        //     }
        //     //right
        //     if (this.cursorKeys.right.isDown) {
        //         // velocity.x += 1;
        //         // this.bgScroll.tilePositionX += +1;
        //         // this.physics.velocityFromRotation(this.ship.rotation, Math.abs(100), this.ship.body.acceleration);
        //         if (this.ship !== undefined) this.ship.rotation += 0.1;
        //     }
        //     //up
        //     if (this.cursorKeys.up.isDown) {
        //         // Util.getTween(this, this.ship, 400, 1, 1, 0, false);
        //         // this.ship.setRotation(0);
        //         // velocity.y -= 1;
        //         //shoot test

        //     }
        //     if (this.cursorKeys.down.isDown) {
        //         // velocity.y += 1;
        //     }
        // }
        // var spaceBar = this.input.keyboard.addKey(Phaser.Input.Keyboard.KeyCodes.SPACE);
        // if (spaceBar.isDown) {
        //     console.log('spacebar');
        //     // this.fireBullet(time);
        // }
    }

}