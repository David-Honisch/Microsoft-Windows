class Boot extends Phaser.Scene {
    constructor() {
        super('Boot');
    }
    preload() {
        this.load.pack('pack1', 'assets/img/level.json', 'general');
		this.load.pack('packLevel', 'assets/img/level.json', 'level');
        // this.load.image('background', 'img/background.png');
        // this.load.image('logo', 'img/logo.png');
        // this.load.image('goldrunner', 'img/gr.png');
        // this.load.image('loading-background', 'img/loading-background.png');
        this.load.atlas('space', 'assets/img/space.png', 'assets/img/space.json');
        this.load.atlas('explosion', 'assets/img/explosion2.png', 'assets/img/explosion2.json');

        // this.load.spritesheet('invader', 'assets/img/invader1.png', { frameWidth: 32, frameHeight: 32 });
        // this.load.spritesheet('boom', 'assets/img/explosion.png', { frameWidth: 64, frameHeight: 64, endFrame: 23 });

        this.load.atlas('flares', 'assets/img/flares.png', 'assets/img/flares.json');
        this.load.json('emitter', 'assets/img/emitter.json');

        this.load.css('css', 'assets/css/loader/80stypography.css');
        WebFont.load({ custom: { families: ['Berlin'], urls: ['assets/fonts/BRLNSDB.css'] } });
        // this.load.htmlTexture('homeHTML', 'assets/html/home.html', 640, 960);
        // this.load.glsl('bundle', '../assets/shaders/bundle.glsl.js');
        // this.load.glsl('bundle2', '../assets/shaders/bundle2.glsl.js');
        this.load.bitmapFont('desyrel', 'assets/fonts/bitmap/desyrel.png', 'assets/fonts/bitmap/desyrel.xml');
		this.load.bitmapFont('atari', 'assets/fonts/bitmap/atari-smooth.png', 'assets/fonts/bitmap/atari-smooth.xml');
		this.load.bitmapFont('ice', 'assets/fonts/bitmap/iceicebaby.png', 'assets/fonts/bitmap/iceicebaby.xml');
		this.load.bitmapFont('gothic', 'assets/fonts/bitmap/gothic.png', 'assets/fonts/bitmap/gothic.xml');
		this.load.bitmapFont('hyper', 'assets/fonts/bitmap/hyperdrive.png', 'assets/fonts/bitmap/hyperdrive.xml');
        this.load.css('css', 'assets/css/loader/80stypography.css');
    }
    create() {
        LC2.world = {
            width: this.cameras.main.width,
            height: this.cameras.main.height,
            centerX: this.cameras.main.centerX,
            centerY: this.cameras.main.centerY
        };
        LC2.Lang.updateLanguage('de');
        LC2.text = LC2.Lang.text[LC2.Lang.current];
        this.scene.start('Preloader');
    }
}