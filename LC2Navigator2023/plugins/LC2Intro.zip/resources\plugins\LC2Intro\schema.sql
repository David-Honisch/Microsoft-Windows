-- select '<h2>Import processes</h2>';
drop table IF EXISTS LC2Intro;
drop table IF EXISTS LC2Intro_Data;
drop table IF EXISTS LC2Intro_data;
drop table IF EXISTS LC2Introtemp;
drop table IF EXISTS LC2Intro_datatemp;
CREATE TABLE LC2Intro( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE LC2Intro_data( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE IF NOT EXISTS LC2Introtemp (
"name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL
);
-- create table IF NOT EXISTS LC2Intro_datatemp ( name varchar(255));
CREATE TABLE IF NOT EXISTS LC2Intro_datatemp (
"name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL
);
-- import menu
-- select '<p>Import processes</p>';
.separator ";"
.import .\\resources\\plugins\\LC2Intro\\import\\import.csv LC2Introtemp
-- INSERT INTO LC2Intro(first_name,name,zipcode, city, description) select name,name, pid,ftype,tpid  from LC2Introtemp;
-- insert work data
INSERT INTO LC2Intro(first_name,name,zipcode, city, description) select first_name,name,zipcode, city, description  from LC2Introtemp;
-- eof insert work data
select 'LC2Intro count:';
select count(*) from LC2Intro;
-- select '<p>Import working data processes</p>';
-- .separator ";"
--.import .\\resources\\plugins\\LC2Intro\\import\\LC2Introwork.csv LC2Introtemp
-- .import .\\resources\\plugins\\LC2Intro\\import\\LC2Introwork.csv LC2Introtemp
-- .import .\\resources\\plugins\\LC2Intro\\blz-aktuell-txt-data.txt  LC2Introtemp
-- select 'COUNT:'+count(*) from LC2Introtemp;
-- INSERT INTO LC2Intro_data(first_name,name,zipcode, city, description) select first_name,name,zipcode, city, description  from LC2Introtemp;
.separator ';'
.import '.\\resources\\plugins\\LC2Intro\\import\\menu.csv' LC2Intro_datatemp
-- select '<h6>Main menu importing done</h6>'; 
-- select '<p>LC2Intro_datatemp count:';
-- select count(*)  from LC2Intro_datatemp;
-- select '</p>';
-- INSERT INTO LC2Intro_Data (first_name,name, description,url) select name,name, menu,url  from LC2Intro_Datatemp;
-- INSERT INTO LC2Intro_data (first_name,name,zipcode, city, description,url) select substr( name, 0, 9 ),rtrim(substr( name, 10, 58 )), substr(name,68,71), substr(name,73,78), name,trim(substr( name, 140, 169))  from LC2Intro_datatemp;
INSERT INTO LC2Intro_data(first_name,name,zipcode, city, description) select first_name,name,zipcode, city, description  from LC2Intro_datatemp;
select '<p>LC2Intro count:';
select count(*) from LC2Intro;
select 'LC2Intro_data count:';
select count(*) from LC2Intro_data;
drop table IF EXISTS LC2Introtemp;
-- select '<p>Import done</p>';
.exit