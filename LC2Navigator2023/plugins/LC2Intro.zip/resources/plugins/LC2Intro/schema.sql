-- select '<h2>Import processes</h2>';
drop table IF EXISTS LC2Intro;
drop table IF EXISTS LC2Intro_data;
drop table IF EXISTS LC2Intro_procdata;
drop table IF EXISTS LC2Introtemp;
drop table IF EXISTS LC2Intro_datatemp;
CREATE TABLE LC2Intro( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE LC2Intro_data( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE LC2Intro_procdata( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE IF NOT EXISTS LC2Introtemp (
"name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL
);
-- create table IF NOT EXISTS LC2Intro_datatemp ( name varchar(255));
CREATE TABLE IF NOT EXISTS LC2Intro_datatemp (
"name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL
);
-- import menu
-- select '<p>Import processes</p>';
.separator ";"
-- .import .\\resources\\plugins\\LC2Intro\\import\\import.csv LC2Introtemp
-- INSERT INTO LC2Intro(first_name,name,zipcode, city, description) select first_name,name,zipcode, city, description  from LC2Introtemp;
.import .\\resources\\plugins\\LC2Intro\\import\\import.csv LC2Intro
--
-- eof insert work data
select 'LC2Intro count:';
select count(*) from LC2Intro;
--.separator ';'
.separator ";"
--.import '.\\resources\\plugins\\LC2Intro\\import\\menu.csv' LC2Intro_datatemp
-- .import '.\\resources\\plugins\\LC2Intro\\import\\menu.csv' LC2Intro_datatemp
-- INSERT INTO LC2Intro_data(first_name,name,zipcode, city, description) select first_name,name,zipcode, city, description  from LC2Intro_datatemp;
.import '.\\resources\\plugins\\LC2Intro\\import\\menu.csv' LC2Intro_data
delete from LC2Intro_datatemp;
--
-- .separator ","
-- .import '.\\resources\\plugins\\LC2Intro\\import\\LC2Introwork.csv' LC2Intro_datatemp
-- INSERT INTO LC2Intro_procdata(first_name,name,zipcode, city, description) select first_name,name,zipcode, city, description  from LC2Intro_datatemp;
--
select '<p>LC2Intro count:';
select count(*) from LC2Intro;
select 'LC2Intro_data count:';
select count(*) from LC2Intro_data;
select 'LC2Intro_procdata count:';
select count(*) from LC2Intro_procdata;
.separator ";"
drop table IF EXISTS LC2Introtemp;
-- select '<p>Import done</p>';
.exit