//import LazersPostFX from './assets/pipelines/LazersPostFX.js';
var enablePWA = false;
if (enablePWA) {
    // SERVICE WORKER
    if ('serviceWorker' in navigator) {
        navigator.serviceWorker.register('./js/sw.js');
    };
    // NOTIFICATIONS TEMPLATE
    Notification.requestPermission().then(function(result) {
        if (result === 'granted') {
            exampleNotification();
        }
    });

    function exampleNotification() {
        var notifTitle = 'LC Core Game Loader v.1.0';
        var notifBody = 'Created by David Honisch';
        var notifImg = 'assets/img/icons/icon-512.png';
        var options = {
            body: notifBody,
            icon: notifImg
        }
        var notif = new Notification(notifTitle, options);
        setTimeout(exampleNotification, 30000);
    }
}

var gameConfig = {
    type: Phaser.AUTO,
    scale: {
        mode: Phaser.Scale.FIT,
        autoCenter: Phaser.Scale.CENTER_BOTH,
        width: 640,
        height: 960
    },
    dom: {
		createContainer: true
	},
    scene: [Boot, Preloader, MainMenu, Redirect, Settings, Story, Game]
}
game = new Phaser.Game(gameConfig);
window.focus();

// Usage tracking
window.dataLayer = window.dataLayer || [];

// function gtag() { dataLayer.push(arguments); }
// gtag('js', new Date());
// gtag('config', 'UA-30485283-26');