class Game extends Phaser.Scene {
    playerConfig = {
        maxTime: 30,
        lives: 3,
        hits: 100,
        rate: 1
    }
    cursorKeys;
    ship;    
    enemies;
    invaders;
    invaderships;
    bullets;

    lastFired = 0;
    fire;
    xparticles;
    spaceOuter;
    spaceInner;

    


    constructor() {
        var sceneConfig = {
            type: Phaser.AUTO,
            parent: 'content',
            key: 'Game',
            isAutoRedirected: false,
            pixelArt: true,
            dom: {
                createContainer: true
            },
            input: {
                gamepad: true
            },

            scale: {
                mode: Phaser.Scale.FIT,
                parent: 'content',
                autoCenter: Phaser.Scale.CENTER_BOTH,
                width: 1900,
                height: 1080
            },
            physics: {
                default: 'arcade',
                arcade: {
                    gravity: { y: 0.0 },
                    fps: 60,
                    debug: false
                }
            },
            scene: {
                init: "init",
                preload: "preload",
                create: "create",
                update: "update",
                extend: {
                    checkBulletVsEnemy: "checkBulletVsEnemy",
                    launchEnemy: "launchEnemy",
                    hitShip: "hitShip",
                    hitEnemy: "hitEnemy"
                }
            }
        };

        super(sceneConfig);
    }
    preload() {
        this.load.tilemapCSV('levelstart', '../../resources/html/v.1.2/assets/tilemaps/csv/levelstart.csv');

        this.load.tilemapCSV('level0', '../../resources/html/v.1.2/assets/tilemaps/csv/level0.csv');
		this.load.tilemapCSV('level1', '../../resources/html/v.1.2/assets/tilemaps/csv/level1.csv');
		this.load.tilemapCSV('level2', '../../resources/html/v.1.2/assets/tilemaps/csv/level2.csv');
		this.load.tilemapCSV('level3', '../../resources/html/v.1.2/assets/tilemaps/csv/level3.csv');
		this.load.tilemapCSV('level4', '../../resources/html/v.1.2/assets/tilemaps/csv/level4.csv');
		this.load.tilemapCSV('level5', '../../resources/html/v.1.2/assets/tilemaps/csv/level5.csv');
		this.load.tilemapCSV('level6', '../../resources/html/v.1.2/assets/tilemaps/csv/level6.csv');
		this.load.tilemapCSV('level7', '../../resources/html/v.1.2/assets/tilemaps/csv/level7.csv');
		this.load.tilemapCSV('level8', '../../resources/html/v.1.2/assets/tilemaps/csv/level8.csv');
		this.load.tilemapCSV('level9', '../../resources/html/v.1.2/assets/tilemaps/csv/level9.csv');

		this.load.tilemapCSV('bglevel0', '../../resources/html/v.1.2/assets/tilemaps/csv/bglevel0.csv');
		this.load.tilemapCSV('bglevel1', '../../resources/html/v.1.2/assets/tilemaps/csv/bglevel1.csv');
		this.load.tilemapCSV('bglevel2', '../../resources/html/v.1.2/assets/tilemaps/csv/bglevel2.csv');
		this.load.tilemapCSV('bglevel3', '../../resources/html/v.1.2/assets/tilemaps/csv/bglevel3.csv');
		this.load.tilemapCSV('bglevel4', '../../resources/html/v.1.2/assets/tilemaps/csv/bglevel4.csv');
		this.load.tilemapCSV('bglevel5', '../../resources/html/v.1.2/assets/tilemaps/csv/bglevel5.csv');
		this.load.tilemapCSV('bglevel6', '../../resources/html/v.1.2/assets/tilemaps/csv/bglevel6.csv');
		this.load.tilemapCSV('bglevel7', '../../resources/html/v.1.2/assets/tilemaps/csv/bglevel7.csv');
		this.load.tilemapCSV('bglevel8', '../../resources/html/v.1.2/assets/tilemaps/csv/bglevel8.csv');
		this.load.tilemapCSV('bglevel9', '../../resources/html/v.1.2/assets/tilemaps/csv/bglevel9.csv');        
    }
    create() {
        this.level = 0;
        this.tilesetutils = new Tilesetutils();
        this.spaceOuter = new Phaser.Geom.Rectangle(-200, -200, 640, 960);
        this.spaceInner = new Phaser.Geom.Rectangle(0, 0, 800, 600);
        this.cursorKeys = this.input.keyboard.createCursorKeys();

        this.textures.addSpriteSheetFromAtlas('mine-sheet', { atlas: 'space', frame: 'mine', frameWidth: 64 });
        this.anims.create({ key: 'mine-anim', frames: this.anims.generateFrameNumbers('mine-sheet', { start: 0, end: 15 }), frameRate: 20, repeat: -1 });

        this.textures.addSpriteSheetFromAtlas('invader-sheet', { atlas: 'space', frame: 'asteroid', frameWidth: 96 });
        this.anims.create({ key: 'invader-anim', frames: this.anims.generateFrameNumbers('invader-sheet', { start: 0, end: 24 }), frameRate: 20, repeat: -1 });

        this.textures.addSpriteSheetFromAtlas('asteroid-sheet', { atlas: 'space', frame: 'asteroid2', frameWidth: 96 });
        this.anims.create({ key: 'asteroid-anim', frames: this.anims.generateFrameNumbers('asteroid-sheet', { start: 0, end: 24 }), frameRate: 20, repeat: -1 });

        this.textures.addSpriteSheetFromAtlas('invaderships-sheet', { atlas: 'space', frame: 'asteroid3', frameWidth: 96 });
        this.anims.create({ key: 'invaderships-anim', frames: this.anims.generateFrameNumbers('invaderships-sheet', { start: 0, end: 24 }), frameRate: 20, repeat: -1 });

        var shader = createShader(this, 640, 480);
        shader.setAlpha(0.5);
        // this.add.sprite(0, 0, 'bg').setOrigin(0, 0).setAlpha(0.9);
        this.bg = this.add.tileSprite(0, 0, 0, 0, "bg").setOrigin(0).setScale(1).setSize(640, 960).setAlpha(0.9);

        var bprop = { key: 'levelstart', tileWidth: 64, tileHeight: 64 };
        var bmap = this.tilesetutils.makeCSVTileMap(this, bprop);
        var blayer = this.tilesetutils.makeCSVLayer(this, bmap, 'desert', 0, 0, 64, 64);
        //this.layer = this.tilesetutils.createLayer(this);
        var prop = { key: 'level' + this.level, tileWidth: 16, tileHeight: 16 };        
        var bmap2 = this.tilesetutils.makeCSVTileMap(this, prop);        
        var blayer2 = this.tilesetutils.makeCSVLayer(this, bmap2, 'tilesmap', 0, 0, 54, 83);

        
		

        // var planet = this.add.image(200, 200, 'purple-planet').setOrigin(0).setScale(0.2);
        // LC2.getTween(this, planet,'Quad.easeInOut','Cubic.easeInOut', 4000,0.5,0.5,-1, true);
        var sun = this.add.image(300, 300, 'sun').setScale(0.1);
        LC2.getTween(this, sun,'Quad.easeInOut','Cubic.easeInOut', 10000,3.0,3.0,-1, true);

        this.stateStatus = null;
        this._score = 0;
        this._time = this.playerConfig.maxTime;
        this._gamePaused = false;
        this._runOnce = false;



        this.buttonDummy = new Button(LC2.world.centerX, LC2.world.centerY, 'logo', this.addPoints, this, 'static');
        this.buttonDummy.setOrigin(0.5, 0.5);
        this.buttonDummy.setAlpha(0);
        this.buttonDummy.setScale(0.1);
        this.tweens.add({ targets: this.buttonDummy, alpha: 1, duration: 500, ease: 'Linear' });
        this.tweens.add({ targets: this.buttonDummy, scale: 1, duration: 500, ease: 'Back' });

        this.initUI();
        this.currentTimer = this.time.addEvent({
            delay: 1000,
            callback: function () {
                this._time--;
                this.textTime.setText(LC2.text['gameplay-timeleft'] + this._time);
                if (!this._time) {
                    this._runOnce = false;
                    this.stateStatus = 'gameover';
                }
            },
            callbackScope: this,
            loop: true
        });

        //this.ship = this.physics.add.image(0, Math.round(height / 2),'goldrunner').setDepth(2);
        //this.ship = this.add.image(100, Math.round(this.height / 2),'goldrunner');//.setDepth(2);
        this.ship = this.physics.add.image(Math.round(300), Math.round(900), 'goldrunner').setDepth(2);//.setDepth(2);
        this.ship.rotation = 0.0;
        this.ship.setCollideWorldBounds(true);

        this.ship.setDamping(true);
        this.ship.setDrag(0.95);
        this.ship.setMaxVelocity(400);

        this.cameras.main.setBounds(0, 0, bmap2.widthInPixels, bmap2.heightInPixels);
        this.physics.add.collider(this.ship, blayer);
        this.physics.add.collider(this.ship, blayer2);

        this.xparticles = LC2.createEmitter(this, this.ship);



        this.input.keyboard.on('keydown', this.handleKey, this);
        this.cameras.main.fadeIn(250);
        this.stateStatus = 'playing';
        this.enemies = this.physics.add.group({
            classType: Enemy,
            maxSize: 10,
            runChildUpdate: true
        });

        this.invaders = this.physics.add.group({
            classType: Invader,
            maxSize: 2,
            runChildUpdate: true
        });

        this.asteroids = this.physics.add.group({
            classType: EnemyAsteroid,
            maxSize: 2,
            runChildUpdate: true
        });

        this.invaderships = this.physics.add.group({
            classType: InvaderShips,
            maxSize: 2,
            runChildUpdate: true
        });

        this.bullets = new Bullets(this);
        // new Invaders().createInvaders(this, this.ship, "invader", "move", "invader", "explode", "boom", 640, 760);

        this.physics.add.overlap(this.bullets, this.enemies, this.hitEnemy, this.checkBulletVsEnemy, this);
        this.physics.add.overlap(this.bullets, this.invaders, this.hitEnemy, this.checkBulletVsEnemy, this);
        this.physics.add.overlap(this.bullets, this.asteroids, this.hitEnemy, this.checkBulletVsEnemy, this);
        this.physics.add.overlap(this.bullets, this.invaderships, this.hitEnemy, this.checkBulletVsEnemy, this);

        for (var i = 0; i < 6; i++) {
            this.launchEnemy();
        }

        this.input.on('pointermove', (pointer) => {

            this.ship.x = pointer.x;

        });

        this.input.on('pointerdown', (pointer) => {
            LC2.Sfx.play('shoot');
            this.bullets.fireBullet(this.ship, this.ship.x, this.ship.y);

        });

        this.isStartFollow = true;
        if (this.isStartFollow && this.level >2) {
			this.cameras.main.startFollow(this.ship);
    			this.cameras.main.followOffset.set(-20, 0);
		}
    }
    update(time, delta) {
        this.bg.tilePositionY += +1;
        if (this.stateStatus == 'gameover') {
            this.enemies.remove;
            this.invaders.remove;
            this.asteroids.remove;
        }
        LC2.setCursorControls(this, this.ship, this.cursorKeys);
        LC2.setFireControls(this, this.ship, this.bullets);
        switch (this.stateStatus) {
            case 'paused':
                {
                    if (!this._runOnce) {
                        this.statePaused();
                        this._runOnce = true;
                    }
                    break;
                }
            case 'gameover':
                {
                    if (!this._runOnce) {
                        this.stateGameover();
                        this._runOnce = true;
                    }
                    break;
                }
            case 'playing':
                {
                    this.statePlaying();
                }
            default:
                { }
        }


    }
    launchEnemy() {
        if (this.stateStatus == 'gameover')
            return;
        var a = this.invaders.get();
        if (a) {
            a.launch();
        }
        var b = this.enemies.get();
        if (b) {
            b.launch();
        }
        var c = this.asteroids.get();
        if (c) {
            c.launch();
        }
        var d = this.invaderships.get();
        if (d) {
            d.launch();
        }
    }

    checkBulletVsEnemy(bullet, enemy) {
        return (bullet.active && enemy.active);
    }

    hitShip(ship, enemy) {
    }

    hitEnemy(bullet, enemy) {
        this.xparticles.emitParticleAt(enemy.x, enemy.y);
        this.cameras.main.shake(500, 0.01);
        bullet.kill();
        enemy.kill();
        this.addPoints();
        LC2.Sfx.play('explodedbl');
    }
    fireBullet(time) {
        var bullet = this.bullets.get();
        if (bullet) {
            bullet.fire(this.ship, this.ship.x, this.ship.y);
            LC2.Sfx.play('shoot');
            this.lastFired = time + 100;
        }
    }
    handleKey(e) {
        switch (e.code) {
            case 'Enter':
                {
                    this.addPoints();

                    break;
                }
            case 'KeyP':
                {
                    this.managePause();
                    break;
                }
            case 'KeyB':
                {
                    this.stateBack();
                    break;
                }
            case 'KeyT':
                {
                    this.stateRestart();
                    break;
                }
            case 'Space':
                {
                    this.fireBullet(1);
                    break;
                }
            default:
                { }
        }
    }
    managePause() {
        this._gamePaused = !this._gamePaused;
        this.currentTimer.paused = !this.currentTimer.paused;
        LC2.Sfx.play('click');
        if (this._gamePaused) {
            LC2.fadeOutIn(function (self) {
                self.buttonPause.input.enabled = false;
                self.buttonDummy.input.enabled = false;
                self.stateStatus = 'paused';
                self._runOnce = false;
            }, this);
            this.screenPausedBack.x = -this.screenPausedBack.width - 20;
            this.tweens.add({ targets: this.screenPausedBack, x: 100, duration: 500, delay: 250, ease: 'Back' });
            this.screenPausedContinue.x = LC2.world.width + this.screenPausedContinue.width + 20;
            this.tweens.add({ targets: this.screenPausedContinue, x: LC2.world.width - 100, duration: 500, delay: 250, ease: 'Back' });
        } else {
            LC2.fadeOutIn(function (self) {
                self.buttonPause.input.enabled = true;
                self.buttonDummy.input.enabled = true;
                self._stateStatus = 'playing';
                self._runOnce = false;
            }, this);
            this.screenPausedBack.x = 100;
            this.tweens.add({ targets: this.screenPausedBack, x: -this.screenPausedBack.width - 20, duration: 500, ease: 'Back' });
            this.screenPausedContinue.x = LC2.world.width - 100;
            this.tweens.add({ targets: this.screenPausedContinue, x: LC2.world.width + this.screenPausedContinue.width + 20, duration: 500, ease: 'Back' });
        }
    }
    statePlaying() {
        if (this._time === 0) {
            this._runOnce = false;
            this.stateStatus = 'gameover';
        }
    }
    statePaused() {
        this.screenPausedGroup.toggleVisible();
    }
    stateGameover() {
        this.currentTimer.paused = !this.currentTimer.paused;
        LC2.Storage.setHighscore('EPT-highscore', this._score);
        LC2.fadeOutIn(function (self) {
            self.screenGameoverGroup.toggleVisible();
            self.buttonPause.input.enabled = false;
            self.buttonDummy.input.enabled = false;
            self.screenGameoverScore.setText(LC2.text['gameplay-score'] + self._score);
            self.gameoverScoreTween();
        }, this);
        this.screenGameoverBack.x = -this.screenGameoverBack.width - 20;
        this.tweens.add({ targets: this.screenGameoverBack, x: 100, duration: 500, delay: 250, ease: 'Back' });
        this.screenGameoverRestart.x = LC2.world.width + this.screenGameoverRestart.width + 20;
        this.tweens.add({ targets: this.screenGameoverRestart, x: LC2.world.width - 100, duration: 500, delay: 250, ease: 'Back' });
    }
    initUI() {
        this.buttonPause = new Button(20, 20, 'button-pause', this.managePause, this);
        this.buttonPause.setOrigin(0, 0);

        var fontScore = { font: '38px ' + LC2.text['FONT'], fill: '#ffde00', stroke: '#000', strokeThickness: 5 };
        var fontScoreWhite = { font: '38px ' + LC2.text['FONT'], fill: '#000', stroke: '#ffde00', strokeThickness: 5 };
        this.textScore = this.add.text(LC2.world.width - 30, 45, LC2.text['gameplay-score'] + this._score, fontScore);
        this.textScore.setOrigin(1, 0);

        this.textScore.y = -this.textScore.height - 20;
        this.tweens.add({ targets: this.textScore, y: 45, duration: 500, delay: 100, ease: 'Back' });

        this.textTime = this.add.text(30, LC2.world.height - 30, LC2.text['gameplay-timeleft'] + this._time, fontScore);
        this.textTime.setOrigin(0, 1);

        this.textTime.y = LC2.world.height + this.textTime.height + 30;
        this.tweens.add({ targets: this.textTime, y: LC2.world.height - 30, duration: 500, ease: 'Back' });

        this.buttonPause.y = -this.buttonPause.height - 20;
        this.tweens.add({ targets: this.buttonPause, y: 20, duration: 500, ease: 'Back' });

        var fontTitle = { font: '48px ' + LC2.text['FONT'], fill: '#000', stroke: '#ffde00', strokeThickness: 10 };

        this.screenPausedGroup = this.add.group();
        this.screenPausedBg = this.add.sprite(0, 0, 'overlay');
        this.screenPausedBg.setAlpha(0.95);
        this.screenPausedBg.setOrigin(0, 0);
        this.screenPausedText = this.add.text(LC2.world.centerX, 100, LC2.text['gameplay-paused'], fontTitle);
        this.screenPausedText.setOrigin(0.5, 0);
        this.screenPausedBack = new Button(100, LC2.world.height - 100, 'button-mainmenu', this.stateBack, this);
        this.screenPausedBack.setOrigin(0, 1);
        this.screenPausedContinue = new Button(LC2.world.width - 100, LC2.world.height - 100, 'button-continue', this.managePause, this);
        this.screenPausedContinue.setOrigin(1, 1);
        this.screenPausedGroup.add(this.screenPausedBg);
        this.screenPausedGroup.add(this.screenPausedText);
        this.screenPausedGroup.add(this.screenPausedBack);
        this.screenPausedGroup.add(this.screenPausedContinue);
        this.screenPausedGroup.toggleVisible();

        this.screenGameoverGroup = this.add.group();
        this.screenGameoverBg = this.add.sprite(0, 0, 'overlay');
        this.screenGameoverBg.setAlpha(0.95);
        this.screenGameoverBg.setOrigin(0, 0);
        this.screenGameoverText = this.add.text(LC2.world.centerX, 100, LC2.text['gameplay-gameover'], fontTitle);
        this.screenGameoverText.setOrigin(0.5, 0);
        this.screenGameoverBack = new Button(100, LC2.world.height - 100, 'button-mainmenu', this.stateBack, this);
        this.screenGameoverBack.setOrigin(0, 1);
        this.screenGameoverRestart = new Button(LC2.world.width - 100, LC2.world.height - 100, 'button-restart', this.stateRestart, this);
        this.screenGameoverRestart.setOrigin(1, 1);
        this.screenGameoverScore = this.add.text(LC2.world.centerX, 300, LC2.text['gameplay-score'] + this._score, fontScoreWhite);
        this.screenGameoverScore.setOrigin(0.5, 0.5);
        this.screenGameoverGroup.add(this.screenGameoverBg);
        this.screenGameoverGroup.add(this.screenGameoverText);
        this.screenGameoverGroup.add(this.screenGameoverBack);
        this.screenGameoverGroup.add(this.screenGameoverRestart);
        this.screenGameoverGroup.add(this.screenGameoverScore);
        // if (this.asteroids !== undefined){
        //     this.asteroids.toggleVisible();
        // }
        //this.invaders.toggleVisible();
        //this.enemies.toggleVisible();
        // this.screenGameoverGroup.add(this.asteroids);
        // this.screenGameoverGroup.add(this.enemies);
        // this.screenGameoverGroup.add(this.invaders);
        this.screenGameoverGroup.toggleVisible();
    }
    addPoints() {
        this._score += 10;
        this.textScore.setText(LC2.text['gameplay-score'] + this._score);

        var randX = Phaser.Math.Between(200, LC2.world.width - 200);
        var randY = Phaser.Math.Between(200, LC2.world.height - 200);
        var pointsAdded = this.add.text(randX, randY, '+10', { font: '48px ' + LC2.text['FONT'], fill: '#ffde00', stroke: '#000', strokeThickness: 10 });
        pointsAdded.setOrigin(0.5, 0.5);
        this.tweens.add({ targets: pointsAdded, alpha: 0, y: randY - 50, duration: 1000, ease: 'Linear' });
        LC2.Sfx.play('points');
        this.cameras.main.shake(100, 0.01, true);
    }
    stateRestart() {
        LC2.Sfx.play('click');
        LC2.fadeOutScene('Game', this);
    }
    stateBack() {
        LC2.Sfx.play('click');
        LC2.fadeOutScene('MainMenu', this);
    }
    gameoverScoreTween() {
        this.screenGameoverScore.setText(LC2.text['gameplay-score'] + '0');
        if (this._score) {
            this.pointsTween = this.tweens.addCounter({
                from: 0,
                to: this._score,
                duration: 2000,
                delay: 250,
                onUpdateScope: this,
                onCompleteScope: this,
                onUpdate: function () {
                    this.screenGameoverScore.setText(LC2.text['gameplay-score'] + Math.floor(this.pointsTween.getValue()));
                },
                onComplete: function () {
                    var emitter = this.add.particles('particle').createEmitter({
                        x: this.screenGameoverScore.x + 30,
                        y: this.screenGameoverScore.y,
                        speed: { min: -600, max: 600 },
                        angle: { min: 0, max: 360 },
                        scale: { start: 0.5, end: 3 },
                        blendMode: 'ADD',
                        active: true,
                        lifespan: 2000,
                        gravityY: 1000,
                        quantity: 250
                    });
                    emitter.explode();
                }
            });
        }
    }




};