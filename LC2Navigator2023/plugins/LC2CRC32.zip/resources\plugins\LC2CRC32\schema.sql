select '<h4>LC2CRC32 Plugin SQL Import</h4>';
drop table IF EXISTS LC2CRC32;
drop table IF EXISTS LC2CRC32temp;
CREATE TABLE LC2CRC32 ( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "last_name" TEXT NULL,  "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL, "street" TEXT NULL,	 "url" TEXT NULL);
create table IF NOT EXISTS LC2CRC32temp (name TEXT,url TEXT, description TEXT NULL, zipcode TEXT NULL, "first_name" TEXT NULL, "last_name" TEXT NULL, "city" TEXT NULL, "street" TEXT NULL);
-- select 'LC2CRC32 Import data running...';
-- .separator "\t"
-- .import .\\import.csv LC2CRC32temp
.separator ";"
.import .\\resources\\plugins\\LC2CRC32\\import\\import.csv LC2CRC32temp
--.import ..\\import\\materialnohead.csv url
-- select '<p>LC2CRC32 temp count:';
-- select count(*) from LC2CRC32temp;
-- select '</p>';
-- select '<hr>';
INSERT INTO LC2CRC32 (name, url, description, zipcode) select name, url, description, zipcode  from LC2CRC32temp;
select '<p>Imported item count:';
select count(*) from LC2CRC32;
select '</p>';
-- select '<hr>';
-- select '<p>successfully imported.</p>';
.exit