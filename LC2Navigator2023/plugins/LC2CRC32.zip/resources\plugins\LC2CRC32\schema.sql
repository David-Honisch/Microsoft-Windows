select '<h4>LC2CRC32 Plugin SQL Import</h4>';
drop table IF EXISTS LC2CRC32;
drop table IF EXISTS LC2CRC32temp;
CREATE TABLE LC2CRC32 ( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
create table IF NOT EXISTS LC2CRC32temp ( first_name varchar(255),name varchar(255), menu TEXT, url varchar(255), subtext TEXT);
-- select 'Create table LC2CRC32 Import';
-- .separator "\t"
-- .import .\\import.csv LC2CRC32temp
.separator ";"
.import .\\resources\\plugins\\LC2CRC32\\import\\import.csv LC2CRC32temp
--.import ..\\import\\materialnohead.csv url
--INSERT INTO person VALUES (4, 'Alice', '351246233');
-- DELETE FROM url where url.name = '';
-- select '<p>LC2CRC32temp count:';
-- select count(*) from LC2CRC32temp;
-- select '</p>';
-- select '<p>SQL Import successfully done</p>';
-- select '<p>LC2CRC32 count:'+count(*)+'</p>' from LC2CRC32temp;
-- select * from LC2CRC32temp limit 1;
-- select '<p>temp table COUNT:'+count(*)+'</p>' from LC2CRC32temp;
INSERT INTO LC2CRC32 (first_name,name, description,zip,url) select first_name,name, menu, subtext,url  from LC2CRC32temp;
select '<p>LC2CRC32 count:';
select count(*) from LC2CRC32;
select '</p>';
-- select '<p>COUNT:'+count(*)+'</p>' from LC2CRC32;
-- select '<p>SQL Menu:</p><br>';
-- select '';
-- select '<hr>';
-- select '<a href="'+url+'">'+name+'</a>' from LC2CRC32;
-- select '<hr>';
-- select '<p>LC2CRC32 count:'+count(*)+' successfully imported.</p>' from LC2CRC32;
.exit