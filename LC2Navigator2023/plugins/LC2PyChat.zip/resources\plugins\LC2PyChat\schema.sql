-- select '<h2>Import processes</h2>';
drop table IF EXISTS LC2PyChat;
drop table IF EXISTS LC2PyChat_Data;
drop table IF EXISTS LC2PyChat_data;
drop table IF EXISTS LC2PyChattemp;
drop table IF EXISTS LC2PyChat_datatemp;
CREATE TABLE LC2PyChat( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE LC2PyChat_data( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE IF NOT EXISTS LC2PyChattemp (
"name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL
);
-- create table IF NOT EXISTS LC2PyChat_datatemp ( name varchar(255));
CREATE TABLE IF NOT EXISTS LC2PyChat_datatemp (
"name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL
);
-- import menu
-- select '<p>Import processes</p>';
.separator ";"
.import .\\resources\\plugins\\LC2PyChat\\import\\import.csv LC2PyChattemp
-- INSERT INTO LC2PyChat(first_name,name,zipcode, city, description) select name,name, pid,ftype,tpid  from LC2PyChattemp;
-- insert work data
INSERT INTO LC2PyChat(first_name,name,zipcode, city, description) select first_name,name,zipcode, city, description  from LC2PyChattemp;
-- eof insert work data
select 'LC2PyChat count:';
select count(*) from LC2PyChat;
-- select '<p>Import working data processes</p>';
-- .separator ";"
--.import .\\resources\\plugins\\LC2PyChat\\import\\LC2PyChatwork.csv LC2PyChattemp
-- .import .\\resources\\plugins\\LC2PyChat\\import\\LC2PyChatwork.csv LC2PyChattemp
-- .import .\\resources\\plugins\\LC2PyChat\\blz-aktuell-txt-data.txt  LC2PyChattemp
-- select 'COUNT:'+count(*) from LC2PyChattemp;
-- INSERT INTO LC2PyChat_data(first_name,name,zipcode, city, description) select first_name,name,zipcode, city, description  from LC2PyChattemp;
.separator ';'
.import '.\\resources\\plugins\\LC2PyChat\\import\\menu.csv' LC2PyChat_datatemp
-- select '<h6>Main menu importing done</h6>'; 
-- select '<p>LC2PyChat_datatemp count:';
-- select count(*)  from LC2PyChat_datatemp;
-- select '</p>';
-- INSERT INTO LC2PyChat_Data (first_name,name, description,url) select name,name, menu,url  from LC2PyChat_Datatemp;
-- INSERT INTO LC2PyChat_data (first_name,name,zipcode, city, description,url) select substr( name, 0, 9 ),rtrim(substr( name, 10, 58 )), substr(name,68,71), substr(name,73,78), name,trim(substr( name, 140, 169))  from LC2PyChat_datatemp;
INSERT INTO LC2PyChat_data(first_name,name,zipcode, city, description) select first_name,name,zipcode, city, description  from LC2PyChat_datatemp;
select '<p>LC2PyChat count:';
select count(*) from LC2PyChat;
select 'LC2PyChat_data count:';
select count(*) from LC2PyChat_data;
drop table IF EXISTS LC2PyChattemp;
-- select '<p>Import done</p>';
.exit