<br />
<b>Warning</b>:  "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? in <b>D:\xampp\htdocs\admin\adminer-4.7.0.php</b> on line <b>1176</b><br />
-- Adminer 4.7.0 MySQL dump

SET NAMES utf8;
SET time_zone = '+00:00';
SET foreign_key_checks = 0;
SET sql_mode = 'NO_AUTO_VALUE_ON_ZERO';

DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id` int(20) NOT NULL AUTO_INCREMENT,
  `user` varchar(255) NOT NULL,
  `pass` varchar(255) NOT NULL,
  `confirmed` tinyint(4) NOT NULL,
  `user_level` tinyint(4) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `users` (`id`, `user`, `pass`, `confirmed`, `user_level`) VALUES
(1,	'admin',	'$2a$10$N8J5wRMeJ5v6z65btGmZvOYGgkS9kIEbSwon3tMKnxZV9mzkqpwzu',	1,	0);

-- 2021-11-18 16:05:06
