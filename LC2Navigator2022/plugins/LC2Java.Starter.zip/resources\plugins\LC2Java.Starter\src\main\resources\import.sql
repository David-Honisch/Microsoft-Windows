REPLACE INTO Books (id, title, price, description) VALUES (1, 'LC1', 9.99, 'LetzteChance.Org - MicroService CMS v.1.0');
REPLACE INTO Books (id, title, price, description) VALUES (2, 'LC2', 19.99, 'LetzteChance.Org - MicroService CMS v.1.1');
REPLACE INTO Books (id, title, price, description) VALUES (3, 'LC3', 29.99, 'LetzteChance.Org - MicroService CMS v.1.2');
REPLACE INTO Books (id, title, price, description) VALUES (4, 'LC4', 39.99, 'LetzteChance.Org - MicroService CMS v.1.3');
REPLACE INTO Books (id, title, price, description) VALUES (5, 'LC5', 49.99, 'LetzteChance.Org - MicroService CMS v.1.4');
--INSERT INTO Books (id, title, price, description, nbofpage, illustrations) VALUES (0, 'aFunctional Programming in Scala', 49.99, 'Functional Programming in Scala is a serious tutorial for programmers looking to learn FP and apply it to the everyday business of coding.', 301, false);
--INSERT INTO Books (id, title, price, description, nbofpage, illustrations) VALUES (1, 'aBig Data Analytics Beyond Hadoop: Real-Time Applications with Storm, Spark, and More Hadoop Alternatives', 55.99, 'Master alternative Big Data technologies that can do what Hadoop can''t: real-time analytics and iterative machine learning', 240, true);
--REPLACE INTO 'projects' ('id', 'description', 'end_date', 'name', 'price', 'start_date', 'subtitle', 'title') VALUES (1, 'Test', NULL, 'Test', '11', NULL, 'Test', NULL);
--REPLACE INTO 'projects' ('id', 'description', 'end_date', 'name', 'price', 'start_date', 'subtitle', 'title') VALUES (2, 'Agile Board', NULL, 'Test', '11', NULL, 'Test', NULL);
--REPLACE INTO 'projects' ('id', 'description', 'end_date', 'name', 'price', 'start_date', 'subtitle', 'title') VALUES (3, 'Agile Time Board', NULL, 'Time Test', '11', NULL, 'Test', NULL);
INSERT INTO projects (id,title,price) VALUES (1, 'Goolge',1.99);
INSERT INTO projects (id,title,price) VALUES (2, 'Microsoft',11.99);
INSERT INTO projects (id,title,price) VALUES (3, 'IBM',9.99);
INSERT INTO projects (id,title,price) VALUES (4, 'Amazon',19.99);
--INSERT INTO projects (id,title,subtitle,  description, name, price,  start_date, end_date) VALUES (3, 'Facebook',  'TEST3',  'TEST3',  'TEST3', 2,99, NULL, NULL);
--INSERT INTO projects (id,title,subtitle,  description, name, price,  start_date, end_date) VALUES (4, 'IBM',  'Oracle',  'Oracle',  'Oracle', 2,99, NULL, NULL);
--INSERT INTO projects (id,title,subtitle,  description, name, price,  start_date, end_date) VALUES (5, 'Oracle',  'Oracle',  'Oracle',  'Oracle', 2,99, NULL, NULL);
--INSERT INTO projects (id,title,subtitle,  description, name, price,  start_date, end_date) VALUES (6, 'Amazon',  'Oracle',  'Oracle',  'Oracle', 2,99, NULL, NULL);
--INSERT INTO projects (id,title,subtitle,  description, name, price,  start_date, end_date) VALUES (8, 'Twitter',  'TEST2',  'TEST2',  'TEST2', 1,99, NULL, NULL);

INSERT INTO products (id,title,price) VALUES (1, 'Google',1.99);
INSERT INTO products (id,title,price) VALUES (2, 'IBM',1.99);

INSERT INTO items (id,release_date, title)VALUES (1,'2019-07-14', 'test');
INSERT INTO items (id, release_date, title)VALUES (2,'2019-07-10', 'test2');
INSERT INTO items (id, release_date, title)VALUES (3,'2019-07-11', 'test3');
INSERT INTO items (id, release_date, title)VALUES (4,'2019-01-12', 'test4');

INSERT INTO author (id,birth_date, name, surname) VALUES (1,'1974-05-01', 'David','Honisch');
INSERT INTO author (id,birth_date, name, surname) VALUES (2,'1964-07-01', 'peter','Mustermann');
INSERT INTO author (id,birth_date, name, surname) VALUES (3,'1964-07-01', 'Anna','Mustermann');

INSERT INTO author_item (author_id, item_id) VALUES (1,2);
INSERT INTO author_item (author_id, item_id) VALUES (1,3);
INSERT INTO author_item (author_id, item_id) VALUES (2,1);
INSERT INTO author_item (author_id, item_id) VALUES (2,2);

--INSERT INTO user (email, password, name, surname) VALUES ('test@test.com', 'test', 'John', 'Smith');
