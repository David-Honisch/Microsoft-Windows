package org.letztechance.quarkus.extension.1.it;

import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.is;

import org.junit.jupiter.api.Test;

import io.quarkus.test.junit.QuarkusTest;

@QuarkusTest
public class 1ResourceTest {

    @Test
    public void testHelloEndpoint() {
        given()
                .when().get("/1")
                .then()
                .statusCode(200)
                .body(is("Hello 1"));
    }
}
