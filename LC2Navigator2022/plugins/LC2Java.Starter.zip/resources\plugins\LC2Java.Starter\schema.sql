select '<h4>LC2Java.Starter Plugin SQL Import</h4>';
drop table IF EXISTS LC2Java_Starter;
drop table IF EXISTS LC2Java_Startertemp;
CREATE TABLE LC2Java.Starter ( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
create table IF NOT EXISTS LC2Java_Startertemp ( name varchar(255), menu TEXT, url varchar(255), subtext TEXT);
-- select 'Create table LC2Java.Starter Import';
-- .separator "\t"
-- .import .\\import.csv LC2Java.Startertemp
.separator ";"
.import .\\resources\\plugins\\LC2Java.Starter\\import\\import.csv LC2Java_Startertemp
--.import ..\\import\\materialnohead.csv url
--INSERT INTO person VALUES (4, 'Alice', '351246233');
-- DELETE FROM url where url.name = '';
-- select '<p>LC2Java.Startertemp count:';
-- select count(*) from LC2Java.Startertemp;
-- select '</p>';
-- select '<p>SQL Import successfully done</p>';
-- select '<p>LC2Java.Starter count:'+count(*)+'</p>' from LC2Java.Startertemp;
-- select * from LC2Java.Startertemp limit 1;
-- select '<p>temp table COUNT:'+count(*)+'</p>' from LC2Java.Startertemp;
INSERT INTO LC2Java.Starter (first_name,name, description,url) select name,name, menu,url  from LC2Java_Startertemp;
select '<p>LC2Java.Starter count:';
select count(*) from LC2Java_Starter;
select '</p>';
-- select '<p>COUNT:'+count(*)+'</p>' from LC2Java.Starter;
-- select '<p>SQL Menu:</p><br>';
-- select '';
-- select '<hr>';
-- select '<a href="'+url+'">'+name+'</a>' from LC2Java.Starter;
-- select '<hr>';
-- select '<p>LC2Java.Starter count:'+count(*)+' successfully imported.</p>' from LC2Java.Starter;
.exit