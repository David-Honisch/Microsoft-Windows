package org.letztechance.domain.quarkus.projects.hibernate.orm.services.items;

import java.math.BigDecimal;
import java.math.BigInteger;

import org.letztechance.domain.quarkus.orm.entities.items.Item;

public class ItemService {
	
	public boolean valid;
    public String name;
    public String data;
	public Item findItem(Integer id) {
		Item item = new Item();
		item.name = "Fuck";
		item.price = new BigDecimal(new BigInteger(new byte[] {0x01}));
		return item;
	}
    
    

}
