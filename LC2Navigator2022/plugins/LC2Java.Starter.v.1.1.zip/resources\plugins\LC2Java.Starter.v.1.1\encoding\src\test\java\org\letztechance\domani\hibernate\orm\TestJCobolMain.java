package org.letztechance.domani.hibernate.orm;

import static io.restassured.RestAssured.given;
import static org.hamcrest.CoreMatchers.containsString;

import org.junit.jupiter.api.Test;
import org.letztechance.domani.hibernate.orm.entities.CobolCommand;

import io.quarkus.test.junit.QuarkusTest;

@QuarkusTest
public class TestJCobolMain implements CobolCommand {
	
    @Test
    public void testGetListAllCobolCommands() {
        //List all, should have all 3 products the database has initially:
        given()
                .when().get("/cobolcommand")
                .then()
                .statusCode(200)
                .body(
                		containsString(COBOL_COMMAND_X1.replace("%s","1")),
                        containsString(COBOL_COMMAND_X1.replace("%s","2")));

    }
    
    
}
