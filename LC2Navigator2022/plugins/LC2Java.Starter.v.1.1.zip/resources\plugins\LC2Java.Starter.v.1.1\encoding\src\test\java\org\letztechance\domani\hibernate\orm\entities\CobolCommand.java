package org.letztechance.domani.hibernate.orm.entities;

public interface CobolCommand {
	public static final String COBOL_COMMAND_X1 = "CobolCommand x%s";
}
