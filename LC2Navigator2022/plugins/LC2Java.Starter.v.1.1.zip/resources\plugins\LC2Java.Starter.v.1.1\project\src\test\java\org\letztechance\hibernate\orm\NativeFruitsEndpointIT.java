//package org.letztechance.hibernate.orm;
//
//import io.quarkus.test.junit.NativeImageTest;
//
//@NativeImageTest
//public class NativeFruitsEndpointIT extends FruitsEndpointTest {
//
//    // Runs the same tests as the parent class
//
//}
