package org.letztechance.domain.quarkus.projects.hibernate.orm;

import io.quarkus.test.junit.NativeImageTest;

@NativeImageTest
public class NativeProductsEndpointIT extends TestProductEndpoint {

    // Runs the same tests as the parent class

}
