package org.letztechance.domani.hibernate.orm.entities;

import static io.restassured.RestAssured.given;
import static org.hamcrest.CoreMatchers.containsString;
import static org.hamcrest.core.IsNot.not;

import org.junit.jupiter.api.Test;

import io.quarkus.test.junit.QuarkusTest;

@QuarkusTest
public class TestCobolCommandsEndpoint extends TestCobolEndPointListAll {

    

	@Test
    public void testListAll() {
        //List all, should have all 3 products the database has initially:
        given()
                .when().get("/cobolcommand")
                .then()
                .statusCode(200)
                .body(
                        containsString(COBOL_COMMAND_X1.replace("%s","1")),
                        containsString(COBOL_COMMAND_X1.replace("%s","2")),
                        containsString(COBOL_COMMAND_X1.replace("%s","3")));


        //Delete the 3:
        given()
                .when().delete("/cobolcommand/3")
                .then()
                .statusCode(204);

        //List all, 3 should be missing now:
        given()
                .when().get("/cobolcommand")
                .then()
                .statusCode(200)
                .body(
                        not(containsString(COBOL_COMMAND_X1.replace("%s","3"))),
                        containsString(COBOL_COMMAND_X1.replace("%s","1")),
                        containsString(COBOL_COMMAND_X1.replace("%s","2")));

        //Create the Product:
        given()
                .when()
                .body("{\"name\" : \""+COBOL_COMMAND_X1.replace("%s","4")+"\"}")
                .contentType("application/json")
                .post("/cobolcommand")
                .then()
                .statusCode(201);

        //List all, products should be missing now:
        given()
                .when().get("/cobolcommand")
                .then()
                .statusCode(200)
                .body(
                        not(containsString(COBOL_COMMAND_X1.replace("%s","5"))),
                        containsString(COBOL_COMMAND_X1.replace("%s","1")),
                        containsString(COBOL_COMMAND_X1.replace("%s","2")),
                        containsString(COBOL_COMMAND_X1.replace("%s","3")));
    }

}
