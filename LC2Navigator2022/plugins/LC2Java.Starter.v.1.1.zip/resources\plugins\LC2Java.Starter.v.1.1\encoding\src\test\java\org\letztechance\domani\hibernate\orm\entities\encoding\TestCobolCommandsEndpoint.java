package org.letztechance.domani.hibernate.orm.entities.encoding;

import static io.restassured.RestAssured.given;
import static org.hamcrest.CoreMatchers.containsString;
import static org.hamcrest.core.IsNot.not;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.letztechance.domani.hibernate.orm.entities.TestCobolEndPointListAll;

import io.quarkus.test.junit.QuarkusTest;

@QuarkusTest
public class TestCobolCommandsEndpoint extends TestCobolEndPointListAll {

	@Test
	public void testListAll() {
		// List all, should have all 3 products the database has initially:
		given().when().get("/cobolcommand").then().statusCode(200).body(containsString("CobolCommand x1"),
				containsString("CobolCommand x2"), containsString("CobolCommand x3"));

	}

	@Test
	public void testCreateEncodedItems() {
		// List all, should have all 3 products the database has initially:
		List<String> list = new ArrayList<String>() {
			{
				add("CobolCommand x11");
				add("CobolCommand x12");
				add("CobolCommand x13");
				add("CobolCommand x14");
				add("CobolCommand x15");
				add("CobolCommand x16");
				add("CobolCommand x17");
				add("CobolCommand x18");
				add("CobolCommand x19");
				add("CobolCommand x20");
			}
		};
		for (String s : list) {
			given().when().body("{\"name\" : \"" + s + "\"}").contentType("application/json").post("/cobolcommand")
					.then().statusCode(201);
		}

		// List all, cherry should be missing now:
		given().when().get("/cobolcommand").then().statusCode(200).body(not(containsString("Cherry")),
				containsString("CobolCommand x11"), 
				containsString("CobolCommand x19"), 
				containsString("CobolCommand x20"));
	}

}
