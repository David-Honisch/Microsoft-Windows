package org.letztechance.domain.quarkus.projects.hibernate.orm.services.resources;
//package org.letztechance.domain.quarkus.projects.hibernate.orm;
//
//import javax.inject.Inject;
//import javax.ws.rs.GET;
//import javax.ws.rs.Path;
//import javax.ws.rs.Produces;
//import javax.ws.rs.QueryParam;
//import javax.ws.rs.core.MediaType;
//
//import io.quarkus.qute.TemplateInstance;
//import io.quarkus.qute.CheckedTemplate;
//
//@Path("Welcome")
//public class WelcomeResource {
//
////    @Inject
////    Template welcome;
//	@CheckedTemplate
//	public static class Templates {
//		public static native TemplateInstance welcome(String name);
//	}
//
//	@GET
//    @Produces(MediaType.TEXT_PLAIN)
//    public TemplateInstance get(@QueryParam("name") String name) {
//        return Templates.welcome(name); 
//    }
//}
