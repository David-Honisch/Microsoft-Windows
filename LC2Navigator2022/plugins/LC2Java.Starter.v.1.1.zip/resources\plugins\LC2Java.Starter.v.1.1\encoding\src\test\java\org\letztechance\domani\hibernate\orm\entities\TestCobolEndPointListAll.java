package org.letztechance.domani.hibernate.orm.entities;

import static io.restassured.RestAssured.given;
import static org.hamcrest.CoreMatchers.containsString;


import org.junit.jupiter.api.Test;

import io.quarkus.test.junit.NativeImageTest;

@NativeImageTest
public class TestCobolEndPointListAll implements CobolCommand  {

	public static String getCobolCommandX1() {
		return COBOL_COMMAND_X1;
	}
	
	@Test
    public void testListAllCobolCommands() {
        //List all, should have all 3 products the database has initially:
        given()
                .when().get("/cobolcommand")
                .then()
                .statusCode(200)
                .body(
                        containsString(COBOL_COMMAND_X1.replace("%s","1")),
                        containsString(COBOL_COMMAND_X1.replace("%s","2")),
                        containsString(COBOL_COMMAND_X1.replace("%s","3")));

	
	}
}
