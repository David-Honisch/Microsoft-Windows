var app = angular.module("app", []);

//Controller Part
app.controller("appController", function($scope, $http) {
	$scope.title = "LC Projects - Home";
	$scope.api = "/projects";
	$scope.navs = [];
	$scope.projects = [];
	$scope.products = [];

	$scope.form = {
		id: -1,
		name: "",
		customerName: "",
	};
	document.title = $scope.title;
	//Now load the data from server
	_refreshPageData();

	//HTTP POST/PUT methods for add/edit projects
	$scope.update = function() {
		var method = "";
		var url = "";
		var data = {};
		if ($scope.form.id == -1) {
			//Id is absent so add projects - POST operation
			method = "POST";
			url = $scope.api;
			data.name = $scope.form.name;
			data.customerName = $scope.form.customerName;
		} else {
			//If Id is present, it's edit operation - PUT operation
			method = "PUT";
			url = $scope.api + $scope.form.id;
			data.name = $scope.form.name;
			data.customerName = $scope.form.customerName;
		}

		$http({
			method: method,
			url: url,
			data: angular.toJson(data),
			headers: {
				'Content-Type': 'application/json'
			}
		}).then(_success, _error);
	};

	//HTTP DELETE- delete project by id
	$scope.remove = function(project) {
		$http({
			method: 'DELETE',
			url: $scope.api + project.id
		}).then(_success, _error);
	};

	//In case of edit projects, populate form with project data
	$scope.edit = function(project) {
		$scope.form.name = project.name;
		$scope.form.id = project.id;
	};

	/* Private Methods */
	//HTTP GET- get all projects collection
	function _refreshPageData() {
		$http({
			method: 'GET',
			url: $scope.api
		}).then(function successCallback(response) {
			$scope.projects = response.data;
		}, function errorCallback(response) {
			console.log(response.statusText);
		});
		$http({
			method: 'GET',
			url: '/products'
		}).then(function successCallback(response) {
			$scope.products = response.data;
		}, function errorCallback(response) {
			console.log(response.statusText);
		});
		$http({
			method: 'GET',
			url: '/assets/data/nav.json'
		}).then(function successCallback(response) {
			$scope.navs = response.data;
			console.log(JSON.stringify($scope.navs));
		}, function errorCallback(response) {
			console.log(response.statusText);
		});
	}

	function _success(response) {
		_refreshPageData();
		_clearForm()
	}

	function _error(response) {
		alert(response.data.message || response.statusText);
	}

	//Clear the form
	function _clearForm() {
		$scope.form.name = "";
		$scope.form.id = -1;
	}
});