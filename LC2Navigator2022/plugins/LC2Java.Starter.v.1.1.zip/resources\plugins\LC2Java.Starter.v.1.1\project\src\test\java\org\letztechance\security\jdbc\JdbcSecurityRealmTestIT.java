package org.letztechance.security.jdbc;

import io.quarkus.test.junit.NativeImageTest;

@NativeImageTest
public class JdbcSecurityRealmTestIT extends JdbcSecurityRealmTest {
}
