//'use strict';
//// const path = window.nodeRequire('path');
//// // const $ = window.nodeRequire('jquery');
//// const jQuery = window._PAGE_.jQuery;
//// // const fs = window.nodeRequire('fs');
//// const cfg = window.nodeRequire(path.join(__dirname, 'assets', 'js', 'config.json'));
//// const out = $('#out');
//console.log('RUNNING...');
//$('#golegend').html('OUT:');
//// test('#golegend', '#golegend')
//console.log('RUNNING.2..');
//$.urlParam = function(name) {
//    var results = new RegExp('[\?&]' + name + '=([^&#]*)').exec(window.location.href);
//    if (results == null) {
//        return null;
//    }
//    return decodeURI(results[1]) || 0;
//}
//
//
//window.onload = init();
//
//function init() {
//
//    getHead();
//    $('#out').html('...');
//    $('#out').append('RUNNING DONE.');
//    console.log('INIT RUNNING...');
//    $('#out').append('INIT RUNNING...');
//
//    $('#out').html('Successfully done.');
//    $('body').on('click', '#alertcnt a', (event) => {
//        let link = event.target.href;
//        event.preventDefault();
//        console.log(link);
//        window.nodeRequire("electron").shell.openExternal(link);
//    });
//
//    console.log('DONE.');
//}
//
//function getHead() {
//    document.title = 'LETZECHANCE.ORG - Show tables';
//    var head = getHeader(cfg.local);
//    // console.log(JSON.stringify(head));    
//    $('#head').html(head);
//    $('#ptitle').html('LC2Navigator Home - Show tables');
//}
//
//
//function print(t, isAppend) {
//    if (!isAppend) {
//        out.html(t);
//    } else {
//        out.append(t);
//    }
//}
//
//function msg(t) {
//    return t;
//}
//
//
//
//function getHeader(page) {
//    var result = "<div id=\"cm-menu\">";
//    result += "<nav id=\"top\" class=\"cm-navbar cm-navbar-primary lc-header\"> ";
//    result += "<div class=\"cm-flex\"><a href=\"index.html\" class=\"cm-logo\"></a></div> ";
//    result += "<div class=\"btn btn-primary md-menu-white lc-header\" data-toggle=\"cm-menu\" id=\"cm-menu\"></div> ";
//    result += "</nav>";
//
//    result += "<div id=\"ctop\"></div>";
//
//    result += "<div id=\"cm-menu-content\"> ";
//    result += "<div id=\"cm-menu-items-wrapper\"> ";
//    result += "<div id=\"cm-menu-scroller\"> ";
//    result += "<ul class=\"cm-menu-items\"> ";
//
//    result += "<li class=\"cm_submenu\"><a href=\"index.html\">Application</a></li> ";
//    result += "<li ><a href=\"index.html\">Application</a></li> ";
//    // result += "<li ><a href=\"index.html\">Application</a></li> ";
//    result += "</ul> ";
//    result += "</div> ";
//    result += "</div> ";
//    result += "</div> ";
//    result += "</div> ";
//    result += " <header id=\"cm-header\"> ";
//    result += " <nav class=\"cm-navbar cm-navbar-primary lc-header\"> ";
//    result += "<div class=\"btn btn-primary md-menu-white hidden-md hidden-lg lc-header\" data-toggle=\"cm-menu\">";
//
//
//    // result += "<ul class=\"cm-menu-items\"> ";
//    // result += "<li ><a href=\"index.html\">Application</a></li> ";
//    // result += "<li ><a href=\"index.html\">Application</a></li> ";
//    // result += "</ul> ";
//
//    result += "</div> ";
//    result += " <div class=\"cm-flex\"> ";
//    result += " <div class=\"cm-breadcrumb-container\"> ";
//    // result += " <ol class=\"breadcrumb\"> ";
//    // result += " <li><a href=\"index.html\">" + msg('indexpage') + "</a></li> ";
//    // result += " <li><a href=\"start.html\" class=\"active\">" + msg('startpage') + "</a></li> ";
//    // result += " </ol> ";
//    result += "</div> ";
//    result += "<form id=\"cm-search\" action=\"" + page.host + "\" method=\"get\"> ";
//    result += "<input type=\"search\" id=\"btnquery\" name=\"query\" autocomplete=\"on\" placeholder=\"" + msg('search') + "\"> ";
//    result += "<input type=\"hidden\" name=\"q\" value=\"search\">";
//
//    result += "</form> ";
//    result += "</div> ";
//    // result += "<div class=\"pull-right\"> ";
//    // result += "<div id=\"cm-search-btn\" class=\"btn btn-primary md-search-white lc-header\" data-toggle=\"cm-search\"></div> ";
//    // result += "</div> ";
//    // result += "<div class=\"dropdown pull-right\"> ";
//    // result += "<button class=\"btn btn-primary md-notifications-white lc-header\" data-toggle=\"dropdown\" id=\"btnalerts\"><span class=\"label label-danger\" id=\"lbldanger\">10</span></button><div class=\"popover cm-popover bottom\"> ";
//    // result += "<div class=\"arrow\"></div> ";
//    // result += "<div class=\"popover-content\"> ";
//    // result += "<div class=\"list-group\" id=\"list-group\"> ";
//    // result += "</div> ";
//    // result += "<div style=\"padding:10px\"><a id=\"btnshowmore\" class=\"btn btn-success btn-block\" href=\"./start.html#fullcalendar\" rel=\"external\">" + msg('showmemore') + "</a></div> ";
//    // result += "</div> ";
//    // result += "</div> ";
//    // result += "</div> ";
//    // result += "<div class=\"dropdown pull-right\"> ";
//    // result += "<button class=\"btn btn-primary md-account-circle-white lc-header\" data-toggle=\"dropdown\"></button> ";
//
//    // result += "<ul class=\"dropdown-menu\"> ";
//    // result += "<li class=\"disabled text-center\"> ";
//    // result += "<a style=\"cursor:default;\"><strong id=\"uname\">anonymous</strong></a> ";
//    // result += "</li> ";
//    // result += "<li class=\"divider\"></li> ";
//    // result += "<li> ";
//    // result += "<a href=\"#\" id=\"btnprofil\" data-toggle=\"modal\" data-target=\"#myModal\"><i class=\"fa fa-fw fa-user\"></i>" + msg('profil') + "</a> ";
//    // result += "</li> ";
//    // result += "<li> ";
//    // result += "<a href=\"#\" id=\"btnoptions\" data-toggle=\"modal\" data-target=\"#myModal\"><i class=\"fa fa-fw fa-cog\"></i>" + msg('options') + "</a> ";
//    // result += "</li> ";
//    // result += "<li> ";
//    // result += "<a href=\"./?logout=1&l=de_DE\" id=\"btnlogout\"><i class=\"fa fa-fw fa-sign-out\"></i>" + msg('logout') + "</a> ";
//    // result += "</li> ";
//    result += "</ul> ";
//
//    result += "</div> ";
//    result += "</nav> ";
//    result += "</header> ";
//    return result;
//}
////deprecated
//// function getContent() {
////     var result = "";
////     // var result = "<!--cookie--><div class=\"ui-widget\"><div class=\"cookie-message ui-widget-header brown\"><p>Cookies erlauben?Cookies sind harmlos und werden niemals zur identifizerung Ihrer Person verwendet.</p></div></div><!--and this is the end.--> ";
////     result = this.getHeader(result);
//
////     result += " <div id=\"global\"> ";
////     result += " <noscript><div style=\"text-align:center;\"><h1 class=\"alert\">Javascript not activated</h1><p class=\"salert\">Important navigation elements are not visible.</p></div></noscript> ";
//
////     result += " <div id=\"headcnt\"></div> ";
////     // result += " <div id=\"bodycnt\">";
////     result += "<div id=\"out\"><div class=\"preloader\">Lade</div></div>";
////     result += "<div id=\"cnt\" class=\"cnt\" ></div>";
////     result += "<div id=\"statistic\" class=\"container-fluid cm-container-white\"></div>";
////     result += "<div id=\"error\" class=\"error\" ></div>";
////     result += "<div id=\"carousel\" class=\"carousel\" ></div>";
////     // result += " </div> ";
////     // result += " <div id=\"footcnt\"></div> ";
////     result += "<div id=\"mdialog\" title=\"\"></div>";
////     result += ModalDialog.getModalDialog();
//
////     // result += " </div> ";
////     result += " </div> ";
////     // result += " <div class=\"container-fluid cm-container-white\" id=\"log\">";
////     // result += " </div> ";
////     result += "<div class=\"container-fluid cm-container-white\" id=\"footcontent\">";
////     result += "<div class=\"preload\">foot loading...</div>";
////     result += "</div>";
//
////     result += "<footer class=\"cm-footer container-fluid cm-container-white\" id=\"footercnt\">";
////     result += "<span class=\"pull-left2\" id=\"lconnected\">Internet Connection:</span><span class=\"pull-left2\" id=\"conntected\">Not status available</span>&nbsp;|&nbsp;";
////     result += "<span class=\"pull-left2\" id=\"lloggedin\">Logged in:</span><span class=\"pull-left2\" id=\"loggedin\">Not status available</span>";
////     result += "</footer>";
////     return result;
//// }