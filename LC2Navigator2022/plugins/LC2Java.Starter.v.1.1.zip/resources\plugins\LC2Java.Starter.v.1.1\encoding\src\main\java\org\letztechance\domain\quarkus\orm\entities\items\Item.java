package org.letztechance.domain.quarkus.orm.entities.items;

import java.math.BigDecimal;

public class Item {
	public String name;
    public BigDecimal price;
    
    

}
