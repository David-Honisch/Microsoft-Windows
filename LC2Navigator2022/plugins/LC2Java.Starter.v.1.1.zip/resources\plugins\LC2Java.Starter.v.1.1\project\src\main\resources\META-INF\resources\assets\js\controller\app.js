//LC2Navigator 2022
var app = angular.module('app', ['ui.bootstrap']);

function AppController($scope, $http, $filter) {
	$scope.title = "LC data - Home";
	$scope.api = "/projects/";

	// default values for pagination and filtering
	$scope.pageSize = 10;
	$scope.maxSize = 10;
	$scope.start = 0;
	$scope.end = 0;
	$scope.currentPage = 0;
	$scope.numOfPages = 0;
	$scope.filteredItems = [];
	$scope.startItems = [];
	$scope.pagedItems = [];
	//$scope.currentTable = $.urlParam('db') !== undefined ? $.urlParam('db') : "systables";
	$scope.currentTable = "systables";
	$scope.data = [];
	$scope.query = { name: "" };
	$scope.index = [];
	$scope.news = [];
	$scope.menu = [];
	$scope.navs = [];
	//	$scope.data = [];
	$scope.products = [];
	$scope.cfg = {  };

	// get the data
	//	$http.get('assets/js/data/mainmenu.json')
	//		.success(function(data) {
	//			// set the data
	//			$scope.menu = data;
	//		});		
	

//	$http.get($scope.api)
//		.success(function(data) {
//			// set the data
//			$scope.data = data;
//		});
	document.title = $scope.title;
	//Now load the data from server
	_refreshPageData();


	// when the data is altered, filter the items and set the page
	$scope.$watch('data', function(data, old) {
		$scope.filteredItems = $filter('filter')(data, $scope.query);
		if (old === null) setPage();
	});

	// when the query value changes, refilter the data
	$scope.$watch('query|json', function() {
		$scope.filteredItems = $filter('filter')($scope.data, $scope.query);
	});

	// set the pagination for the filtered items
	function setPage() {
		$scope.start = ($scope.currentPage - 1) * $scope.pageSize + ($scope.filteredItems === undefined && $scope.filteredItems.length ? 1 : 0);
		$scope.startItems = $filter('startFrom')($scope.filteredItems, $scope.start - 1);
	}

	// when the current page is changed by the pagination control, update the list of items
	$scope.$watch('currentPage', function(page) {
		setPage();
	});

	// when the filtered items are set, recalculate the number of pages
	$scope.$watch('filteredItems', function(items, old) {
		$scope.currentPage = 0;
		if (items !== undefined && items.length !== undefined)
			$scope.numOfPages = Math.ceil(items.length / $scope.pageSize);
	});

	// when the page start is changed, update the list of paged items
	$scope.$watch('startItems', function(items) {
		$scope.pagedItems = $filter('limitTo')(items, $scope.pageSize);
		$scope.end = ($scope.currentPage -1 ) * $scope.pageSize + $scope.pagedItems.length;
	});

	$scope.form = {
		id: -1,
		name: "",
		customerName: "",
	};


	$scope.update = function() {
		var method = "";
		var url = "";
		var data = {};
		if ($scope.form.id == -1) {
			//Id is absent so add data - POST operation
			method = "POST";
			url = $scope.api;
			data.name = $scope.form.name;
			data.customerName = $scope.form.customerName;
		} else {
			//If Id is present, it's edit operation - PUT operation
			method = "PUT";
			url = $scope.api + $scope.form.id;
			data.name = $scope.form.name;
			data.customerName = $scope.form.customerName;
		}

		$http({
			method: method,
			url: url,
			data: angular.toJson(data),
			headers: {
				'Content-Type': 'application/json'
			}
		}).then(_success, _error);
	};

	//HTTP DELETE- delete project by id
	$scope.remove = function(project) {
		$http({
			method: 'DELETE',
			url: $scope.api + '' + project.id
		}).then(_success, _error);
	};

	//In case of edit data, populate form with project data
	$scope.edit = function(project) {
		$scope.form.name = project.name;
		$scope.form.id = project.id;
	};

	/* Private Methods */
	//HTTP GET- get all data collection
	function _refreshPageData() {
		//get nav
		$http({
			method: 'GET',
			url: '/assets/data/nav.json'
		}).then(function successCallback(response) {
			$scope.navs = response.data;
			//			console.log(JSON.stringify($scope.navs));
		}, function errorCallback(response) {
			console.log(response.statusText);
		});		
		//get products
		$http({
			method: 'GET',
			url: '/products'
		}).then(function successCallback(response) {
			$scope.products = response.data;
		}, function errorCallback(response) {
			console.log(response.statusText);
		});
		//get projects
		$http({
			method: 'GET',
			url: $scope.api
		}).then(function successCallback(response) {
			$scope.data = response.data;
			$scope.news = response.data;
		}, function errorCallback(response) {
			console.log(response.statusText);
		});
		$http.get('assets/data/config.json')
			.success(function(data) {
				$scope.cfg = data;
				$scope.menu = data.urls;
			});

		$http.get('/projects')
			.success(function(data) {
				// set the data
				$scope.index = data;
			});

//		$http.get('/products')
//			.success(function(data) {
//				// set the data
//				$scope.news = data;
//			});

	}

	function _success(response) {
		_refreshPageData();
		_clearForm()
	}

	function _error(response) {
		alert(response.data.message || response.statusText);
	}

	//Clear the form
	function _clearForm() {
		$scope.form.name = "";
		$scope.form.id = -1;
	}



}

// angular directive to change default behavior from processing input change immediately to on blur or enter
app.directive('ngModelBlur', function() {
	return {
		restrict: 'A',
		require: 'ngModel',
		link: function(scope, elm, attr, ngModelCtrl) {
			if (attr.type === 'radio' || attr.type === 'checkbox') { return; }

			elm.unbind('input').unbind('keydown').unbind('change');
			elm.bind('blur keydown', function(e) {
				if (e.type === 'keydown' && e.which !== 13) { return; }

				scope.$apply(function() {
					ngModelCtrl.$setViewValue(elm.val());
				});
			});
		}
	};
});

// angular filter to take array items starting from provided index
app.filter('startFrom', function() {
	return function(input, start) {
		if (angular.isArray(input)) {
			var st = parseInt(start, 10);
			if (isNaN(st)) st = 0;
			return input.slice(st);
		}
		return input;
	};
});