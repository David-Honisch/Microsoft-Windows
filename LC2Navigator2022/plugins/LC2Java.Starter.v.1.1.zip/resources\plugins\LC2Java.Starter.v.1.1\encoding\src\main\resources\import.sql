--CREATE ROLE quarkus WITH LOGIN PASSWORD 'quarkus';
--CREATE DATABASE quarkus_test;
--GRANT ALL PRIVILEGES ON DATABASE quarkus_test TO quarkus;
--\c quarkus_test

CREATE TABLE test_user (
    id INT,
    username VARCHAR(255),
    password VARCHAR(255),
    role VARCHAR(255)
);
GRANT ALL PRIVILEGES ON TABLE  test_user TO quarkus;
INSERT INTO test_user (id, username, password, role) VALUES (1, 'admin', 'admin', 'admin');
INSERT INTO test_user (id, username, password, role) VALUES (2, 'user','user', 'user');


INSERT INTO known_cobolcommands(id, name) VALUES (1, 'CobolCommand x1');
INSERT INTO known_cobolcommands(id, name) VALUES (2, 'CobolCommand x2');
INSERT INTO known_cobolcommands(id, name) VALUES (3, 'CobolCommand x3');

INSERT INTO known_products(id, name) VALUES (1, 'create');
INSERT INTO known_products(id, name) VALUES (2, 'insert');
INSERT INTO known_products(id, name) VALUES (3, 'update');
INSERT INTO known_products(id, name) VALUES (4, 'delete');
INSERT INTO known_products(id, name) VALUES (5, 't1');
INSERT INTO known_products(id, name) VALUES (6, 't2');
INSERT INTO known_products(id, name) VALUES (7, 't3');