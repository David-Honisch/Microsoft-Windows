package org.letztechance.domani.hibernate.orm.entities;

import static io.restassured.RestAssured.given;
import static org.hamcrest.CoreMatchers.containsString;
import static org.hamcrest.core.IsNot.not;

import org.junit.jupiter.api.Test;

import io.quarkus.test.junit.QuarkusTest;

@QuarkusTest
public class TestProductEndpoint {

    @Test
    public void testProducts() {
        //List all, should have all 10 product the database has initially:
        given()
                .when().get("/products")
                .then()
                .statusCode(200)
                .body(
                        containsString("update"),
                        containsString("insert"),
                        containsString("delete"));

        //Delete the 5:
        given()
                .when().delete("/products/5")
                .then()
                .statusCode(204);

        //List all, 5 should be missing now:
        given()
                .when().get("/products")
                .then()
                .statusCode(200)
                .body(
                        not(containsString("AnyData")),
                        containsString("update"),
                        containsString("delete"));

        //Create the item:
        given()
                .when()
                .body("{\"name\" : \"INSERTME\"}")
                .contentType("application/json")
                .post("/products")
                .then()
                .statusCode(201);

        //List all, products should be missing now:
        given()
                .when().get("/products")
                .then()
                .statusCode(200)
                .body(
                        not(containsString("Cherio")),
                        containsString("update"),
                        containsString("insert"),
                        containsString("delete"));
    }

}
