package org.letztechance.quarkus.extension.1.it;

import io.quarkus.test.junit.NativeImageTest;

@NativeImageTest
public class Native1ResourceIT extends 1ResourceTest {
}
