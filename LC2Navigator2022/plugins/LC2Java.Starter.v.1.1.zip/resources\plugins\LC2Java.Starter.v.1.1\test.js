@echo off
SET "LT=^<"
SET "RT=^>"
cls
call %~dp0config.bat
@echo off
set "outFile=%1"

REM echo %LT%div class="row" %RT%
REM APP
echo %LT%div class="panel panel-default" %RT%
echo %LT%div class="panel-heading" %RT% APP %LT%/div%RT%
echo %LT%div class="panel-body" %RT%

echo %LT%h1%RT%%title% %version%%LT%/h1%RT%
REM LC2LinkCLI.exe -n Test -t LC2LinkCLI.exe.lnk -s LC2LinkCLI.exe.exe
echo call %cd%\resources\plugins\%plugin%\LC2LinkCLI.exe -n LC2LinkCLI -t %cd%\resources\plugins\%plugin%\LC2LinkCLI.exe.lnk -s %cd%\resources\plugins\%plugin%\LC2LinkCLI.exe
call %~dp0LC2LinkCLI.exe -n LC2LinkCLI -t LC2LinkCLI.exe.lnk -s %cd%\resources\plugins\%plugin%\LC2LinkCLI

dir /b /s %~dp0 > %temp%\lc2link.log
type %temp%\lc2link.log

REM echo %LT%hr%RT%
REM echo %LT%div id="appcnt"%RT%%LT%/div%RT%
echo %LT%div id="app_cnt"%RT%%LT%/div%RT%
echo %LT%div id="test_cnt"%RT%%LT%/p%RT% %LT%/div%RT%
echo %LT%div id="appcntprogress"%RT%%LT%/div%RT%

echo %LT%div id="mysqlcnt"%RT%
echo %LT%h6%RT%Data sucessfully loaded. %LT%/h6%RT%
echo %LT%/div%RT%



echo %LT%/div%RT%
REM echo %LT%/div%RT%
REM EOF APP
timeout 0 > NUL 
@echo on 