select '<h4>LC2EncrypDecrypt Plugin SQL Import</h4>'; 
drop table IF EXISTS LC2EncrypDecrypt;
drop table IF EXISTS LC2EncrypDecrypttemp;
CREATE TABLE LC2EncrypDecrypt ( 'person_id' INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, 'created' TIMESTAMP DEFAULT CURRENT_TIMESTAMP NULL, 'modified' TIMESTAMP DEFAULT CURRENT_TIMESTAMP NULL, 'enddate' TIMESTAMP DEFAULT CURRENT_TIMESTAMP NULL, 'name' TEXT NOT NULL, 'first_name' TEXT NULL, 'description' TEXT NULL, 'zipcode' TEXT NULL, 'city' TEXT NULL,	 'street' TEXT NULL,	 'url' TEXT NULL);
create table IF NOT EXISTS LC2EncrypDecrypttemp ( name varchar(255), menu TEXT, url varchar(255), subtext TEXT);
.separator ';'
.import .\\resources\\plugins\\LC2EncrypDecrypt\\import\\import.csv LC2EncrypDecrypttemp
INSERT INTO LC2EncrypDecrypt (first_name,name, description,url) select name,name, menu,url  from LC2EncrypDecrypttemp;
select '<p>LC2EncrypDecrypt count:';
select count(*) from LC2EncrypDecrypt;
select '</p>';
.exit
