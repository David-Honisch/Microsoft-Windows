var utils = new XLSXUtils(XLSX);

/* <input type="submit" value="Import to SQLite" id="dbimport" onclick="export_db();" disabled="false"></input> */
$("#xlsxport").on("click", function(e) {
    e.preventDefault();
    e.stopPropagation();
    utils.export_all();
});
$("#csvxport").on("click", function(e) {
    e.preventDefault();
    e.stopPropagation();
    utils.export_csv();
});
$("#xmlxport").on("click", function(e) {
    e.preventDefault();
    e.stopPropagation();
    utils.export_xml();
});
$("#jsonxport").on("click", function(e) {
    e.preventDefault();
    e.stopPropagation();
    utils.export_json();
});
$("#dbimport").on("click", function(e) {
    e.preventDefault();
    e.stopPropagation();
    // alert('Debug');
    utils.export_db();
});
var httprequest = new HttpRequest();
httprequest.getFullList();