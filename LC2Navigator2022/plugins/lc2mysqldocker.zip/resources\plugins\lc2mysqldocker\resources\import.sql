use lc
-- dh 4.7.0 MySQL dump

SET NAMES utf8;
SET time_zone = '+00:00';
SET foreign_key_checks = 0;
SET sql_mode = 'NO_AUTO_VALUE_ON_ZERO';

CREATE USER 'david'@'localhost' IDENTIFIED BY 'david';
GRANT ALL PRIVILEGES ON lc . * TO 'david'@'%';
-- GRANT ALL PRIVILEGES ON lc . * TO 'david'@'localhost';

DROP TABLE IF EXISTS `userschat`;
CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `isAdmin` int(1) NOT NULL,
  `u_id` varchar(20) COLLATE latin1_german1_ci NOT NULL,
  `ipaddress` varchar(16) COLLATE latin1_german1_ci DEFAULT NULL,
  `user` varchar(50) COLLATE latin1_german1_ci NOT NULL DEFAULT '',
  `pass` varchar(60) COLLATE latin1_german1_ci NOT NULL DEFAULT '',
  `email` varchar(60) COLLATE latin1_german1_ci NOT NULL DEFAULT '',
  `first_name` varchar(50) COLLATE latin1_german1_ci DEFAULT NULL,
  `last_name` varchar(60) COLLATE latin1_german1_ci DEFAULT NULL,
  `phone` varchar(12) COLLATE latin1_german1_ci DEFAULT NULL,
  `fax` varchar(12) COLLATE latin1_german1_ci DEFAULT NULL,
  `alt_phone` varchar(12) COLLATE latin1_german1_ci DEFAULT NULL,
  `reg_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `last_active` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `user_level` smallint(1) NOT NULL DEFAULT '0',
  `notes` longtext COLLATE latin1_german1_ci,
  `admin_notes` longtext COLLATE latin1_german1_ci,
  `hash` varchar(50) COLLATE latin1_german1_ci NOT NULL,
  `deleted` int(11) NOT NULL,
  `confirmed` int(11) NOT NULL,
  `locked` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`),
  UNIQUE KEY `user` (`user`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_german1_ci;

INSERT INTO `users` (`id`, `isAdmin`, `u_id`, `ipaddress`, `user`, `pass`, `email`, `first_name`, `last_name`, `phone`, `fax`, `alt_phone`, `reg_date`, `last_active`, `user_level`, `notes`, `admin_notes`, `hash`, `deleted`, `confirmed`, `locked`) VALUES
(6,	0,	'*xxx',	NULL,	'webmaster',	'xxx',	'sux@localhost',	NULL,	NULL,	NULL,	NULL,	NULL,	'2011-00-00 00:00:00',	'2017-05-23 11:42:27',	0,	NULL,	NULL,	'1223',	0,	1,	0)
;

-- 2021-03-30 16:51:45
