select '<h4>LC2DEBanksUpdaterData Plugin SQL Import</h4>'; 
drop table IF EXISTS LC2DEBanksUpdaterData;
drop table IF EXISTS LC2DEBanksUpdaterDatatemp;
CREATE TABLE LC2DEBanksUpdaterData ( 'person_id' INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, 'created' TIMESTAMP DEFAULT CURRENT_TIMESTAMP NULL, 'modified' TIMESTAMP DEFAULT CURRENT_TIMESTAMP NULL, 'enddate' TIMESTAMP DEFAULT CURRENT_TIMESTAMP NULL, 'name' TEXT NOT NULL, 'first_name' TEXT NULL, 'description' TEXT NULL, 'zipcode' TEXT NULL, 'city' TEXT NULL,	 'street' TEXT NULL,	 'url' TEXT NULL);
create table IF NOT EXISTS LC2DEBanksUpdaterDatatemp ( name varchar(255), menu TEXT, url varchar(255), subtext TEXT);
select '<h4>Importing...</h4>'; 
--create table IF NOT EXISTS LC2DEBanksUpdaterDatatemp ( name varchar(500), menu TEXT);
.separator ';'
.import '.\\resources\\plugins\\LC2DEBanksUpdater\\import\\LC2DEBanksUpdater.csv' LC2DEBanksUpdaterDatatemp
select '<h4>Importing done</h4>'; 
select '<p>LC2DEBanksUpdaterDatatemp count:';
select count(*)  from LC2DEBanksUpdaterDatatemp;
select '</p>';
INSERT INTO LC2DEBanksUpdaterData (first_name,name, description,url) select name,name, menu,url  from LC2DEBanksUpdaterDatatemp;
select '<p>LC2DEBanksUpdaterData count:';
select count(*) from LC2DEBanksUpdaterData;
select '</p>';

INSERT OR REPLACE INTO application(name, first_name, description, zipcode, city, street, url)VALUES('LC2DEBanksUpdater Data v.1.02a','LC2DEBanksUpdater Data v.1.01a','','','','','execCMD(''exec .\\resources\\plugins\\LC2DEBanksUpdater\\show.bat'', ''out'');'); 
select count(*) as count from application;

.exit