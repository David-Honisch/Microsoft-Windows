select '<h4>LC2ApacheDS Plugin SQL Import</h4>';
drop table IF EXISTS LC2ApacheDS;
drop table IF EXISTS LC2ApacheDStemp;
CREATE TABLE LC2ApacheDS ( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
create table IF NOT EXISTS LC2ApacheDStemp ( name varchar(255), menu TEXT, url varchar(255), subtext TEXT);
-- select 'Create table LC2ApacheDS Import';
-- .separator "\t"
-- .import .\\import.csv LC2ApacheDStemp
.separator ";"
.import .\\resources\\plugins\\LC2ApacheDS\\import\\import.csv LC2ApacheDStemp
--.import ..\\import\\materialnohead.csv url
--INSERT INTO person VALUES (4, 'Alice', '351246233');
-- DELETE FROM url where url.name = '';
-- select '<p>LC2ApacheDStemp count:';
-- select count(*) from LC2ApacheDStemp;
-- select '</p>';
-- select '<p>SQL Import successfully done</p>';
-- select '<p>LC2ApacheDS count:'+count(*)+'</p>' from LC2ApacheDStemp;
-- select * from LC2ApacheDStemp limit 1;
-- select '<p>temp table COUNT:'+count(*)+'</p>' from LC2ApacheDStemp;
INSERT INTO LC2ApacheDS (first_name,name, description,url) select name,name, menu,url  from LC2ApacheDStemp;
select '<p>LC2ApacheDS count:';
select count(*) from LC2ApacheDS;
select '</p>';
-- select '<p>COUNT:'+count(*)+'</p>' from LC2ApacheDS;
-- select '<p>SQL Menu:</p><br>';
-- select '';
-- select '<hr>';
-- select '<a href="'+url+'">'+name+'</a>' from LC2ApacheDS;
-- select '<hr>';
-- select '<p>LC2ApacheDS count:'+count(*)+' successfully imported.</p>' from LC2ApacheDS;
.exit