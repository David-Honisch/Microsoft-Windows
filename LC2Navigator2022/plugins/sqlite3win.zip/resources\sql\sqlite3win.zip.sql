SELECT '<h1>SQL SQLite3 SCRIPT IS RUNNING</h1>';
SELECT '<h5>Init import script</h5>';
--DELETE FROM importscripts;
SELECT '<h5>INSERT import script</h5>';
SELECT '<h4>SET CLEAR</h4>';
-- INSERT OR REPLACE INTO importscripts (first_name,name,url) 
-- values 
-- ('Clear','Clear','echo .');
SELECT '<h4>INSERT SQLITE3 to applications</h4>';
INSERT OR REPLACE INTO application (first_name,name,url) 
values 
('SQLite3','.\\resources\\app\\sqlite\\SQLite3.exe','.\\resources\\app\\sqlite\\SQLite3.exe');
-- 
INSERT INTO plugins VALUES(6,'all.zip all.zip Download','all.zip all.zip Download',NULL,NULL,NULL,NULL,'exec .\\resources\\cmd\\getupdates.bat /plugins/all.zip all.zip all.zip all.zip');
-- 
SELECT '<h5>INSERT PLUGINS DONE v.0.001</h5>';
SELECT '<h4>'||(SELECT COUNT(*) FROM application)||' plugin added...</h4>';
SELECT '<h1>UPDATE SQL SCRIPT DONE</h1>';