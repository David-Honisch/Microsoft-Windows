var express = require('express');
var router = express.Router();

/* GET users listing. */
router.get('/info', function(req, res, next) {
  const APP_CFG = "application.config.json";
  var appConfig = getAppConfig(APP_CFG);
  var result = '<h1>Welcome to '+appConfig.title+' Port:'+appConfig.serverport+'</h1>';
  result += '<a href="/">/</a><br>';
  result += '<a href="/info">/info</a><br>';
  result += '<a href="/users">/users</a><br>';
  res.send(result);
});
function getAppConfig(f) {
  const fs = require('fs');
  let rawdata = fs.readFileSync(f);
  let appConfig = JSON.parse(rawdata);
  console.log(appConfig);
  return appConfig;
}

module.exports = router;
