function do_Unzip(link, target) {
    const path = window.nodeRequire('path');
    const fs = window.nodeRequire('fs');
    target = path.join(target);
    link = path.join(link);
    if (link.includes(".zip")) {
        document.getElementById('modcnt').innerHTML += '<br><h4>Extracting:</h4><p>' + link + ' to:' + target + '</p>';
        try {
            new HttpRequest().execCMD('extract ' + link, 'extplugin_cnt');
        } catch (error) {
            alert(error);
            console.error(error.stack);
        }
    } else {
        document.getElementById('modcnt').innerHTML += '<p> ' + link + ' <strong>NOT</strong> extracted to:' + target + '</p>';
    }
    document.getElementById('modcnt').innerHTML += '<hr><strong>DONE</strong>';
    console.log('Extraction complete')

}

function InstallModules(tmpDir) {
    try {
        const { npmImportAsync, npmInstallAsync } = window.nodeRequire('runtime-npm-install');
        npmInstallAsync(rlibs, tmpDir)
            .then(function() {
                document.getElementById('modcnt').innerHTML += '<h1>Successfully Installed to:</h1>' + tmpDir + '<br>';
                document.getElementById('modcnt').innerHTML += '<h2>Done. Close window now and start main plugin.</h2>';

            });
        printDir(path.join(tmpDir, 'node_modules'));
    } catch (error) {
        alert(error);
    }
}

function printDir(dir_path) {
    const path = window.nodeRequire('path');
    const fs = window.nodeRequire('fs');
    console.log('DIR:' + dir_path);
    fs.readdir(dir_path, function(err, files) {
        //handling error
        if (err) {
            return console.log('Unable to find or open the directory: ' + err);
        }
        //Print the array of images at one go
        // console.log(files);
        //listing all files using forEach
        files.forEach(function(file) {
            var isValid = false;
            console.log(file);
            document.getElementById("modcnt").innerHTML += "<br>" + file;
            for (v in rlibs) {
                if (file.includes(v)) {
                    isValid = true;
                }
            }
            if (isValid) {
                document.getElementById("modcnt").innerHTML += "<br>" + file + " <strong>found</strong>.";
            }
        });
    });
}

function doDownload(links, target) {
    // console.log("Target:" + target);
    for (var v in links) {
        getDownloadFile(links[v].path, links[v].file, target + links[v].file, target);
        // downloadAppBinaries(links[v].path, links[v].file, target);
        // bulkDownloadAppBinaries(links, target);
    }
}


function getDownloadFile(baseUrl, link, targetFile, target) {
    var request = window.nodeRequire('request');
    var fs = window.nodeRequire('fs');
    // Save variable to know progress
    var received_bytes = 0;
    var total_bytes = 0;
    var url = baseUrl + link;
    console.log('DL:' + url)
    var req = request({
        method: 'GET',
        uri: url
    });

    var out = fs.createWriteStream(targetFile);
    req.pipe(out);

    req.on('response', function(data) {
        // Change the total bytes value to get progress later.
        total_bytes = parseInt(data.headers['content-length']);
    });

    req.on('data', function(chunk) {
        // Update the received bytes
        received_bytes += chunk.length;

        showProgress(received_bytes, total_bytes);
    });

    req.on('end', function() {
        // alert("File succesfully downloaded");
        document.getElementById("appcnt").innerHTML += "<br>" + url + " File succesfully downloaded";
        document.getElementById("appcnt").innerHTML += "<br>" + targetFile + " File succesfully written.";
        document.getElementById("appcnt").innerHTML += "<br>Path:" + target + ".";
        document.getElementById("appcnt").innerHTML += "<br>Link:" + link + ".";
        if (('' + targetFile).includes(".zip")) {
            do_Unzip(targetFile, target);
            document.getElementById("appcnt").innerHTML += "<br>Unzip:" + targetFile + ".";
        }
    });
}

function showProgress(received, total) {
    var percentage = (received * 100) / total;
    console.log(percentage + "% | " + received + " bytes out of " + total + " bytes.");
    document.getElementById("appcntprogress").innerHTML = percentage + "% | " + received + " bytes out of " + total + " bytes.";
}
// try {
//     document.getElementById("appcnt").innerHTML = "";
//     document.getElementById("modcnt").innerHTML = "";
//     var modDir = path.join(__dirname, '../../../resources/');
//     InstallModules(modDir);
//     var downloadDir = path.join(__dirname, '../../../');
//     // InstallModules(targetDir);

//     doDownload(downloadUrls, downloadDir);

//     // doUnzip(downloadUrls, downloadDir) //.then(x => {
//     //     document.getElementById("modcnt").innerHTML += "<p>Finished</p>";
//     // });
// } catch (e) {
//     alert(e.stack);
// }
// try {
//     // updateApp(links);
//     const targetDir = path.join(__dirname, '../../../../');
//     // alert(targetDir + " <strong>found.</strong>.<br>");
//     //downloadAppBinaries(downloadUrls[0], targetDir);
//     downloadAppBinaries(downloadUrls[0], targetDir);
//     // bulkDownloadAppBinaries(downloadUrls, targetDir);
// } catch (error) {
//     alert(error.stack);
// }