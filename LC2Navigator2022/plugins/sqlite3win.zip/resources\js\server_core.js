var server;
var fs = require('fs');
var opath = require('path');
console.log('Server is starting..');

const rlibs = [
    'jquery',
    'https',
    'stream',
    'line-reader',
    'fs',
    'request',
    'runtime-npm-install',
    'decompress-zip',
    // 'extract-zip',
    'csv',
	'net',
	'promise',
    'jszip',
    'sax',
    'xlsx',
    'xlsx-to-json',
    'xlsx-to-json-lc',
    'xml2js',
    'xmlbuilder',
    'xmldom',
    'xml-js',
    'xmljson'
];


const APP_CFG = "application.config.json";
var appConfig = getAppConfig(APP_CFG);
var serverport = appConfig.serverport
var serverportalt = appConfig.serverportalt

var resDir = opath.join(__dirname, '../../resources/');
var downloadDir = opath.join(__dirname, '../../');
console.log(resDir);
getNodeModules(resDir,rlibs);


var https = require('http');//coming soon

//var mime = require('mime');
console.log('Checking server port is available...');
var net = require('net');
var Promise = require('bluebird');

function checkConnection(host, port, timeout) {
    return new Promise(function(resolve, reject) {
        timeout = timeout || 10000;     // default of 10 seconds
        var timer = setTimeout(function() {
            reject("timeout");
            socket.end();
        }, timeout);
        var socket = net.createConnection(port, host, function() {
            clearTimeout(timer);
            resolve();
            socket.end();
        });
        socket.on('error', function(err) {
            clearTimeout(timer);
            reject(err);
        });
    });
}

checkConnection("localhost", serverport,1).then(function() {
    console.log('The port is listening. The server might be running.');
}, function(err) {
    console.log('port is NOT listening. The Server is NOT running.');
})
console.log('Server is running...');
function getNodeModules(tmpDir, rlibs) {
    try {
        const { npmImportAsync, npmInstallAsync } = require('runtime-npm-install');
        npmInstallAsync(rlibs, tmpDir)
            .then(function() {
                console.error(tmpDir);
                // document.getElementById('modcnt').innerHTML += '<h1>Successfully Installed to:</h1>' + tmpDir + '<br>';
                // document.getElementById('modcnt').innerHTML += '<h2>Done. Close window now and start main plugin.</h2>';

            });
        // printDir(path.join(tmpDir, 'node_modules'));
    } catch (error) {
        console.error(error);
    }
}


function handlePublicRequest(req, res) {
	var fs = require('fs');
	var path = require('path');
    const publicPath = path.dirname(__dirname);
    try {
        var file = path.join(publicPath,'public', req.url);
        console.log('Loading:' + file);

        fs.exists(file, function (exists) {
            if (exists && fs.lstatSync(file).isFile()) {
                try {
                    // res.setHeader("Content-Type", mime.lookup(file));
                    res.writeHead(200, {
                        'Access-Control-Allow-Origin': '*'
                    });
                    fs.createReadStream(file).pipe(res);
                } catch (e) {
                    console.error(e);
                    console.error(e.stack);
                }
                return;
            }

            res.writeHead(404);
            res.write('404 Not Found');
            res.end();
        });
    } catch (e) {
        console.error(e);
        console.error(e.stack);
    }
}
function getAppConfig(f) {
    // const fs = require('fs');
    let rawdata = fs.readFileSync(f);
    let appConfig = JSON.parse(rawdata);
    console.log(appConfig);
    return appConfig;
}

try{
console.log('Port:'+serverport);
serverport = serverport !== undefined?serverport:serverportalt;
console.log('Server Port:'+serverport);
server = https.createServer(handlePublicRequest);	
checkConnection("localhost", serverport,10000).then(function() {
    console.log('Port is NOT available. Try running on alternative port'+serverportalt);
    server.listen(serverport, function () {
        console.log('server started at http://localhost:'+serverportalt);
    });
}, function(err) {
    console.log('Port is available. Running on port'+serverportalt);
    server.listen(serverport, function () {
        console.log('server started at http://localhost:'+serverport);
    });
})
}catch(e){
	console.error(e);
	console.error(e.stack);
}

// const crypto = require('crypto'),
//       fs = require("fs"),
//       http = require("http");

// var privateKey = fs.readFileSync('privatekey.pem').toString();
// var certificate = fs.readFileSync('certificate.pem').toString();

// var credentials = crypto.createCredentials({key: privateKey, cert: certificate});

// var handler = function (req, res) {
//   res.writeHead(200, {'Content-Type': 'text/plain'});
//   res.end('Hello World\n');
// };

// var server = http.createServer();
// server.setSecure(credentials);
// server.addListener("request", handler);
// server.listen(8000);