function createDir(dir) {
    const fs = window.nodeRequire('fs');
    if (!fs.existsSync(dir)) {
        fs.mkdirSync(dir);
    }
}
function doUnzip(link, target) {
    console.log('Extract' + link);
    alert('Extract' + link);
    var DecompressZip = window.nodeRequire('decompress-zip');
    // for (var v in links) {
    var ZIP_FILE_PATH = link;
    var DESTINATION_PATH = target;
    var unzipper = new DecompressZip(ZIP_FILE_PATH);

    // Add the error event listener
    unzipper.on('error', function(err) {
        console.log('Caught an error' + link, err);
    });

    // Notify when everything is extracted
    unzipper.on('extract', function(log) {
        console.log('Finished extracting', log);
    });

    // Notify "progress" of the decompressed files
    unzipper.on('progress', function(fileIndex, fileCount) {
        console.log('Extracted file ' + (fileIndex + 1) + ' of ' + fileCount);
        document.getElementById("appcnt").innerHTML += 'Extracted file ' + (fileIndex + 1) + ' of ' + fileCount;
    });

    // Start extraction of the content
    unzipper.extract({
        path: DESTINATION_PATH
            // You can filter the files that you want to unpack using the filter option
            //filter: function (file) {
            //console.log(file);
            //return file.type !== "SymbolicLink";
            //}
    });
    // }

}

function InstallModules(tmpDir) {
    try {
        const { npmImportAsync, npmInstallAsync } = window.nodeRequire('runtime-npm-install');
        npmInstallAsync(rlibs, tmpDir)
            .then(function() {
                document.getElementById('modcnt').innerHTML += '<h1>Successfully Installed to:</h1>' + tmpDir + '<br>';
                document.getElementById('modcnt').innerHTML += '<h2>Done. Close window now and start main plugin.</h2>';

            });
        printDir(path.join(tmpDir, 'node_modules'));
    } catch (error) {
        alert(error);
    }
}

function printDir(dir_path) {
    const path = window.nodeRequire('path');
    const fs = window.nodeRequire('fs');
    console.log('DIR:' + dir_path);
    fs.readdir(dir_path, function(err, files) {
        //handling error
        if (err) {
            return console.log('Unable to find or open the directory: ' + err);
        }
        //Print the array of images at one go
        // console.log(files);
        //listing all files using forEach
        files.forEach(function(file) {
            var isValid = false;
            console.log(file);
            document.getElementById("modcnt").innerHTML += "<br>" + file;
            for (v in rlibs) {
                if (file.includes(v)) {
                    isValid = true;
                }
            }
            if (isValid) {
                document.getElementById("modcnt").innerHTML += "<br>" + file + " <strong>found</strong>.";
            }
        });
    });
}

function downloadAppBinaries(path, link, target) {
    // var target = path.join(appRoot, "download");
    document.getElementById("appcnt").innerHTML = "<h4>URL:<strong>" + path + link + "</strong> to " + target + "</h4>";
    const downloadManager = window.nodeRequire("electron").remote.require("electron-download-manager");
    downloadManager.register({ downloadFolder: target });
    downloadManager.downloadFolder = target; //.register({ downloadFolder: target });
    downloadManager.download({
        url: path + link,
        properties: { directory: target },
        filePath: target,
    }, function(error, info) {
        if (error) {
            console.log(error);
            document.getElementById("moappcntcnt").innerHTML += path + link + " <strong>NOT downloaded.</strong>.<br>";
            return;
        }
        console.log(JSON.stringify(info));
        document.getElementById("appcnt").innerHTML += "URL:" + info.url + " <strong>downloaded.</strong>.<br>";
        document.getElementById("appcnt").innerHTML += "FILE:" + info.filePath + " " + " <strong>written.</strong>.<br>";
        doUnzip(target + link, target);
        console.log("DONE: " + info.url);
    })
}

function bulkDownloadAppBinaries(links, target) {
    // var target = path.join(appRoot, "download");
    // window.nodeRequire("electron").remote.require("electron-download-manager").bulkDownload({
    //     url: links,
    //     // properties: { directory: target },
    //     filePath: target,
    // }, function(error, finished, errors) {
    //     if (error) {
    //         console.log(error);
    //         document.getElementById("appcnt").innerHTML += error + " <strong>NOT downloaded.</strong>.<br>";
    //         return;
    //     }
    //     document.getElementById("appcnt").innerHTML += "URL:" + finished.url + " <strong>downloaded.</strong>.<br>";
    //     document.getElementById("appcnt").innerHTML += "FILE:" + finished.path + "-" + finished.files + " <strong>written.</strong>.<br>";
    //     console.log("DONE: " + finished.url);
    // })
}


function doDownload(links, target) {
    console.log("Target:" + target);
    for (var v in links) {
        getDownloadFile(links[v].path, links[v].file, target + links[v].file);
        // downloadAppBinaries(links[v].path, links[v].file, target);
        // bulkDownloadAppBinaries(links, target);
    }
}


function getDownloadFile(baseUrl, link, target) {
    var request = window.nodeRequire('request');
    var fs = window.nodeRequire('fs');
    // Save variable to know progress
    var received_bytes = 0;
    var total_bytes = 0;
    var url = baseUrl + link;
    console.log('DL:' + url)
    var req = request({
        method: 'GET',
        uri: url
    });

    var out = fs.createWriteStream(target);
    req.pipe(out);

    req.on('response', function(data) {
        // Change the total bytes value to get progress later.
        total_bytes = parseInt(data.headers['content-length']);
    });

    req.on('data', function(chunk) {
        // Update the received bytes
        received_bytes += chunk.length;

        showProgress(received_bytes, total_bytes);
    });

    req.on('end', function() {
        // alert("File succesfully downloaded");
        document.getElementById("appcnt").innerHTML += "<br>" + url + "File succesfully downloaded";
        // doUnzip(target + link, target);
    });
}

function showProgress(received, total) {
    var percentage = (received * 100) / total;
    console.log(percentage + "% | " + received + " bytes out of " + total + " bytes.");
    document.getElementById("appcntprogress").innerHTML = percentage + "% | " + received + " bytes out of " + total + " bytes.";
}