select '<h4>sqlite3win Plugin SQL Import</h4>'; 
drop table IF EXISTS sqlite3win;
drop table IF EXISTS sqlite3wintemp;
CREATE TABLE sqlite3win ( 'person_id' INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, 'created' TIMESTAMP DEFAULT CURRENT_TIMESTAMP NULL, 'modified' TIMESTAMP DEFAULT CURRENT_TIMESTAMP NULL, 'enddate' TIMESTAMP DEFAULT CURRENT_TIMESTAMP NULL, 'name' TEXT NOT NULL, 'first_name' TEXT NULL, 'description' TEXT NULL, 'zipcode' TEXT NULL, 'city' TEXT NULL,	 'street' TEXT NULL,	 'url' TEXT NULL);
create table IF NOT EXISTS sqlite3wintemp ( name varchar(255), menu TEXT, url varchar(255), subtext TEXT);
.separator ';'
.import .\\resources\\plugins\\sqlite3win\\import\\import.csv sqlite3wintemp
INSERT INTO sqlite3win (first_name,name, description,url) select name,name, menu,url  from sqlite3wintemp;
select '<p>sqlite3win count:';
select count(*) from sqlite3win;
select '</p>';
.exit
