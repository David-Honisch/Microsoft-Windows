var pluginName = "Main";
const installDirectories = [
    // 'lcwebclient_final_lib',
    // 'org.letztechance.domain.web.GrabUrls',
    // 'org.letztechance.domain.web.GrabUrls\\org.letztechance.domain.web.GrabUrls_lib',
    'resources\\plugins\\lcwebclient_final',
    'resources\\plugins\\lcwebclient_final\\lcwebclient_final_lib',
    'resources\\plugins\\org.letztechance.domain.web.GrabUrls',
    'resources\\plugins\\org.letztechance.domain.web.GrabUrls\\org.letztechance.domain.web.GrabUrls_lib',

];
var downloadUrls = [
	// {
        // path: "https://raw.githubusercontent.com/David-Honisch/Microsoft-Windows/master/LC2Navigator2020/plugins/",
        // file: "sqlite3win.zip",
    // },
    
    {
        path: "https://www.letztechance.org/LC2Intro.v.4.0/assets/",
        file: "lclogo.png",
    },

];
const rlibs = [
    'jquery',
    'fs',
    'request',
    'runtime-npm-install',
    'extract-zip',
    'JSZip-sync',
    '​unzipper​',
    'csv',
    'jszip',
    'sax',
    'xlsx',
    'xlsx-to-json',
    'xlsx-to-json-lc',
    'xml2js',
    'xmlbuilder',
    'xmldom',
    'xml-js',
    'xmljson'
];