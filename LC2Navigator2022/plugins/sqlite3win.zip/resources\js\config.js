var pluginName = "LC2CRC32";
var downloadUrls = [{
        path: "https://raw.githubusercontent.com/David-Honisch/Microsoft-Windows/master/LC2Navigator2020/plugins/",
        file: "sqlite3win.zip",
    },
    {
        path: "https://www.letztechance.org/LC2Intro.v.4.0/assets/",
        file: "lclogo.png",
    },

];
const rlibs = [
    'jquery',
    'fs',
    'request',
    'runtime-npm-install',
    'extract-zip',
    'JSZip-sync',
    '​unzipper​',
    'csv',
    'jszip',
    'sax',
    'xlsx',
    'xlsx-to-json',
    'xlsx-to-json-lc',
    'xml2js',
    'xmlbuilder',
    'xmldom',
    'xml-js',
    'xmljson'
];