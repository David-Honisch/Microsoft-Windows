function getXsltProcess(source, target) {
    const path = window.nodeRequire('path');
    const fs = window.nodeRequire('fs');
    const { xsltProcess, xmlParse } = window.nodeRequire('xslt-processor');
    const xmlString = fs.readFileSync(source, { encoding: 'utf8', flag: 'r' });
    const xsltString = fs.readFileSync(target, { encoding: 'utf8', flag: 'r' });
    return outXmlString = xsltProcess(
        xmlParse(xmlString),
        xmlParse(xsltString)
    );
}