const { npmImportAsync, npmInstallAsync, npmInstallSync } = require('runtime-npm-install');
var fs = require('fs');
var path = require('path');
const APP_CFG = "application.config.json";
var appConfig = getAppConfig(APP_CFG);
const nodeModules = [
    'http-errors',
    'debug',
    'jquery',
    'https',
    'stream',
    'line-reader',
    'fs',
    'request',
    'runtime-npm-install',
    'decompress-zip',
    // 'extract-zip',
    'csv',
    'net',
    'promise',
    'jszip',
    'sax',
    'xlsx',
    'xlsx-to-json',
    'xlsx-to-json-lc',
    'xml2js',
    'xmlbuilder',
    'xmldom',
    'xml-js',
    'xmljson'
];
// var resDir = path.join(__dirname, '../../resources/js/org.letztechance.express.approuter/');
// var resDir = path.join(__dirname, '../../resources/js/');
var resDir = path.join(__dirname, '../../');
// var downloadDir = opath.join(__dirname, '../../');
console.log("resdir:"+resDir);
npmInstallAsync([
    'http-errors',    
    'promise'
  ], resDir)
  .then(console.log);
getNodeModules(resDir, nodeModules);
//
var https = require('http');//coming soon
var net = require('net');
var Promise = require('bluebird');
var server;
var app = require('./org.letztechance.express.approuter/app');
//var debug = require('debug')('org.letztechance.express.approuter:server');
console.log('Server is starting..');




var serverport = appConfig.serverport
var serverportalt = appConfig.serverportalt

//var mime = require('mime');
try {
    console.log('Checking server port is available...');

    checkConnection("localhost", serverport, 1).then(function () {
        console.log('The port is listening. The server might be running.');
    }, function (err) {
        console.log('port is NOT listening. The Server is NOT running.');
    })
    console.log('Server is running...');

    console.log('Port:' + serverport);
    serverport = serverport !== undefined ? serverport : serverportalt;
    console.log('Server Port:' + serverport);

    createServer(server, app);
} catch (e) {
    console.error(e);
    console.error(e.stack);
}
function createServer(server, app) {
    checkConnection("localhost", serverport, 10000).then(function () {
        console.log('Port is NOT available. Try running on alternative port' + serverportalt);
        var serverport = normalizePort(process.env.PORT || appConfig.serverport);
        app.set('port', serverport);
        // server = https.createServer(handlePublicRequest);        
        server = https.createServer(app);
        server.listen(serverport, function () {
            console.log('server started at http://localhost:' + serverportalt);
        });
        server.on('error', onError);
        server.on('listening', onListening);
    }, function (err) {
        console.log('Port is available. Running on port' + serverportalt);
        app.set('port', serverport);
        // server = https.createServer(handlePublicRequest);        
        server = https.createServer(app);
        server.listen(serverport, function () {
            console.log('server started at http://localhost:' + serverportalt);
        });
        server.on('error', onError);
        server.on('listening', onListening);
    });
}
function checkConnection(host, port, timeout) {
    return new Promise(function (resolve, reject) {
        timeout = timeout || 10000;     // default of 10 seconds
        var timer = setTimeout(function () {
            reject("timeout");
            socket.end();
        }, timeout);
        var socket = net.createConnection(port, host, function () {
            clearTimeout(timer);
            resolve();
            socket.end();
        });
        socket.on('error', function (err) {
            clearTimeout(timer);
            reject(err);
        });
    });
}
function getNodeModules(tmpDir, nodeModules) {
    try {
        const { npmImportAsync, npmInstallAsync } = require('runtime-npm-install');
        npmInstallAsync(nodeModules, tmpDir)
            .then(function (data) {                
                console.log(tmpDir);
                console.log(data);
                // document.getElementById('modcnt').innerHTML += '<h1>Successfully Installed to:</h1>' + tmpDir + '<br>';
                // document.getElementById('modcnt').innerHTML += '<h2>Done. Close window now and start main plugin.</h2>';

            });
            // printNodeModuleDir(path.join(tmpDir, 'node_modules'));
    } catch (error) {
        console.error(error);
    }
}
function printNodeModuleDir(dir_path) {
    const path =require('path');
    const fs = require('fs');
    console.log('DIR:' + dir_path);
    fs.readdir(dir_path, function(err, files) {
        //handling error
        if (err) {
            return console.log('Unable to find or open the directory: ' + err);
        }
        //Print the array of images at one go
        // console.log(files);
        //listing all files using forEach
        files.forEach(function(file) {
            var isValid = false;
            console.log(file);
            document.getElementById("modcnt").innerHTML += "<br>" + file;
            for (v in rlibs) {
                if (file.includes(v)) {
                    isValid = true;
                }
            }
            if (isValid) {
                document.getElementById("modcnt").innerHTML += "<br>" + file + " <strong>found</strong>.";
            }
        });
    });
}

function handlePublicRequest(req, res) {
    var fs = require('fs');
    var path = require('path');
    const publicPath = path.dirname(__dirname);
    try {
        var file = path.join(publicPath, 'public', req.url);
        console.log('Loading:' + file);

        fs.exists(file, function (exists) {
            if (exists && fs.lstatSync(file).isFile()) {
                try {
                    // res.setHeader("Content-Type", mime.lookup(file));
                    res.writeHead(200, {
                        'Access-Control-Allow-Origin': '*'
                    });
                    fs.createReadStream(file).pipe(res);
                } catch (e) {
                    console.error(e);
                    console.error(e.stack);
                }
                return;
            }

            res.writeHead(404);
            res.write('404 Not Found');
            res.end();
        });
    } catch (e) {
        console.error(e);
        console.error(e.stack);
    }
}

function getAppConfig(f) {
    // const fs = require('fs');
    let rawdata = fs.readFileSync(f);
    let appConfig = JSON.parse(rawdata);
    console.log(appConfig);
    return appConfig;
}


function onError(error) {
    if (error.syscall !== 'listen') {
        throw error;
    }

    var bind = typeof port === 'string'
        ? 'Pipe ' + port
        : 'Port ' + port;

    // handle specific listen errors with friendly messages
    switch (error.code) {
        case 'EACCES':
            console.error(bind + ' requires elevated privileges');
            process.exit(1);
            break;
        case 'EADDRINUSE':
            console.error(bind + ' is already in use');
            process.exit(1);
            break;
        default:
            throw error;
    }
}

/**
 * Event listener for HTTP server "listening" event.
 */

function onListening() {
    if (server != null) {
        var addr = server.address();
        var bind = typeof addr === 'string'
            ? 'pipe ' + addr
            : 'port ' + addr.port;
        console.log('Listening on ' + bind);
    }
}

/**
 * Normalize a port into a number, string, or false.
 */

function normalizePort(val) {
    var port = parseInt(val, 10);

    if (isNaN(port)) {
        // named pipe
        return val;
    }

    if (port >= 0) {
        // port number
        return port;
    }

    return false;
}

/**
 * Event listener for HTTP server "error" event.
 */

function onError(error) {
    if (error.syscall !== 'listen') {
        throw error;
    }

    var bind = typeof port === 'string'
        ? 'Pipe ' + port
        : 'Port ' + port;

    // handle specific listen errors with friendly messages
    switch (error.code) {
        case 'EACCES':
            console.error(bind + ' requires elevated privileges');
            process.exit(1);
            break;
        case 'EADDRINUSE':
            console.error(bind + ' is already in use');
            process.exit(1);
            break;
        default:
            throw error;
    }
}

/**
 * Event listener for HTTP server "listening" event.
 */

// function onListening(server) {
//     var addr = server.address();
//     var bind = typeof addr === 'string'
//         ? 'pipe ' + addr
//         : 'port ' + addr.port;
//     debug('Listening on ' + bind);
// }


// const crypto = require('crypto'),
//       fs = require("fs"),
//       http = require("http");

// var privateKey = fs.readFileSync('privatekey.pem').toString();
// var certificate = fs.readFileSync('certificate.pem').toString();

// var credentials = crypto.createCredentials({key: privateKey, cert: certificate});

// var handler = function (req, res) {
//   res.writeHead(200, {'Content-Type': 'text/plain'});
//   res.end('Hello World\n');
// };

// var server = http.createServer();
// server.setSecure(credentials);
// server.addListener("request", handler);
// server.listen(8000);