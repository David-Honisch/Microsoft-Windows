// console.log('Server is running..');
// var fs = require('fs');
// const APP_CFG = "application.config.json";
// var https = require('http');//coming soon

// //var mime = require('mime');
// console.log('Server is running...');

// function handlePublicRequest(req, res) {
// 	var fs = require('fs');
// 	var path = require('path');
//     const publicPath = path.dirname(__dirname);
//     try {
//         var file = path.join(publicPath,'public', req.url);
//         console.log('Loading:' + file);

//         fs.exists(file, function (exists) {
//             if (exists && fs.lstatSync(file).isFile()) {
//                 try {
//                     // res.setHeader("Content-Type", mime.lookup(file));
//                     res.writeHead(200, {
//                         'Access-Control-Allow-Origin': '*'
//                     });
//                     fs.createReadStream(file).pipe(res);
//                 } catch (e) {
//                     console.error(e);
//                     console.error(e.stack);
//                 }
//                 return;
//             }

//             res.writeHead(404);
//             res.write('404 Not Found');
//             res.end();
//         });
//     } catch (e) {
//         console.error(e);
//         console.error(e.stack);
//     }
// }
// function getAppConfig(f) {
//     // const fs = require('fs');
//     let rawdata = fs.readFileSync(f);
//     let appConfig = JSON.parse(rawdata);
//     console.log(appConfig);
//     return appConfig;
// }
// var appConfig = getAppConfig(APP_CFG);
// var serverport = appConfig.serverport
// console.log('Port:'+serverport);
// serverport = serverport !== undefined?serverport:9999;
// console.log('Server Port:'+serverport);
// var server = https.createServer(handlePublicRequest);
// server.listen(serverport, function () {
//     console.log('server started at http://localhost:'+serverport);
// });

// // const crypto = require('crypto'),
// //       fs = require("fs"),
// //       http = require("http");

// // var privateKey = fs.readFileSync('privatekey.pem').toString();
// // var certificate = fs.readFileSync('certificate.pem').toString();

// // var credentials = crypto.createCredentials({key: privateKey, cert: certificate});

// // var handler = function (req, res) {
// //   res.writeHead(200, {'Content-Type': 'text/plain'});
// //   res.end('Hello World\n');
// // };

// // var server = http.createServer();
// // server.setSecure(credentials);
// // server.addListener("request", handler);
// // server.listen(8000);