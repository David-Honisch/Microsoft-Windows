select '<h4>LC2ApacheRancher Plugin SQL Import</h4>'; 
drop table IF EXISTS LC2ApacheRancher;
drop table IF EXISTS LC2ApacheRanchertemp;
CREATE TABLE LC2ApacheRancher ( 'person_id' INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, 'created' TIMESTAMP DEFAULT CURRENT_TIMESTAMP NULL, 'modified' TIMESTAMP DEFAULT CURRENT_TIMESTAMP NULL, 'enddate' TIMESTAMP DEFAULT CURRENT_TIMESTAMP NULL, 'name' TEXT NOT NULL, 'first_name' TEXT NULL, 'description' TEXT NULL, 'zipcode' TEXT NULL, 'city' TEXT NULL,	 'street' TEXT NULL,	 'url' TEXT NULL);
create table IF NOT EXISTS LC2ApacheRanchertemp ( name varchar(255), menu TEXT, url varchar(255), subtext TEXT);
.separator ';'
.import .\\resources\\plugins\\LC2ApacheRancher\\import\\import.csv LC2ApacheRanchertemp
INSERT INTO LC2ApacheRancher (first_name,name, description,url) select name,name, menu,url  from LC2ApacheRanchertemp;
select '<p>LC2ApacheRancher count:';
select count(*) from LC2ApacheRancher;
select '</p>';
.exit
