select '<h4>org.letztechance.domain.xml.Lib Plugin SQL Import</h4>'; 
drop table IF EXISTS org.letztechance.domain.xml.Lib;
drop table IF EXISTS org.letztechance.domain.xml.Libtemp;
CREATE TABLE org.letztechance.domain.xml.Lib ( 'person_id' INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, 'created' TIMESTAMP DEFAULT CURRENT_TIMESTAMP NULL, 'modified' TIMESTAMP DEFAULT CURRENT_TIMESTAMP NULL, 'enddate' TIMESTAMP DEFAULT CURRENT_TIMESTAMP NULL, 'name' TEXT NOT NULL, 'first_name' TEXT NULL, 'description' TEXT NULL, 'zipcode' TEXT NULL, 'city' TEXT NULL,	 'street' TEXT NULL,	 'url' TEXT NULL);
create table IF NOT EXISTS org.letztechance.domain.xml.Libtemp ( name varchar(255), menu TEXT, url varchar(255), subtext TEXT);
.separator ';'
.import .\\resources\\plugins\\org.letztechance.domain.xml.Lib\\import\\import.csv org.letztechance.domain.xml.Libtemp
INSERT INTO org.letztechance.domain.xml.Lib (first_name,name, description,url) select name,name, menu,url  from org.letztechance.domain.xml.Libtemp;
select '<p>org.letztechance.domain.xml.Lib count:';
select count(*) from org.letztechance.domain.xml.Lib;
select '</p>';
.exit
