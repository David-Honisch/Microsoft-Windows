select '<h4>LC2JXMLTransform Plugin SQL Import</h4>'; 
drop table IF EXISTS LC2JXMLTransform;
drop table IF EXISTS LC2JXMLTransformtemp;
CREATE TABLE LC2JXMLTransform ( 'person_id' INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, 'created' TIMESTAMP DEFAULT CURRENT_TIMESTAMP NULL, 'modified' TIMESTAMP DEFAULT CURRENT_TIMESTAMP NULL, 'enddate' TIMESTAMP DEFAULT CURRENT_TIMESTAMP NULL, 'name' TEXT NOT NULL, 'first_name' TEXT NULL, 'description' TEXT NULL, 'zipcode' TEXT NULL, 'city' TEXT NULL,	 'street' TEXT NULL,	 'url' TEXT NULL);
create table IF NOT EXISTS LC2JXMLTransformtemp ( name varchar(255), menu TEXT, url varchar(255), subtext TEXT);
.separator ';'
.import .\\resources\\plugins\\LC2JXMLTransform\\import\\import.csv LC2JXMLTransformtemp
INSERT INTO LC2JXMLTransform (first_name,name, description,url) select name,name, menu,url  from LC2JXMLTransformtemp;
select '<p>LC2JXMLTransform count:';
select count(*) from LC2JXMLTransform;
select '</p>';
.exit
