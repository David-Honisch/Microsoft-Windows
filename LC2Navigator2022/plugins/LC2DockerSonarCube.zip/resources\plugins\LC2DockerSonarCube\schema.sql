select '<h4>LC2DockerSonarCube Plugin SQL Import</h4>';
drop table IF EXISTS LC2DockerSonarCube;
drop table IF EXISTS LC2DockerSonarCubetemp;
CREATE TABLE LC2DockerSonarCube ( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
create table IF NOT EXISTS LC2DockerSonarCubetemp ( name varchar(255), menu TEXT, url varchar(255), subtext TEXT);
-- select 'Create table LC2DockerSonarCube Import';
-- .separator "\t"
-- .import .\\import.csv LC2DockerSonarCubetemp
.separator ";"
.import .\\resources\\plugins\\LC2DockerSonarCube\\import\\import.csv LC2DockerSonarCubetemp
--.import ..\\import\\materialnohead.csv url
--INSERT INTO person VALUES (4, 'Alice', '351246233');
-- DELETE FROM url where url.name = '';
-- select '<p>LC2DockerSonarCubetemp count:';
-- select count(*) from LC2DockerSonarCubetemp;
-- select '</p>';
-- select '<p>SQL Import successfully done</p>';
-- select '<p>LC2DockerSonarCube count:'+count(*)+'</p>' from LC2DockerSonarCubetemp;
-- select * from LC2DockerSonarCubetemp limit 1;
-- select '<p>temp table COUNT:'+count(*)+'</p>' from LC2DockerSonarCubetemp;
INSERT INTO LC2DockerSonarCube (first_name,name, description,url) select name,name, menu,url  from LC2DockerSonarCubetemp;
select '<p>LC2DockerSonarCube count:';
select count(*) from LC2DockerSonarCube;
select '</p>';
-- select '<p>COUNT:'+count(*)+'</p>' from LC2DockerSonarCube;
-- select '<p>SQL Menu:</p><br>';
-- select '';
-- select '<hr>';
-- select '<a href="'+url+'">'+name+'</a>' from LC2DockerSonarCube;
-- select '<hr>';
-- select '<p>LC2DockerSonarCube count:'+count(*)+' successfully imported.</p>' from LC2DockerSonarCube;
.exit