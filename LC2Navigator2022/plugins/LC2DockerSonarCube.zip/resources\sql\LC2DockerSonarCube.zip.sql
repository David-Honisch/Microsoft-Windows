SELECT '<h1>LC2DockerSonarCube PLUGIN SQL SCRIPT IS RUNNING</h1>'; 
SELECT '<h5>Deleting import script</h5>'; 
SELECT '<h5>RUNNING IMPORT</h5>'; 
SELECT '<h4>SET CLEAR</h4>'; 
select count(*) as count from application; 
SELECT '<h4>DELETING application</h4>'; 
SELECT '<h1>UPDATE LC2DockerSonarCube SQL SCRIPT DONE</h1>'; 
INSERT OR REPLACE INTO application(name, first_name, description, zipcode, city, street, url)VALUES('LC2DockerSonarCube Plugin v.1.02a','LC2DockerSonarCube Plugin v.1.01a','','','','','execCMD(''exec .\\resources\\plugins\\LC2DockerSonarCube\\index.bat .\\resources\\plugins\\LC2DockerSonarCube\\menu.csv'', ''out'');'); 

select count(*) as count from application; 
SELECT '<h5>SQL LC2DockerSonarCube IMPORT DONE</h5>'; 
