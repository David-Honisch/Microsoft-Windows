select '<h4>LC2bat2exe Plugin SQL Import</h4>'; 
drop table IF EXISTS LC2bat2exe;
drop table IF EXISTS LC2bat2exetemp;
CREATE TABLE LC2bat2exe ( 'person_id' INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, 'created' TIMESTAMP DEFAULT CURRENT_TIMESTAMP NULL, 'modified' TIMESTAMP DEFAULT CURRENT_TIMESTAMP NULL, 'enddate' TIMESTAMP DEFAULT CURRENT_TIMESTAMP NULL, 'name' TEXT NOT NULL, 'first_name' TEXT NULL, 'description' TEXT NULL, 'zipcode' TEXT NULL, 'city' TEXT NULL,	 'street' TEXT NULL,	 'url' TEXT NULL);
create table IF NOT EXISTS LC2bat2exetemp ( name varchar(255), menu TEXT, url varchar(255), subtext TEXT);
.separator ';'
.import .\\resources\\plugins\\LC2bat2exe\\import\\import.csv LC2bat2exetemp
INSERT INTO LC2bat2exe (first_name,name, description,url) select name,name, menu,url  from LC2bat2exetemp;
select '<p>LC2bat2exe count:';
select count(*) from LC2bat2exe;
select '</p>';
.exit
