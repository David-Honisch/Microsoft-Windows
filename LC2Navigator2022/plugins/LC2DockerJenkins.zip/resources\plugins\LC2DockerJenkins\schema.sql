select '<h4>LC2DockerJenkins Plugin SQL Import</h4>';
drop table IF EXISTS LC2DockerJenkins;
drop table IF EXISTS LC2DockerJenkinstemp;
CREATE TABLE LC2DockerJenkins ( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL,"created" TIMESTAMP DEFAULT CURRENT_TIMESTAMP NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
create table IF NOT EXISTS LC2DockerJenkinstemp ( name varchar(255), url varchar(255), subtext TEXT);
-- .separator "\t"
.separator ";"
.import .\\resources\\plugins\\LC2DockerJenkins\\import\\import.csv LC2DockerJenkinstemp
INSERT INTO LC2DockerJenkins (first_name,name, description,url) select name,name, subtext,url  from LC2DockerJenkinstemp;
select '<p>LC2DockerJenkins count:';
select count(*) from LC2DockerJenkins;
select '</p>';
.exit