select '<h4>LC2DockerJenkins Plugin SQL Import</h4>';
drop table IF EXISTS LC2DockerJenkins;
drop table IF EXISTS LC2DockerJenkinstemp;
CREATE TABLE LC2DockerJenkins ( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
create table IF NOT EXISTS LC2DockerJenkinstemp ( name TEXT, url TEXT, type TEXT, tpid TEXT, mem TEXT);
-- .separator "\t"
-- .import .\\import.csv LC2DockerJenkinstemp
.separator ";"
.import .\\resources\\plugins\\LC2DockerJenkins\\import\\import.csv LC2DockerJenkinstemp
--.import ..\\import\\materialnohead.csv url
-- DELETE FROM url where url.name = '';
INSERT INTO LC2DockerJenkins (first_name,name, url) select name,name,url from LC2DockerJenkinstemp;
select '<p>LC2DockerJenkins count:';
select count(*) from LC2DockerJenkins;
select '</p>';
-- select '<p>COUNT:'+count(*)+'</p>' from LC2DockerJenkins;
-- select '<p>SQL Menu:</p><br>';
-- select '';
-- select '<hr>';
-- select '<a href="'+url+'">'+name+'</a>' from LC2DockerJenkins;
-- select '<hr>';
-- select '<p>LC2DockerJenkins count:'+count(*)+' successfully imported.</p>' from LC2DockerJenkins;
.exit