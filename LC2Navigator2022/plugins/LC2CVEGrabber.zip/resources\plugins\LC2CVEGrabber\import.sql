select '<h4>LC2CVEGrabber_Data Plugin SQL Import</h4>'; 
drop table IF EXISTS LC2CVEGrabber_Import;
drop table IF EXISTS LC2CVEGrabber_Datatemp;
CREATE TABLE LC2CVEGrabber_Import ( 'person_id' INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, 'created' TIMESTAMP DEFAULT CURRENT_TIMESTAMP NULL, 'modified' TIMESTAMP DEFAULT CURRENT_TIMESTAMP NULL, 'enddate' TIMESTAMP DEFAULT CURRENT_TIMESTAMP NULL, 'name' TEXT NOT NULL, 'first_name' TEXT NULL, 'description' TEXT NULL, 'zipcode' TEXT NULL, 'city' TEXT NULL,	 'street' TEXT NULL,	 'url' TEXT NULL);
-- create table IF NOT EXISTS LC2CVEGrabber_Datatemp ( name varchar(255), menu TEXT, url varchar(255), subtext TEXT);
-- create table IF NOT EXISTS LC2CVEGrabber_Datatemp ( name varchar(255));
create table IF NOT EXISTS LC2CVEGrabber_Datatemp ( name TEXT, menu TEXT, url varchar(255), subtext TEXT, subtext0 TEXT, subtext1 TEXT, subtext2 TEXT);
select '<h4>Importing...</h4>'; 
--create table IF NOT EXISTS LC2CVEGrabber_Datatemp ( name varchar(500), menu TEXT);
.separator ','
.import '.\\resources\\plugins\\LC2CVEGrabber\\import\\LC2CVEGrabber_Data.csv' LC2CVEGrabber_Datatemp
select '<h4>Importing done</h4>'; 
select '<p>LC2CVEGrabber_Datatemp count:';
select count(*)  from LC2CVEGrabber_Datatemp;
select '</p>';
INSERT INTO LC2CVEGrabber_Import (first_name,name, description,url) select name||subtext||subtext0||subtext1||subtext2,name||menu||subtext, subtext||subtext0||subtext1||subtext2,url  from LC2CVEGrabber_Datatemp;
--INSERT INTO LC2CVEGrabber_Data (first_name,name,zipcode, city, description,url) select substr( name, 0, 9 ),rtrim(substr( name, 10, 58 )), substr(name,68,71), substr(name,73,78), name,trim(substr( name, 140, 169))  from LC2CVEGrabber_Datatemp;
select '<p>LC2CVEGrabber_Data count:';
select count(*) from LC2CVEGrabber_Import;
select '</p>';
-- INSERT OR REPLACE INTO application(name, first_name, description, zipcode, city, street, url)VALUES('LC2CVEGrabber (Real Data) v.1.02a','LC2CVEGrabber (Real Data) v.1.01a','','','','','execCMD(''exec .\\resources\\plugins\\LC2CVEGrabber\\show.bat'', ''out'');'); 
select count(*) as count from application;
.exit