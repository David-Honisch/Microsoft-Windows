try {
    var utils = new XLSXUtils(XLSX);
    $('#lblPlugin').html(pluginName);
    $('#txtPlugin').html(pluginName);
    $('#txtPluginVersion').html(pluginVersion);
    $('#txtDesc').html(pluginDesc);
    $("#reload").on("click", function(e) {
        e.preventDefault();
        window.location = window.location;
    });
    $("#editconfig").on("click", function(e) {
        e.preventDefault();
        new HttpRequest().execCMD('notepad .\\resources\\plugins\\LC2RotatingTorproxy\\config.bat', 'outcnt', true);
    });
    $("#showplugins").on("click", function(e) {
        e.preventDefault();
        new HttpRequest().execCMD('exec .\\resources\\cmd\\showplugins.bat', 'outcnt');
    });
    $("#upload").on("click", function(e) {
        e.preventDefault();
        new HttpRequest().getExtFile('file://' + __dirname + '\\uploaddl.html');
    });
    $("#showserver").on("click", function(e) {
        e.preventDefault();
        new HttpRequest().getExtFile('http://localhost:8081/index.html');
    });
    $("#runserver").on("click", function(e) {
        e.preventDefault();
        e.stopPropagation();
        try {
            // alert('Debug');
            new HttpRequest().execCMD('.\\resources\\plugins\\LC2RotatingTorproxy\\runserver.bat', 'outcnt');
            // alert('Debug');
        } catch (error) {
            alert(error);
            alert(error.stack);
        }
    });
    //excel

    $("#xlsxport").on("click", function(e) {
        alert('Debug');
        e.preventDefault();
        e.stopPropagation();
        utils.export_all();
    });
    $("#csvxport").on("click", function(e) {
        e.preventDefault();
        e.stopPropagation();
        utils.export_csv();
    });
    $("#xmlxport").on("click", function(e) {
        e.preventDefault();
        e.stopPropagation();
        utils.export_xml();
    });
    $("#jsonxport").on("click", function(e) {
        e.preventDefault();
        e.stopPropagation();
        utils.export_json();
    });
    $("#btngraburls").on("click", function(e) {
        e.preventDefault();
        e.stopPropagation();
        // alert('Debug');
        utils.grab_urls();
    });
    $("#dbimport").on("click", function(e) {
        e.preventDefault();
        e.stopPropagation();
        // alert('Debug');
        utils.export_db();
    });
    $("#wsxport").on("click", function(e) {
        e.preventDefault();
        e.stopPropagation();
        // alert('Debug');
        utils.export_ws();
    });

    var httprequest = new HttpRequest();
    httprequest.getFullList();
} catch (error) {
    alert(error);
    alert(error.stack);
}