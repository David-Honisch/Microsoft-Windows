select '<h4>lc2dockerphpapacheservice Plugin SQL Import</h4>'; 
drop table IF EXISTS lc2dockerphpapacheservice;
drop table IF EXISTS lc2dockerphpapacheservicetemp;
CREATE TABLE lc2dockerphpapacheservice ( 'person_id' INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, 'created' TIMESTAMP DEFAULT CURRENT_TIMESTAMP NULL, 'modified' TIMESTAMP DEFAULT CURRENT_TIMESTAMP NULL, 'enddate' TIMESTAMP DEFAULT CURRENT_TIMESTAMP NULL, 'name' TEXT NOT NULL, 'first_name' TEXT NULL, 'description' TEXT NULL, 'zipcode' TEXT NULL, 'city' TEXT NULL,	 'street' TEXT NULL,	 'url' TEXT NULL);
create table IF NOT EXISTS lc2dockerphpapacheservicetemp ( name varchar(255), menu TEXT, url varchar(255), subtext TEXT);
.separator ';'
.import .\\resources\\plugins\\lc2dockerphpapacheservice\\import\\import.csv lc2dockerphpapacheservicetemp
INSERT INTO lc2dockerphpapacheservice (first_name,name, description,url) select name,name, menu,url  from lc2dockerphpapacheservicetemp;
select '<p>lc2dockerphpapacheservice count:';
select count(*) from lc2dockerphpapacheservice;
select '</p>';
.exit
