<?PHP
require('./config/const.cls.php');
// require('./include/auth/basic.auth.cls.php');
// // require_auth();
// require_auth();
// list($_SERVER['PHP_AUTH_USER'], $_SERVER['PHP_AUTH_PW']) =  explode(':', base64_decode(substr($_SERVER['HTTP_AUTHORIZATION'], 6)));

?>
<!DOCTYPE html>
<html class="html__responsive ">

<head>
  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
  <title><?PHP echo $env["hptitle"]; ?></title>
  <meta name="title" content="NuSOAP, HTTP Authentication and HTTP Proxy" />
  <meta name="author" content="beanizer" />
  <meta name="description" content="Using HTTP Authentication and HTTP Proxy with NuSOAP" />
  <meta name="keywords" content="nusoap, http authentication, http proxy" />
  <meta name="Generator" content="<?PHP echo $env["copyright"]; ?>" />
  <meta name="robots" content="index, follow" />
  <!-- <base href="http://www.letztechance.org/site/" /> -->

  <link rel="stylesheet" type="text/css" href="assets/css/core.css">
  <link rel="stylesheet" type="text/css" href="assets/css/table.css">
  <link rel="shortcut icon" href="http://www.letztechance.org/favicon.ico" />
</head>

<body>
  <h1><?PHP echo $env["hptitle"]; ?></h1>
  <fieldset>
    <div id="menu">Loading...</div>
    <button type="button" onclick="loadXMLDoc('loggedin','/webservices/menu.xml','CD', ['PARENT', 'TITLE'])">START</button>
  </fieldset>

  <fieldset>
    <div id="out"></div>
  </fieldset>


  <?PHP
  $scripts = './webservices';
  IO::printDir($scripts);

  ?>

  <!-- <script>
    var cpage;
    // $('#gout').append('RUNNING DONE.');
    window._PAGE_ = {
      cpage: ""
    };
    try {
      window.nodeRequire = require;
      window.nodeExports = window.exports;
      window.nodeModule = window.module;
      delete window.require;
      delete window.exports;
      delete window.module;
    } catch (error) {
      console.error(error);
      console.error(error.stack);
    }
  </script> -->
  <script src="assets/js/jquery/jquery.min.js"></script>
  <script src="assets/js/actions/api.js"></script>
  <script src="assets/js/actions/main.js"></script>
</body>

</html>