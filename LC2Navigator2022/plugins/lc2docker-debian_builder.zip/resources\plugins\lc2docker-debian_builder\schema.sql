select '<h4>lc2docker-deb.builder Plugin SQL Import</h4>'; 
drop table IF EXISTS lc2docker-deb.builder;
drop table IF EXISTS lc2docker-deb.buildertemp;
CREATE TABLE lc2docker-deb.builder ( 'person_id' INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, 'created' TIMESTAMP DEFAULT CURRENT_TIMESTAMP NULL, 'modified' TIMESTAMP DEFAULT CURRENT_TIMESTAMP NULL, 'enddate' TIMESTAMP DEFAULT CURRENT_TIMESTAMP NULL, 'name' TEXT NOT NULL, 'first_name' TEXT NULL, 'description' TEXT NULL, 'zipcode' TEXT NULL, 'city' TEXT NULL,	 'street' TEXT NULL,	 'url' TEXT NULL);
create table IF NOT EXISTS lc2docker-deb.buildertemp ( name varchar(255), menu TEXT, url varchar(255), subtext TEXT);
.separator ';'
.import .\\resources\\plugins\\lc2docker-deb.builder\\import\\import.csv lc2docker-deb.buildertemp
INSERT INTO lc2docker-deb.builder (first_name,name, description,url) select name,name, menu,url  from lc2docker-deb.buildertemp;
select '<p>lc2docker-deb.builder count:';
select count(*) from lc2docker-deb.builder;
select '</p>';
.exit
