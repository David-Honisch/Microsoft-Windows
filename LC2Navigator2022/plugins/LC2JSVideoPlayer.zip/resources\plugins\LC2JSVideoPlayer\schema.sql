select '<h4>LC2JSVideoPlayer Plugin SQL Import</h4>'; 
drop table IF EXISTS LC2JSVideoPlayer;
drop table IF EXISTS LC2JSVideoPlayertemp;
CREATE TABLE LC2JSVideoPlayer ( 'person_id' INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, 'created' TIMESTAMP DEFAULT CURRENT_TIMESTAMP NULL, 'modified' TIMESTAMP DEFAULT CURRENT_TIMESTAMP NULL, 'enddate' TIMESTAMP DEFAULT CURRENT_TIMESTAMP NULL, 'name' TEXT NOT NULL, 'first_name' TEXT NULL, 'description' TEXT NULL, 'zipcode' TEXT NULL, 'city' TEXT NULL,	 'street' TEXT NULL,	 'url' TEXT NULL);
create table IF NOT EXISTS LC2JSVideoPlayertemp ( name varchar(255), menu TEXT, url varchar(255), subtext TEXT);
.separator ';'
.import .\\resources\\plugins\\LC2JSVideoPlayer\\import\\import.csv LC2JSVideoPlayertemp
INSERT INTO LC2JSVideoPlayer (first_name,name, description,url) select name,name, menu,url  from LC2JSVideoPlayertemp;
select '<p>LC2JSVideoPlayer count:';
select count(*) from LC2JSVideoPlayer;
select '</p>';
.exit
