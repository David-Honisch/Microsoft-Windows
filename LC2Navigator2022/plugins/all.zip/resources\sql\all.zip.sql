PRAGMA foreign_keys=OFF;
BEGIN TRANSACTION;
SELECT 'SQL Plugin import script running...'
-- CREATE TABLE plugins ( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
REPLACE OR INSERT INTO plugins VALUES(1,'All Plugins Download v.0.91a',NULL,NULL,NULL,NULL,NULL,'execCMD(''.\\resources\\cmd\\getupdates.bat /plugins/all.zip all.zip'', ''out'')');
REPLACE OR INSERT INTO plugins VALUES(2,'Install SQLITE v.1.0(sqlite3win.zip) and required scripts',NULL,NULL,NULL,NULL,NULL,'execCMD(''.\\resources\\cmd\\getupdates.bat /plugins/sqlite3win.zip sqlite3win.zip'', ''out'')');
REPLACE OR INSERT INTO plugins VALUES(3,'LC2CRC32 v.0.1a',NULL,NULL,NULL,NULL,NULL,'execCMD(''.\\resources\\cmd\\getupdates.bat /plugins/LC2CRC32.zip LC2CRC32.zip'', ''out'')');
REPLACE OR INSERT INTO plugins VALUES(4,'lc2process v.0.1a',NULL,NULL,NULL,NULL,NULL,'execCMD(''.\\resources\\cmd\\getupdates.bat /plugins/lc2process.zip lc2process.zip'', ''out'')');
REPLACE OR INSERT INTO plugins VALUES(5,'LC2ShortCutCLI v.0.1a',NULL,NULL,NULL,NULL,NULL,'execCMD(''.\\resources\\cmd\\getupdates.bat /plugins/LC2ShortCutCLI.zip LC2ShortCutCLI.zip'', ''out'')');
REPLACE OR INSERT INTO plugins VALUES(6,'LC2Java.Starter.v.1.1',NULL,NULL,NULL,NULL,NULL,'execCMD(''.\\resources\\cmd\\getupdates.bat /plugins/LC2Java.Starter.v.1.1.zip LC2Java.Starter.v.1.1.zip'', ''out'')');
REPLACE OR INSERT INTO plugins VALUES(7,'lc2mysqldocker.v.1.01a',NULL,NULL,NULL,NULL,NULL,'execCMD(''.\\resources\\cmd\\getupdates.bat /plugins/lc2mysqldocker.zip lc2mysqldocker.zip'', ''out'')');
SELECT 'SQL Plugin import script done.'
COMMIT;
