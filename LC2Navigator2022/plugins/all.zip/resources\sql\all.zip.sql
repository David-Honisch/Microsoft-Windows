SELECT 'Plugins count ',count(*) from plugins; 
SELECT 'Importing Install SQLITE v.1.0(sqlite3win.zip) and required scripts Plugin SCRIPT'; 	
INSERT OR REPLACE INTO plugins(person_id,first_name,name,url)values("1","Install 
SELECT 'Importing Install SQLITE v.1.0(sqlite3win.zip) and required scripts Plugin SCRIPT DONE'; 	
SELECT 'Importing LC2CRC32 v.0.1a Plugin SCRIPT'; 	
INSERT OR REPLACE INTO plugins(person_id,first_name,name,url)values("2","LC2CRC32 
SELECT 'Importing LC2CRC32 v.0.1a Plugin SCRIPT DONE'; 	
SELECT 'Importing lc2process v.0.1a Plugin SCRIPT'; 	
INSERT OR REPLACE INTO plugins(person_id,first_name,name,url)values("3","lc2process 
SELECT 'Importing lc2process v.0.1a Plugin SCRIPT DONE'; 	
SELECT 'Importing LC2ShortCutCLI v.0.1a Plugin SCRIPT'; 	
INSERT OR REPLACE INTO plugins(person_id,first_name,name,url)values("4","LC2ShortCutCLI 
SELECT 'Importing LC2ShortCutCLI v.0.1a Plugin SCRIPT DONE'; 	
SELECT 'Importing LC2Java.Starter.v.1.1 v.0.1a Plugin SCRIPT'; 	
INSERT OR REPLACE INTO plugins(person_id,first_name,name,url)values("5","LC2Java.Starter.v.1.1 
SELECT 'Importing LC2Java.Starter.v.1.1 v.0.1a Plugin SCRIPT DONE'; 	
SELECT 'Importing Missing Plugins and Updates Info Plugin SCRIPT'; 	
INSERT OR REPLACE INTO plugins(person_id,first_name,name,url)values("6","Missing 
SELECT 'Importing Missing Plugins and Updates Info Plugin SCRIPT DONE'; 	
SELECT 'Plugins count ',count(*) from plugins; 
SELECT 'Running SQL plugins import DONE'; 
