PRAGMA foreign_keys=OFF;
BEGIN TRANSACTION;
SELECT 'IMPORTING PLUGINS...';
SELECT 'Registered Plugins count:';
select count(*) from plugins;
--CREATE TABLE plugins ( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
INSERT OR REPLACE INTO plugins (person_id,name,url) VALUES(1,'All Plugins Download v.1.23 (Update vom 17.06.2022)','execCMD(''.\\resources\\cmd\\getupdates.bat /plugins/all.zip all.zip'', ''out'')');
INSERT OR REPLACE INTO plugins (person_id,name,url) VALUES(2,'Install SQLITE v.1.0(sqlite3win.zip) and required scripts','execCMD(''.\\resources\\cmd\\getupdates.bat /plugins/sqlite3win.zip sqlite3win.zip'', ''out'')');
INSERT OR REPLACE INTO plugins (person_id,name,url) VALUES(3,'LC2CRC32 Plugin Downloader v.0.2a','execCMD(''.\\resources\\cmd\\getupdates.bat /plugins/LC2CRC32.zip LC2CRC32.zip'', ''out'')');
INSERT OR REPLACE INTO plugins (person_id,name,url) VALUES(4,'lc2process Plugin Downloader v.0.2a','execCMD(''.\\resources\\cmd\\getupdates.bat /plugins/lc2process.zip lc2process.zip'', ''out'')');
INSERT OR REPLACE INTO plugins (person_id,name,url) VALUES(5,'LC2ShortCutCLI Plugin Downloader v.0.2a','execCMD(''.\\resources\\cmd\\getupdates.bat /plugins/LC2ShortCutCLI.zip LC2ShortCutCLI.zip'', ''out'')');
INSERT OR REPLACE INTO plugins (person_id,name,url) VALUES(6,'apache-ant Downloader v.1.0','execCMD(''.\\resources\\cmd\\getupdates.bat /plugins/apache-ant.zip apache-ant.zip'', ''out'')');
INSERT OR REPLACE INTO plugins (person_id,name,url) VALUES(7,'apache-maven 3.81 Downloader v.1.0','execCMD(''.\\resources\\cmd\\getupdates.bat /plugins/apache-maven.zip apache-maven.zip'', ''out'')');


INSERT OR REPLACE INTO plugins (person_id,name,url) VALUES(107,'lc2mysqldocker Plugin Downloader v.1.01a','execCMD(''.\\resources\\cmd\\getupdates.bat /plugins/lc2mysqldocker.zip lc2mysqldocker.zip'', ''out'')');
INSERT OR REPLACE INTO plugins (person_id,name,url) VALUES(108,'lc2postgresdocker Plugin Downloader v.1.01a','execCMD(''.\\resources\\cmd\\getupdates.bat /plugins/lc2postgresdocker.zip lc2postgresdocker.zip'', ''out'')');
INSERT OR REPLACE INTO plugins (person_id,name,url) VALUES(109,'lc2mongodb Plugin Downloader v.1.01a','execCMD(''.\\resources\\cmd\\getupdates.bat /plugins/lc2mongodb.zip lc2mongodb.zip'', ''out'')');
INSERT OR REPLACE INTO plugins (person_id,name,url) VALUES(110,'lc2sqlservercmd Plugin Downloader v.1.01a','execCMD(''.\\resources\\cmd\\getupdates.bat /plugins/lc2sqlservercmd.zip lc2sqlservercmd.zip'', ''out'')');
INSERT OR REPLACE INTO plugins (person_id,name,url) VALUES(111,'LC2DockerJenkins Plugin Downloader v.1.01a','execCMD(''.\\resources\\cmd\\getupdates.bat /plugins/LC2DockerJenkins.zip LC2DockerJenkins.zip'', ''out'')');
INSERT OR REPLACE INTO plugins (person_id,name,url) VALUES(112,'LC2Grafana Plugin Downloader v.1.01a','execCMD(''.\\resources\\cmd\\getupdates.bat /plugins/LC2Grafana.zip LC2Grafana.zip'', ''out'')');
INSERT OR REPLACE INTO plugins (person_id,name,url) VALUES(113,'LC2RegistryWizard Plugin Downloader v.1.2 Final','execCMD(''.\\resources\\cmd\\getupdates.bat /plugins/LC2RegistryWizard.zip LC2RegistryWizard.zip'', ''out'')');
INSERT OR REPLACE INTO plugins (person_id,name,url) VALUES(114,'LC2Microsoft.Toolkit Plugin Downloader v.1.01a','execCMD(''.\\resources\\cmd\\getupdates.bat /plugins/LC2Microsoft.Toolkit.zip LC2Microsoft.Toolkit.zip'', ''out'')');
INSERT OR REPLACE INTO plugins (person_id,name,url) VALUES(115,'lc2ircs Plugin Downloader v.1.01a','execCMD(''.\\resources\\cmd\\getupdates.bat /plugins/lc2ircs.zip lc2ircs.zip'', ''out'')');
INSERT OR REPLACE INTO plugins (person_id,name,url) VALUES(116,'LC2Clock Plugin Downloader v.1.01a','execCMD(''.\\resources\\cmd\\getupdates.bat /plugins/LC2Clock.zip LC2Clock.zip'', ''out'')');
INSERT OR REPLACE INTO plugins (person_id,name,url) VALUES(117,'LC2Age Plugin Downloader v.1.01a','execCMD(''.\\resources\\cmd\\getupdates.bat /plugins/LC2Age.zip LC2Age.zip'', ''out'')');
INSERT OR REPLACE INTO plugins (person_id,name,url) VALUES(118,'lc2dockerphpapache Plugin Downloader v.1.01a','execCMD(''.\\resources\\cmd\\getupdates.bat /plugins/lc2dockerphpapache.zip lc2dockerphpapache.zip'', ''out'')');
INSERT OR REPLACE INTO plugins (person_id,name,url) VALUES(119,'LC2RotatingTorproxy Plugin Downloader v.1.01a','execCMD(''.\\resources\\cmd\\getupdates.bat /plugins/LC2RotatingTorproxy.zip LC2RotatingTorproxy.zip'', ''out'')');
INSERT OR REPLACE INTO plugins (person_id,name,url) VALUES(120,'LC2Age Plugin Downloader v.1.01a (Coming soon)','execCMD(''.\\resources\\cmd\\getupdates.bat /plugins/LC2Age.zip LC2Age.zip'', ''out'')');
INSERT OR REPLACE INTO plugins (person_id,name,url) VALUES(121,'LC2DockerSonarCube Plugin Downloader v.1.01a (Coming soon)','execCMD(''.\\resources\\cmd\\getupdates.bat /plugins/LC2DockerSonarCube.zip LC2DockerSonarCube.zip'', ''out'')');
INSERT OR REPLACE INTO plugins (person_id,name,url) VALUES(122,'LC2Python Plugin Downloader v.1.01a','execCMD(''.\\resources\\cmd\\getupdates.bat /plugins/LC2Python.zip LC2Python.zip'', ''out'')');
INSERT OR REPLACE INTO plugins (person_id,name,url) VALUES(123,'LC2ApacheDS Plugin Downloader v.1.01a','execCMD(''.\\resources\\cmd\\getupdates.bat /plugins/LC2ApacheDS.zip LC2ApacheDS.zip'', ''out'')');
INSERT OR REPLACE INTO plugins (person_id,name,url) VALUES(124,'LC2PHP2Exe Plugin Downloader v.1.01a (Coming soon)','execCMD(''.\\resources\\cmd\\getupdates.bat /plugins/LC2PHP2Exe.zip LC2PHP2Exe.zip'', ''out'')');
INSERT OR REPLACE INTO plugins (person_id,name,url) VALUES(125,'LC2Lampp Plugin Downloader v.1.01a','execCMD(''.\\resources\\cmd\\getupdates.bat /plugins/LC2Lampp.zip LC2Lampp.zip'', ''out'')');
INSERT OR REPLACE INTO plugins (person_id,name,url) VALUES(126,'LC2JXMLTransform Plugin Downloader v.1.01a','execCMD(''.\\resources\\cmd\\getupdates.bat /plugins/LC2JXMLTransform.zip LC2JXMLTransform.zip'', ''out'')');
INSERT OR REPLACE INTO plugins (person_id,name,url) VALUES(127,'LC2IRCClient Plugin Downloader v.1.01a','execCMD(''.\\resources\\cmd\\getupdates.bat /plugins/LC2IRCClient.zip LC2IRCClient.zip'', ''out'')');
INSERT OR REPLACE INTO plugins (person_id,name,url) VALUES(128,'LC2FileExplorer Plugin Downloader v.1.01a','execCMD(''.\\resources\\cmd\\getupdates.bat /plugins/LC2FileExplorer.zip LC2FileExplorer.zip'', ''out'')');
INSERT OR REPLACE INTO plugins (person_id,name,url) VALUES(129,'lc2dockerphpapacheservice Plugin Downloader v.1.01a','execCMD(''.\\resources\\cmd\\getupdates.bat /plugins/lc2dockerphpapacheservice.zip lc2dockerphpapacheservice.zip'', ''out'')');
INSERT OR REPLACE INTO plugins (person_id,name,url) VALUES(130,'LC2DBCLI Plugin Downloader v.1.01a','execCMD(''.\\resources\\cmd\\getupdates.bat /plugins/LC2DBCLI.zip LC2DBCLI.zip'', ''out'')');
INSERT OR REPLACE INTO plugins (person_id,name,url) VALUES(131,'LC2Rancher Plugin Git Downloader v.1.01a Beta1','execCMD(''.\\resources\\cmd\\getupdates.bat /plugins/LC2ApacheRancher.zip LC2ApacheRancher.zip'', ''out'')');
INSERT OR REPLACE INTO plugins (person_id,name,url) VALUES(132,'LC2DEBanksUpdater Downloader v.1.2b Beta3','execCMD(''.\\resources\\cmd\\getupdates.bat /plugins/LC2DEBanksUpdater.zip LC2DEBanksUpdater.zip'', ''out'')');
INSERT OR REPLACE INTO plugins (person_id,name,url) VALUES(133,'PhaserEditor_2D_Downloader Downloader v.1.01a','execCMD(''.\\resources\\cmd\\getupdates.bat /plugins/PhaserEditor_2D_Downloader.zip PhaserEditor_2D_Downloader.zip'', ''out'')');
INSERT OR REPLACE INTO plugins (person_id,name,url) VALUES(134,'LetsEncryptBoulder Downloader v.1.01a','execCMD(''.\\resources\\cmd\\getupdates.bat /plugins/LetsEncryptBoulder.zip LetsEncryptBoulder.zip'', ''out'')');
INSERT OR REPLACE INTO plugins (person_id,name,url) VALUES(135,'lc2sqlservercmd Downloader v.1.02','execCMD(''.\\resources\\cmd\\getupdates.bat /plugins/lc2sqlservercmd.zip lc2sqlservercmd.zip'', ''out'')');
INSERT OR REPLACE INTO plugins (person_id,name,url) VALUES(136,'LC2JSVideoPlayer Downloader v.0.1.2','execCMD(''.\\resources\\cmd\\getupdates.bat /plugins/LC2JSVideoPlayer.zip LC2JSVideoPlayer.zip'', ''out'')');
INSERT OR REPLACE INTO plugins (person_id,name,url) VALUES(137,'LC2WiFiDirectLegacyAPI Downloader v.0.1.2','execCMD(''.\\resources\\cmd\\getupdates.bat /plugins/LC2WiFiDirectLegacyAPI.zip LC2WiFiDirectLegacyAPI.zip'', ''out'')');
INSERT OR REPLACE INTO plugins (person_id,name,url) VALUES(138,'LC2EncrypDecrypt Downloader v.1.0','execCMD(''.\\resources\\cmd\\getupdates.bat /plugins/LC2EncrypDecrypt.zip LC2EncrypDecrypt.zip'', ''out'')');
INSERT OR REPLACE INTO plugins (person_id,name,url) VALUES(139,'LC2bat2exe Downloader v.1.0','execCMD(''.\\resources\\cmd\\getupdates.bat /plugins/LC2bat2exe.zip LC2bat2exe.zip'', ''out'')');



INSERT OR REPLACE INTO plugins (person_id,name,url) VALUES(200,'LC2Java.Starter Plugin Downloader v.1.1c Small Demo App','execCMD(''.\\resources\\cmd\\getupdates.bat /plugins/LC2Java.Starter.zip LC2Java.Starter.zip'', ''out'')');

INSERT OR REPLACE INTO plugins (person_id,name,url) VALUES(1000000,'Please update all plugins soon','alert(''Update all plugins. There might be some brandnew updates.'')');
SELECT 'SUCCESSFULLY IMPORTED.';
SELECT 'Registered Plugins count:';
select count(*) from plugins;
SELECT 'Plugins IMPORT done.';
COMMIT;