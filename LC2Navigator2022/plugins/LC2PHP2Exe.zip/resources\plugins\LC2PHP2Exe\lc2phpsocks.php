<?
$action = "home";
$host = "127.0.0.1";
$port = 1234;
if ($argc == 1) {
	print "Usage: lc2SocketServer <port>\n";
	exit;
}
if ($argc >= 1) {
	echo "action:" . $argv[1];
	$action = intval($argv[1]);
}
include("./include/socket/sockslib.php");
include("./include/socket/sock-recv.php");
switch ($action) {
	case 'home':
		getSocketServerReceiv($host);
		break;
	case 'receive':
		getSocketServerReceiv($host);
		break;
	case 'server':
		if ($argc >= 2) {
			echo "Arg:" . $argv[2];
			$port = intval($argv[2]);
		}
		getSocketServer($host, $port);
		break;

	default:
		getSocketServerReceiv($host);
		break;
}
