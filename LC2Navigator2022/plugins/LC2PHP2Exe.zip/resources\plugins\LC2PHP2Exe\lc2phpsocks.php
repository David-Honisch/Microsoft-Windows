<?
// set some variables
$host = "127.0.0.1";
$port = 1234;
if ($argc == 1) {
	print "Usage: lc2SocketServer <port>\n";
	exit;
}
if ($argc >= 1) {
	echo "Arg:" . $argv[1];
	$port = intval($argv[1]);
}
include("./include/socket/lc2SocketServer2022.php");
getSocketServer($host, $port);
?>
