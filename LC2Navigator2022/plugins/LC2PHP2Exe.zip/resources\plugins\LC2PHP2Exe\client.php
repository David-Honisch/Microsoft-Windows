<?php
$address="127.0.0.1";
$port="801";
$msg="Hello server";

$sock=socket_create(AF_INET,SOCK_STREAM,0) or die("Cannot create a socket");
socket_connect($sock,$address,$port) or die("Could not connect to the socket");
socket_write($sock,$msg);

$read=socket_read($sock,1024);
echo $read;
socket_close($sock);
// $input = socket_read($socket, 801);
// // In most cases, error produces an empty string and not FALSE
// if ($input === FALSE || strcmp($input, '') == 0) {
//     $code = socket_last_error($socket);

//     // You MUST clear the error, or it will not change on next read
//     socket_clear_error($socket);

//     if ($code == SOCKET_EAGAIN) {
//         // Nothing to read from non-blocking socket, try again later...

//     } else {
//         // Connection most likely closed, especially if $code is '0'
//     }

// } else {
//     // Deal with the data
// }
?>