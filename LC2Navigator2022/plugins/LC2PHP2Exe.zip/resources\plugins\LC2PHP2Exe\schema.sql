select '<h4>LC2PHP2Exe Plugin SQL Import</h4>'; 
drop table IF EXISTS LC2PHP2Exe;
drop table IF EXISTS LC2PHP2Exetemp;
CREATE TABLE LC2PHP2Exe ( 'person_id' INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, 'created' TIMESTAMP DEFAULT CURRENT_TIMESTAMP NULL, 'modified' TIMESTAMP DEFAULT CURRENT_TIMESTAMP NULL, 'enddate' TIMESTAMP DEFAULT CURRENT_TIMESTAMP NULL, 'name' TEXT NOT NULL, 'first_name' TEXT NULL, 'description' TEXT NULL, 'zipcode' TEXT NULL, 'city' TEXT NULL,	 'street' TEXT NULL,	 'url' TEXT NULL);
create table IF NOT EXISTS LC2PHP2Exetemp ( name varchar(255), menu TEXT, url varchar(255), subtext TEXT);
.separator ';'
.import .\\resources\\plugins\\LC2PHP2Exe\\import\\import.csv LC2PHP2Exetemp
INSERT INTO LC2PHP2Exe (first_name,name, description,url) select name,name, menu,url  from LC2PHP2Exetemp;
select '<p>LC2PHP2Exe count:';
select count(*) from LC2PHP2Exe;
select '</p>';
.exit
