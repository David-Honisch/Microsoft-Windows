<?php
/**
 * ProcessSimpleType method
 * @param string $who name of the person we'll say hello to
 * @return string $helloText the hello  string
 */
if (strpos("register.auth.cls.php", $_SERVER['PHP_SELF'])) {
    Header("Location:/index.php");
    die();
}
/**
 *
 * @return ------------------------------------------------
 */
// --------------------------------------------------------->
// Get getAuth
// --------------------------------------------------------->
$server->register(
    // method name:
    'getAuth', 
    // parameter list:
    // array('name'=>'xsd:string'),
    array(
        'value1' => 'xsd:string',
        'value2' => 'xsd:string'
    ), 
    // return value(s):
    array(
        'return' => 'xsd:string'
    ), 
    // namespace:
    $namespace, 
    // soapaction: (use default)
    false, 
    // style: rpc or document
    'rpc', 
    // use: encoded or literal
    'encoded', 
    // description: documentation for the method
    'LC2WebService getAuth');

$server->register(
    // method name:
    'isAuth', 
    // parameter list:
    // array('name'=>'xsd:string'),
    array(
        'token' => 'xsd:string'
    ), 
    // return value(s):
    array(
        'return' => 'xsd:string'
    ), 
    // namespace:
    $namespace, 
    // soapaction: (use default)
    false, 
    // style: rpc or document
    'rpc', 
    // use: encoded or literal
    'encoded', 
    // description: documentation for the method
    'LC2WebService isAuth');
$server->register(
    // method name:
    'delToken', 
    // parameter list:
    // array('name'=>'xsd:string'),
    array(
        'token' => 'xsd:string'
    ), 
    // return value(s):
    array(
        'return' => 'xsd:string'
    ), 
    // namespace:
    $namespace, 
    // soapaction: (use default)
    false, 
    // style: rpc or document
    'rpc', 
    // use: encoded or literal
    'encoded', 
    // description: documentation for the method
    'LC2WebService getToken');
// --------------------------------------------------------->
// EOF
// --------------------------------------------------------->
?>