<!DOCTYPE html>
<html class="html__responsive ">
<head>
  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
  <title>LC2DockerApachePHPMySQL</title>
  <meta name="title" content="NuSOAP, HTTP Authentication and HTTP Proxy" />
  <meta name="author" content="beanizer" />
  <meta name="description" content="Using HTTP Authentication and HTTP Proxy with NuSOAP" />
  <meta name="keywords" content="nusoap, http authentication, http proxy" />
  <meta name="Generator" content="Copyright (C) 2022 - 1998 Open Source Matters. All rights reserved." />
  <meta name="robots" content="index, follow" />
  <!-- <base href="http://www.letztechance.org/site/" /> -->
  <link rel="shortcut icon" href="http://www.letztechance.org/favicon.ico" />
  <script language="JavaScript" type="text/javascript">
  </script>
</head>

<body>
  <h1>Welcome to LetzteChance.Org - WebService API Explorer</h1>
  <!-- <h4>Attempting MySQL connection fromx php...</h4> -->
  <a href="/index.php" target="_parent">Home</a>
  <a href="/adminer-4.7.0.php" target="_blank">Admin</a>
  <a href="/showdb.php" target="_blank">showdb.php</a>
  <hr>
  <form action="upload.php" method="post" enctype="multipart/form-data">
    Select image to upload:
    <input type="file" name="fileToUpload" id="fileToUpload">
    <input type="submit" value="Upload Image" name="submit">
  </form>
  <input type="button" value="Submit" name="submit" id="postbutton">
  <hr>
  <div id="out"></div>
  <script src="assets/js/jquery/jquery.min.js"></script>
  <script src="assets/js/actions/ismysqlconnected.js"></script>
</body>

</html>