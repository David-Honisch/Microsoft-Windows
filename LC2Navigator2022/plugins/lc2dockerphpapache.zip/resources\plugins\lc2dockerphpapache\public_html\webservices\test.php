<?php
require "../config/const.cls.php";
// require "path_to_adodb/adodb.inc.php";
// require "path_to_adodb/adodb-xmlschema03.inc.php";
 
/* Configuration information. Define the schema filename,
 * RDBMS platform (see the ADODB documentation for valid
 * platform names), and database connection information here.
 */
$schemaFile = 'dao.xml';
// $platform = 'mysql';
// $dbHost = 'localhost';
// $dbName = 'database';
// $dbUser = 'username';
// $dbPassword = 'password';
 
/* Start by creating a normal ADODB connection.
 */
//$db = ADONewConnection($platform);
//$db->connect($dbHost, $dbUser, $dbPassword, $dbName);
 
/* Use the database connection to create a new adoSchema object.
 */
$schema = new adoSchema($db);
 
/* Call parseSchema() to build SQL from the XML schema file.
 * Then call executeSchema() to apply the resulting SQL to 
 * the database.
 */
$sql = $schema->parseSchema($schemaFile);
$result = $schema->executeSchema();
print_r($result);
print $schema->printSQL('TEXT'); // Display SQL as text
print $schema->printSQL('HTML'); // Display SQL as HTML
$sql = $schema->printSQL();	// Fetch SQL as array
 
// Save SQL to file
$schema->saveSQL('schema.sql');