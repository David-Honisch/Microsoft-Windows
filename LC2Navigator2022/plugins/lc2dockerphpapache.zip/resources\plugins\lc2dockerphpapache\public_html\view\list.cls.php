<ul id="myTab" class="nav nav-tabs" role="tablist">
    <li role="presentation" class="active">
        <a href="#home" id="home-tab" role="tab" data-toggle="tab" aria-controls="home" aria-expanded="true">Home</a>
    </li>
    <li role="presentation" class="">
        <a href="#importcsv" role="tab" id="importcsv-tab" data-toggle="tab" aria-controls="importcsv" aria-expanded="false">News</a></li>

    <li role="presentation" class="">
        <a href="#exportdb" role="tab" id="exportdb-tab" data-toggle="tab" aria-controls="exportdb" aria-expanded="false">Export Database</a></li>

    <li role="presentation" class="">
        <a href="#readcsv" role="tab" id="readcsv-tab" data-toggle="tab" aria-controls="readcsv" aria-expanded="false">Read CSV</a></li>

    <li role="presentation" class="dropdown">
        <a href="#" id="myTabDrop1" class="dropdown-toggle" data-toggle="dropdown" aria-controls="myTabDrop1-contents" aria-expanded="false">API <span class="caret"></span></a>
        <ul class="dropdown-menu" role="menu" aria-labelledby="myTabDrop1" id="myTabDrop1-contents">
            <li><a href="#dropdown1" tabindex="-1" role="tab" id="dropdown1-tab" data-toggle="tab" aria-controls="dropdown1">@coming soon</a></li>
            <li><a href="#dropdown2" tabindex="-1" role="tab" id="dropdown2-tab" data-toggle="tab" aria-controls="dropdown2">@update coming soon.</a></li>
        </ul>
    </li>
</ul>
<br>
<div id="myTabContent" class="tab-content">
    <div role="tabpanel" class="tab-pane fade active in" id="home" aria-labelledby="home-tab">
    <ul class="listul">
            <li ng-repeat="item in pagedItems">
                <a href="index.php?q=read&value1={{item.id}}">a{{item.title}}b</a>
                <!-- <pre>{{item}}</pre> -->
                <span>
                <!-- <input class="right" type="button" value="Show" onclick="readFile( '{{item.url}}', 'out') "></input>
                <input class="right" type="button" value="Open" onclick="openFile( 'list.html?db={{item.name}}') "></input>
                <input class="right" type="button" value="Delete" onclick="deleteItem('{{item.id}}') "></input> -->
                </span>
            </li>
        </ul>

    </div>

    <div role="tabpanel" class="tab-pane fade" id="importcsv" aria-labelledby="importcsv-tab">
        <button type="button" class="btn btn-default" onclick="execCMD('call menu.bat', 'out');">Reload</button>

        <fieldset>
            <legend>Import File</legend>
            <ul class="listul">
            <li ng-repeat="item in news">
                <a href="index.php?q=read&value1={{item.name}}">{{item.subject}}</a>
            </li>
        </ul>
        </fieldset>

        <fieldset>
                <legend id="menutitle">Application</legend>
               
                <!-- <p>edit:</p>
                <webview nodeIntegration src="edit.html"></webview> -->

                <select id="database">
                <option ng-repeat="item in data" value="{{item.name}}">{{item.name}}</option>
                </select>
                <input type="button" name="goto" id="goto" value="Go to" onClick="goToTable() " /><br>
                <div id="newdbcnt"></div>
                <input type="text" name="newdb" id="newdb" placeholder="please type the table name" />
                <input type="button" name="createdb" id="createdb" value="Create Table" onClick=" createDatabase()" />

                <div>
                    <input type="text " name="browser" id="browser" ng-model="query.name" ng-model-blur placeholder="name" />
                    <pre>{{query}}</pre>

                    <hr>
                    <ul class="listul">
                        <li ng-repeat="item in pagedItems">
                            <a href="index.php?q=list&value1={{item.id}}">{{item.title}}</a>
                            <!-- <pre>{{item}}</pre> -->
                            <span>
                            <!-- <input class="right" type="button" value="Show" onclick="readFile( '{{item.url}}', 'out') "></input>
                            <input class="right" type="button" value="Open" onclick="openFile( 'list.html?db={{item.name}}') "></input>
                            <input class="right" type="button" value="Delete" onclick="deleteItem('{{item.id}}') "></input> -->
                            </span>
                        </li>
                    </ul>

                    <!-- <article ng-repeat="item in pagedItems">
                        <pre>{{item}}</pre>
                        <input type="button" value="Show" onclick="readFile( '{{item.url}}', 'out') "></input>
                        <input type="button" value="Open" onclick="openFile( 'list.html?db={{item.name}}') "></input>
                        <input type="button" value="Delete" onclick="deleteItem('{{item.id}}') "></input>
                    </article> -->

                    <div class="clearfix ">
                        <span class="pull-left">showing {{start}} to {{end}} of
                            {{filteredItems.length}}<span
                            ng-show="data.length !=filteredItems.length "> (from
                                {{data.length}})</span>
                        </span>

                        <pagination class="pagination-right pagination-small" style="margin:0" num-pages="numOfPages" current-page="currentPage" max-size="maxSize" boundary-links="true"></pagination>
                    </div>
                </div>

            </fieldset>



        <form>
            <label>Import Suchbegriff:</label>
            <input id="importpattern" type="text" value="test.csv"></input>
            <label>Tabelle:</label>
            <input id="importtable" type="text" value="appgames"></input>
            <input id="importLinks" type="button" value="Import Links" onclick="execCMD('call .\\resources\\cmd\\import.from.csv.to.sqlite.bat '+$('#importpattern').val()+' '+$('#importtable').val(), 'extplugin_cnt');"></input>
            <input id="importFiles" type="button" value="Import Files" onclick="execCMD('call .\\resources\\cmd\\import.files.from.csv.to.sqlite.bat '+$('#importpattern').val()+' '+$('#importtable').val(), 'extplugin_cnt');"></input>
        </form>
    </div>

    <div role="tabpanel" class="tab-pane fade" id="exportdb" aria-labelledby="exportdb-tab">
        <button type="button" class="btn btn-default" onclick="execCMD('call .\\resources\\cmd\\exportdb.bat', 'appcnt');">Export</button>

    </div>


    <div role="tabpanel" class="tab-pane fade" id="dropdown1" aria-labelledby="dropdown1-tab">
        <button type="button" class="btn btn-default" onclick="execCMD('call menu.bat', 'appcnt');">Reload</button>
    </div>
    <div role="tabpanel" class="tab-pane fade" id="dropdown2" aria-labelledby="dropdown2-tab">
        <button type="button" class="btn btn-default" onclick="execCMD('call menu.bat', 'appcnt');">Reload</button>
    </div>
</div>
<hr>
<div id="extplugin_cnt"></div>
<script src="assets/js/page/home.js "></script>