<?php
if (strpos("getallcalendardates.cls.php", $_SERVER['PHP_SELF'])) {
    Header("Location:/index.php");
    die();
}
class AllCalendarDays
{
    public function get($env, $db)
    {
        try {
            //$sql = "SELECT s.session, (SELECT * FROM users WHERE user = '" . $user . "' and pass =  md5('" . $pwd . "') limit 0,1) as 'name' FROM session s WHERE u_id = (SELECT u_id FROM users WHERE user = '" . $user . "' and pass = md5('" . $pwd . "') limit 0,1) limit 0,1";
            $sql = "SELECT * FROM contentpages limit 0,1000";
            $rs = $db->Execute($sql);
        } catch (Exception $e) {
            throw $e;
        }
        return $rs->GetAll();

    }
    public function print2($env)
    {

        try {
            // $filename = "https://chart.googleapis.com/chart?chs=300x300&cht=qr&chl=".$query."&choe=UTF-8";
            // $imagedata = file_get_contents($filename);
            // //@unlink($filename);

            // // alternatively specify an URL, if PHP settings allow
            // $base64 = base64_encode($imagedata);
            // // $result["QRUTF8"] = utf8_decode($base64);
            // $str = utf8_encode(base64_decode($base64));
            // $result["QR"] = $base64;

            // $responseString = new soapval('return', 'xsd:string', json_encode($result));
            // require ("../config/const.cls.php");
            $dateFunc = null;
            if (file_exists($env["include"] . "parse/read_functions.cls.php")) {
                require_once($env["include"] . "calendar/datefunc.cls.php");
                $datefunc = new DateFunc();

                // $date_format = 'Y-m-d';
                $date_format = 'd.m.Y';
                // $startdate = "2019-02-10"; // Order placing date
                $businessdays = 7; // number of days for delivery
                $holidays = array(
                    '2019-05-27',
                    '2019-06-14'
                ); // array of dates having holidays. excluding business days.
                $dateformat = 'd-m-Y'; // output date format for displaying.
                $result["startdate"] = $startdate;
                $result["enddate"] = $enddate;
                $result["date"] = easter_date();
                $result["easterdate"] = date($date_format, easter_date(2019));
                $result["easterdays"] = easter_days("2019");
                $result["businessdays"] = $datefunc->add_business_days($startdate, $businessdays, $holidays, $dateformat);
                $result["workingdays"] = $datefunc->getWorkingDays($startdate, $enddate);
                $result["americanholidays"] = $datefunc->getNationalAmericanHolidays("2019");
                //
                $jsonIterator = new RecursiveIteratorIterator(new RecursiveArrayIterator(getJSONFile($env["WS"] . "holidays.json")), RecursiveIteratorIterator::SELF_FIRST);

                foreach ($jsonIterator as $key => $val) {
                    if (is_array($val)) {
                        $result["holidays"][$key] = $key;
                    } else {
                        $result["holidays"][$key] = $val;
                    }
                }
            }

            $responseString = new soapval('return', 'xsd:string', json_encode($result));
            // return $responseString;
        } catch (\Throwable $th) {
            throw $th;
        }
    }
    function getAllCalendarDays($location, $date, $startdate, $enddate)
    {
        require("../config/const.cls.php");
        $dateFunc = null;
        if (file_exists($env["include"] . "parse/read_functions.cls.php")) {
            require($env["include"] . "calendar/datefunc.cls.php");
            $datefunc = new DateFunc();

            // $date_format = 'Y-m-d';
            $date_format = 'd.m.Y';
            // $startdate = "2019-02-10"; // Order placing date
            $businessdays = 7; // number of days for delivery
            $holidays = array(
                '2019-05-27',
                '2019-06-14'
            ); // array of dates having holidays. excluding business days.
            $dateformat = 'd-m-Y'; // output date format for displaying.
            $result["startdate"] = $startdate;
            $result["enddate"] = $enddate;
            $result["date"] = easter_date();
            $result["easterdate"] = date($date_format, easter_date(2019));
            $result["easterdays"] = easter_days("2019");
            $result["businessdays"] = $datefunc->add_business_days($startdate, $businessdays, $holidays, $dateformat);
            $result["workingdays"] = $datefunc->getWorkingDays($startdate, $enddate);
            $result["americanholidays"] = $datefunc->getNationalAmericanHolidays("2019");
            //
            $jsonIterator = new RecursiveIteratorIterator(new RecursiveArrayIterator(getJSONFile($env["WS"] . "holidays.json")), RecursiveIteratorIterator::SELF_FIRST);

            foreach ($jsonIterator as $key => $val) {
                if (is_array($val)) {
                    $result["holidays"][$key] = $key;
                } else {
                    $result["holidays"][$key] = $val;
                }
            }
        }

        $responseString = new soapval('return', 'xsd:string', json_encode($result));
        return $responseString;
    }

    public function getJSONFile($fileName)
    {
        $string = file_get_contents($fileName);
        return json_decode($string, true);
    }
}
$o = new AllCalendarDays();
$result["data"]["cp"] = $o->get($env, $db);