<?php
if (!isset($env) && empty($env)) {
    if (file_exists("../config/const.cls.php")) {
        include("../config/const.cls.php");
    } else {
        echo "404 NOT FOUND";
        die();
    }
}
class AuthPostUser
{
    public static function getAuth($env, $user, $pass)
    {
        $useCURL = isset($_POST['usecurl']) ? $_POST['usecurl'] : '0';
        require_once($env["include"] . "nusoap/lib/nusoap.php");
        $proxyhost = "";
        $proxyport = "";
        $proxyusername = "";
        $proxypassword = "";
        $client = new nusoap_client($env["WebService"], false, $proxyhost, $proxyport, $proxyusername, $proxypassword);
        $result = "";
        $err = $client->getError();
        if ($err) {
            echo '<h2>Constructor error</h2><pre>' . $err . '</pre>';
            echo '<h2>Debug</h2><pre>' . htmlspecialchars($client->getDebug(), ENT_QUOTES) . '</pre>';
            exit();
        }

        $client->setUseCurl($useCURL);
        $client->soap_defencoding = 'UTF-8';
        $client->setCredentials("administrator", "H@nd3l2017", "basic");

        $params = array(
            'user' => '' . $user,
            'pass' => '' . $pass
        );
        return $client->call("getAuth", $params, "urn:String", "urn:String");
    }

    public static function postUrl($env, $token, $url)
    {
        $useCURL = isset($_POST['usecurl']) ? $_POST['usecurl'] : '0';
        require_once($env["include"] . "nusoap/lib/nusoap.php");
        $date = new DateTime();
        $proxyhost = "";
        $proxyport = "";
        $proxyusername = "";
        $proxypassword = "";
        $client = new nusoap_client($env["WebService"], false, $proxyhost, $proxyport, $proxyusername, $proxypassword);
        $result = "";
        $err = $client->getError();
        if ($err) {
            echo '<h2>Constructor error</h2><pre>' . $err . '</pre>';
            echo '<h2>Debug</h2><pre>' . htmlspecialchars($client->getDebug(), ENT_QUOTES) . '</pre>';
            exit();
        }

        $client->setUseCurl($useCURL);
        $client->soap_defencoding = 'UTF-8';
        $client->setCredentials("administrator", "H@nd3l2017", "basic");

        $params = array(
            'token' => '' . $token,
            'date' => '' . $date->format('Y-m-d H:i:s'),
            'value1' => '' . 87,
            'subject' => '' . $url,
            'body' => '[url]' . $url . '[/url]'
        );
        // print_r($params);
        return $client->call("doInsert", $params, "urn:String");
    }
}
class GrabURLHTML
{
    /**
     */
    private static function getWebForm()
    {
        $result = "";
        $result .= "<p align=\"center\">\n";
        $result .= "<font class=\"big\">Link Parser</font>\n";
        $result .= "<p>Geben Sie eine Webhost an: </p>\n";
        $result .= "<form name=\"website\" method=\"get\" action=\"./\" rel=\"external\" target=\"_parent\">\n";
        $result .= "<input type=\"hidden\" name=\"q\" value=\"read\">\n";
        $result .= "<input type=\"hidden\" name=\"value1\" value=\"22\">\n";
        $result .= "<input type=\"hidden\" name=\"value2\" value=\"3\">\n";
        $result .= "<input type=\"hidden\" name=\"plugin\" value=\"webparser\">\n";
        $result .= "<p>Host</p>\n";
        $result .= "  <p>\n";
        $result .= "    <input type=\"text\" name=\"query\">\n";
        $result .= "  </p>\n";
        $result .= "<p>Proxy:</p>\n";
        $result .= "  <p>\n";
        $result .= "<input type=\"text\" name=\"proxy\">\n";
        $result .= "Port:\n";
        $result .= "<input type=\"text\" name=\"port\" size=\"5\">\n";
        $result .= "  </p>\n";
        $result .= "  <p>\n";
        $result .= "    <input type=\"submit\" name=\"Submit\" value=\"Submit\">\n";
        $result .= "  </p>\n";
        $result .= "</form>\n";
        $result .= "<p>\n";
        $result .= "<a href=\"#\" onClick=\"cFCW('proxies.html',700,400,152,120);return false\">Proxies</a><br>\n";
        return $result;
    }
}
class PluginGrabUrls
{

    private static function get_valueFromStringUrl($url, $parameter_name)
    {
        $parts = parse_url($url);
        if (isset($parts['query'])) {
            parse_str($parts['query'], $query);
            if (isset($query[$parameter_name])) {
                return $query[$parameter_name];
            } else {
                return null;
            }
        } else {
            return null;
        }
    }

    public static function getUrl($url)
    {
        return parse_url($url, PHP_URL_SCHEME) . "://" . parse_url($url, PHP_URL_HOST) . parse_url($url, PHP_URL_PATH) . parse_url($url, PHP_URL_QUERY);
    }

    public static function requestedByTheSameDomain()
    {
        $myDomain       = isset($_SERVER['SCRIPT_URI']) ? $_SERVER['SCRIPT_URI'] : null;
        $requestsSource = isset($_SERVER['HTTP_REFERER']) ? $_SERVER['HTTP_REFERER'] : null;
        return parse_url($myDomain, PHP_URL_HOST) === parse_url($requestsSource, PHP_URL_HOST);
    }

    public static function  file_get_contents_curl($url)
    {
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_HEADER, 0);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1); //Set curl to return the data instead of printing it to the browser.
        curl_setopt($ch, CURLOPT_URL, $url);
        $data = curl_exec($ch);
        curl_close($ch);
        return $data;
    }

    public static function get($env, $query)
    {
        $result = [];
        $url = isset($query) ? $query : null;
        $url = isset($url) ? $url : (isset($_REQUEST["query"]) ? $_REQUEST["query"] : "");
        $proxy = isset($env["req"]["proxy"]) ? $env["req"]["proxy"] : "";
        $port = isset($env["req"]["port"]) ? $env["req"]["port"] : "";
        $result["url01"] = $url;
        $url = !empty(self::get_valueFromStringUrl($_SERVER['REQUEST_URI'], "query")) ? self::get_valueFromStringUrl($_SERVER['REQUEST_URI'], "query") : $url;
        $result["url02"] = $url;
        $t = urldecode(getReqQuery("query"));
        $url = !empty($t) ? $t : $url;
        $result["url"] = "" . $url;


        if (!PluginGrabUrls::requestedByTheSameDomain()) {
            echo "<h1>Access denied</h1>";
        } else {
            $result["rawhtml"] = PluginGrabUrls::file_get_contents_curl($url);
            $dom = new DOMDocument;
            //Parse the HTML. The @ is used to suppress any parsing errors
            //that will be thrown if the $html string isn't valid XHTML.
            @$dom->loadHTML($result["html"]);

            //Get all links. You could also use any other tag name here,
            //like 'img' or 'table', to extract other tags.
            $links = $dom->getElementsByTagName('a');

            //Iterate over the extracted links and display their URLs
            $v = 0;
            foreach ($links as $link) {
                if (!empty($link->nodeValue)&& !empty($link->getAttribute('href'))) {
                    //Extract and show the "href" attribute.
                    $result["html"][$v] = "" . $link->nodeValue;
                    $result["href"][$v]  = json_decode($link->getAttribute('href'));
                    $v++;
                }
            }
        }
        // $snoopy = null;
        // if (file_exists($env["docroot"] . "include/snoopy/Snoopy.class.php")) {
        //     include $env["docroot"] . "include/snoopy/Snoopy.class.php";
        //     $snoopy = new Snoopy();
        //     $result["proxydata"] = self::setConfiguration($snoopy, $proxy, $port);
        //     $result["agent"] = $snoopy->agent;
        //     $result["referer"] = $snoopy->referer;
        // } else {
        //     $result["error"] = "404-Parser not found...";
        //     die();
        // }
        // $result["info"] = "WebParser initializing...";
        // // $result["form"] = self::getWebForm();
        // if (! empty($url)) {            
        //     $result["urlFinal"] = "" . $url . "";            
        //     $token = AuthPostUser::getAuth($env, "administrator", "H@nd3l2017");
        //     //             echo $token;
        //     $result["reading"] = "Reading:".$url;
        //     $link = "";

        //     if ($snoopy->fetchlinks($url)) {
        //         $n = count($snoopy->results);
        //         $result["msgreading"] = "Es wurden " . $n . " Links gefunden:	<br>";
        //         for ($i = 1; $i <= $n; $i ++) {
        //             $furl = isset($snoopy->results[$i]) ? $snoopy->results[$i] : "";
        //             if (strlen($furl) != 0) {
        //                 $link = self::setLink($furl, $url, $i);
        //                 // echo "<br/>[url]<a href=\"./?q=read&value1=22&value2=3&query=" . $link . "&proxy=" . $proxy . "&port=" . $port . "\">";
        //                 $result["links"][$i] = $link . "";
        //                 // echo "</a>[/url]";

        //                 $result["post"][$i] = AuthPostUser::postUrl($env,$token, $link);
        //             }
        //         }
        //     } else {
        //         $result["errorfetch"] = "error fetching document: " . $snoopy->error . "\n";
        //     }

        // } else {
        //     $result["errormsg"] = "Bitte geben Sie bitte eine Webseite an:";
        // }
        return $result;
    }

    /**
     *
     * @param
     *            proxy
     * @param
     *            port
     */
    private static function setConfiguration($snoopy, $proxy, $port)
    {
        $result = [];
        $snoopy->agent = "(compatible; MSIE 4.01; MSN 2.5; AOL 4.0; Windows 98)";
        $snoopy->referer = "http://www.xmicrosnot.com/";
        if (!empty($proxy)) {
            $result["errorproxy"] = "Es wurde ein Proxy angegeben: $proxy";
            $snoopy->proxy_host = $proxy;

            if ($port) {
                $snoopy->proxy_port = $port;
                $result["port"] = ":" . $port;
            } else {
                $snoopy->proxy_port = "8080";
                $result["port"] = ":8080";
            }
        } else {
            $result["errorproxymain"] = "Es wurde kein Proxy angegeben.<br>";
        }
        return $result;
    }



    /**
     *
     * @param String $furl
     * @param String $url
     * @param String $i
     * @return string
     */
    private static function setLink($furl, $url, $i)
    {
        $domain = parse_url($url, PHP_URL_SCHEME) . "://" . parse_url($url, PHP_URL_HOST);
        // Debug($furl);
        if (isset($furl) && strpos($furl, $domain) === false && strpos($furl, "@") === true) {
            $link = "a" . $domain . $furl;
        } else {
            if (isset($furl) && strpos($furl, parse_url($url, PHP_URL_SCHEME)) == 0) {
                //
                $link = self::getUrl($furl);
            } else {
                $link = "b" . self::getUrl(substr(self::getUrl($furl), strlen($domain), strlen(self::getUrl($furl))));
            }
        }
        return $link;
    }
}
$result["data"] = PluginGrabUrls::get($env, $query);
