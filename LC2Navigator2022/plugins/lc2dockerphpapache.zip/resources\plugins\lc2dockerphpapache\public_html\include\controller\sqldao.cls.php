<?php

class SqLDao
{

    public $db = null;

    public $env = null;

    public $result = null;

    public $hptitle = null;

    public $install = null;

    public function __construct($db, $env, $hptitle)
    {
        $this->db = $db;
        $this->env = $env;
        $this->hptitle = $hptitle;
        // $result = $this->getPage($db, $env);
    }

    public function getAuth($user, $pwd)
    {
        try {
            $sql = "SELECT s.session, (SELECT user FROM users WHERE user = '" . $user . "' and pass =  md5('" . $pwd . "') limit 0,1) as 'name' FROM session s WHERE u_id = (SELECT u_id FROM users WHERE user = '" . $user . "' and pass = md5('" . $pwd . "') limit 0,1) limit 0,1";
            $rs = $this->db->Execute($sql);
        } catch (Exception $e) {
            throw $e;
        }
        return $rs->GetAll();
    }

    public function isAuth($token)
    {
        $auth = [];
        $sql = "SELECT u.user_level as 'lvl',u.deleted as 'deleted',u.locked as 'locked',u.isAdmin as 'isAdmin', u.user as 'name' FROM users u WHERE u_id = (SELECT s.u_id FROM session s " . "WHERE session = '" . $token . "')" . "limit 0,1";
        $rs = $this->db->Execute($sql);
        $auth["data"] = $rs->GetAll();
        $count = $rs->recordCount();        
        $auth["count"] = $count;
        $auth["login"] = ($count != null && intval($count) > 0) ? true : false;
        return $auth;
    }

    public function delToken($token)
    {
        $result = [];
        $table = "session";

        try {
            $sql = "DELETE FROM `" . $this->env["defaultdb"] . "`.`" . $table . "` WHERE `" . $table . "`.`session` = '" . $token . "'";
            // $sql = "delete FROM session s WHERE s.session = '" . $token . "'";
            $this->db->StartTrans();
            $this->db->Execute($sql);
            $this->db->StartTrans(); // ignored
            // if (!CheckRecords()) $this->db->FailTrans();
            $this->db->CompleteTrans(); // ignored
        } catch (ADODB_Exception $ex) {
            $this->printExeption($ex);
        }
        $result["result"] = $this->db->Affected_Rows();

        return $result;
    }

    public function getTitle()
    {
        return $this->$hptitle;
    }

    public function setTitle($value)
    {
        $this->hptitle = $this->hptitle . $value;
    }

    public function getContent()
    {
        // $q = preg_replace('@/((\&)?PHPSESSID=[a-zA-Z0-9]+(\&)?)/i@', "", $this->env["req"]["q"]);
        // $rs = $this->db->Execute("SELECT * FROM contentpages WHERE page = '".$q."' limit 0,1");
        // return $rs->FetchRow();
        return self::getContent($this->env["req"]["q"]);
    }

    public function getContentPage($q)
    {
        $q = preg_replace('@/((\&)?PHPSESSID=[a-zA-Z0-9]+(\&)?)/i@', "", $q);
        $rs = $this->db->Execute("SELECT * FROM contentpages WHERE page = '" . $q . "' limit 0,1");
        return $rs->FetchRow();
    }

    /*
     * function checkInstallTable()
     * {
     * $isConfigured = $dao->checkInstallTable("content_forum");
     * $isConfigured = true;
     * $env["metaschema"] = $db->MetaTables();
     * //print_r($env["metaschema"]);
     * for ($i = 0;$i < count($env["metaschema"]);$i++)
     * {
     * //if ($env["metaschema"][$i] == "content_forum")
     * if ($env["metaschema"][$i] == "".$tableName)
     * {
     * $isConfigured = true;
     * }
     * }
     * return $isConfigured;
     * }
     */
    public function checkTable($tableName)
    {
        $isConfigured = false;
        for ($i = 0; $i < count($this->env["metaschema"]); $i++) {
            if ($this->env["metaschema"][$i] == $tableName) {
                $isConfigured = true;
            }
        }
        return $isConfigured;
    }

    public function printTables()
    {
        for ($i = 0; $i < count($this->env["metaschema"]); $i++) {
            echo $this->env["metaschema"][$i] . "<br />";
        }
    }

    /**
     * doInstallDB($env, $db, $env["defaultdb"]);
     * Enter description here .
     *
     *
     *
     *
     * ..
     *
     * @param unknown_type $env
     * @param unknown_type $db
     * @param unknown_type $tableName
     */
    public function doInstallDB($tableName, $isDBinstalled)
    {
        $isInstalled = false;
        // echo "Debug:";
        try {
            if (file_exists($this->env["include"] . "install/install.cls.php")) {
                include $this->env["include"] . "install/install.cls.php";
                $this->install = new Installer();
                // ------------------------------------------------------------------->
                // echo "Installing Database...";
                // ------------------------------------------------------------------->
                if (!$isDBinstalled) {
                    if ($this->install->doInstallDB($this->env, $this->db, $tableName)) {
                        echo "<h1>Database installed successfully.</h1>";
                        echo "<h3>Please refresh the page now...</h3>";
                        die();
                    }
                }
                // ------------------------------------------------------------------->
                // echo "EOF Installing Database...";
                // ------------------------------------------------------------------->
                // ------------------------------------------------------------------->
                $this->install->doInstallDBTables($this->env, $this->db, $tableName);
                // ------------------------------------------------------------------->
                $isInstalled = true;
                // ------------------------------------------------------------------->
                $this->install = null;
            }
        } catch (Exception $ex) {
            new Exception("Error in installaton progress. Error Detail:" . $ex);
        }
        return $isInstalled;
    }

    /**
     * Enter description here .
     *
     *
     *
     * ..
     */
    public function getPage()
    {
        $rs = null;
        $q = "home";
        try {
            if (!empty($this->env["req"]["q"])) {
                $q = preg_replace('@/((\&)?PHPSESSID=[a-zA-Z0-9]+(\&)?)/i@', "", $this->env["req"]["q"]);
            }
            $rs = $this->db->Execute("SELECT * FROM contentpages WHERE page = '" . $q . "' limit 0,1");
        } catch (ADODB_Exception $ex) {
            $this->printExeption($ex);
        }
        return $rs->FetchRow();
    }

    // returns the complete db object instance
    /**
     * mysql, mssql, oracle, sqlite,...
     * Enter description here ...
     *
     * @param String $args
     *            defines database type
     */
    public function getDB($args)
    {
        // $dao = null;
        $result = null;

        switch ($this->dbType) {
            case "oracle":

                // echo "Oracle";
                $result = $this->getOracle($args);
                break;
            case "mysql":

                // echo "MySQL";
                $result = $this->getMySQL($args);
                break;
            case "mssql":

                // echo "MsSQL";
                $result = $this->getMsSQL($args);
                break;
            case "sqlite":

                // echo "SQLite";
                $result = $this->getSQLite($args);
                break;
            default:

                // echo "SQLite";
                $result = $this->getSQLite($args);
                break;
        }
        return $result;
    }

    private function printExeption($ex)
    {
        echo $ex;
    }

    /**
     * Returns paging hrefs !!
     * Enter description here .
     *
     *
     *
     *
     * ..
     *
     * @param unknown_type $tableName
     */
    public function getCount($tableName)
    {
        $pagecount = 1;
        try {
            $sql = "SELECT count(*) FROM " . $tableName . " subject WHERE subject.sid = 0";
            // echo $sql;
            $count = $this->db->GetAll("" . $sql);
            if (!empty($count[0][0])) {
                // echo "<hr>".$count[0][0]."<hr>";
                $pagecount = ceil($count[0][0] / $this->env["numofentries"]);
            }
        } catch (ADODB_Exception $ex) {
            $this->printExeption($ex);
        }
        return $pagecount;
    }

    /**
     *
     * Enter description here ...
     *
     * @param unknown_type $pattern
     * @param unknown_type $tableName
     */
    public function getSearchCount($pattern, $tableName)
    {
        $pagecount = 1;
        try {
            // $sql = "SELECT count(*) FROM ".$tableName." subject WHERE subject.sid = 0";
            $sql = "SELECT" . " count(*) " . " FROM " . $tableName . " subject" . " LEFT JOIN " . $tableName . "_bodies body on subject.id = body.id" . " WHERE subject.sid = 0" . " AND subject.subject like '%" . $pattern . "%' " . " OR body.body like '%" . $pattern . "%' " . " ORDER by subject.id asc";
            $count = $this->db->GetAll("" . $sql);
            if (!empty($count[0][0])) {
                // echo "<hr>".$count[0][0]."<hr>";
                $pagecount = ceil($count[0][0] / $this->env["numofentries"]);
            }
        } catch (ADODB_Exception $ex) {
            $this->printExeption($ex);
        }
        return $pagecount;
    }

    /**
     *
     * @param unknown $tableName
     * @return number
     */
    public function getDateCount($tableName)
    {
        $pagecount = 1;
        try {
            $sql = "SELECT count(*) FROM " . $tableName . " subject WHERE subject.sid = 0";
            $count = $this->db->GetAll("" . $sql);
            if (!empty($count[0][0])) {
                // echo "<hr>".$count[0][0]."<hr>";
                $pagecount = ceil($count[0][0] / $this->env["numofentries"]);
            }
        } catch (ADODB_Exception $ex) {
            $this->printExeption($ex);
        }
        return $pagecount;
    }

    /**
     *
     * @return number
     */
    public function getIndexCount()
    {
        $pagecount = 1;
        try {
            $sql = "SELECT count(*) FROM content_forum subject WHERE subject.sid = 0";
            $count = $this->db->GetAll("" . $sql);
            if (!empty($count[0][0])) {
                $pagecount = ceil($count[0][0] / $this->env["numofentries"]);
            }
        } catch (ADODB_Exception $ex) {
            $this->printExeption($ex);
        }
        return $pagecount;
    }

    /**
     *
     * Enter description here ...
     *
     * @param unknown_type $index
     *            - CacheIndex
     * @param unknown_type $value1
     *            - Search forum number
     */
    public function getTableNameFromNumber($index, $value1)
    {
        $tableName = "neues";
        try {
            if (isset($index) && !empty($value1)) {
                for ($i = 0; $i <= sizeof($index); $i++) {                    
                    if (!empty($index[$i]["table_name"])) {
                        if ($value1 == $index[$i]["id"]) {
                            $tableName = !empty($index[$i]["table_name"]) ? $index[$i]["table_name"] : "neues";
                            return "" . $tableName;
                        }
                    }

                }
            }
        } catch (ADODB_Exception $ex) {
            echo $ex;
        }
        return "" . $tableName;
    }

    public function getTableFullNameFromNumber($index, $value1)
    {
        $tableName = "neues";
        try {
            if (isset($index) && !empty($value1)) {
                for ($i = 0; $i <= sizeof($index); $i++) {                    
                    if (!empty($index[$i]["table_name"])) {
                        if ($value1 == $index[$i]["id"]) {
                            $tableName = !empty($index[$i]["name"]) ? $index[$i]["name"] : "neues";
                            return "" . $tableName;
                        }
                    }

                }
            }
        } catch (ADODB_Exception $ex) {
            echo $ex;
        }
        return "" . $tableName;
    }

    /**
     *
     * Enter description here ...
     *
     * @param unknown_type $start
     */
    public function getIndexData($start)
    {
        try {
            $sql = "SELECT " . "subject.id ,subject.name, subject.sid " . " FROM content_forum subject " . " WHERE subject.sid = 0" . " ORDER by subject.id asc" . " LIMIT " . $start . "," . $this->env["numofentries"] . "";
            // echo $sql;
            $rs = $this->db->GetAll("" . $sql);
        } catch (ADODB_Exception $ex) {
            $this->printExeption($ex);
        }
        return $rs;
    }

    /**
     *
     * Enter description here ...
     *
     * @param unknown_type $v1
     * @param unknown_type $v2
     * @param unknown_type $isRequest
     */
    public function getIndex($v1, $isRequest = true)
    {
        $value1 = 1;
        $start = 0;
        try {
            if ($isRequest) {
                if (isset($v1) && !empty($v1)) {
                    $value1 = $this->checkForumNumber($v1);
                }
            }
            $start = ($this->env["numofentries"] * $value1 - $this->env["numofentries"]);
            $end = ($this->env["numofentries"] * $value1);
            $pagecount = 0;
            $pagecount = $this->getIndexCount();
            $rs = $this->getIndexData($start);
            $rs["page"]["count"] = $pagecount;
            $rs["page"]["start"] = $start;
            $rs["page"]["value1"] = $value1;
        } catch (ADODB_Exception $ex) {
            $this->printExeption($ex);
        }
        return $rs;
    }

    public function getFullIndex()
    {
        try {
            $sql = "SELECT subject.id ,subject.subject, subject.url,subject.parent,subject.child, subject.sid " . " FROM content_topmenu as subject" .
            // " LEFT JOIN ".$tableName."_bodies body on subject.id = body.id".
            " WHERE subject.sid = 0" . " ORDER by subject.id asc , subject.parent desc, subject.child desc" .
            // " LIMIT ".$start.",".$this->env["numofentries"]."";
            " LIMIT 0,999";
            // echo $sql;
            $rs = $this->db->GetAll("" . $sql);
            // print_r($rs);
        } catch (ADODB_Exception $ex) {
            $this->printExeption($ex);
        }
        $rs["page"]["count"] = sizeof($rs);
        $rs["page"]["name"] = "all";
        $rs["page"]["start"] = 1;
        $rs["page"]["value1"] = 1;
        $rs["page"]["value2"] = 1;
        return $rs;
    }

    /**
     *
     * Enter description here ...
     *
     * @param unknown_type $value
     */
    public function checkForumNumber($v1 = 1)
    {
        if (isset($v1) && !empty($v1)) {
            // $value1 = preg_replace('@/((\&)?PHPSESSID=[a-zA-Z0-9]+(\&)?)/i@', "", $this->env["req"]["value1"]);
            return preg_replace('@/((\&)?PHPSESSID=[0-9]+(\&)?)/i@', "", $v1);
        }
        return null;
    }

    /**
     * Check request page Number !!
     * Enter description here .
     *
     *
     *
     *
     * ..
     */
    public function checkPageNumber($v2)
    {
        if (isset($v2) && !empty($v2)) {
            // $value1 = preg_replace('@/((\&)?PHPSESSID=[a-zA-Z0-9]+(\&)?)/i@', "", $this->env["req"]["value1"]);
            return preg_replace('@/((\&)?PHPSESSID=[0-9]+(\&)?)/i@', "", $v2);
        }
        return 1;
    }

    /**
     *
     * Enter description here ...
     *
     * @param unknown_type $start
     * @param unknown_type $tableName
     */
    public function getListData($start, $tableName, $isBody = true)
    {
        $rs = null;
        $sql = "";
        try {
            $sql = "SELECT " . "subject.id ,subject.subject, subject.isPHPCode, subject.sid, body.body, subject.datestamp " . ",(select sid from content_forum forum where table_name = '" . $tableName . "') as catsid, '" . $tableName . "' as tableName " . " FROM " . $tableName . " subject" . " LEFT JOIN " . $tableName . "_bodies body on subject.id = body.id" . " WHERE subject.sid = 0" . " ORDER by subject.id desc" . " LIMIT " . $start . "," . $this->env["numofentries"] . "";
            if (!$isBody) {
                $sql = "SELECT " . "subject.id ,subject.subject, subject.isPHPCode, subject.sid, subject.datestamp " . ",(select sid from content_forum forum where table_name = '" . $tableName . "') as catsid, '" . $tableName . "' as tableName " . " FROM " . $tableName . " subject" . "  WHERE subject.sid = 0" . " ORDER by subject.id desc" . " LIMIT " . $start . "," . $this->env["numofentries"] . "";
            }

            if ($this->env["userIsLoggedIn"] == 1) {
                $sql = "SELECT " . "subject.id ,subject.subject, subject.isPHPCode, subject.sid, body.body, subject.datestamp " . ",(select sid from content_forum forum where table_name = '" . $tableName . "') as catsid , '" . $tableName . "' as tableName" . " FROM " . $tableName . " subject" . " LEFT JOIN " . $tableName . "_bodies body on subject.id = body.id" . " WHERE subject.sid <= " . $this->env["user"]["user_level"] . "" . " ORDER by subject.id desc" . " LIMIT " . $start . "," . $this->env["numofentries"] . "";
                if (!$isBody) {
                    $sql = "SELECT " . "subject.id ,subject.subject, subject.isPHPCode, subject.sid, subject.datestamp " . ",(select sid from content_forum forum where table_name = '" . $tableName . "') as catsid , '" . $tableName . "' as tableName" . " FROM " . $tableName . " subject" . "  WHERE subject.sid <= " . $this->env["user"]["user_level"] . "" . " ORDER by subject.id desc" . " LIMIT " . $start . "," . $this->env["numofentries"] . "";
                }

            }
            // echo $sql;
            $rs = $this->db->GetAll("" . $sql);
            // print_r($rs);
        } catch (ADODB_Exception $ex) {
            $this->printExeption($ex);
        }
        return $rs;
    }

    /**
     *
     * Enter description here ...
     *
     * @param unknown_type $v1
     * @param unknown_type $v2
     * @param unknown_type $isRequest
     */
    public function getList($index, $v1, $v2, $isRequest = true, $isBody = true)
    {
        $value1 = 1;
        $value2 = 1;
        $start = 0;
        $tableName = "neues";
        $Description = "Neuigkeiten";
        $rs = null;
        $pagecount = 0;
        try {
            if (!empty($v1)) {
                $value1 = $v1;
            }
            if (!empty($v2)) {
                $value2 = $v2;
            }
            // echo $v1;
            //
            if ($isRequest == true) {
                if (isset($v1) && !empty($v1)) {
                    $value1 = $this->checkForumNumber($v1);
                }
                if (isset($v2) && !empty($v2)) {
                    $value2 = $this->checkPageNumber($v2);
                }
            }
            $start = ($this->env["numofentries"] * $value2 - $this->env["numofentries"]);
            $end = ($this->env["numofentries"] * $value2);
            if (isset($value1) && !empty($value1)) {
                $tableName = $this->getTableNameFromNumber($index, $value1);
                $tableFullName = $this->getTableFullNameFromNumber($index, $value1);
                $pagecount = $this->getCount($tableName);
                // /*
                if ($value2 > $pagecount) {
                    $value2 = $pagecount;
                    $start = ($pagecount * $this->env["numofentries"]) - $this->env["numofentries"];
                }
                if ($value2 < 0) {
                    $value2 = 1;
                    $start = 0;
                }
            }
            if ($value2 <= $pagecount && $value2 > 0) {
                // Debug($v1."sx".$tableName);
                $rs = $this->getListData($start, $tableName, $isBody);
                //print_r($rs);
            }
            // adding request data to array
            $rs["page"]["count"] = $pagecount;
            $rs["page"]["name"] = $tableName;
            $rs["page"]["tableName"] = !empty($tableFullName) ? $tableFullName : "N/A";
            $rs["page"]["start"] = $start;
            $rs["page"]["value1"] = $value1;
            $rs["page"]["value2"] = $value2;
            $rs["page"]["description"] = !empty($index[$value1 - 1]["name"]) ? $index[$value1 - 1]["name"] : "N/A";
            //print_r($rs);
        } catch (ADODB_Exception $ex) {
            $this->printExeption($ex);
        }
        return $rs;
    }

    /**
     * Default usage:
     * getRead($this->env["req"]["value1"],$this->env["req"]["value2"],true);
     * Enter description here .
     *
     *
     *
     *
     * ..
     */
    public function getRead($env, $index, $v1, $v2, $isRequest = true)
    {
        $result = "";
        $value1 = 1;
        $value2 = 1;
        $start = 0;
        $pagecount = 1;
        $tableName = "neues";
        $rs = null;
        try {
            if ($isRequest) {
                if (isset($v1) && !empty($v1)) {
                    // $value1 = preg_replace('@/((\&)?PHPSESSID=[a-zA-Z0-9]+(\&)?)/i@', "", $v1);
                    $value1 = preg_replace('@/((\&)?PHPSESSID=[a-zA-Z0-9]+(\&)?)/i@', "", $v1);
                }
                if (isset($v2) && !empty($v2)) {
                    $value2 = preg_replace('@/((\&)?PHPSESSID=[a-zA-Z0-9]+(\&)?)/i@', "", $v2);
                }
            }

            $tableName = $this->getTableNameFromNumber($index, $value1);
            // echo "<hr>".$tableName;
            if (!empty($tableName)) {
                $pagecount = $this->getCount($tableName);
                // /*
                if ($value2 > $pagecount) {
                    // $value2 = $pagecount;
                    $start = ($pagecount * $this->env["numofentries"]) - $this->env["numofentries"];
                }
                // echo "Debug:".$value2;
                if ($value2 < 0) {
                    $value2 = 1;
                    $start = 0;
                }
                $sql = "SELECT " . "subject.id, subject.sid , subject.isPHPCode, subject.subject, subject.datestamp, subject.email," . " subject.author, subject.host, body.body " . " ,(select max(sub.id) FROM " . $tableName . " as sub) as maxcount " . " ,(select name FROM content_forum sub2 WHERE sub2.table_name = '" . $tableName . "') as description " . " FROM " . $tableName . " subject" . " LEFT JOIN " . $tableName . "_bodies body on subject.id = body.id" . " WHERE subject.sid = 0" . " AND subject.id = " . $value2 . " ORDER by subject.id desc" . " limit 0,1";
                //echo "Debug:". $sql;
                if ($env["userIsLoggedIn"] == 1) {
                    $sql = "SELECT " . "subject.id, subject.sid ,subject.isPHPCode, subject.subject, subject.datestamp, subject.email," . " subject.author, subject.host, body.body, " . " (select max(sub.id) FROM " . $tableName . " as sub) as maxcount ," . " (select name FROM content_forum sub2 WHERE sub2.table_name = '" . $tableName . "') as description " . " FROM " . $tableName . " subject" . " LEFT JOIN " . $tableName . "_bodies body on subject.id = body.id" . " WHERE subject.sid <= " . $env["user"]["user_level"] . "" . " AND subject.id = " . $value2 . " ORDER by subject.id desc" . " limit 0,1";
                }
                $rs = $this->db->GetAll("" . $sql);
            }
            // define additional parameters
            $rs["page"]["count"] = $pagecount;
            $rs["page"]["max"] = isset($rs[0]["maxcount"]) ? $rs[0]["maxcount"] : "1";
            $rs["page"]["name"] = $tableName;
            $rs["page"]["start"] = $start;
            $rs["page"]["value1"] = $value1;
            $rs["page"]["value2"] = $value2;
            $rs["page"]["date"] = isset($rs[0]) ? $rs[0]["datestamp"] : "";
            $rs["page"]["isPHPCode"] = isset($rs[0]["isPHPCode"]) && $rs[0]["isPHPCode"] == 1 ? true : false;
            if (isset($rs[0]["sid"])) {
                $rs["page"]["sid"] = $rs[0]["sid"];
            } else {
                $rs["page"]["sid"] = "3";
            }
            if (isset($rs[0]["description"])) {
                $rs["page"]["description"] = $rs[0]["description"];
            } else {
                $rs["page"]["description"] = "503 or 404 - Access denied.";
            }
        } catch (ADODB_Exception $ex) {
            $this->printExeption($ex);
        }
        //print_r($rs);
        return $rs;
    }

    public function readJSON($env, $index, $v1, $v2, $order = "desc", $isRequest = true)
    {
        $result = "";
        $value1 = 1;
        $value2 = 1;
        $start = 0;
        $pagecount = 1;
        $tableName = "neues";
        $rs = null;
        try {
            if ($isRequest) {
                if (isset($v1) && !empty($v1)) {
                    // $value1 = preg_replace('@/((\&)?PHPSESSID=[a-zA-Z0-9]+(\&)?)/i@', "", $v1);
                    $value1 = preg_replace('@/((\&)?PHPSESSID=[a-zA-Z0-9]+(\&)?)/i@', "", $v1);
                }
                if (isset($v2) && !empty($v2)) {
                    $value2 = preg_replace('@/((\&)?PHPSESSID=[a-zA-Z0-9]+(\&)?)/i@', "", $v2);
                }
            }

            $tableName = $this->getTableNameFromNumber($index, $value1);
            // echo "<hr>".$tableName;
            if (!empty($tableName)) {
                $pagecount = $this->getCount($tableName);
                // /*
                if ($value2 > $pagecount) {
                    // $value2 = $pagecount;
                    $start = ($pagecount * $this->env["numofentries"]) - $this->env["numofentries"];
                }
                if ($value2 < 0) {
                    $value2 = 1;
                    $start = 0;
                }

                // $sql = "SELECT " . "subject.id , subject.isPHPCode, subject.subject, subject.datestamp, subject.email, subject.author, subject.host, body.body " . " FROM " . $tableName . " subject" . " LEFT JOIN " . $tableName . "_bodies body on subject.id = body.id" . " WHERE subject.sid = 0" . " AND subject.id = " . $value2 . " ORDER by subject.id desc" . " limit 0,1";
                // if ($this->env ["userIsLoggedIn"] == 1 && $this->env ["user"] ["user_level"] >= $value ["sid"]) {
                // $sql = "SELECT " . "subject.id , subject.isPHPCode, subject.subject, body.body " . " FROM " . $tableName . " subject" . " LEFT JOIN " . $tableName . "_bodies body on subject.id = body.id" . " WHERE subject.sid <= " . $this->env ["user"] ["user_level"] . "" . " AND subject.id = " . $value2 . " ORDER by subject.id desc" . " limit 0,1";
                // }
                $sql = "SELECT " . "subject.id, subject.sid , subject.isPHPCode, subject.subject, subject.datestamp, subject.email," . " subject.author, subject.host, body.body " . " ,(select max(sub.id) FROM " . $tableName . " as sub) as maxcount " . " ,(select name FROM content_forum sub2 WHERE sub2.table_name = '" . $tableName . "') as description " . " FROM " . $tableName . " subject" . " LEFT JOIN " . $tableName . "_bodies body on subject.id = body.id" . " WHERE subject.sid = 0" . " AND subject.id = " . $value2 . " ORDER by subject.id " . $order . "" . " limit 0,1";
                if ($env["userIsLoggedIn"] == 1) {
                    $sql = "SELECT " . "subject.id, subject.sid ,subject.isPHPCode, subject.subject, subject.datestamp, subject.email," . " subject.author, subject.host, body.body, " . " (select max(sub.id) FROM " . $tableName . " as sub) as maxcount ," . " (select name FROM content_forum sub2 WHERE sub2.table_name = '" . $tableName . "') as description " . " FROM " . $tableName . " subject" . " LEFT JOIN " . $tableName . "_bodies body on subject.id = body.id" . " WHERE subject.sid <= " . $env["user"]["user_level"] . "" . " AND subject.id = " . $value2 . " ORDER by subject.id " . $order . "" . " limit 0,1";
                }
                $rs = $this->db->GetAll("" . $sql);
            }
            // define additional parameters
            $rs["page"]["count"] = $pagecount;
            $rs["page"]["name"] = $tableName;
            $rs["page"]["start"] = $start;
            $rs["page"]["value1"] = $value1;
            $rs["page"]["value2"] = $value2;
            if (isset($rs[0]["sid"])) {
                $rs["page"]["sid"] = $rs[0]["sid"];
            } else {
                $rs["page"]["sid"] = "3";
            }
            if (isset($rs[0]["description"])) {
                $rs["page"]["description"] = $rs[0]["description"];
            } else {
                $rs["page"]["description"] = "503 or 404 - Access denied.";
            }
        } catch (ADODB_Exception $ex) {
            $this->printExeption($ex);
        }
        // print_r($rs);
        return $rs;
    }

    /**
     * Enter description here .
     *
     *
     *
     * ..
     */
    public function getDate($env, $doc, $index, $v1, $isRequest = true)
    {
        $result = "";
        $value1 = 1;
        $value2 = 1;
        $start = 0;
        $pagecount = 1;
        $tableName = "neues";
        $tableNumber = 1;
        $rs = null;
        try {
            if ($isRequest) {
                if (isset($v1) && !empty($v1)) {
                    // if (is_numeric($v1))
                    // {
                    $value1 = preg_replace('@/((\&)?PHPSESSID=[a-zA-Z0-9]+(\&)?)/i@', "", $v1);
                    // }
                }
            }

            $tableName = $this->getTableNameFromNumber($index, $tableNumber);
            $subsql = "(SELECT count(a.id) FROM " . $tableName . " a" . " LEFT JOIN " . $tableName . "_bodies b ON a.id = b.id" . " WHERE" . " (a.datestamp BETWEEN '" . date("Y-m-d", $value1) . " 00:00:00' AND '" . date("Y-m-d", $value1) . " 23:59:59' )" . " ORDER BY a.id DESC LIMIT 0,30) as maxcount";
            $sql = "SELECT a.id ,a.subject, a.datestamp, b.body," . $subsql . " FROM " . $tableName . " a" . " LEFT JOIN " . $tableName . "_bodies b ON a.id = b.id" . " WHERE" . " (a.datestamp BETWEEN '" . date("Y-m-d", $value1) . " 00:00:01' AND '" . date("Y-m-d", $value1) . " 23:59:59' )" . " ORDER BY a.id DESC LIMIT 0,30";
            // echo $sql;
            $rs = $this->db->GetAll("" . $sql);
            // print_r($rs);
            // define additional parameters
            $rs["page"]["count"] = $rs[0]["maxcount"];
            $rs["page"]["name"] = $tableName;
            $rs["page"]["id"] = $tableNumber;
            $rs["page"]["start"] = $start;
            $rs["page"]["value1"] = $value1;
            $rs["page"]["value2"] = $value2;
        } catch (ADODB_Exception $ex) {
            $this->printExeption($ex);
        }
        // print_r($rs);
        return $rs;
    }

    public function getLinkedDaysData($value1, $value2)
    {
        $rs = null;
        try {
            $sql = "SELECT UNIX_TIMESTAMP(DATE_FORMAT(datestamp, '%Y-%m-%d 00:00:00')) as date FROM neues" . " WHERE" . " (datestamp BETWEEN '" . date("Y-m-d", $value1) . " 00:00:00' AND '" . date("Y-m-d", $value2) . " 23:59:59' )" .
            // ." datestamp < NOW() OR DATE_ADD(NOW(), INTERVAL 30 HOUR) > NOW()"
            " GROUP by datestamp LIMIT 0,100"; // This might be deleted !!!
            $rs = $this->db->GetAll("" . $sql);
            $nrs = array();
            $nrs["title"] = "Linked Days";
            // $nrs[0][0] = $this->env["firstDayInMonth"];
            // $nrs[0] = 0;
            $nrs["Error"] = "";
            foreach ($rs as $key => $value) {
                $nrs[$value[0]] = $value[0];
            }
        } catch (ADODB_Exception $ex) {
            $this->printExeption($ex);
        }
        return $nrs;
    }

    public function getLastContentData($start, $tableName)
    {
        $rs = null;
        try {
            $sql = "SELECT " . "subject.id , subject.sid, subject.isPHPCode, subject.subject, body.body " . " ,(select max(sub.id) FROM " . $tableName . " as sub) as max " . " ,(select name FROM content_forum sub2 WHERE sub2.table_name = '" . $tableName . "') as description " . " FROM " . $tableName . " subject" . " LEFT JOIN " . $tableName . "_bodies body on subject.id = body.id" . " WHERE subject.sid = 0" . " AND subject.id = (SELECT max(sub1.id) FROM " . $tableName . " sub1) " . " ORDER by subject.id asc" . " LIMIT " . $start . "," . $this->env["numofentries"] . "";
            // echo $sql;
            $rs = $this->db->GetAll("" . $sql);
        } catch (ADODB_Exception $ex) {
            $this->printExeption($ex);
        }
        return $rs;
    }

    /**
     *
     * Enter description here ...
     *
     * @param unknown_type $v1
     * @param unknown_type $v2
     * @param unknown_type $isRequest
     */
    public function getLastContent($index, $v1, $v2, $isRequest = true)
    {
        $value1 = 1;
        $value2 = 1;
        $start = 0;
        $tableName = "neues";
        $rs = null;
        try {
            if (!empty($v1)) {
                $value1 = $v1;
            }
            if (isset($v1) && !empty($v1)) {
                $value1 = $this->checkForumNumber($v1);
            }
            $start = ($this->env["numofentries"] * $value2 - $this->env["numofentries"]);
            $end = ($this->env["numofentries"] * $value2);
            $pagecount = 0;
            if (isset($value1) && !empty($value1)) {
                $tableName = $this->getTableNameFromNumber($index, $value1);
                $pagecount = $this->getCount($tableName);
                // /*
                if ($value2 > $pagecount) {
                    $value2 = $pagecount;
                    $start = ($pagecount * $this->env["numofentries"]) - $this->env["numofentries"];
                }
                if ($value2 < 0) {
                    $value2 = 1;
                    $start = 0;
                }
            }
            // EOF
            $rs = $this->getLastContentData($start, $tableName);
            // }
            $rs["page"]["count"] = $pagecount;
            $rs["page"]["name"] = $tableName;
            $rs["page"]["start"] = $start;
            $rs["page"]["value1"] = $value1;
            $rs["page"]["value2"] = $value2;
        } catch (ADODB_Exception $ex) {
            $this->printExeption($ex);
        }
        // print_r($rs);
        return $rs;
    }

    public function getSearchContentData($env,$q, $start, $tableName, $sort = "asc")
    {
        $rs = null;
        try {
            $sql = "SELECT " . "subject.id ,subject.subject, subject.isPHPCode, body.body " . " FROM " . $tableName . " subject" . " LEFT JOIN " . $tableName . "_bodies body on subject.id = body.id" . " WHERE subject.sid = 0" . " AND subject.subject like '%" . $q . "%' " . " OR body.body like '%" . $q . "%' " . " ORDER by subject.id " . $sort . " " . " LIMIT " . $start . "," . $this->env["numofentries"] . "";
            if ($env["userIsLoggedIn"] == 1) {
                //extend role of user
                $sql = "SELECT " . "subject.id ,subject.subject, subject.isPHPCode, body.body " . " FROM " . $tableName . " subject" . " LEFT JOIN " . $tableName . "_bodies body on subject.id = body.id" . " WHERE subject.sid <= 1" . " AND subject.subject like '%" . $q . "%' " . " OR body.body like '%" . $q . "%' " . " ORDER by subject.id " . $sort . " " . " LIMIT " . $start . "," . $this->env["numofentries"] . "";
            }
            // echo $sql;
            $rs = $this->db->GetAll("" . $sql);
        } catch (ADODB_Exception $ex) {
            $this->printExeption($ex);
        }
        return $rs;
    }

    /**
     *
     * Enter description here ...
     *
     * @param unknown_type $catid
     * @param unknown_type $page
     * @param unknown_type $isRequest
     */
    public function getSearch($env, $index, $query, $catid, $page, $isSort = "asc", $isRequest = true)
    {
        $tempValue = 1;
        $value2 = 1;
        $start = 0;
        $tableName = "neues";
        $rs = null;
        try {
            if (!empty($catid)) {
                $tempValue = $catid;
            }
            if (!empty($page)) {
                $value2 = $page;
            }
            if (isset($catid) && !empty($catid)) {
                $tempValue = $this->checkForumNumber($catid);
            }
            $start = ($this->env["numofentries"] * $value2 - $this->env["numofentries"]);
            $end = ($this->env["numofentries"] * $value2);
            $pagecount = 0;
            // echo "Debug:". $start.$end."#".$value1."<hr>";
            if (isset($tempValue) && !empty($tempValue)) {
                if (is_numeric($tempValue)) {
                    $tableName = $this->getTableNameFromNumber($index, $tempValue);
                }
                $pagecount = $this->getSearchCount($query, $tableName);
                // /*
                if ($value2 > $pagecount) {
                    $value2 = $pagecount;
                    $start = ($pagecount * $this->env["numofentries"]) - $this->env["numofentries"];
                }
                if ($value2 < 0) {
                    $value2 = 1;
                    $start = 0;
                }
            }
            // }
            // if ($value2 <= $pagecount && $value2 > 0)
            // {
            // return HTML::getBox(HTML::getList($value1, $value2,$start, $pagecount ,$this->env, $this->getList($start, $tableName)));
            $rs = $this->getSearchContentData($env, $query, $start, $tableName, $isSort);
            // }
            $rs["page"]["count"] = $pagecount;
            $rs["page"]["name"] = $tableName;
            $rs["page"]["start"] = $start;
            $rs["page"]["value1"] = $tempValue;
            $rs["page"]["value2"] = $value2;
        } catch (ADODB_Exception $ex) {
            $this->printExeption($ex);
        }
        // print_r($rs);
        return $rs;
    }

    /**
     *
     * @param array $env
     * @param string $q
     * @param int $start
     * @param int $value2
     * @return array
     */
    public function getSearchContentLinksData($env, $q, $start, $value2)
    {
        $rs = null;
        $tableName = "links";
        try {
            $start = $start;
            $end = (($start + 1) * $env["numofentries"]);

            $this->db->Connect($env["dbhost"], $env["dbuser"], $env["dbpassword"], $env["cntdb"]); // change db
            $subsql = "(SELECT count(*) FROM " . $tableName . " sl WHERE sl.title like '%" . $q . "%' OR sl.url like '%" . $q . "%' OR sl.description like '%" . $q . "%' OR sl.fulltxt like '%" . $q . "%')";
            $sql = "SELECT " . $subsql . " as count, l.* FROM " . $tableName . " l WHERE l.title like '%" . $q . "%' OR l.url like '%" . $q . "%' OR l.description like '%" . $q . "%' OR l.fulltxt like '%" . $q . "%'  LIMIT " . $start . ", " . $end . "";
            // echo $sql."\n";
            $rs["content"] = $this->db->GetAll("" . $sql);
            $rs["page"]["size"] = count($rs["content"]);
            $this->db->Connect($env["dbhost"], $env["dbuser"], $env["dbpassword"], $env["defaultdb"]);
        } catch (ADODB_Exception $ex) {
            $this->printExeption($ex);
        }
        return $rs;
    }

    /**
     *
     * @param unknown $env
     * @param unknown $dao
     */
    public function getTagsData()
    {
        $rs = null;
        try {
            $sql = "SELECT * FROM (SELECT tag as 'query',quantity as quantity  FROM query_log q GROUP BY query ORDER BY quantity desc) s ORDER BY quantity  desc LIMIT 0,50";
            $rs = $this->db->GetAll("" . $sql);
        } catch (ADODB_Exception $ex) {
            $this->printExeption($ex);
        }
        return $rs;
    }

    public function getFullCalendar($cdate)
    {
        $rs = null;
        // Debug($cdate);
        try {
            // Debug("Test");
            // Debug("" . $cdate);
            // $cdate = (isset($cdate)) ? $cdate : "2020-01-01 12:00:00";
            $dp = explode(" ", $cdate)[0];
            // print_r($dp);
            // Debug("" . $cdate);
            //$sql = "SELECT id, title as title, startdate, enddate, allDay, url FROM calendarviewfull order by startdate desc, id desc limit 10000";
            //$start = "'". date("Y-m-d", $cdate) . " 00:00:00'";
            // $stdate = new DateTime($send);
            // $start = $stdate->format('Y-m-1');
            // // $start = $cdate;//"'". date("Y-m-d", $cdate) . " 00:00:00'";
            // // $end = "'".date("Y-m-d", $cdate) . " 23:59:59'";
            $s_date = date_create("" . $dp);            
			$start = date_format($s_date, '2000-01-01 0:0:0');
			// Debug("".$start);

            $edate = date_create("" . $dp);
            $end = date_format($edate, 'Y-m-31 23:59:59');
            // Debug("".$end);
            // Debug( $start ."-".$end);
            //Debug( $end);

            $sql = "SELECT id, title as title, startdate, enddate, allDay, url FROM calendarviewfull ";
            //$sql .= "WHERE (startdate BETWEEN '" . date("Y-m-d", "".$cdate) . " 00:00:00' AND '" . date("Y-m-d", "".$cdate) . " 23:59:59' )";
            $sql .= "WHERE (startdate BETWEEN '" . $start . "' AND '" . $end . "' )";
            $sql .= " order by startdate desc, id desc limit 9999";
            // echo $sql;
            $rs = $this->db->GetAll("" . $sql);
            //$rs["_sql"] = $sql;
            // print_r($rs);
        } catch (ADODB_Exception $ex) {
            $this->printExeption($ex);
        }
        return $rs;
    }

    public function insertArrayOfSql($db, $value)
    {
        try {
            foreach ($value as $key => $value) {
                // echo $key;
                $sql = "INSERT INTO `lc`.`filme` " . "(`sid`, `datestamp`, `thread`, `parent`, `author`, `subject`, `email`, `host`, `email_reply`, `approved`, `modifystamp`, `userid`, `closed`) " . " VALUES " . "('0', '0000-00-00 00:00:01', '0', '0', '', '" . $value . "', '', '', 'N', 'N', '0', '0', '0');";
                self::doInsertTransact($index, $db, $dbname, $table, $subject, $body, $sid, $isPHPCode);
            }
        } catch (ADODB_Exception $ex) {
            $this->printExeption($ex);
        }
    }

    /**
     *
     * @param unknown $env
     * @param unknown $db
     */
    public function insertUser($env, $db)
    {
        try {
            self::doInsertUserTransact($index, $db, $dbname, $table, $subject, $body, $sid, $isPHPCode);
        } catch (ADODB_Exception $ex) {
            $this->printExeption($ex);
        }
    }

    /**
     *
     * @param unknown $index
     * @param unknown $db
     * @param unknown $dbname
     * @param unknown $table
     * @param unknown $subject
     * @param unknown $body
     * @param unknown $sid
     * @param unknown $isPHPCode
     */
    public function insertSingle($index, $db, $dbname, $table, $date, $subject, $body, $sid, $isPHPCode)
    {
        $result = 0;
        try {
            if (isset($table) || !empty($table) || $table == 0) {
                // check the db table
                $tableName = $this->getTableNameFromNumber($index, $table);
                // begin transaction
                $result = self::doInsertTransact($index, $db, $dbname, $tableName, $date, $subject, $body, $sid, $isPHPCode);
            } else {
                echo "Fatal Exception:" . $table . " not found.";
            }
        } catch (ADODB_Exception $ex) {
            $this->printExeption($ex);
        }
        return $result;
    }

    /**
     *
     * @param unknown $index
     * @param unknown $env
     * @param unknown $db
     * @param unknown $dbname
     * @param unknown $table
     * @param unknown $subject
     * @param unknown $body
     * @param unknown $sid
     * @param unknown $isPHPCode
     */
    //$dao->updateSingle($doc["CacheIndex"], $db, $env["defaultdb"], "" . $value1, "" . $value2, $date, $subject, $body, $protLevel, $isPHPCode);
    public function updateSingle($index, $db, $dbname, $table, $row, $date, $subject, $body, $sid, $isPHPCode)
    {
        try {
            if (isset($table) && !empty($table)) {
                $table = $this->getTableNameFromNumber($index, $table);
            }
            // Start Update Transaction
            $this->doUpdateTransact($index, $db, $dbname, $table, $row, $date, $subject, $body, $sid, $isPHPCode);
        } catch (ADODB_Exception $ex) {
            $this->printExeption($ex);
        }
    }

    /**
     *
     * @param array $index
     * @param array $env
     * @param string $db
     * @param string $dbname
     * @param string $table
     * @param string $subject
     * @param string $body
     * @param int $sid
     * @param int $isPHPCode
     */
    public function doUpdateTransact($index, $db, $dbname, $table, $row, $date, $subject, $body, $sid, $isPHPCode)
    {
        try {
            $subject = utf8_encode($subject);
            $body = utf8_encode($body);
            // $body = str_replace("'", "&acute;", str_replace("'", "�", $body));
            $subject = str_replace("'", "&acute;", str_replace("'", "�", $subject));

            $body = $db->qStr($body);
            $body = str_replace("'", "\"", $body);
            $end = (strlen($body) - 2);
            $body = substr($body, 1, $end);

            $sid = !empty($sid) ? $sid : 0;
            $ip = !empty($this->env["ip"]) ? $this->env["ip"] : '127.0.0.1';

            //$ttimestamp = strtotime($date);
            //            $date = date("Y-m-d H:i:s", $ttimestamp);
            //            echo $timestamp;
            // SQL
            $sql = "UPDATE `" . $dbname . "`.`" . $table . "` SET `subject` = '" . $subject . "', `datestamp` = '" . $date . "',`author` = '" . (!empty($this->env["user"]["email"]) ? $this->env["user"]["email"] : "webmaster@letztechance.org") . "',`sid` = '" . $sid . "',`host` = '" . $ip . "',`closed` = '1' WHERE `" . $table . "`.`id` =" . $row . ";";
            // SQL
            $sql2 = "UPDATE `" . $dbname . "`.`" . $table . "_bodies` SET `body` = '" . $body . "', `id` =" . $row . "  WHERE `" . $table . "_bodies`.`id` =" . $row . ";";
            $this->db->StartTrans();
            $this->db->Execute($sql);
            $this->db->StartTrans(); // ignored
            // if (!CheckRecords()) $this->db->FailTrans();

            $this->db->Execute($sql2);
            $this->db->StartTrans();
            $this->db->CompleteTrans(); // ignored
            // Debug($sql . "" . $sql2);
        } catch (ADODB_Exception $ex) {
            $this->printExeption($ex);
        }
    }

    /**
     *
     * @param unknown $env
     * @param unknown $db
     */
    public function doInsertUserTransact($env, $db)
    {
        try {
            // SQL 1
            $sql = "INSERT INTO `users` (`isAdmin`, `u_id`, `ipaddress`, `user`, `pass`, `email`, `first_name`, `last_name`, `phone`, `fax`, `alt_phone`, `reg_date`, `last_active`, `user_level`, `notes`, `admin_notes`, `hash`, `deleted`, `confirmed`, `locked`) VALUES
			( 0, password('" . ($this->env["req"]["user"]) . "'), NULL, '" . $this->env["req"]["user"] . "', password('" . $this->env["req"]["password"] . "'), '" . $this->env["req"]["email"] . "', NULL, NULL, NULL, NULL, NULL, '" . date("d.m.Y H:i:s") . "', '" . date("d.m.Y H:i:s") . "', 0, NULL, NULL, '1223', 0, 0, 0);";

            // SQL 1
            echo $sql;
            $this->db->StartTrans();
            $this->db->Execute($sql);
            $this->db->StartTrans(); // ignored
            // if (!CheckRecords()) $this->db->FailTrans();
            echo "<br />";
        } catch (ADODB_Exception $ex) {
            $this->printExeption($ex);
        }
    }

    public function doInsertTransact($index, $db, $dbname, $table, $date, $subject, $body, $sid, $isPHPCode = 0)
    {
        try {
            $subject = str_replace("'", "�", $subject);
            $subject = str_replace("'", "&acute;", str_replace("'", "&acute;", $subject));
            // $body = utf8_encode($body);
            // $body = str_replace("'", "&acute;", str_replace("'", "�", $body));
            $body = $db->qStr($body);
            $body = str_replace("'", "\"", $body);
            $end = (strlen($body) - 2);
            $body = substr($body, 1, $end);
            // echo $body;
            // SQL 1
            $sql = "INSERT INTO `" . $dbname . "`.`" . $table . "` " . "(`sid`, `datestamp`, `thread`, `parent`, `author`, `subject`, `email`, `host`, `email_reply`, `approved`, `modifystamp`, `userid`, `closed`,`isPHPCode`) " . " VALUES " . "('" . $sid . "', '" . $date . "', '0', '0', '', '" . $subject . "', '', '', 'N', 'N', '0', '0', '0','" . $isPHPCode . "');";
            //             Debug($sql);
            // SQL 2
            $sql2 = "INSERT INTO `" . $dbname . "`.`" . $table . "_bodies` (`body`, `thread`) VALUES ('" . $body . "', '" . $subject . "');";
            //EOF SQL 2
            $this->db->beginTrans();

            $this->db->StartTrans();
            $ok = $this->db->Execute($sql);
            if ($ok) {
                /*
                * The previous execution succeeded, do some more
                */ 
                $ok = $this->db->execute($sql2);
             } else {
                /*
                * Branch, do some other work, then return
                */
             }
             if (!$ok) {
                /*
                * Test the last insertion, if not successful roll 
                * back the entire transaction scope
                */
                $this->db->rollbackTrans();
            } else {
                /*
                * Go ahead and commit
                */ 
                $this->db->commitTrans();
            }
            // $this->db->StartTrans(); // ignored
            // if (!CheckRecords()) $this->db->FailTrans();
            // echo "<br />";
            // echo $sql2;
            // $this->db->Execute($sql2);
            // $this->db->StartTrans();
            // $this->db->CompleteTrans(); // ignored
            //            Debug($sql);
        } catch (ADODB_Exception $ex) {
            $this->printExeption($ex);
        }
        return $this->db->Affected_Rows();
    }

    /**
     *
     * @param unknown $index
     * @param unknown $db
     * @param unknown $dbname
     * @param unknown $table
     * @param unknown $subject
     * @param unknown $body
     * @param unknown $sid
     * @param unknown $isPHPCode
     *            $index, $db, $dbname, $table, $value1, $value2
     */
    public function deleteSingle($index, $db, $dbname, $value1, $value2)
    {
        $result = 0;
        $table = "neues";
        try {
            if (isset($table) && !empty($table)) {
                $table = $this->getTableNameFromNumber($index, $value1);
            }
            // $index, $db, $dbname, $table, $value1, $value2
            $result = self::doDeleteTransact($index, $db, $dbname, $table, $value1, $value2);
        } catch (ADODB_Exception $ex) {
            $this->printExeption($ex);
        }
        return $result;
    }

    /**
     *
     * @param unknown $index
     * @param unknown $db
     * @param unknown $dbname
     * @param unknown $table
     * @param unknown $subject
     * @param unknown $body
     * @param unknown $sid
     * @param unknown $isPHPCode
     */
    public function doDeleteTransact($index, $db, $dbname, $table, $value1, $value2)
    {
        try {
            // SQL 2
            $sql = "DELETE FROM `" . $dbname . "`.`" . $table . "` WHERE `" . $table . "`.`id` =" . $value2;
            // SQL 2
            $sql2 = "DELETE FROM `" . $dbname . "`.`" . $table . "_bodies` WHERE `id` = " . $value2 . "";
            // SQL 2
            // echo $sql;
            $this->db->StartTrans();
            $this->db->Execute($sql);
            $this->db->StartTrans(); // ignored
            // if (!CheckRecords()) $this->db->FailTrans();
            $this->db->Execute($sql2);
            $this->db->StartTrans();
            $this->db->CompleteTrans(); // ignored
        } catch (ADODB_Exception $ex) {
            $this->printExeption($ex);
        }
        return $this->db->Affected_Rows();
    }

    public function doInsertDate($date, $subject)
    {
        try {
            $subject = str_replace("'", "��", $subject);
            $subject = str_replace("'", "&acute;", str_replace("'", "&acute;", $subject));
            $sql = "INSERT INTO calendar(`title`, `startdate`, `enddate`, `allDay`) VALUES('$subject','$date','$date','false')";
            $this->db->StartTrans();
            $this->db->Execute($sql);
            $this->db->StartTrans(); // ignored
        } catch (ADODB_Exception $ex) {
            $this->printExeption($ex);
        }
        return $this->db->Affected_Rows();
    }
}
