const APPCFG = "application.config.json";
// const path = window.nodeRequire('path');
// const jQuery = window._PAGE_.jQuery;
// const fs = window.nodeRequire('fs');
// const cfg = window.nodeRequire(path.join(__dirname, 'assets', 'js', 'config.json'));
// const model = window.nodeRequire(path.join(__dirname, 'app', 'model.js'));
// const cpath = path.join(__dirname);
// const dbPath = path.join(__dirname, '..', 'lc.db'); // remote.getGlobal('sharedObj').dbPath; // remote.getGlobal('sharedObj').dbPath;
// const gelectron = window.nodeRequire('electron');
// const shell = gelectron.shell;
const OPEN_LINK = "https://www.letztechance.org/openlink?";
// -var remote = window.nodeRequire('electron').remote;
// const rootLib = window.nodeRequire('app-root-path');
// const appRoot = path.dirname(('' + rootLib).replace("app.asar", ""));
// console.log('rootLib:' + rootLib);
var dialogProperties = {
    // appendTo: "#dialog",
    show: "puff",
    hide: "explode",
    resizable: true,
    closeOnEscape: true,
    minWidth: 150,
    minHeight: 150,
    // position: { my: "left top", of: "left top" },
    height: "auto",
    width: "auto"
};

$.urlParam = function(name) {
    var results = new RegExp('[\?&]' + name + '=([^&#]*)').exec(window.location.href);
    if (results == null) {
        return null;
    }
    return decodeURI(results[1]) || 0;
}

function print(t, isAppend) {
    if (!isAppend) {
        out.html(t);
    } else {
        out.append(t);
    }
}

function msg(t) {
    return t;
}


function createDatabase() {
    var table = $("#newdb").val();
    alert('Create Database:' + table);
    var res = model.GetQuery(dbPath, 'CREATE TABLE ' + table + ' ( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT(255,0) NOT NULL, "first_name" TEXT(255,0) NULL, "description" TEXT(255,0) NULL, "zipcode" TEXT(255,0) NULL, "city" TEXT(255,0) NULL,	 "street" TEXT(255,0) NULL,	 "url" TEXT NULL);');
    document.getElementById("newdbcnt").innerHTML = JSON.stringify(res) + " done.";
    res = model.GetQuery(dbPath, 'INSERT INTO systables (name,first_name, description,url)VALUES(\'' + table + '\',\'menu.bat\',\'menu.bat\',\'menu.bat\');');
    document.getElementById("newdbcnt").innerHTML += JSON.stringify(res) + " done.";
}

function readItem(table, id) {
    return model.GetQuery(dbPath, 'SELECT * FROM ' + table + ' WHERE person_id=' + id + ';');
}

function addItem() {
    var res;
    var table = $.urlParam('db');
    var name = $("#name").val();
    var first_name = $("#first_name").val();
    var last_name = $("#last_name").val();
    var zipcode = $("#zipcode").val();
    var description = $("#description").val();
    var url = $("#url").val();

    res = model.GetQuery(dbPath, 'INSERT INTO ' + table +
        ' (name,first_name, zipcode,description,url)VALUES' +
        '(\'' + name + '\',\'' + first_name + '\',\'' + zipcode + '\',\'' + description + '\',\'' + url + '\');' +
        '');
    document.getElementById("out").innerHTML += JSON.stringify(res) + " done.";
}

function addItem2() {
    var res;
    var table = $.urlParam('db');
    var name = $("#name").val();
    var first_name = $("#first_name").val();
    var last_name = $("#last_name").val();
    var zipcode = $("#zipcode").val();
    var description = $("#description").val();
    var url = $("#url").val();
    $("#conformdialog").attr("title", "Add");
    $("#conformdialog").dialog({
        // appendTo: "#dialog",
        show: "puff",
        hide: "explode",
        resizable: true,
        closeOnEscape: false,
        minWidth: 150,
        minHeight: 150,
        // position: { my: "left top", of: "left top" },
        height: "auto",
        width: "auto",
        modal: true,
        buttons: {
            "Yes": function() {
                res = model.GetQuery(dbPath, 'INSERT INTO ' + table +
                    ' (name,first_name, zipcode,description,url)VALUES' +
                    '(\'' + name + '\',\'' + first_name + '\',\'' + zipcode + '\',\'' + description + '\',\'' + url + '\');' +
                    '');
                document.getElementById("newdbcnt").innerHTML += JSON.stringify(res) + " done.";
                $(this).dialog("close");
            },
            Cancel: function() {
                document.getElementById("newdbcnt").innerHTML += JSON.stringify(res) + "Not done.";
                $(this).dialog("close");
            }
        }
    });
}

function updateItem() {
    var table = $.urlParam('db');
    var keyValue = {
        "columns": ["person_id", "name", "first_name", "zipcode", "city", "street", "description", "url"],
        "values": [$.urlParam('id'), $("#name").val(), $("#first_#name").val(), $("#zipcode").val(), $("#city").val(), $("#street").val(), $("#description").val(), $("#url").val()],
    };
    var columns = keyValue.columns;
    var values = keyValue.values;
    model.saveData(dbPath, table, columns, values, function() {
        model.getQuery(dbPath, table, 'SELECT * FROM `' + table + '` ORDER BY `person_id` ASC', '#app_cnt');
    });

    document.getElementById("newdbcnt").innerHTML += JSON.stringify(keyValue) + " done.";
}


function deleteItem(id) {
    var table = $.urlParam('db');
    var query = 'SELECT * FROM `' + table + '` ORDER BY `person_id` ASC';
    document.getElementById("newdbcnt").innerHTML = 'Realy delete:' + id + " from " + table;
    // var res = model.GetQuery(dbPath, 'DELETE from \'systables\' WHERE person_id = \'' + id + '\';');
    var res = model.deletePerson(dbPath, table, id, function() {
        model.getQuery(dbPath, table, query, '#app_cnt');
    });
    document.getElementById("newdbcnt").innerHTML = JSON.stringify(res) + " done.";
    location.reload();
}


function goToTable() {
    var t = $("#database").val();
    window.location = 'list.html?db=' + t;
}

function goToItem() {
    var t = $("#database").val();
    var id = $("#database").val();
    window.location = 'edit.html?db=' + t + '&id=' + id;
}

function openPage(s) {
    window.location = s;
}

function openPage(s) {
    window.open(s);
}

function openAddTable() {
    var t = $.urlParam('db');
    var url = 'edit.html?db=' + t;
    // openDialog("#dialog", url + " #addPage", t, { minWidth: 250, minHeight: 150, width: 400 });
    // getOpenDialog('#dialog', url, 'Install', { minWidth: 250, minHeight: 150, width: 400 });
    getExtFile(url, 'blank', { minWidth: 250, minHeight: 150, width: 400 });
}

function openAddPage() {
    var t = $.urlParam('db');
    var url = 'edit.html?db=' + t;
    window.open(url, '_blank', 'top=500,left=200,frame=true,nodeIntegration=yes, contextIsolation: false,enableRemoteModule: true');
}

function openPage(url, target, props) {
    window.open(url, target, props);
}

// function getAppConfig(appConfigFileName) {
//     const fs = window.nodeRequire('fs');
//     let rawdata = fs.readFileSync(appConfigFileName);
//     let appConfig = JSON.parse(rawdata);
//     console.log(appConfig);
//     return appConfig;
// }

// function setAppConfig(appConfigFileName, appConfig) {
//     let data = JSON.stringify(appConfig, null, 2);
//     fs.writeFileSync(appConfigFileName, data);
// }

// function getFileContent(id, url) {
//     document.getElementById(id).innerHTML = get_FileData(url);
//     $(id).load(f);
// }

function loadFileContent(id, url) {
    $(id).load(url);
}

function openBrowser(t) {
    require("shell").openExternal(t);
}

function openFile(t) {
    window.location = t;
}

function readFile(t, id) {
    var childProcess = window.nodeRequire("child_process");
    // This line initiates
    var script_process = childProcess.spawn(t, [], { env: process.env });
    // Echoes any command output
    script_process.stdout.on('data', function(data) {
        console.log('stdout: ' + data);
        document.getElementById(id).innerHTML = data;

    });
    // Error output
    script_process.stderr.on('data', function(data) {
        document.getElementById(id).innerHTML = 'stderr: ' + data;
        console.log('stderr: ' + data);

    });
    // Process exit
    script_process.on('close', function(code) {
        console.log('child process exited with code ' + code);
    });
}

function getLocalFile(url) {
    const electron = window.nodeRequire('electron');
    const BrowserWindow = electron.remote.BrowserWindow;
    //	const url = require('url');

    const childWindow = new BrowserWindow({
        width: 800,
        height: 600
    });
    console.log("file://" + __dirname + "/" + url);
    childWindow.loadURL("file://" + __dirname + "/" + url);
}

function readLocalFile(url) {
    const { readFileSync } = window.nodeRequire('fs')
    return readFileSync(url)
}

function execCMD(text, id) {
    const {
        exec
    } = window.nodeRequire('child_process');
    document.getElementById(id).innerHTML = "<div class=\"preload\"></div>";
    // alert('OUT:'+text.length);
    exec('' + text, (err, stdout, stderr) => {

        if (err) {
            console.error(err);
            document.getElementById(id).innerHTML = "" + JSON.stringify(err);
            document.getElementById(id).innerHTML = stdout;
            return;
        }
        console.log('OUT:' + stdout);
        console.log('id:' + id);
        document.getElementById(id).innerHTML = stdout;
        $("html, body").delay(100).animate({
            scrollTop: $('#' + id).offset().top
        }, 30);
    });
}

function evalCMD(text) {
    const {
        exec
    } = window.nodeRequire('child_process');
    // alert('OUT:'+text.length);
    exec('' + text, (err, stdout, stderr) => {

        if (err) {
            console.error(err);
            return;
        }
        // console.log('OUT:' + stdout);
        // document.getElementById(id).innerHTML = stdout;
        try {

            eval(stdout);
        } catch (error) {
            alert(error);
            console.error(error.stack);
        }
    });
}

function openBrowser(url) {
    openBrowser(url, false);
}

function openBrowser(url, isOpen) {
    if (isOpen) {
        window.nodeRequire("electron").shell.openExternal("https://www.letztechance.org/openlink?" + url);
    } else {
        window.nodeRequire("electron").shell.openExternal(url);
    }
}

function getExtFile(url, target, props) {
    // window.open(url, '_blank', 'top=500,left=200,frame=false,nodeIntegration=no');
    console.log('open:' + url);
    window.open(url, target, props);
}

function getFile(url, target, props) {
    const childWindow = window.open(url, '_blank');
    // childWindow.document.write('<h1>Hello</h1>');
    childWindow.document.write('<h1>Hello</h1>');
}

function get_FileData(url) {
    const { readFileSync } = window.nodeRequire('fs');
    return readFileSync(url);
}

function getLocalFile(url, props) {
    var pop = props !== undefined ? props : {
        width: 800,
        height: 600
    };
    const electron = window.nodeRequire('electron');
    const BrowserWindow = electron.remote.BrowserWindow;
    //	const url = require('url');
    const path = window.nodeRequire('path');
    const childWindow = new BrowserWindow(prop);
    console.log("file://" + __dirname + "/" + url);
    childWindow.loadURL("file://" + __dirname + "/" + url);

}

function loadFile(url, props) {
    var prop = props !== undefined ? props : {
        width: 800,
        height: 600
    };
    const electron = window.nodeRequire('electron');
    const BrowserWindow = electron.remote.BrowserWindow;
    const path = window.nodeRequire('path');
    const childWindow = new BrowserWindow(prop);
    childWindow.loadURL(url);
    // childWindow.readFile(get_FileData(path.join(url)));

}

function getTextWindow(t, props) {
    var prop = props !== undefined ? props : {
        width: 800,
        height: 600
    };
    const electron = window.nodeRequire('electron');
    const BrowserWindow = electron.remote.BrowserWindow;
    const path = window.nodeRequire('path');
    const childWindow = new BrowserWindow(prop);
    // childWindow.loadFileContent("file://" + __dirname + "/" + url);
    childWindow.loadURL('data:text/html;charset=utf-8,' + get_FileData(path.join(t)));
}

function openDialog(id, f, title, props) {
    var prop = props !== undefined ? prop : {
        // appendTo: "#dialog",
        show: "puff",
        hide: "explode",
        resizable: true,
        closeOnEscape: false,
        minWidth: 150,
        minHeight: 150,
        // position: { my: "left top", of: "left top" },
        height: "auto",
        width: "auto"
    };
    $(function() {
        $(id).attr("title", title);
        $(id).dialog(prop);
        console.log(f);
        $(id + "cnt").load(f);
    });
}

function getOpenDialog(id, f, title, props) {
    // $.noConflict();
    dialogProperties = props !== undefined ? props : dialogProperties;
    var res = get_FileData(path.join(f));
    $(id).attr("title", title);
    console.log(f);
    $(id + "cnt").html('Loading now...');
    $(id).append('Loading...');
    $(id).html('' + res);
    $(id).dialog(dialogProperties);
}

function getOpenDialogText(id, t, title, props) {
    // $.noConflict();
    dialogProperties = props !== undefined ? props : dialogProperties;
    $(id).attr("title", title);
    $(id + "cnt").html('Loading now...');
    $(id).append('Loading...');
    $(id).html('' + t);
    $(id).dialog(dialogProperties);
}


function conFirmDialog(id, title, props) {
    dialogProperties.buttons = {
        "Yes": function() {
            isValid = true;
            $(this).dialog("close");
        },
        Cancel: function() {
            $(this).dialog("close");
        }
    };
    dialogProperties = props !== undefined ? props : dialogProperties;
    var isValid = false;
    // $(function() {
    $(id).attr("title", title);
    // alert(title);
    $(id).dialog(dialogProperties);
    // $(id).dialog({
    //     appendTo: "#dialog",
    //     show: "puff",
    //     hide: "explode",
    //     resizable: true,
    //     closeOnEscape: false,
    //     minWidth: 150,
    //     minHeight: 150,
    //     // position: { my: "left top", of: "left top" },
    //     height: "auto",
    //     width: "auto",
    //     modal: true,
    //     buttons: {
    //         "Yes": function() {
    //             isValid = true;
    //             $(this).dialog("close");
    //         },
    //         Cancel: function() {
    //             $(this).dialog("close");
    //         }
    //     }
    // });
    // // });
    return isValid;
}

function getHeader(page) {
    var result = "<div id=\"cm-menu\">";
    result += "<nav id=\"top\" class=\"cm-navbar cm-navbar-primary lc-header\"> ";
    result += "<div class=\"cm-flex\"><a href=\"index.html\" class=\"cm-logo\"></a></div> ";
    result += "<div class=\"btn btn-primary md-menu-white lc-header\" data-toggle=\"cm-menu\" id=\"cm-menu\"></div> ";
    result += "</nav>";

    result += "<div id=\"ctop\"></div>";

    result += "<div id=\"cm-menu-content\"> ";
    result += "<div id=\"cm-menu-items-wrapper\"> ";
    result += "<div id=\"cm-menu-scroller\"> ";
    result += "<ul class=\"cm-menu-items\"> ";

    result += "<li class=\"cm_submenu\"><a href=\"index.html\">Application</a></li> ";
    result += "<li ><a href=\"index.html\">Application</a></li> ";
    // result += "<li ><a href=\"index.html\">Application</a></li> ";
    result += "</ul> ";
    result += "</div> ";
    result += "</div> ";
    result += "</div> ";
    result += "</div> ";
    result += " <header id=\"cm-header\"> ";
    result += " <nav class=\"cm-navbar cm-navbar-primary lc-header\"> ";
    result += "<div class=\"btn btn-primary md-menu-white hidden-md hidden-lg lc-header\" data-toggle=\"cm-menu\">";
    result += "</div> ";
    result += " <div class=\"cm-flex\"> ";
    result += " <div class=\"cm-breadcrumb-container\"> ";
    // result += " <ol class=\"breadcrumb\"> ";
    // result += " <li><a href=\"index.html\">" + msg('indexpage') + "</a></li> ";
    // result += " <li><a href=\"start.html\" class=\"active\">" + msg('startpage') + "</a></li> ";
    // result += " </ol> ";
    result += "</div> ";
    result += "<form id=\"cm-search\" action=\"" + page.host + "\" method=\"get\"> ";
    result += "<input type=\"search\" id=\"btnquery\" name=\"query\" autocomplete=\"on\" placeholder=\"" + msg('search') + "\"> ";
    result += "<input type=\"hidden\" name=\"q\" value=\"search\">";

    result += "</form> ";
    result += "</div> ";

    result += "</ul> ";

    result += "</div> ";
    result += "</nav> ";
    result += "</header> ";
    return result;
}