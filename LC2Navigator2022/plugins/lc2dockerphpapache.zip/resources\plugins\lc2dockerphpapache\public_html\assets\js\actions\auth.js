// var loginAPI = "index.php?login";
// var logoutAPI = "index.php?login";
// var url = "/view/index.php";
// var authUrl = "/view/fragments/getauth.php";
// var infoAPI = "http://localhost/webservices/client.php?q=getFullIndexJSON";
// var authAPI = "https://www.letztechance.org/webservices/client.php?q=getAuth";
// var menuAPI = "./view/fragments/menu.html";
// var loggedinAPI = "./view/fragments/loggedin.php";
// var fileuploadAPI = "./view/fragments/fileupload.html";
// $('#out').html("running...");
// // $("#menu").load(menuAPI, function(responseTxt, statusTxt, xhr) {
// //     if (statusTxt == "success")
// //         $('#menu').append(".");
// //     if (statusTxt == "error")
// //         $('#menu').append("Error: " + xhr.status + ": " + xhr.statusText);
// // });
// // $("#loggedin").load(loggedinAPI, function(responseTxt, statusTxt, xhr) {
// //     if (statusTxt == "success")
// //         $('#loggedin').append(".");
// //     if (statusTxt == "error")
// //         $('#loggedin').append("Error: " + xhr.status + ": " + xhr.statusText);
// // });
// // $("#fileuploadForm").load(fileuploadAPI, function(responseTxt, statusTxt, xhr) {
// //     if (statusTxt == "success")
// //         $('#fileuploadForm').append(".");
// //     if (statusTxt == "error")
// //         $('#fileuploadForm').append("Error: " + xhr.status + ": " + xhr.statusText);
// // });
// // // $("#out").load("/view/index.php");
// // $("#out").load(url, function(responseTxt, statusTxt, xhr) {
// //     if (statusTxt == "success")
// //         $('#out').append(".");
// //     if (statusTxt == "error")
// //         $('#out').append("Error: " + xhr.status + ": " + xhr.statusText);
// // });

// $("#auth").load(authUrl, function(responseTxt, statusTxt, xhr) {
//     if (statusTxt == "success")
//         $('#auth').append(".");
//     if (statusTxt == "error")
//         $('#auth').append("Error: " + xhr.status + ": " + xhr.statusText);
// });



// $.get(url, function(data, status) {
//     $('#out').append("Data: " + data + "\nStatus: " + status);
// });
// $.get(infoAPI + "&value1=test&value2=test", function(data, status) {
//     var result = "";
//     var json = JSON.parse(data);
//     result += "<select>";
//     for (var v in json["list"]) {
//         if (json["list"][v]["name"] !== undefined)
//             result += "<option>" + json["list"][v]["name"] + "</option>";
//     }
//     result += "</select>";
//     //$('#out').append("infoAPI Data: " + data + "\nStatus: " + status);
//     $('#out').append("" + result + "\nStatus: " + status);
// });
// $(document).ready(function() {
//     $("#postbutton").click(function() {
//         $.post(infoAPI, {
//                 q: "getFullIndexJSON",
//                 value1: "Donald+Duck",
//             },
//             function(data, status) {
//                 $('#out').append("Data: " + data + "\nStatus: " + status);
//             });
//         $.get(infoAPI + "&value1=test&value2=test", function(data, status) {
//             $('#out').append("infoAPI Data: " + data + "\nStatus: " + status);
//         });
//     });
//     // $("#loginbutton").click(function() {
//     //     alert('Logi2n');
//     //     $.post(loginAPI, {
//     //             login: "true",
//     //             user: $('#user').val(),
//     //             password: $('#password').val(),
//     //         },
//     //         function(data, status) {
//     //             alert('Loggedin');
//     //             $('#loggedin').append("Data: " + data + "\nStatus: " + status);
//     //         });
//     // });
// });