<?php
require('../config/const.cls.php');
// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}
$result = [];
$_q = isset($_REQUEST["q"]) ? $_REQUEST["q"] : (isset($post["q"]) ? $post["q"] : 'error');
switch ($_q) {
  case 'load':
    $result = trim(isset($_REQUEST["query"]) ? file_get_contents($_REQUEST["query"], true) : "");
    writeToFile("_cd_catalog.xml", $result);
    echo $result;
    break;
  case 'setQuery':
    $result["results"] = setQuery($conn, $_REQUEST["query"], 'x', 'x', '12');
    echo json_encode($result);
    break;
  case 'getQuery':
    $result["results"] = getQuery($conn, $_REQUEST["query"]);
    error_reporting(0);
    writeToFile("_query.json", json_encode($result));
    error_reporting(E_ALL);
    echo json_encode($result);
    break;
  case 'getLog':
    $result["results"] = getQuery($conn, "SELECT * FROM INFORMATION_SCHEMA.INNODB_SYS_TABLES");
    echo json_encode($result);
    break;
  case 'getInfo':
    $result["results"] = getDefault($conn);
    echo json_encode($result);
    break;
    //lc services
  case 'getIndex':
    $result = file_get_contents("https://www.letztechance.org/webservices/client.php?q=getFullIndexJSON&value1=1");
    echo $result;
    writeToFile("_index.json", $result);
    break;
  case 'getList':
    $result = file_get_contents("https://www.letztechance.org/webservices/client.php?q=getListJSON&value1=" . $_REQUEST["value1"]);
    echo $result;
    writeToFile("_list.json", $result);
    break;
  case 'getListJSON':
    $result = file_get_contents("https://www.letztechance.org/webservices/client.php?q=getListJSON&value1=" . $_REQUEST["value1"]);
    echo $result;
    writeToFile("_list.json", $result);
    break;
  case 'getRead':
    $result = file_get_contents("https://www.letztechance.org/webservices/client.php?q=getReadJSON&value1=" . $_REQUEST["value1"] . "&value2=" . $_REQUEST["value2"]);
    echo $result;
    writeToFile("_read.json", $result);
    break;
  case 'getReadJSON':
    $result = file_get_contents("https://www.letztechance.org/webservices/client.php?q=getReadJSON&value1=" . $_REQUEST["value1"] . "&value2=" . $_REQUEST["value2"]);
    echo $result;
    writeToFile("_read.json", $result);
    break;
  default:
    $result["results"] = getDefault($conn);
    echo json_encode($result);
    break;
}
$conn->close();
/**
 * default
 */
function writeToFile($file, $t)
{
  $f = fopen($file, "w");
  fwrite($f, $t);
  fclose($f);
}
function getDefault($conn)
{
  $result = [];
  $sql = "SELECT * FROM INFORMATION_SCHEMA.INNODB_SYS_TABLES";
  $res = $conn->query($sql);

  if ($res->num_rows > 0) {
    $i = 0;
    while ($row = $res->fetch_assoc()) {
      $result[$i++] = json_encode($row);
    }
  } else {
    $result["results"] = "0 results";
  }
  return $result;
}
/**
 * 
 * getQuery
 */
function getQuery($conn, $sql)
{
  $result = [];
  if (!$sql) return;
  $sql = "SELECT * FROM dbtest." . $sql;//TODO:change this!!!
  $res = $conn->query($sql);
  if ($res->num_rows > 0) {
    $i = 0;
    while ($row = $res->fetch_assoc()) {
      $result[$i++] = json_encode($row);
    }
  } else {
    $result["results"] = "0 results";
  }
  return $result;
}
function setQuery($conn, $sql, $title, $description, $price)
{
  $i = 0;
  $result = [];
  $sql = "INSERT INTO " . $sql . " (title, description,price)VALUES ('$title', '$description',$price)";
  if ($conn->query($sql) === TRUE) {
    $result[$i++] = "New record created successfully";
  } else {
    $result[$i++] = "Error: " . $sql . "<br>" . $conn->error;
  }
  return $result;
}
