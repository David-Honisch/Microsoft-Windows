<?php
error_reporting(E_ALL);
require "../include/nusoap/lib/nusoap.php";
error_reporting(0);

// $namespace = "http://www.letztechance.org/ws";
// $namespace = "https://letztechance.org.org/webservices";
$namespace = "https://letztechance.org.org/ws";
// if (doAuthenticate()){echo "Logged in !!";}else{echo "Not Logged in";}
// create a new soap server
$server = new soap_server();
$server->decode_utf8 = true;
$server->soap_defencoding = 'UTF-8';
// configure our WSDL
// $server->configureWSDL("LetztChance.Org Webservice");
$server->configureWSDL("LC WebServices");
/**
 * ProcessSimpleType method
 * @param string $who name of the person we'll say hello to
 * @return string $helloText the hello  string
 */
//functions
//require "./include/functions/functions.cls.php";
$FuncSearchDirectory = "./include/functions";
$RegisterSearchDirectory = "./include/register";

if (file_exists("../include/io/io.cls.php")) {
    require_once("../include/io/io.cls.php");
    $dir2 = IO::readDirToArray($FuncSearchDirectory);
    foreach ($dir2 as $v)
    {
        $target = $FuncSearchDirectory."/".$v;
        require  $target;
    }
    $dir = IO::readDirToArray($RegisterSearchDirectory);
    foreach ($dir as $v)
    {
        $target = $RegisterSearchDirectory."/".$v;
        require  $target;
    }
} else {
    echo $env["FileNotFound"];
    echo "IO Failure or page not found.";
    die();
}


// // $namespace = "http://www.letztechance.org/ws";
// // $namespace = "https://letztechance.org.org/webservices";
// $namespace = "https://letztechance.org.org/ws";
// // if (doAuthenticate()){echo "Logged in !!";}else{echo "Not Logged in";}
// // create a new soap server
// $server = new soap_server();
// $server->decode_utf8 = true;
// $server->soap_defencoding = 'UTF-8';
// // configure our WSDL
// // $server->configureWSDL("LetztChance.Org Webservice");
// $server->configureWSDL("LC WebServices");
// set our namespace
$server->wsdl->schemaTargetNamespace = $namespace;
// register our WebMethod
//require_once "./include/register/register.cls.php";
// require_once "./include/register/register.calendar.cls.php";
// require_once "./include/register/register.json.cls.php";
// require_once "./include/register/register.tasks.cls.php";
// require_once "./include/register/register.auth.cls.php";
// require_once "./include/register/register.email.cls.php";
// require_once "./include/register/register.utils.cls.php";
// require_once "./include/register/register.crud.cls.php";
// require_once "./include/register/register.content.json.cls.php";
// require_once "./include/register/register.date.cls.php";
// require_once "./include/register/register.graburls.cls.php";
// require_once "./include/register/register.plugins.cls.php";
if (file_exists("../include/io/io.cls.php")) {
    require_once("../include/io/io.cls.php");
    $dir = IO::readDirToArray($RegisterSearchDirectory);
    foreach ($dir as $v)
    {
        $target = $RegisterSearchDirectory."/".$v;
        // echo  $target;
        require  $target;
    }
} else {
    echo $env["FileNotFound"];
    echo "IO Failure or page not found.";
    die();
}

// require_once("./include/register-plugins.cls.php");
// Get our posted data if the service is being consumed
// otherwise leave this data blank.
// $POST_DATA = isset($GLOBALS['HTTP_RAW_POST_DATA'])
// ? $GLOBALS['HTTP_RAW_POST_DATA'] : '';
// pass our posted data (or nothing) to the soap service
// $server->service($POST_DATA);
$server->service(file_get_contents("php://input"));
// exit();
