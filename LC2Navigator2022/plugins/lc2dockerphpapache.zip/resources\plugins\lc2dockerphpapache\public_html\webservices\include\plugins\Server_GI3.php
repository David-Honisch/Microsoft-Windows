<?php
require("./config/const.php");
// **********************************************
// Webservice (c) 2009 by David Honisch
// **********************************************
// =============== Webservice Server =============
// This server will work with GET and with POST requests.
// You must sanitize all input data in the real world to fight back hacker attacks!
// This simple sample does not sanitize data
$Operation = $_REQUEST["Operation"];
$search = preg_replace('@/((\&)?PHPSESSID=[a-zA-Z0-9]+(\&)?)/i@', "", $_REQUEST["search"]);
$start = preg_replace('@/((\&)?PHPSESSID=[a-zA-Z0-9]+(\&)?)/i@', "", $_REQUEST["start"]);
$end = preg_replace('@/((\&)?PHPSESSID=[a-zA-Z0-9]+(\&)?)/i@', "", $_REQUEST["end"]);
//
$rsite = "http://images.google.de/images?q=".$search."&oe=utf-8&start=".$start."&sa=".$end."";
//
switch (strtoupper($Operation)) {
	case "MULTIPLY" :
		echo " < Result > < Value > " . ($Value1 * $Value2) . " < / Value > < / Result > ";
		exit;

	case " ADD " :
		echo " < Result > < Value > " . ($Value1 + $Value2) . " < / Value > < / Result > ";
		exit;

	case " CONCAT " :
		echo " < Result > < Value > $Value1 $Value2 < / Value > < / Result > ";
		exit;

	default :
		//header(" HTTP / 1.1 501 Not supported ");
		//echo " < Result > < Error > The operation is not supported . < / Error > < / Result >";
		//echo getThumbshotCode($rsite);
		GI($rsite);
		//echo "Test:<br>";
		exit;
}
function getThumbshotCode($url, $scale = 6) {
	$baseurl = "http://www.m-software.de/screenshot/Screenshot.png";
	$owidth = 900;
	$oheight = 600;
	$url = urlencode($url);
	$width = $owidth / $scale;
	$height = $oheight / $scale;
	$thumburl = $baseurl . "?url=" . $url . "&scale=" . $scale;
	$code = "<img src='$thumburl' width='$width' height='$height'/>";
	return $code;
}
function GI($rsite) {
	include "./include/snoopy/Snoopy.class.php";
	$snoopy = new Snoopy;
	$lv = 0;
	// $snoopy->proxy_host = "my.proxy.host";
	// $snoopy->proxy_port = "8080";
	//$rsite = "http://www.phpbuilder.com";

	$snoopy->agent = "(compatible; MSIE 4.01; MSN 2.5; AOL 4.0; Windows 98)";
	$snoopy->referer = "http://www.miecrosnot.com/";
	$snoopy->cookies["SessionID"] = 238472834723489;
	$snoopy->cookies["favoriteColor"] = "RED";
	$snoopy->rawheaders["Pragma"] = "no-cache";
	$snoopy->maxredirs = 2;
	$snoopy->offsiteok = false;
	$snoopy->expandlinks = false;
	$snoopy->user = "joe";
	$snoopy->pass = "bloe";
	/*echo "<?xml version=\"1.0\" encoding=\"UTF-8\"?>";*/
	echo "<Result><Value>";
	if ($snoopy->fetchtext($rsite)) {
		$snoopy->fetchlinks($rsite);
		$pos = "";
		foreach ($snoopy->results as $row) {
			if (eregi(".jpg", $row) || eregi(".gif", $row)|| eregi(".gif", $row))
			{
				if (eregi(".gif", $row))
				{
					$pos = strpos($row, ".gif");
				}
				if (eregi(".png", $row))
				{
					$pos = strpos($row, ".png");
				}
				if (eregi(".jpg", $row))
				{
					$pos = strpos($row, ".jpg");
				}
				if (eregi(".jpeg", $row))
				{
					$pos = strpos($row, ".jpeg");
				}					
				$images = explode("/imgres?imgurl=", $row);
				$image = preg_split('/&/', $images[1]);
				//print_r($image);
				$imagetitle = preg_split('/amp;imgrefurl=/', $image[1]);
				//amp;imgrefurl=
				//echo $image[0]."".$imagetitle[1];
				//echo $image;
				/*
				 echo "<a href=\"".$image."\">";
				 echo "<img src=\"" . rawurldecode($image) . "\" width=\"150px\" width=\"150px\" border=\"0\">";
				 echo "</a>";
				 */
				echo "<img".$lv.">" . $image[0] . "</img".$lv.">";
				echo "<title".$lv.">" . $imagetitle[0] . "</title".$lv.">";
				$lv++;
			}
		}
		//echo "<img22>".$rsite."<img22>";
	}
	else {
		echo "Can�t fetch " . $rsite;
	}
	echo "</Value></Result>";
}
?>