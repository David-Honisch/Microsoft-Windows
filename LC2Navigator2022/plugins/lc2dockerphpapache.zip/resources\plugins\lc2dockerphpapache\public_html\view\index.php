<?php
require('../config/const.cls.php');
require('../config/config.cls.php');
//$conn = $env["db"]["con"];
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} else {
    echo "Connected to MySQL successfully!";
}
$conn->close();
?>
<script>
  $('#out').append("done")
  // $("#out").load("demo_test.txt");
</script>