<h1>LC2MySQL Database</h1>
<h4>Attempting MySQL connection from php...</h4>
<a href="showdb.php">showdb.php</a>
<hr>
<?php
require('./config/const.cls.php');
//$conn = $env["db"]["con"];
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} else {
    echo "Connected to MySQL successfully!";
}
// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

//$sql = "SELECT id, firstname, lastname FROM MyGuests";
// $sql = "Show databases";
  // $sql = "SELECT * FROM INFORMATION_SCHEMA.INNODB_SYS_TABLES WHERE NAME='dbtest'";
$sql = "SELECT * FROM INFORMATION_SCHEMA.INNODB_SYS_TABLES";
$result = $conn->query($sql);
// print_r($result);
if ($result->num_rows > 0) {
  // output data of each row
  while($row = $result->fetch_assoc()) {
    echo "id: " . $row["TABLE_ID"]. " - Name: " . $row["NAME"]. " " . $row["FILE_FORMAT"]. "<br>";
  }
} else {
  echo "0 results";
}
$conn->close();
?> 