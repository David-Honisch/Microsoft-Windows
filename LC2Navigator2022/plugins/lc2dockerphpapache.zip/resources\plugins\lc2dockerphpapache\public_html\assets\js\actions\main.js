var CONFIG = {
    CURRENT_CONFIGVALS: "",
    API: new API()
}

function API() {
    this.loginAPI = "index.php?login";
    this.logoutAPI = "index.php?login";
    this.url = "/view/index.php";
    this.authUrl = "/view/fragments/getauth.php";
    this.infoAPI = "http://localhost:84/webservices/client.php?q=getFullIndexJSON";
    this.authAPI = "https://www.letztechance.org/webservices/client.php?q=getAuth";
    this.menuAPI = "./view/fragments/menu.html";
    this.loggedinAPI = "./view/fragments/loggedin.php";
    this.fileuploadAPI = "./view/fragments/fileupload.html";
    this.homeAPI = "./view/home.cls.php";
}

function EVENTS() {
    function initLoginButton() {
        $("#postbutton").click(function() {
            $.post(infoAPI, {
                    q: "getFullIndexJSON",
                    value1: "Donald+Duck",
                },
                function(data, status) {
                    $('#out').append("Data: " + data + "\nStatus: " + status);
                });
            $.get(infoAPI + "&value1=test&value2=test", function(data, status) {
                $('#out').append("infoAPI Data: " + data + "\nStatus: " + status);
            });
        });
    }

    function initPostButton() {
        $("#loginbutton").click(function() {
            alert('Logi2n');
            $.post(loginAPI, {
                    login: "true",
                    user: $('#user').val(),
                    password: $('#password').val(),
                },
                function(data, status) {
                    alert('Loggedin');
                    $('#loggedin').append("Data: " + data + "\nStatus: " + status);
                });
        });
    }
}

function HTML() {
    this.getUrlVar = function getUrlVar(name) {
        return this.getUrlVars()[name];
    }

    this.getUrlVars = function getUrlVars() {
        var vars = [],
            hash;
        var hashes = window.location.href.slice(
            window.location.href.indexOf('?') + 1).split('&');
        for (var i = 0; i < hashes.length; i++) {
            hash = hashes[i].split('=');
            vars.push(hash[0]);
            vars[hash[0]] = hash[1];
        }
        return vars;
    }
}

function PAGES() {
    this.api = new API();
    this.html = HTML;
    this.home = function home() {
        $('#out').html("running..." + this.api.menuAPI);
        loadQUERY(this.api.homeAPI, "#out");
        loadQUERY(this.api.menuAPI, "#menu");
        loadQUERY(this.api.fileuploadAPI, "#fileuploadForm");
        loadQUERY('/view/views/home.html', 'out')
        $.get(this.api.infoAPI + "&value1=test&value2=test", function(data, status) {
            var result = "";
            var json = JSON.parse(data);
            result += "<select>";
            for (var v in json["list"]) {
                if (json["list"][v]["name"] !== undefined)
                    result += "<option>" + json["list"][v]["name"] + "</option>";
            }
            result += "</select>";
            $('#out').append("" + result + "\nStatus: " + status);
        });
    }
}

function PAGE() {
    this.init = function init() {
        var html = new HTML();
        var pages = new PAGES();
        $('#out').html("running...");
        var q = html.getUrlVar("q");

        switch (q) {
            case "home":
                pages.home();
                break;
            case "neues":
                pages.home();
                break;
            default:
                pages.home();
                break;
        }
    }
}
$(document).ready(function() {
    new PAGE().init();

});