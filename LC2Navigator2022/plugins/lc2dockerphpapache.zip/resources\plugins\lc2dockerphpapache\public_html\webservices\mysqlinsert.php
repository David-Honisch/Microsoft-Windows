<?php
require('./config/const.cls.php');
//$conn = $env["db"]["con"];
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} else {
    echo "Connected to MySQL successfully!";
}
$sql = "INSERT INTO dbtest.products (title, description,price)VALUES ('John', 'john@example.com',1122)";

if ($conn->query($sql) === TRUE) {
  echo "New record created successfully";
} else {
  echo "Error: " . $sql . "<br>" . $conn->error;
}
$conn->close();
?> 