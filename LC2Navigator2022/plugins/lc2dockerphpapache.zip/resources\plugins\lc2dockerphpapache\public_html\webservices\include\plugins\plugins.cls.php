<?php
if (strpos("functions.auth.cls.php", $_SERVER['PHP_SELF'])) {
    Header("Location:/index.php");
    die();
}

/**
 * $startdate = "2019-02-10";
 * $enddate = "2019-05-10";
 *
 * @param unknown $location
 * @param unknown $date
 * @param unknown $startdate
 * @param unknown $enddate
 * @return soapval
 */
function getCalendarDays($location, $date, $startdate, $enddate)
{
    require ("../config/const.cls.php");
    $dateFunc = null;
    if (file_exists($env["include"] . "parse/read_functions.cls.php")) {
        require ($env["include"] . "calendar/datefunc.cls.php");
        $datefunc = new DateFunc();
        
        // $date_format = 'Y-m-d';
        $date_format = 'd.m.Y';
        // $startdate = "2019-02-10"; // Order placing date
        $businessdays = 7; // number of days for delivery
        $holidays = array(
            '2019-05-27',
            '2019-06-14'
        ); // array of dates having holidays. excluding business days.
        $dateformat = 'd-m-Y'; // output date format for displaying.
        $result["startdate"] = $startdate;
        $result["enddate"] = $enddate;
        $result["date"] = easter_date();
        $result["easterdate"] = date($date_format, easter_date(2019));
        $result["easterdays"] = easter_days("2019");
        $result["businessdays"] = $datefunc->add_business_days($startdate, $businessdays, $holidays, $dateformat);
        $result["workingdays"] = $datefunc->getWorkingDays($startdate, $enddate);
        $result["americanholidays"] = $datefunc->getNationalAmericanHolidays("2019");
        //
        $jsonIterator = new RecursiveIteratorIterator(new RecursiveArrayIterator(getJSONFile($env["WS"] . "holidays.json")), RecursiveIteratorIterator::SELF_FIRST);
        
        foreach ($jsonIterator as $key => $val) {
            if (is_array($val)) {
                $result["holidays"][$key] = $key;
            } else {
                $result["holidays"][$key] = $val;
            }
        }
    }
    
    $responseString = new soapval('return', 'xsd:string', json_encode($result));
    return $responseString;
}

function getJSONFile($fileName)
{
    $string = file_get_contents($fileName);
    return json_decode($string, true);
}
?>