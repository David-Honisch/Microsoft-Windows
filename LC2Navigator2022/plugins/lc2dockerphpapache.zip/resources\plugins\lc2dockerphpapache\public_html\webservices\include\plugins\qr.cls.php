<?php
if (strpos("qr.cls.php", $_SERVER['PHP_SELF'])) {
    Header("Location:/index.php");
    die();
}
try {
    $filename = "https://chart.googleapis.com/chart?chs=300x300&cht=qr&chl=".$query."&choe=UTF-8";
    $imagedata = file_get_contents($filename);
    //@unlink($filename);

    // alternatively specify an URL, if PHP settings allow
    $base64 = base64_encode($imagedata);
    // $result["QRUTF8"] = utf8_decode($base64);
    $str = utf8_encode(base64_decode($base64));
    $result["QR"] = $base64;

    $responseString = new soapval('return', 'xsd:string', json_encode($result));
} catch (\Throwable $th) {
    throw $th;
}
