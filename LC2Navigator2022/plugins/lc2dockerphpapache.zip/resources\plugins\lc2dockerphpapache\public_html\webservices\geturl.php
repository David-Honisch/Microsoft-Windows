<?php
function requestedByTheSameDomain()
{
	$myDomain       = isset($_SERVER['SCRIPT_URI']) ? $_SERVER['SCRIPT_URI'] : null;
	$requestsSource = isset($_SERVER['HTTP_REFERER']) ? $_SERVER['HTTP_REFERER'] : null;
	return parse_url($myDomain, PHP_URL_HOST) === parse_url($requestsSource, PHP_URL_HOST);
}
if (!requestedByTheSameDomain()) {
	echo "<h1>Access denied</h1>";
} else {
	$ext_url = isset($_REQUEST['ext_url']) ? $_REQUEST['ext_url'] : "";
	if ($ext_url == null || $ext_url == "") {
		echo "Type a parameter ext_url:";
	} else {
		$ext_url = isset($_REQUEST['apikey']) ? $ext_url . "&apikey=" . $_REQUEST['apikey'] : $ext_url;
		// echo "OUT:".$ext_url;
		echo file_get_contents_curl($ext_url);
	}
	// echo file_get_contents($ext_url);
	// $curl_handle = curl_init();
	// curl_setopt($curl_handle, CURLOPT_URL, $ext_url);
	// curl_setopt($curl_handle, CURLOPT_CONNECTTIMEOUT, 2);
	// curl_setopt($curl_handle, CURLOPT_RETURNTRANSFER, 1);
	// curl_setopt($curl_handle, CURLOPT_USERAGENT, 'LC Reader v.1.1');
	// $query = curl_exec($curl_handle);
	// curl_close($curl_handle);
	// echo "<h1>Response</h1>"+$query;
	// $json_is = "https://www.google.com/search?source=hp&ei=nZQgX-quH8uaa-LaiZgH&q=test&oq=test&gs_lcp=CgZwc3ktYWIQAzIFCAAQsQMyBQgAELEDMgUIABCxAzIFCAAQsQMyBQgAELEDMgUIABCxAzIFCAAQsQMyAggAMgUIABCxAzICCAA6CAgAELEDEIMBOggILhCxAxCDAVD7FliHHGCJHWgAcAB4AIABTYgB_gGSAQE0mAEAoAEBqgEHZ3dzLXdpeg&sclient=psy-ab&ved=0ahUKEwiq8cGd7vDqAhVLzRoKHWJtAnMQ4dUDCAg&uact=5";
	// $video_info = json_decode(file_get_contents($json_is), true);
	// $video_title = is_array($video_info) ? $video_info['feed']['entry'][0]['title']['$t'] : '';
}
function file_get_contents_curl($url)
{
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_HEADER, 0);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1); //Set curl to return the data instead of printing it to the browser.
	curl_setopt($ch, CURLOPT_URL, $url);
	$data = curl_exec($ch);
	curl_close($ch);
	return $data;
}
?>
<?php
if (!isset($env) && empty($env)) {
	if (file_exists("../config/const.cls.php")) {
		include("../config/const.cls.php");
	} else {
		echo "404 NOT FOUND";
		die();
	}
}
if (file_exists($env["docroot"] . "include/snoopy/Snoopy.class.php")) {
	include $env["docroot"] . "include/snoopy/Snoopy.class.php";
} else {
	echo "404-Parser not found...";
}
// include "Snoopy.class.php";
$snoopy = new Snoopy;
$url = "http://www.letztechance.org/read-26-2928.html";
$snoopy->fetchtext($url);
print $snoopy->results;
echo "<hr>";
$snoopy->fetchlinks($url);
print_r($snoopy->results);
echo "<hr>";
$snoopy->fetchlinks("https://stackoverflow.com/questions/5410238/how-to-check-if-a-request-if-coming-from-the-same-server-or-different-server");
print_r($snoopy->results);
echo "<hr>";
$snoopy->fetchlinks("http://www.phpbuilder.com/");
print_r($snoopy->results);

// $submit_url = "http://lnk.ispi.net/texis/scripts/msearch/netsearch.html";

// $submit_vars["q"] = "amiga";
// $submit_vars["submit"] = "Search!";
// $submit_vars["searchhost"] = "Altavista";

// $snoopy->submit($submit_url,$submit_vars);
// print $snoopy->results;

// $snoopy->maxframes=5;
// $snoopy->fetch("http://www.ispi.net/");
// echo "<PRE>\n";
// echo htmlentities($snoopy->results[0]); 
// echo htmlentities($snoopy->results[1]); 
// echo htmlentities($snoopy->results[2]); 
// echo "</PRE>\n";

// $snoopy->fetchform("http://www.altavista.com");
// print $snoopy->results;




class Plugin_22_4
{
	private static function get_valueFromStringUrl($url, $parameter_name)
	{
		$parts = parse_url($url);
		if (isset($parts['query'])) {
			parse_str($parts['query'], $query);
			if (isset($query[$parameter_name])) {
				return $query[$parameter_name];
			} else {
				return null;
			}
		} else {
			return null;
		}
	}
	/**
	 * 
	 */
	public static function get($env)
	{
		$url = (isset($env["query"])) ? $env["query"] : "";
		$proxy = (isset($env["req"]["proxy"])) ? $env["req"]["proxy"] : "";
		$port = (isset($env["req"]["proxy"])) ? $env["req"]["port"] : "";

		$url = !empty(self::get_valueFromStringUrl($_SERVER['REQUEST_URI'], "query")) ? self::get_valueFromStringUrl($_SERVER['REQUEST_URI'], "query") : "";
		$t = urldecode(getReqQuery("query"));
		$url = !empty($t) ? $t : $url;
		echo $url;

		$snoopy = null;
		//echo $env ["docroot"]. "include/snoopy/Snoopy.class.php"; 
		if (file_exists($env["docroot"] . "include/snoopy/Snoopy.class.php")) {
			include $env["docroot"] . "include/snoopy/Snoopy.class.php";
		} else {
			echo "404-Parser not found...";
		}
		echo "WebParser initializing...";
		echo "<p align=\"center\">\n";
		echo "<font class=\"big\">Link Parser</font>\n";
		echo "<p>Geben Sie eine Webhost an: </p>\n";
		echo "<form name=\"website\" method=\"get\" action=\"./read-22-4.html\" rel=\"external\" target=\"_parent\">\n";
		echo "<input type=\"hidden\" name=\"q\" value=\"read\">\n";
		echo "<input type=\"hidden\" name=\"value1\" value=\"22\">\n";
		echo "<input type=\"hidden\" name=\"value2\" value=\"4\">\n";
		echo "<input type=\"hidden\" name=\"plugin\" value=\"webparser\">\n";
		echo "<p>Host</p>\n";
		echo "  <p>\n";
		echo "    <input type=\"text\" name=\"query\">\n";
		echo "  </p>\n";
		echo "<p>Proxy:</p>\n";
		echo "  <p>\n";
		echo "<input type=\"text\" name=\"proxy\">\n";
		echo "Port:\n";
		echo "<input type=\"text\" name=\"port\" size=\"5\">\n";
		echo "  </p>\n";
		echo "  <p>\n";
		echo "    <input type=\"submit\" name=\"Submit\" value=\"Submit\">\n";
		echo "  </p>\n";
		echo "</form>\n";
		echo "<p>\n";
		echo "<a href=\"#\" onClick=\"cFCW('proxies.html',700,400,152,120);return false\">Proxies</a><br>\n";
		if (!empty($url)) {
			/**
			 * Just an example of sourceforge.net.php
			 *
			 * @access public
			 * @author David Honisch
			 */
			$snoopy->agent = "(compatible; MSIE 4.01; MSN 2.5; AOL 4.0; Windows 98)";
			$snoopy->referer = "http://www.microsnot.com/";

			/**
			 *
			 * @access proxy
			 */

			if (!empty($proxy)) {
				echo "Es wurde ein Proxy angegeben: $tproxy";
				$snoopy->proxy_host = $trpoxy;

				if ($port) {
					echo ":" . $port;
					$snoopy->proxy_port = $port;
					echo "<br>";
				} else {
					$snoopy->proxy_port = "8080";
					echo "<br>";
				}
			} else {
				echo "Es wurde kein Proxy angegeben.<br>";
			}
			/**
			 *
			 * @access website
			 */

			echo "URL:" . $url . "<br>";
			// if (file_exists ( "./include/snoopy/Snoopy.class.php" )) {
			// include "./include/snoopy/Snoopy.class.php";
			echo "Reading...";
			echo "<textarea rows=\"20\" cols=\"100\">";
			$snoopy = new Snoopy();
			// $snoopy2 = new Snoopy;
			if ($snoopy->fetchlinks($url)) {
				$n = count($snoopy->results);
				echo "Es wurden " . $n . " Links gefunden:	<br>";
				for ($i = 1; $i <= $n; $i++) {
					//echo "\n[url]<a href=\"/?q=plugins&plugin=webparser&url=" . $snoopy->results [$i] . "&proxy=" . $proxy . "&port=" . $port . "\">";
					echo "\n[url]" . $snoopy->results[$i] . "[/url]";
					//echo $snoopy->results [$i] . "";
					// echo "" . $snoopy->results [$i] . "";
					//echo "</a>[/url]";
				}
			} 			// }
			else {
				echo "error fetching document: " . $snoopy->error . "\n";
			}
			/*
			 * $submit_url = "http://www.php.net"; $submit_vars["q"] = "amiga"; $submit_vars["submit"] = "Search!"; $submit_vars["searchhost"] = "Altavista"; $snoopy->submit($submit_url,$submit_vars); print $snoopy->results; $snoopy->maxframes=5; $snoopy->fetch("http://www.php.net/"); echo "<PRE>\n"; echo htmlentities($snoopy->results[0]); echo htmlentities("<a href=\"".$snoopy->results[1].">".$snoopy->results[1]."</a>"); echo htmlentities($snoopy->results[2]); echo "</PRE>\n"; $snoopy->fetchform("http://www.altavista.com"); print $snoopy->results;
			 */
		} else {
			echo "Bitte geben Sie bitte eine Webseite an:";
		}
		echo "</textarea>";
	}
}
Plugin_22_4::get($env);
?>