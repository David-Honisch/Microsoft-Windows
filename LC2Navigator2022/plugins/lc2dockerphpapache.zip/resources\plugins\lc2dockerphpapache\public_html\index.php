<h1>Hello to LC2MySQL Database</h1>
<h4>Attempting MySQL connection from php...</h4>
<a href="adminer-4.7.0.php">Admin</a>
<a href="showdb.php">showdb.php</a>
<hr>
<form action="upload.php" method="post" enctype="multipart/form-data">
  Select image to upload:
  <input type="file" name="fileToUpload" id="fileToUpload">
  <input type="submit" value="Upload Image" name="submit">
</form>
<hr>
<?php
$host = 'mysql';
$user = 'root';
$pass = 'rootpassword';
$conn = new mysqli($host, $user, $pass);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} else {
    echo "Connected to MySQL successfully!";
}

?>