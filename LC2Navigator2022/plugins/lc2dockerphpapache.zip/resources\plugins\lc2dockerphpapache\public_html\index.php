<?PHP
// require('./include/auth/basic.auth.cls.php');
// // require_auth();
// require_auth();
// list($_SERVER['PHP_AUTH_USER'], $_SERVER['PHP_AUTH_PW']) =  explode(':', base64_decode(substr($_SERVER['HTTP_AUTHORIZATION'], 6)));

?>
<!DOCTYPE html>
<html class="html__responsive ">

<head>
  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
  <title>LC2DockerApachePHPMySQL</title>
  <meta name="title" content="NuSOAP, HTTP Authentication and HTTP Proxy" />
  <meta name="author" content="beanizer" />
  <meta name="description" content="Using HTTP Authentication and HTTP Proxy with NuSOAP" />
  <meta name="keywords" content="nusoap, http authentication, http proxy" />
  <meta name="Generator" content="Copyright (C) 2022 - 1998 Open Source Matters. All rights reserved." />
  <meta name="robots" content="index, follow" />
  <!-- <base href="http://www.letztechance.org/site/" /> -->
  <style>
        table,
        th,
        td {
            border: 1px solid black;
            border-collapse: collapse;
        }
        
        th,
        td {
            padding: 5px;
        }
    </style>
  <link rel="shortcut icon" href="http://www.letztechance.org/favicon.ico" />
  <script language="JavaScript" type="text/javascript">
  </script>

</head>

<body>
  <h1>Welcome to LetzteChance.Org - WebService API Explorer</h1>
  <fieldset>  
    <div id="menu">Loading...</div>
    <button type="button" onclick="loadXMLDoc('loggedin','/webservices/menu.xml','CD', ['PARENT', 'TITLE'])">START</button>
  </fieldset>

  <fieldset>
    <div id="loggedin">Loading...<?PHP    //require('./view/fragments/menu.html');    
                                  ?></div>
  </fieldset>
  <fieldset>
    <div id="fileuploadForm">Loading...</div>
    <?PHP  //require('./view/fragments/fileupload.html');   
    ?>
  </fieldset>
  <fieldset>
    <div id="auth">Loading...</div>
    <?PHP //require('./view/fragments/getauth.php'); 
    ?>
  </fieldset>
  <fieldset>
    <div id="out"></div>
  </fieldset>


  <?PHP 
  $scripts = './webservices';
    if ($handle = opendir($scripts)) { 
      echo "<ul class=\"listul\">";
      while (false !== ($entry = readdir($handle))) {
          if ($entry != "." && $entry != ".." )
          echo "<li><a href=\"$scripts/$entry\" target=\"$entry\">$entry\n</a></li>";
      }
      echo "</ul>";
      while ($entry = readdir($handle)) {
          echo "$entry\n";
      }  
      closedir($handle);
  }
  ?>
  
  <script>
    var cpage;
    // $('#gout').append('RUNNING DONE.');
    window._PAGE_ = {
      cpage: ""
    };
    try {
      window.nodeRequire = require;
      window.nodeExports = window.exports;
      window.nodeModule = window.module;
      delete window.require;
      delete window.exports;
      delete window.module;
    } catch (error) {
      console.error(error);
      console.error(error.stack);
    }
  </script>
  <script src="assets/js/jquery/jquery.min.js"></script>
  <script src="assets/js/actions/api.js"></script>
  <script src="assets/js/actions/home.js"></script>
</body>

</html>