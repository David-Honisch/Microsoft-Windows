<?PHP
?>
<!DOCTYPE html>
<html class="html__responsive ">

<head>
  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
  <title>LC2DockerApachePHPMySQL</title>
  <meta name="title" content="NuSOAP, HTTP Authentication and HTTP Proxy" />
  <meta name="author" content="beanizer" />
  <meta name="description" content="Using HTTP Authentication and HTTP Proxy with NuSOAP" />
  <meta name="keywords" content="nusoap, http authentication, http proxy" />
  <meta name="Generator" content="Copyright (C) 2022 - 1998 Open Source Matters. All rights reserved." />
  <meta name="robots" content="index, follow" />
  <!-- <base href="http://www.letztechance.org/site/" /> -->
  <link rel="shortcut icon" href="http://www.letztechance.org/favicon.ico" />
  <script language="JavaScript" type="text/javascript">
  </script>
</head>

<body>
  <h1>Welcome to LetzteChance.Org - WebService API Explorer</h1>
  <fieldset>
    <div id="menu">Loading...</div>
  </fieldset>

  <fieldset>
    <div id="loggedin">Loading...<?PHP    //require('./view/fragments/menu.html');    
                                  ?></div>
  </fieldset>
  <fieldset>
    <div id="fileuploadForm">Loading...</div>
    <?PHP  //require('./view/fragments/fileupload.html');   
    ?>
  </fieldset>
  <fieldset>
    <div id="auth">Loading...</div>
    <?PHP //require('./view/fragments/getauth.php'); 
    ?>
  </fieldset>
  <fieldset>
    <div id="out"></div>
  </fieldset>


  <?PHP 
    if ($handle = opendir('./')) { 
      echo "<ul class=\"listul\">";
      while (false !== ($entry = readdir($handle))) {
          echo "<li><a href=\"./$entry\" target=\"$entry\">$entry\n</a></li>";
      }
      echo "</ul>";
      while ($entry = readdir($handle)) {
          echo "$entry\n";
      }
  
      closedir($handle);
  }
  ?>
  
  <script>
    var cpage;
    // $('#gout').append('RUNNING DONE.');
    window._PAGE_ = {
      cpage: ""
    };
    try {
      window.nodeRequire = require;
      window.nodeExports = window.exports;
      window.nodeModule = window.module;
      delete window.require;
      delete window.exports;
      delete window.module;
    } catch (error) {
      console.error(error);
      console.error(error.stack);
    }
  </script>
  <script src="../assets/js/jquery/jquery.min.js"></script>
  <script src="../assets/js/actions/home.js"></script>
</body>

</html>