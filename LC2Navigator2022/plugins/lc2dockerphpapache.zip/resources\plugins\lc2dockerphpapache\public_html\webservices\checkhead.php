<?php
if (file_exists ( "../config/const.cls.php" )) {
	require_once ("../config/const.cls.php");
} else {
	echo "<h1>504 - Down for maintenance</h1>";
	echo "<h2>Configuration not Found</h2>";
	die ();
}
// echo $env["docrootUrl"]."client.html";
header("Location: ".$env["docrootUrl"]."client.php");
?>