<?php
if (strpos("functions.cls.php", $_SERVER['PHP_SELF'])) {
    Header("Location:/index.php");
    die();
}
function getQR($query)
{
    // echo "OUT:";
    // $query = "fuck";
    $responseString = "";
    $imagedata;
    $result = array();
    // echo "OUT:";
    try {
        if (file_exists("../config/const.cls.php")) {
            require_once '../config/const.cls.php';
        }
        // echo "OUT:";
        $result["numofentries"] = $env["numofentries"];
        $result["data"] = "QR Code";
        $result["url"] = $query;
        if (file_exists("../../tools/LC2PHPQRCode/qrlib.php")) {
            require_once '../../tools/LC2PHPQRCode/qrlib.php';
        }
        // echo "QUERY:".$query;

        $errorCorrectionLevel = 'L';
        $level = isset($_REQUEST['level']) ? $_REQUEST['level'] : 'L';
        if (isset($level) && in_array($level, array('L', 'M', 'Q', 'H'))) {
            $errorCorrectionLevel = $level;
        }
        $matrixPointSize = 4;
        $size = isset($_REQUEST['size']) ? $_REQUEST['size'] : 4;
        if (isset($size)) {
            $matrixPointSize = min(max((int) $size, 1), 10);
        }
        
        //$PNG_TEMP_DIR = dirname(__FILE__) . DIRECTORY_SEPARATOR . 'temp' . DIRECTORY_SEPARATOR;
        $PNG_TEMP_DIR = $_SERVER["DOCUMENT_ROOT"]. "log". DIRECTORY_SEPARATOR;
        //html PNG location prefix
        //$PNG_WEB_DIR = 'temp/';        
        $filename = $PNG_TEMP_DIR . 'test' . md5($query . '|' . $errorCorrectionLevel . '|' . $matrixPointSize) . '.png';
        
        echo "OUT:".$filename;
        if (isset($query)) {
            
            //it's very important!
            if (trim($query) == '') {
                die('data cannot be empty! <a href="?">back</a>');
            }

            // user data
            //QRcode::png($query, $filename, $errorCorrectionLevel, $matrixPointSize, 2);
            // echo "OUT:";
            QRcode::png($query, $filename, $errorCorrectionLevel, $matrixPointSize, 2);

        } else {

            //default data
            //echo 'You can provide data in GET parameter: <a href="?data=like_that">like that</a><hr/>';
            // QRcode::png('PHP QR Code :)', $filename, $errorCorrectionLevel, $matrixPointSize, 2);
            QRcode::png('PHP QR Code :)', $filename, $errorCorrectionLevel, $matrixPointSize, 2);

        }
        echo "OUT:".$filename;
        $imagedata = file_get_contents($filename);
        //@unlink($filename);

        // alternatively specify an URL, if PHP settings allow
        $base64 = base64_encode($imagedata);
        // $result["QRUTF8"] = utf8_decode($base64);
        $str = utf8_encode(base64_decode($base64));
        $result["QR"] = $base64;

        $responseString = new soapval('return', 'xsd:string', json_encode($result));
    } catch (\Throwable $th) {
        throw $th;
    }
    return $responseString;
}   
// function getQR2($query)
// {
    
//     $query = "fuck";
//     $responseString = "";
//     $imagedata;
//     $result = array();
//     if (file_exists("../config/const.cls.php")) {
//         require_once '../config/const.cls.php';
//     }
//     $result["numofentries"] = $env["numofentries"];
//     $result["data"] = "QR Code";
//     echo "OUT:";
//     if (file_exists("../config/const.cls.php")) {
//         require_once '../config/const.cls.php';
//     }
//     try {
//         //code...

//         // if (file_exists("../webservices/services/" . $map . ".cls.php")) {
//         //     require_once "../webservices/services/" . $map . ".cls.php";
//         // }
//         $result["numofentries"] = $env["numofentries"];
//         // if ($map != null) {
//         //     $result["map"] = $query != null ? $map : "Not available";
//         // } else {
//         //     $result["map"] = "Not available";
//         // }
//         // if ($query != null) {
//         //     $result["query"] = $query != null ? $query : "Not available";
//         // } else {
//         //     $result["query"] = "Not available";
//         // }
//         //
//         // $PNG_TEMP_DIR = dirname(__FILE__) . DIRECTORY_SEPARATOR . 'temp' . DIRECTORY_SEPARATOR;
//         //html PNG location prefix
//         // $PNG_WEB_DIR = 'temp/';

//         //if (file_exists($env["include"] . "../config/qrlib.php")) {
//         if (file_exists("../../tools/LC2PHPQRCode/qrlib.php")) {
//             require_once '../../tools/LC2PHPQRCode/qrlib.php';
//         }
//         // include "qrlib.php";
//         //ofcourse we need rights to create temp dir
//         // if (!file_exists($PNG_TEMP_DIR)) {
//         //     mkdir($PNG_TEMP_DIR);
//         // }
//         // $filename = $PNG_TEMP_DIR . 'test.png';
//         //processing form input
//         //remember to sanitize user input in real-life solution !!!
//         $errorCorrectionLevel = 'L';
//         $level = isset($_REQUEST['level']) ? $_REQUEST['level'] : 'L';
//         if (isset($level) && in_array($level, array('L', 'M', 'Q', 'H'))) {
//             $errorCorrectionLevel = $level;
//         }
//         echo "OUT:";
//         $matrixPointSize = 4;
//         $size = isset($_REQUEST['size']) ? $_REQUEST['size'] : 4;
//         if (isset($size)) {
//             $matrixPointSize = min(max((int) $size, 1), 10);
//         }
        
//         if (isset($query)) {

//             //it's very important!
//             if (trim($query) == '') {
//                 die('data cannot be empty! <a href="?">back</a>');
//             }

//             // user data
//             //$filename = $PNG_TEMP_DIR . 'test' . md5($query . '|' . $errorCorrectionLevel . '|' . $matrixPointSize) . '.png';
//             //QRcode::png($query, $filename, $errorCorrectionLevel, $matrixPointSize, 2);
//             echo "OUT:";
//             QRcode::png($query);

//         } else {

//             //default data
//             //echo 'You can provide data in GET parameter: <a href="?data=like_that">like that</a><hr/>';
//             // QRcode::png('PHP QR Code :)', $filename, $errorCorrectionLevel, $matrixPointSize, 2);
//             QRcode::png('PHP QR Code :)');

//         }
//         $imagedata = ob_get_contents();
//         ob_end_clean();
//         echo "FILE:".$imagedata;
//         //display generated file
//         //$result["QRPATH"] = $PNG_WEB_DIR . basename($filename);
//         //$result["imgtag"] = '<img src="' . $PNG_WEB_DIR . basename($filename) . '" /><hr/>';
//         // $imagedata = file_get_contents($filename);
//         // alternatively specify an URL, if PHP settings allow
//         $base64 = base64_encode($imagedata);
//         // $result["QRUTF8"] = utf8_decode($base64);
//         $str = utf8_encode(base64_decode($base64));
//         $result["QR"] = $base64;
//         // print_r($result);
//         $responseString = new soapval('return', 'xsd:string', json_encode($result));
//     } catch (Throwable $th) {
//         throw $th;
//     }
//     return $responseString;
// }

// --------------------------------------------------------->
// --------------------------------------------------------->
// PLUGINS
// --------------------------------------------------------->
function getImageSearchJSON($query, $page)
{
    $result = "";
    require "../config/const.cls.php";
    // echo $env["includeWS"]."GoogleImageSnoopySearch.cls.php";
    if (file_exists($env["includeWS"] . "GoogleImageSnoopySearch.cls.php")) {
        require $env["includeWS"] . "GoogleImageSnoopySearch.cls.php";
    } else {
        echo "<br />Plugins !! not found.";
        die();
    }
    // echo "Debug:".$query.$page;
    $g = new GoogleImageSnoopySearch();
    $result = $g->search($query, $page);
    $responseString = new soapval('return', 'xsd:string', json_encode($result));
    return $responseString;
}
function getMap($map, $query)
{
    $responseString = "";
    $result = array();
    if (file_exists("../config/const.cls.php")) {
        require_once '../config/const.cls.php';
    }
    if (file_exists("../webservices/services/" . $map . ".cls.php")) {
        require_once "../webservices/services/" . $map . ".cls.php";
    }
    $result["numofentries"] = $env["numofentries"];
    if ($map != null) {
        $result["map"] = $query != null ? $map : "Not available";
    } else {
        $result["map"] = "Not available";
    }
    if ($query != null) {
        $result["query"] = $query != null ? $query : "Not available";
    } else {
        $result["query"] = "Not available";
    }

    //display generated file

    // $result["max"] = $db->mysql_num_rows("select t1.id as max from " . $tables["table_name"] . "  as t1");
    // if ($result["max"] > 0) {
    //     $result["numofpages"] = ceil($result["max"] / intval($env["numofentries"]));
    //     $result["lastpage"] = ceil($result["max"] - intval($env["numofentries"]));
    //     $result["start"] = intval(ceil(($value2 * $env["numofentries"]) - $env["numofentries"]));
    //     $result["end"] = ($start - $env["numofentries"]);
    // }
    // if ($result["start"] >= intval($result["max"] - $env["numofentries"])) {
    //     $result["start"] = intval($result["max"] - $env["numofentries"]); // echo "SZUX";
    // }
    // if (intval($result["start"]) <= intval($env["numofentries"])) {
    //     $result["start"] = 0;
    // }

    // print_r($result);
    $responseString = new soapval('return', 'xsd:string', json_encode($result));
    return $responseString;
}
