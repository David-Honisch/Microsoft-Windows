<?php
//// **********************************************
//// Webservice (c) 2009 by David Honisch
//// **********************************************
//// =============== Webservice Server =============
//// This server will work with GET and with POST requests.
//// You must sanitize all input data in the real world to fight back hacker attacks!
//// This simple sample does not sanitize data
//$Operation = $_REQUEST["Operation"];
//$search = preg_replace('@/((\&)?PHPSESSID=[a-zA-Z0-9]+(\&)?)/i@', "", $_REQUEST["search"]);
//$start = preg_replace('@/((\&)?PHPSESSID=[a-zA-Z0-9]+(\&)?)/i@', "", $_REQUEST["start"]);
//$end = preg_replace('@/((\&)?PHPSESSID=[a-zA-Z0-9]+(\&)?)/i@', "", $_REQUEST["end"]);
//require("./config/const.php");
class Plugins
{
	/**
	 *
	 * Enter description here ...
	 * @param $url
	 * @param $scale
	 */
	public static function getThumbshotCode($url, $scale = 6) {
		$baseurl = "https://www.letztechance.org/img/bg.png";
		$owidth = 900;
		$oheight = 600;
		$url = urlencode($url);
		$width = $owidth / $scale;
		$height = $oheight / $scale;
		$thumburl = $baseurl . "?url=" . $url . "&scale=" . $scale;
		$code = "<img src='$thumburl' width='$width' height='$height'/>";
		return $code;
	}
	/**
	 *
	 * Enter description here ...
	 * @param $search
	 * @param $start
	 * @param $end
	 */
	//public static function getGoogleImageSearch($search, $start, $end=1000) {
	public static function getGoogleImageSearch($env, $action, $u_id, $value1, $value2, $value3){
		//echo "Debug:".$search."-".$start."#";
		include "./include/snoopy/Snoopy.class.php";
		//echo "<Search>".$value1."</Search>";
		$snoopy = new Snoopy;
		$rsite = "http://images.google.de/images?q=".$value1."&oe=utf-8&start=".$value2."&sa=".$value3."";
		$lv = 0;
		// $snoopy->proxy_host = "my.proxy.host";
		// $snoopy->proxy_port = "8080";
		//$rsite = "http://www.phpbuilder.com";
		$snoopy->agent = "(compatible; MSIE 4.01; MSN 2.5; AOL 4.0; Windows 98)";
		$snoopy->referer = "http://www.miecrosnot.com/";
		$snoopy->cookies["SessionID"] = 238472834723489;
		$snoopy->cookies["favoriteColor"] = "RED";
		$snoopy->rawheaders["Pragma"] = "no-cache";
		$snoopy->maxredirs = 2;
		$snoopy->offsiteok = false;
		$snoopy->expandlinks = false;
		$snoopy->user = "joe";
		$snoopy->pass = "bloe";
		
		
		echo "<Result><Value>";
		if ($snoopy->fetchtext($rsite)) {
			$snoopy->fetchlinks($rsite);
			$pos = "";
			foreach ($snoopy->results as $row) {
				if (eregi(".jpg", $row) || eregi(".gif", $row)|| eregi(".gif", $row))
				{
					if (eregi(".gif", $row))
					{
						$pos = strpos($row, ".gif");
					}
					if (eregi(".png", $row))
					{
						$pos = strpos($row, ".png");
					}
					if (eregi(".jpg", $row))
					{
						$pos = strpos($row, ".jpg");
					}
					if (eregi(".jpeg", $row))
					{
						$pos = strpos($row, ".jpeg");
					}
					$images = explode("/imgres?imgurl=", $row);
					$image = preg_split('/&/', $images[1]);
					//print_r($image);
					$imagetitle = preg_split('/amp;imgrefurl=/', $image[1]);
					/*
					 echo "<a href=\"".$image."\">";
					 echo "<img src=\"" . rawurldecode($image) . "\" width=\"150px\" width=\"150px\" border=\"0\">";
					 echo "</a>";
					 */
					echo "<img".$lv.">" . $image[0] . "</img".$lv.">";
					echo "<title".$lv.">" . $imagetitle[0] . "</title".$lv.">";
					$lv++;
				}
			}
			//echo "<img22>".$rsite."<img22>";
		}
		else {
			echo "Can�t fetch " . $rsite;
		}
		echo "</Value></Result>";
	}
}
?>