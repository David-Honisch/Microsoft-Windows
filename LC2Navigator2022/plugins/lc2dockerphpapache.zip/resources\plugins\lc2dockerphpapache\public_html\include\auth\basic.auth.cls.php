<?php
function require_auth()
{
	$AUTH_USER = 'admin';
	$AUTH_PASS = 'rootpassword';

	session_start();

	$authorized = false;

	# LOGOUT
	if (isset($_REQUEST['logout']) && !isset($_REQUEST["login"]) && isset($_SESSION['auth'])) {
		$_SESSION = array();
		unset($_COOKIE[session_name()]);
		session_destroy();
		echo "logging out...";
	}

	# checkup login and password
	if (isset($_REQUEST['user']) && isset($_REQUEST['password'])) {
		 if (($AUTH_USER == $_REQUEST['user']) && ($AUTH_PASS == ($_REQUEST['password'])) && isset($_SESSION['auth'])) {
			$authorized = true;
			$_COOKIE[session_name()];
			echo "Loggedin";
		 }
	}
}
function require_basicauth()
{
	$AUTH_USER = 'admin';
	$AUTH_PASS = 'rootpassword';

	if (($_SERVER['PHP_AUTH_PW'] != $AUTH_PASS || $_SERVER['PHP_AUTH_USER'] != $AUTH_USER) || !$_SERVER['PHP_AUTH_USER']) {
		header('WWW-Authenticate: Basic realm="Test auth"');
		header('HTTP/1.0 401 Unauthorized');
		echo 'Auth failed';
		exit;
	}
}
function require_authredirect()
{
	session_start();
	if (!isset($_SESSION['realm'])) {
		$_SESSION['realm'] = mt_rand(1, 1000000000) .
			" SECOND level: Enter your !!!COMPANY!!! password.";

		header("WWW-Authenticate: Basic realm=" . $_SESSION['realm']);
		echo "<meta http-equiv=\"REFRESH\"
                content=\"0;url=index.php\">";
		exit;
	}

	if ($_POST['logout'] == "logout") {
		session_destroy();
		header('Location: comeagain.php');
		exit;
	}
}
function require_auth_cookie()
{
	// 	"http://localhost/admin/?login" - for Login,
	// "http://localhost/admin/?logout" - for Logout,
	// "http://localhost/admin/?logout&login" - for Re-Login.
	$AUTH_USER = 'admin';
	$AUTH_PASS = 'rootpassword';

	session_start();

	$authorized = false;

	# LOGOUT
	if (isset($_GET['logout']) && !isset($_GET["login"]) && isset($_SESSION['auth'])) {
		$_SESSION = array();
		unset($_COOKIE[session_name()]);
		session_destroy();
		echo "logging out...";
	}

	# checkup login and password
	if (isset($_SERVER['PHP_AUTH_USER']) && isset($_SERVER['PHP_AUTH_PW'])) {
		if (($AUTH_USER == $_SERVER['PHP_AUTH_USER']) && ($AUTH_PASS == ($_SERVER['PHP_AUTH_PW'])) && isset($_SESSION['auth'])) {
			$authorized = true;
		}
	}

	# login
	if (
		isset($_GET["login"]) && !$authorized ||
		# relogin
		isset($_GET["login"]) && isset($_GET["logout"]) && !isset($_SESSION['reauth'])
	) {
		header('WWW-Authenticate: Basic Realm="Login please"');
		header('HTTP/1.0 401 Unauthorized');
		$_SESSION['auth'] = true;
		$_SESSION['reauth'] = true;
		echo "Login now or forever hold your clicks...";
		exit;
	}
	$_SESSION['reauth'] = null;
	// <h1>you have <? echo ($authorized) ? (isset($_GET["login"]) && isset($_GET["logout"]) ? 're' : '') : 'not '; logged!</h1>
}

function require_basic_auth()
{

	$AUTH_USER = 'admin';
	$AUTH_PASS = 'rootpassword';
	header('Cache-Control: no-cache, must-revalidate, max-age=0');
	$has_supplied_credentials = !(empty($_SERVER['PHP_AUTH_USER']) && empty($_SERVER['PHP_AUTH_PW']));
	$is_not_authenticated = (!$has_supplied_credentials ||
		$_SERVER['PHP_AUTH_USER'] != $AUTH_USER ||
		$_SERVER['PHP_AUTH_PW']   != $AUTH_PASS
	);
	if ($is_not_authenticated) {
		header('HTTP/1.1 401 Authorization Required');
		header('WWW-Authenticate: Basic realm="Access denied"');
		exit;
	}
}
function require_basic_auth_revalidate()
{
	$valid_passwords = array("admin" => "rootpassword");
	$valid_users = array_keys($valid_passwords);

	$user = $_SERVER['PHP_AUTH_USER'];
	$pass = $_SERVER['PHP_AUTH_PW'];

	$validated = (in_array($user, $valid_users)) && ($pass == $valid_passwords[$user]);

	if (!$validated) {
		header('WWW-Authenticate: Basic realm="My Realm"');
		header('HTTP/1.0 401 Unauthorized');
		die("Not authorized");
	}
}
