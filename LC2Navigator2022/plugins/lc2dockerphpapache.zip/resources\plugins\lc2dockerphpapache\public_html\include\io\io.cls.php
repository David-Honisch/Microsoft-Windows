<?php
// Direkt Aufruf verhindern....
if (strpos( "io.cls.php", $_SERVER ['PHP_SELF'] )) {Header ( "Location:/index.php" );die ();}
// class IO 
class IO {
// 	// function _scandir($dir,$dir2, $pos=2)
// 	function __construct($dir, $datei, $pos = 2) {
// 		// echo $dir."-".$datei;
// 		if ($pos == 2) {
// 			// echo "Der aktuelle Pfad ist:&nbsp;<script>path();</script>";
// 		}
		
// 		$handle = @opendir ( $dir );
// 		while ( $file = @readdir ( $handle ) ) {
// 			if (eregi ( "^\.{1,2}$", $file )) {
// 				continue;
// 			}
// 			if (is_dir ( $dir . $file )) {
// 				// Verzeichnisse werden geschrieben
// 				// fputs($fp,$file);
// 				echo "<div class=\"btabli\">";
// 				// echo "<strong><a href=\"$dir2$file\">";
// 				echo "<a href=\"./?q=plugins&amp;value=$datei&amp;pattern=$file\" >";
// 				echo $dir2 . $file;
// 				echo "</a>";
// 				echo "</div>";
// 			}
// 		}
		
// 		@closedir ( $handle );
// 		// schliesse Dateien
// 		// fclose($fp);
// 		if ($pos == 2) {
// 			// echo "</a>";
// 		}
// 	}
// 	/**
// 	 * ***************
// 	 * Written by wwwlord@gmx.net
// 	 * *****************
// 	 */
// 	function __construct($dir, $datei, $pos = 2) {
// 		$fp = fopen ( $datei, 'w+' );
// 		// Schreibe den Pfad
// 		// $fp5 = fopen($dir.'pfad.log', 'w+');
// 		// fputs($fp5,"$dir");
// 		// Schreibe lokalen Pfad
// 		// $fp6 = fopen('pfad.log', 'w+');
// 		// fputs($fp6,"$dir");
// 		if ($pos == 2) {
// 			// echo "Der aktuelle Pfad ist:&nbsp;<script>path();</script>";
// 		}
		
// 		$handle = @opendir ( $dir );
// 		while ( $file = @readdir ( $handle ) ) {
// 			if (eregi ( "^\.{1,2}$", $file )) {
// 				continue;
// 			}
// 			if (is_dir ( $dir . $file )) {
// 				// Verzeichnisse werden geschrieben
// 				fputs ( $fp, $file );
// 				fputs ( $fp, "\n" );
// 				// sdir($dir.$file."/", $pos + 0);
// 				// }
// 				// else
// 				// {
// 				// Dateien werden geschrieben
// 				// fputs($fp4,$dir.$file);
// 				// $zeit = fileatime("$dir$file");
// 				// $zeit = fileatime("file");
// 				// $datum = "".gmdate("d M Y<br> H:i:s", $zeit);
// 				// $datum = "".gmdate("d M Y", $zeit);
// 				// fputs($fp3,$datum);
// 				// fputs($fp3,"\n");
// 			}
// 		}
		
// 		@closedir ( $handle );
// 		// schliesse Dateien
// 		fclose ( $fp );
// 		if ($pos == 2) {
// 			// echo "</a>";
// 		}
// 	}
	/**
	 *
	 * @param array $strPath
	 * return array
	 */
	public static function getDirectory($strPath) {
		return scandir ( $strPath );
	}
	
	public static function readDirToArray($path) {
		$result = array ();
		$i = 0;
		$ordner = opendir ( "" . $path );
		while ( $datei = readdir ( $ordner ) ) {
			if ($datei !== "*" && $datei !== "." && $datei !== "..") {
				// echo $datei;
				$result [$i] = $datei;
			}
			$i ++;
		}
	
		// $aResult = new array();
		// $handle = opendir ( "../games/" );
		// // echo "Verzeichnisinhalt:<br>";
		// while ( $datei = readdir ( $handle ) ) {
		// if ($datei != "." || $datei != "..") {
		// echo "<a href=\"";
		// echo "/games/" . $datei;
		// echo "\">";
		// echo "$datei";
		// echo "</a>";
		// echo "<br>";
		// }
		// }
	
		closedir ( $ordner );
		return $result;
	}
}
?>
