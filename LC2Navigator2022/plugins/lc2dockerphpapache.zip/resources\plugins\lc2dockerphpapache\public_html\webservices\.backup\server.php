<?php
/**
 * ProcessSimpleType method
 * @param string $who name of the person we'll say hello to
 * @return string $helloText the hello  string
 */
//functions
//require "./include/functions/functions.cls.php";
require "./include/functions/functions.json.cls.php";
require "./include/functions/functions.xml.cls.php";
require "./include/functions/functions.calendar.cls.php";
require "./include/functions/functions.file.cls.php";
require "./include/functions/functions.tasks.cls.php";
require "./include/functions/functions.auth.cls.php";
require "./include/functions/functions.email.cls.php";
require "./include/functions/functions.utils.cls.php";
require "./include/functions/functions.crud.cls.php";
require "./include/functions/functions.content.json.cls.php";
require "./include/functions/functions.date.cls.php";
require "./include/functions/functions.plugins.cls.php";
require "./include/functions/functions.graburls.cls.php";
require "../include/nusoap/lib/nusoap.php";
// $namespace = "http://www.letztechance.org/ws";
$namespace = "http://letztechance.org.org/ws";
// if (doAuthenticate()){echo "Logged in !!";}else{echo "Not Logged in";}
// create a new soap server
$server = new soap_server();
$server->decode_utf8 = true;
$server->soap_defencoding = 'UTF-8';
// configure our WSDL
// $server->configureWSDL("LetztChance.Org Webservice");
$server->configureWSDL("HC WebService");
// set our namespace
$server->wsdl->schemaTargetNamespace = $namespace;
// register our WebMethod
//require_once "./include/register/register.cls.php";
require_once "./include/register/register.calendar.cls.php";
require_once "./include/register/register.json.cls.php";
require_once "./include/register/register.tasks.cls.php";
require_once "./include/register/register.auth.cls.php";
require_once "./include/register/register.email.cls.php";
require_once "./include/register/register.utils.cls.php";
require_once "./include/register/register.crud.cls.php";
require_once "./include/register/register.content.json.cls.php";
require_once "./include/register/register.date.cls.php";
require_once "./include/register/register.plugins.cls.php";
require_once "./include/register/register.graburls.cls.php";

// require_once("./include/register-plugins.cls.php");
// Get our posted data if the service is being consumed
// otherwise leave this data blank.
// $POST_DATA = isset($GLOBALS['HTTP_RAW_POST_DATA'])
// ? $GLOBALS['HTTP_RAW_POST_DATA'] : '';
// pass our posted data (or nothing) to the soap service
// $server->service($POST_DATA);
$server->service(file_get_contents("php://input"));
exit();
