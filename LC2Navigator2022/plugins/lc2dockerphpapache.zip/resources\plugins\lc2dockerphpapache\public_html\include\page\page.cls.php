<?php
class Page
{
    public static function getPage($q)
    {
        switch ($q) {
            case 'home':
                include('./view/home/home.cls.php');
                break;
            case 'db':
                include('./view/db/db.cls.php');
                break;
            case 'index':
                include('./view/index/index.cls.php');
                break;
            case 'list':
                include('./view/list/list.cls.php');
                break;
            case 'read':
                include('./view/read/read.cls.php');
                break;
            case 'admin':
                include('./view/admin/admin.cls.php');
                break;

            default:
                include('./view/error.cls.php');
                break;
        }
    }
}
$q = isset($_REQUEST["q"]) ? $_REQUEST["q"] : "home";
$page = new Page();
$page::getPage($q);
