<?php
/**
 * @name XmlDatenBlock
 * @author david@honisch.org
 * @version 1.1
 * @package include.xml
 *
 * v.1.0	16.07.2012	david@honisch.org	Erstellung
 * v.1.1	20.07.2012	david@honisch.org	Alle Exceptions berichten nun auch, bei Welcher Methode der Fehler auftrat
 * Klasse zum Erstellen eines Datenblocks und dessen Attribute
 *
 */
class XmlDatenBlock{

	private $blockData;
	private $blockType;

	public function __construct($blockData,$blockType){
		$this->blockData = $blockData;
		$this->blockType = $blockType;
	}

	/**
	 * Liefert den Typ des Datenblocks
	 */
	public function getType(){
		return $this->blockType;
	}

	/**
	 * Liefert die Daten des Blocks
	 */
	public function get(){
		return $this->blockData;
	}


}
?>