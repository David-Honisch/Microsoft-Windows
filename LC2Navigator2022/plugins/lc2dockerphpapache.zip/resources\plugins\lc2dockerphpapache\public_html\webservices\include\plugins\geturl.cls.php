<?php
function requestedByTheSameDomain()
{
	$myDomain       = isset($_SERVER['SCRIPT_URI']) ? $_SERVER['SCRIPT_URI'] : null;
	$requestsSource = isset($_SERVER['HTTP_REFERER']) ? $_SERVER['HTTP_REFERER'] : null;
	return parse_url($myDomain, PHP_URL_HOST) === parse_url($requestsSource, PHP_URL_HOST);
}
if (!requestedByTheSameDomain()) {
	$result["access"] = "Access denied";
} else {
	$ext_url = isset($_REQUEST['query']) ? $_REQUEST['query'] : $query;
	if ($ext_url == null || $ext_url == "") {
		$result["missing parameter"] = "Type a parameter query=";
	} else {
		$ext_url = isset($_REQUEST['apikey']) ? $ext_url . "&apikey=" . $_REQUEST['apikey'] : $ext_url;
		// echo "OUT:".$ext_url;
		// $result= file_get_contents_curl($ext_url);
	}
}
function file_get_contents_curl($url)
{
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_HEADER, 0);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1); //Set curl to return the data instead of printing it to the browser.
	curl_setopt($ch, CURLOPT_URL, $url);
	$data = curl_exec($ch);
	curl_close($ch);
	return $data;
}
?>
<?php
if (!isset($env) && empty($env)) {
	if (file_exists("../config/const.cls.php")) {
		require("../config/const.cls.php");
	} else {
		echo "404 NOT FOUND";
		die();
	}
}
if (file_exists($env["docroot"] . "include/snoopy/Snoopy.class.php")) {
	include $env["docroot"] . "include/snoopy/Snoopy.class.php";
} else {
	echo "404-Parser not found...";
}
$links;
$content = file_get_contents_curl($ext_url);
preg_match_all('#\bhttps?://[^,\s()<>]+(?:\([\w\d]+\)|([^,[:punct:]\s]|/))#', $content, $links);
// print_r($links);
$linkscount = count($links[0]);
$result["data"]["count"] = [$linkscount];
$result["data"] = array();
for ($x = 0; $x <= $linkscount; $x++) {
	if (isset($links[0][$x])) {
		$v = $links[0][$x];
		// if (!strpos($v,'http') === 0) {
			$result["data"][$x] = $v;
		// }
	}
}
?>