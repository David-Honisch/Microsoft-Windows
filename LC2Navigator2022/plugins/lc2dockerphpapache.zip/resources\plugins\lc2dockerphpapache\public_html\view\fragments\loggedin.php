<fieldset>
    <input type="text" value="x" name="user" id="user">
    <input type="text" value="x" name="password" id="password">
    <input type="button" value="Submit" name="loginbutton" id="loginbutton">
</fieldset>
<?PHP
// 	"http://localhost/admin/?login" - for Login,
// "http://localhost/admin/?logout" - for Logout,
// "http://localhost/admin/?logout&login" - for Re-Login.
$AUTH_USER = 'admin';
$AUTH_PASS = 'rootpassword';

// session_start();

$authorized = false;

# LOGOUT
if (isset($_GET['logout']) && !isset($_GET["login"]) && isset($_SESSION['auth'])) {
    $_SESSION = array();
    unset($_COOKIE[session_name()]);
    session_destroy();
    echo "logging out...";
}

# checkup login and password
if (isset($_REQUEST['user']) && isset($_REQUEST['password'])) {
    echo "Logging in...";
    if (($AUTH_USER == $_REQUEST['user']) && ($AUTH_PASS == ($_REQUEST['password']))) { //&& isset($_SESSION['auth'])) {
        $authorized = true;
        echo "Logged in...";
    }
}

?>
 <script src="assets/js/actions/auth.js"></script>
<?PHP
//echo "Logging in...";
?>
<script>
    $("#loginbutton").click(function() {
        console.log('Login');
        $.ajax({
            type: "POST",
            url: authAPI,
            q: "getAuth",
            user: $('#user').val(),
            pass: $('#password').val(),
            data: {
                q: "getAuth",
                user: $('#user').val(),
                pass: $('#password').val(),
            },
            //contentType: "application/json; charset=utf-8",
            dataType: "json",
            success: function(data) {
                // $('#loggedin').append(JSON.stringify(data) + "<hr>");
                var session = data[0]["session"];
                // $('#loggedin').append(JSON.stringify(data["data"]) + "<hr>");
                var localsession = data["data"]["0"]["session"];
                var userName = data[0]["userName"];
                // $('#loggedin').append(session + "<hr>");
                if (session.startsWith("LC2Token-RSA-a22343sZIA4C22211sTB33331112")) {
                    ssess = session.replace("LC2Token-RSA-a22343sZIA4C22211sTB33331112","");
                    // $('#loggedin').append("Session:"+ssess);
                    // $('#loggedin').append("localSession:"+localsession);
                    if (userName ==  $('#user').val() && localsession == ssess) {
                        $('#loggedin').append("LoggedIn<hr>");
                    }
                } else {
                    $('#loggedin').append("NOT LoggedIn<hr>");
                }
                console.log(JSON.stringify(session));
                console.log(JSON.stringify(data));

            },
            error: function(errMsg) {
                console.error(errMsg);
            }
        });
    });
</script>