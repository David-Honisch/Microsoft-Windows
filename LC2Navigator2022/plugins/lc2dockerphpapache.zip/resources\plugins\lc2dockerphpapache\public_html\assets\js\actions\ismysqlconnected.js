  var url = "/view/index.php";
  var infoAPI = "http://localhost/webservices/client.php?q=getINFO";
  $('#out').html("running...")
      // $("#out").load("/view/index.php");
  $("#out").load(url, function(responseTxt, statusTxt, xhr) {
      if (statusTxt == "success")
          $('#out').append(".");
      if (statusTxt == "error")
          $('#out').append("Error: " + xhr.status + ": " + xhr.statusText);
  });
  $.get(url, function(data, status) {
      $('#out').append("Data: " + data + "\nStatus: " + status);
  });
  $.get(infoAPI + "&value1=test&value2=test", function(data, status) {
      $('#out').append("infoAPI Data: " + data + "\nStatus: " + status);
  });
  $("#postbutton").click(function() {
      $.post(infoAPI, {
              q: "getINFO",
              value1: "Donald+Duck",
          },
          function(data, status) {
              $('#out').append("Data: " + data + "\nStatus: " + status);
          });
      $.get(infoAPI + "&value1=test&value2=test", function(data, status) {
          $('#out').append("infoAPI Data: " + data + "\nStatus: " + status);
      });
  });