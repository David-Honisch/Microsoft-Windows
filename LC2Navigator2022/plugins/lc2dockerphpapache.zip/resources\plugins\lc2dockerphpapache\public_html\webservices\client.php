<?php
/*
 * Client v1.0. Service: SOAP endpoint Payload: rpc/encoded Transport: http Authentication: none
 */
require_once "./server.php";
