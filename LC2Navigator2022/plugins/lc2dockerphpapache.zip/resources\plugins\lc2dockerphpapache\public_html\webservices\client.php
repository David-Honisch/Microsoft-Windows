<?php
/*
 * Client v1.0. Service: SOAP endpoint Payload: rpc/encoded Transport: http Authentication: none
 */
require_once "../config/const.cls.php";
require_once $env["include"] . "nusoap/lib/nusoap.php";
// require_once('../include/xml2array.cls.php');
// if (strpos($_REQUEST ['isDebug'],"true")===0)
// echo $_REQUEST ['isDebug'];
$result = "";
// $isSort = isset($_REQUEST['isSort']) && (strpos($_REQUEST['isSort'], "asc") === "0" || strpos($_REQUEST['sort'], "asc") === 0) ? true : false;
// $isDebug = isset($_REQUEST['isDebug']) ? (strpos($_REQUEST['isDebug'], "true") === 0) ? true : false : false;
// // $strQuery = isset ( $_POST ['query'] ) ? $_POST ['query'] : '';
$proxyhost = isset($_POST['proxyhost']) ? $_POST['proxyhost'] : '';
$proxyport = isset($_POST['proxyport']) ? $_POST['proxyport'] : '';
$proxyusername = isset($_POST['proxyusername']) ? $_POST['proxyusername'] : '';
$proxypassword = isset($_POST['proxypassword']) ? $_POST['proxypassword'] : '';
$useCURL = isset($_POST['usecurl']) ? $_POST['usecurl'] : '0';
$client = new nusoap_client($env["WebService"], false, $proxyhost, $proxyport, $proxyusername, $proxypassword);
// //$client = new nusoap_client("https://www.letztechance.org/ws/server.php", false, $proxyhost, $proxyport, $proxyusername, $proxypassword);


// $err = $client->getError();
// if ($err) {
//     echo '<h2>Constructor error</h2><pre>' . $err . '</pre>';
//     echo '<h2>Debug</h2><pre>' . htmlspecialchars($client->getDebug(), ENT_QUOTES) . '</pre>';
//     exit();
// }
// $client->setUseCurl($useCURL);
// $client->soap_defencoding = 'UTF-8';
// //
// //
// $client->setCredentials(!empty($_REQUEST["user"]) ? $_REQUEST["user"] : 'anonymous', !empty($_REQUEST["pass"]) ? $_REQUEST["pass"] : "", "basic");

// // echo 'You must set your own Google key in the source code to run this client!'; exit();
// $post = file_get_contents('php://input') ?file_get_contents('php://input'):$_POST;
// // $post = json_decode($post, true);

$_q = isset($_REQUEST["q"]) ? $_REQUEST["q"] : (isset($post["q"]) ? $post["q"] : 'error');
// $query = isset($_REQUEST["query"]) ? $_REQUEST["query"] : (isset($post["query"]) ? $post["query"] : '');
$value1 = isset($_REQUEST["value1"]) ? $_REQUEST["value1"] : (isset($post["value1"]) ? $post["value1"] : '');
$value2 = isset($_REQUEST["value2"]) ? $_REQUEST["value2"] : (isset($post["value2"]) ? $post["value2"] : '');
// $value3 = isset($_REQUEST["value3"]) ? $_REQUEST["value3"] : '30';
// $page = isset($_REQUEST["page"]) ? $_REQUEST["page"] : '1';
// //
// $subject = isset($_REQUEST["subject"]) ? $_REQUEST["subject"] : (isset($post["subject"]) ? $post["subject"] : '');
// $body = isset($_REQUEST["body"]) ? $_REQUEST["body"] : (isset($post["body"]) ? $post["body"] : '');
// $body = isset($_REQUEST["ebody"]) ? $_REQUEST["ebody"] : $body;
// $sid = isset($_REQUEST["sid"]) ? $_REQUEST["sid"] : '0';
// $isPHPCode = isset($_REQUEST["isPHPCode"]) ? $_REQUEST["isPHPCode"] : '0';
// $protLevel = isset($_REQUEST["protLevel"]) ? $_REQUEST["protLevel"] : '0';
// $date = isset($_REQUEST["cdate"]) ? $_REQUEST["cdate"] : (isset($post["cdate"]) ? $post["cdate"] : '0');
// $cdate = isset($_REQUEST["cdate"]) ? $_REQUEST["cdate"] : (isset($post["cdate"]) ? $post["cdate"] : '0');
// // echo "Debug:". $cdate;
// $user = isset($_REQUEST["user"]) ? $_REQUEST["user"] : (isset($post["user"]) ? $post["user"] : 'anonymous');
// $pass = isset($_REQUEST["pass"]) ? $_REQUEST["pass"] : (isset($post["pass"]) ? $post["pass"] : 'anonymous');
// // Debug($user);
// $token = isset($_REQUEST["token"]) ? $_REQUEST["token"] : (isset($post["token"]) ? $post["token"] : 'anonymous');
// //email
// $from = isset($_REQUEST["from"]) ? $_REQUEST["from"] : '';
// $replyto = isset($_REQUEST["replyto"]) ? $_REQUEST["replyto"] : '';

// //
// //calendar
// $location = isset($_REQUEST["location"]) ? $_REQUEST["location"] : '';
// $date = isset($_REQUEST["date"]) ? $_REQUEST["date"] : '';
// $startdate = isset($_REQUEST["startdate"]) ? $_REQUEST["startdate"] : '';
// $enddate = isset($_REQUEST["enddate"]) ? $_REQUEST["enddate"] : '';

// $file = isset($_REQUEST["file"]) ? $_REQUEST["file"] : '';
// $map = isset($_REQUEST["map"]) ? $_REQUEST["map"] : '';
// $method = isset($_REQUEST["method"]) ? $_REQUEST["method"] : '';
// echo "".$subject.$body;
// Debug($token);

// if (isset($post) && !empty($post)) {
//     //todo !!!!
// }
// Debug($_POST["subject"]);
// Debug($cdate);
switch ($_q) {
    case 'getINFO':
        $params = array(
            // 'value1' => '' . $value1,
            // 'value2' => '' . $value2,
        );
        // print_r($params);
        $result = $client->call("getINFO");
        echo "Result:". $result;
        break;
    case 'getINF22O':
        $params = array(
            'value1' => '' . $value1,
            'value2' => '' . $value2,
        );
        // print_r($params);
        $result = $client->call("getINFO", $params, "urn:String", "urn:String");        
        break;
    case 'getLog':
        $params = array(
            'q' => $_REQUEST,
        );
        $result = $client->call("getLog", $params, "urn:String");
        break;
    case 'getEnvironment':
        $params = array(
            'q' => $_REQUEST,
        );
        $result = $client->call("getEnvironment", $params, "urn:String");
        break;
    case 'getQuery':
        $params = array(
            'q' => $_REQUEST,
        );
        $result = $client->call("getQuery", $params, "urn:String", "urn:String");

        break;
    case 'getAuth':
        // Debug($post["user"]);
        $params = array(
            'user' => '' . $user,
            'pass' => '' . $pass,
        );
        $result = $client->call("getAuth", $params, "urn:String", "urn:String");

        break;
    case 'isAuth':
        $params = array(
            'token' => '' . $token,
        );
        $result = $client->call("isAuth", $params, "urn:String");
        break;
    case 'delToken':
        //         echo "Debug:".$token;
        $params = array(
            'token' => '' . $token,
        );
        $result = $client->call("delToken", $params, "urn:String");
        break;
    
    case 'getContent':
        $params = array(
            'value1' => '' . $value1,
            'value2' => '' . $value2,
        );
        $result = $client->call("getContent", $params, "urn:String", "urn:String");

        break;
    case 'getRead':
        $params = array(
            'value1' => '' . $value1,
            'value2' => '' . $value2,
        );
        $result = $client->call("getRead", $params, "urn:String", "urn:String");

        break;
    case 'getReadJSON':
        $params = array(
            'value1' => '' . $value1,
            'value2' => '' . $value2,
        );
        $result = $client->call("getReadJSON", $params, "urn:String", "urn:String");

        break;
    case 'readJSON':
        $params = array(
            'value1' => '' . $value1,
            'value2' => '' . $value2,
            'value3' => '' . $value3,
        );
        $result = $client->call("readJSON", $params, "urn:String", "urn:String", "urn:String");

        break;
    case 'getLastContent':
        $params = array(
            'value1' => '' . $value1,
        );
        $result = $client->call("getLastContent", $params, "urn:String");
        break;
    case 'getIndex':
        $params = array(
            'value1' => '' . $value1,
            'value2' => '' . $value2,
        );
        $result = $client->call("getIndex", $params, "urn:String", "urn:String");

        break;
    case 'getIndexJSON':
        $params = array(
            'value1' => '' . $value1
            // 'value2' => '' . $value2,
        );
        $result = $client->call("getIndexJSON", $params, "urn:String", "urn:String");

        break;
    case 'getFullIndexJSON':
        $params = array();
        $result = $client->call("getFullIndexJSON", $params, "urn:String", "urn:String");

        break;

    case 'getList':
        $params = array(
            'value1' => '' . $value1,
            'value2' => '' . $value2,
        );
        $result = $client->call("getList", $params, "urn:String", "urn:String");

        break;
    case 'getListHeadersJSON':
        $params = array(
            'value1' => '' . $value1,
            'value2' => '' . $value2,
        );
        $result = $client->call("getListHeadersJSON", $params, "urn:String", "urn:String");

        break;
    case 'getListJSON':
        $params = array(
            'value1' => '' . $value1,
            'value2' => '' . $value2,
        );
        $result = $client->call("getListJSON", $params, "urn:String", "urn:String");

        break;
    case 'getListByNumber':
        $params = array(
            'value1' => '' . $value1,
            'value2' => '' . $value2,
        );
        $result = $client->call("getListByNumber", $params, "urn:String", "urn:String");

        break;
    case 'getSearch':
        $params = array(
            'query' => '' . $query,
            'value1' => '' . $value1,
            'value2' => '' . $value2,
            'isSort' => '' . $isSort,
        );
        $result = $client->call("getSearch", $params, "urn:String", "urn:String");

        break;
    case 'getSearchJSON':
        $params = array(
            'value1' => '' . $value1,
            'value2' => '' . $value2,
        );
        $result = $client->call("getSearchJSON", $params, "urn:String", "urn:String");

        break;
    case 'getLinkedDays':
        $params = array(
            'Key' => '' . $value1,
        );
        $result = $client->call("getLinkedDays", $params, "urn:String", "urn:String");
        break;
    case 'getPage':
        $params = array(
            'Key' => '' . $value1,
        );
        $result = $client->call("getPage", $params, "urn:String");
        break;
    case 'getLang':
        $params = array(
            'Key' => "" . isset($value1) ? $value1 : "de_DE",
        );
        $result = $client->call("getLang", $params, "urn:String");
        break;
    case 'getTags':
        $params = array();
        // 'Key' => "" . isset ( $value1 ) ? $value1 : "de_DE"

        $result = $client->call("getTags", $params, "urn:String");
        break;
    case 'getFullCalendar':
        $params = array(
            'Date' => "" . isset($cdate) ? $cdate : "1491256800",
        );
        $result = $client->call("getFullCalendar", $params, "urn:String");
        break;
    case 'getLinkedDays':
        $params = array(
            'Date' => "" . isset($value1) ? $value1 : "1491256800",
        );
        $result = $client->call("getLinkedDays", $params, "urn:String");
        break;
        //
    case 'getRemoteFile':
        $params = array(
            'Date' => "" . isset($value1) ? $value1 : "1491256800",
        );
        $result = $client->call("getRemoteFile", $params, "urn:String");
        break;
        //
    case 'getImageSearch':
        $params = array(
            'query' => '' . $value1,
            'value1' => '' . $value2,
        );
        $result = $client->call("getImageSearch", $params, "urn:String");
        break;
        // getImageSearchJSON
    case 'getImageSearchJSON':
        $params = array(
            'query' => '' . $value1,
            'value1' => '' . $value2,
        );
        $result = $client->call("getImageSearchJSON", $params, "urn:String");
        break;
    case 'getWeather':
        $params = array(
            'query' => '' . $value1,
            'value1' => '' . $value2,
        );
        $result = $client->call("getWeather", $params, "urn:String");
        break;
        //
    case 'getShortWeather':
        $params = array(
            'query' => '' . $value1,
            'value1' => '' . $value2,
        );
        $result = $client->call("getShortWeather", $params, "urn:String");
        break;
        //
    case 'getChatSearchJSON':
        $params = array(
            'query' => '' . $strQuery,
            'value1' => '' . $value2,
        );
        $result = $client->call("getChatSearchJSON", $params, "urn:String");
        break;
    case 'getMovieSearchJSON':
        $params = array(
            'query' => '' . $strQuery,
            'value2' => '' . $value2,
        );
        $result = $client->call("getMovieSearchJSON", $params, "urn:String");
        break;
    case 'getWindowsSearchJSON':
        $params = array(
            'value1' => '' . $value1,
            'value2' => '' . $value2,
        );
        $result = $client->call("getWindowsSearchJSON", $params, "urn:String");
        break;
        //
    case 'doInsert':
        $params = array(
            'token' => '' . $token,
            'date' => '' . $cdate,
            'value1' => '' . $value1,
            'subject' => '' . $subject,
            'body' => '' . $body,
        );
        $result = $client->call("doInsert", $params, "urn:String");
        break;
    case 'doUpdate':
        $params = array(
            'token' => '' . $token,
            'date' => '' . $cdate,
            'value1' => '' . $value1,
            'value2' => '' . $value2,
            'subject' => '' . $subject,
            'body' => '' . $body,
            //        'protLevel' => '' . $protLevel,
            //        'isPHPCode' => '' . $isPHPCode
        );
        //    print_r($params);
        //$result = $client->call("doUpdate", $params, "urn:String", "urn:String", "urn:String", "urn:String");
        $result = $client->call("doUpdate", $params, "urn:String");
        break;

    case 'Insert':
        $params = array(
            'value1' => '' . $value1,
            'subject' => '' . $subject,
            'body' => '' . $body,
        );
        $result = $client->call("Insert", $params, "urn:String");
        break;
        //
    case 'getCreateDate':
        $params = array(
            'date' => '' . $cdate,
            'subject' => '' . $subject,
            'user' => '' . $user,
            'pass' => '' . $pass,
        );
        $result = $client->call("getCreateDate", $params, "urn:String", "urn:String", "urn:String", "urn:String");
        break;
    case 'getCreateSingle':
        // echo "getCreateSingle";
        $params = array(
            'value1' => '' . $value1,
            'value2' => '' . $value2,
            'date' => '' . $cdate,
            'subject' => '' . $subject,
            'body' => '' . $body,
            'sid' => '' . $sid,
            'isPHPCode' => '' . $isPHPCode,
            'user' => '' . $user,
            'pass' => '' . $pass,
        );
        $result = $client->call("getCreateSingle", $params, "urn:String", "urn:String", "urn:String", "urn:String");
        break;
    case 'getDeleteSingle':
        // echo "getCreateSingle";
        $params = array(
            'value1' => '' . $value1,
            'value2' => '' . $value2,
            'date' => '' . $date,
            'subject' => '' . $subject,
            'body' => '' . $body,
            'sid' => '' . $sid,
            'isPHPCode' => '' . $isPHPCode,
            'user' => '' . $user,
            'pass' => '' . $pass,
        );
        $result = $client->call("getDeleteSingle", $params, "urn:String", "urn:String", "urn:String", "urn:String");
        break;
    case 'getGames':
        $params = array(
            'value1' => '' . $value1,
            'value2' => '' . $value2,
        );
        $result = $client->call("getGames", $params, "urn:String", "urn:String");

        break;
    case 'getUploads':
        $params = array(
            'file' => '' . $value1,
        );
        $result = $client->call("getUploads", $params, "urn:String");

        break;
    case 'getFile':
        $params = array(
            'file' => '' . $file,
        );
        $result = $client->call("getFile", $params, "urn:String");

        break;
    case 'getGeoLocation':
        $params = array(
            'date' => '' . $value1,
        );
        $result = $client->call("getGeoLocation", $params, "urn:String");

        break;
        //
    case 'getTaskListJSON':
        $params = array(
            'user' => '' . $value1,
            'categoryid' => '' . $value2,
        );
        $result = $client->call("getTaskListJSON", $params, "urn:String", "urn:String");

        break;
        //
    case 'sendMail':
        $params = array(
            'from' => '' . $from,
            'replyto' => '' . $replyto,
            'subject' => '' . $subject,
            'body' => '' . $body,
        );
        $result = $client->call("sendMail", $params, "urn:String", "urn:String", "urn:String", "urn:String");
        break;
    case 'getContentSearch':
        $params = array(
            'query' => '' . $query,
            'value1' => '' . $page,
            'value2' => '' . $value2,
            'isSorted' => '' . $value3,
        );
        $result = $client->call("getContentSearch", $params, "urn:String", "urn:String", "urn:String", "urn:String");
        break;
    case 'getCalendarDays':
        $params = array(
            'location' => '' . $location,
            'date' => '' . $date,
            'startdate' => '' . $startdate,
            'enddate' => '' . $enddate,
        );
        $result = $client->call("getCalendarDays", $params, "urn:String", "urn:String", "urn:String", "urn:String");

        break;

    case 'getPlugins':
        $client->timeout = 3000;
        $client->response_timeout = 3000;
        $params = array(
            'query' => '' . $query,
            'method' => '' . $method,
        );
        $result = $client->call("getPlugins", $params, "urn:String", "urn:String");
        break;
    case 'getGrabUrls':
        $params = array(
            'query' => '' . $query,
            'table' => '' . $method,
        );
        $result = $client->call("getGrabUrls", $params, "urn:String", "urn:String", "urn:String", "urn:String");
        break;
    case 'getQR':
        // echo "Q:".$query;
        $params = array(
            'text' => '' . $query,
        );
        $result = $client->call("getQR", $params, "urn:String", "urn:String", "urn:String", "urn:String");

        break;
    case 'getMap':
        $params = array(
            'map' => '' . $map,
            'query' => '' . $query,
        );
        $result = $client->call("getMap", $params, "urn:String", "urn:String", "urn:String", "urn:String");

        break;
    default:
        echo "Webmethod not found. Displaying Default data";
        $params = array(
            'Key' => '' . $value1,
        );
        $result = $client->call("getPage", $params, "urn:String");
        break;
}
$isDebug = false;
if ($isDebug == true) {
    if ($client->fault) {
        echo '<h2>Fault</h2><pre>';
        print_r($result);
        echo '</pre>';
    } else {
        $err = $client->getError();
        if ($err) {
            echo '<h2>Error</h2><pre>' . $err . '</pre>';
        } else {
            if ($isDebug == "yes" || $isDebug == true) {
                echo '<h2>Result</h2><pre>';
                print_r($result);
                echo '</pre>';
            }
        }
    }
}
//echo '<h2>Request</h2><pre>' . htmlspecialchars ( $client->request, ENT_QUOTES ) . '</pre>';
echo '<h2>Response</h2><pre>' . htmlspecialchars ( $client->response, ENT_QUOTES ) . '</pre>';
//echo '<h2>Debug</h2><pre>' . htmlspecialchars ( $client->getDebug (), ENT_QUOTES ) . '</pre>';

if ($isDebug == "yes") {
    echo "\n";
    echo "<h2>Webservice Client Output:</h2>";
    echo "<hr>";
    echo $result;
    echo "<hr>";
    $result = xml2ArrayFunction::xml2array($result);
    print_r($result);
    foreach ($result as $v1 => $k1) {
        echo $v1;
        echo $k1;
        foreach ($k1 as $v2 => $k2) {
            // echo "-".$k2;
            // echo $v2;
            foreach ($k2 as $v3 => $k3) {
                echo $k3["id"];
                echo $k3["subject"];
            }
        }
    }
}
//echo $result;
if (!is_array($result)) {
    echo $result;
} else {
    echo json_encode($result);
}
