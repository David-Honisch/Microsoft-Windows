<?php
if (strpos("getallcalendardates.cls.php", $_SERVER['PHP_SELF'])) {
    Header("Location:/index.php");
    die();
}
class DatabaseUtil
{
    public function get($db, $sql)
    {
        $rs = null;
        try {
            $rs = $db->Execute($sql);
        } catch (Exception $e) {
            throw $e;
        }
        return $rs->GetAll();

    }

    public function getJSONFile($fileName)
    {
        $string = file_get_contents($fileName);
        return json_decode($string, true);
    }
}
$o = new DatabaseUtil();
$result["data"]["single"] = $o->get($db,"SELECT * FROM allcountsstatistic");
// ini_set('default_socket_timeout', 500);
// $sql = "SELECT (SELECT count(saf.name) FROM allforums saf where saf.name = af.name) as 'count', datestamp, name".
//        " FROM printstatistic af ".
//        "".
//        " group by af.name order by af.name asc,af.datestamp desc".
//        " limit 1000";
$sql = "SELECT * FROM neues limit 10";
// echo $sql;
@$result["data"]["all"] = $o->get($db,$sql);
// ini_set('default_socket_timeout', 300);