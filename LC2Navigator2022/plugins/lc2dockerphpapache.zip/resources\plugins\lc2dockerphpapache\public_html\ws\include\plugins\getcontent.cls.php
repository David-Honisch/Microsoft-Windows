<?php
function requestedByTheSameDomain() {
    $myDomain       = $_SERVER['SCRIPT_URI'];
    $requestsSource = $_SERVER['HTTP_REFERER'];

    return parse_url($myDomain, PHP_URL_HOST) === parse_url($requestsSource, PHP_URL_HOST);
}
if (!requestedByTheSameDomain())
{
    echo "Access denied";
}
$ext_url = isset($_REQUEST['ext_url']) ? $_REQUEST['ext_url'] : "";
if ($ext_url == null || $ext_url == "") {
    echo "Type a parameter ext_url:";
} else {
    $ext_url = isset($_REQUEST['apikey']) ? $ext_url."&apikey=".$_REQUEST['apikey'] : $ext_url;
    // echo "OUT:".$ext_url;
    echo file_get_contents_curl($ext_url);

    // echo file_get_contents($ext_url);
    // $curl_handle = curl_init();
    // curl_setopt($curl_handle, CURLOPT_URL, $ext_url);
    // curl_setopt($curl_handle, CURLOPT_CONNECTTIMEOUT, 2);
    // curl_setopt($curl_handle, CURLOPT_RETURNTRANSFER, 1);
    // curl_setopt($curl_handle, CURLOPT_USERAGENT, 'LC Reader v.1.1');
    // $query = curl_exec($curl_handle);
    // curl_close($curl_handle);
    // echo "<h1>Response</h1>"+$query;
    // $json_is = "https://www.google.com/search?source=hp&ei=nZQgX-quH8uaa-LaiZgH&q=test&oq=test&gs_lcp=CgZwc3ktYWIQAzIFCAAQsQMyBQgAELEDMgUIABCxAzIFCAAQsQMyBQgAELEDMgUIABCxAzIFCAAQsQMyAggAMgUIABCxAzICCAA6CAgAELEDEIMBOggILhCxAxCDAVD7FliHHGCJHWgAcAB4AIABTYgB_gGSAQE0mAEAoAEBqgEHZ3dzLXdpeg&sclient=psy-ab&ved=0ahUKEwiq8cGd7vDqAhVLzRoKHWJtAnMQ4dUDCAg&uact=5";
    // $video_info = json_decode(file_get_contents($json_is), true);
    // $video_title = is_array($video_info) ? $video_info['feed']['entry'][0]['title']['$t'] : '';
}
function file_get_contents_curl($url) {
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_HEADER, 0);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1); //Set curl to return the data instead of printing it to the browser.
    curl_setopt($ch, CURLOPT_URL, $url);
    $data = curl_exec($ch);
    curl_close($ch);
    return $data;
    }