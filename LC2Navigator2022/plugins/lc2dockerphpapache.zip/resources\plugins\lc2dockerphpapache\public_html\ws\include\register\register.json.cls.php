<?php
/**
 * ProcessSimpleType method
 * @param string $who name of the person we'll say hello to
 * @return string $helloText the hello  string
 */
if (strpos("register.cls.php", $_SERVER['PHP_SELF'])) {
    Header("Location:/index.php");
    die();
}
$server->register(
    // method name:
    'getListHeadersJSON',
    // parameter list:
    array(
        'value1' => 'xsd:string',
        'value2' => 'xsd:string',
    ),
    // return value(s):
    array(
        'return' => 'xsd:string',
    ),
    // namespace:
    $namespace,
    // soapaction: (use default)
    false,
    // style: rpc or document
    'rpc',
    // use: encoded or literal
    'encoded',
    // description: documentation for the method
    'LC2WebService v.1.0 List Headers JSON');
$server->register(
    // method name:
    'getIndexJSON',
    // parameter list:
    array(
        'value1' => 'xsd:string'//,
        // 'value2' => 'xsd:string',

    ),
    // return value(s):
    array(
        'return' => 'xsd:string',
    ),
    // namespace:
    $namespace,
    // soapaction: (use default)
    false,
    // style: rpc or document
    'rpc',
    // use: encoded or literal
    'encoded',
    // description: documentation for the method
    'LC2WebService v.1.0 Index JSON');

$server->register(
    // method name:
    'getFullIndexJSON',
    // parameter list:
    array(
    ),
    // return value(s):
    array(
        'return' => 'xsd:string',
    ),
    // namespace:
    $namespace,
    // soapaction: (use default)
    false,
    // style: rpc or document
    'rpc',
    // use: encoded or literal
    'encoded',
    // description: documentation for the method
    'LC2WebService v.1.0 Full Index JSON');

$server->register(
    // method name:
    'getListJSON',
    // parameter list:
    array(
        'value1' => 'xsd:string',
        'value2' => 'xsd:string',
    ),
    // return value(s):
    array(
        'return' => 'xsd:string',
    ),
    // namespace:
    $namespace,
    // soapaction: (use default)
    false,
    // style: rpc or document
    'rpc',
    // use: encoded or literal
    'encoded',
    // description: documentation for the method
    'LC2WebService v.1.0 List JSON');
// --------------------------------------------------------->
// Read
// --------------------------------------------------------->
$server->register(
    // method name:
    'getReadJSON',
    // parameter list:
    array(
        'value1' => 'xsd:string',
        'value2' => 'xsd:string',
    ),
    // return value(s):
    array(
        'return' => 'xsd:string',
    ),
    // namespace:
    $namespace,
    // soapaction: (use default)
    false,
    // style: rpc or document
    'rpc',
    // use: encoded or literal
    'encoded',
    // description: documentation for the method
    'LC2WebService v.1.0 Read JSON');
// --------------------------------------------------------->
// EOF Read
// --------------------------------------------------------->
// --------------------------------------------------------->
// Read
// --------------------------------------------------------->
$server->register(
    // method name:
    'getLastContent',
    // parameter list:
    array(
        'value1' => 'xsd:string',
    ),
    // return value(s):
    array(
        'return' => 'xsd:string',
    ),
    // namespace:
    $namespace,
    // soapaction: (use default)
    false,
    // style: rpc or document
    'rpc',
    // use: encoded or literal
    'encoded',
    // description: documentation for the method
    'LC2WebService v.1.0 getLastContent');

$server->register(
    // method name:
    'getSearch',
    // parameter list:
    array(
        'query' => 'xsd:string',
        'value1' => 'xsd:string',
        'value2' => 'xsd:string',
        'isSort' => 'xsd:string',
    ),
    // return value(s):
    array(
        'return' => 'xsd:string',
    ),
    // namespace:
    $namespace,
    // soapaction: (use default)
    false,
    // style: rpc or document
    'rpc',
    // use: encoded or literal
    'encoded',
    // description: documentation for the method
    'LC2WebService v.1.0 getSearch');
// // --------------------------------------------------------->
// // get Tags
// // --------------------------------------------------------->
$server->register(
    // method name:
    'getTags',
    // parameter list:
    array(),
    // return value(s):
    array(
        'return' => 'xsd:string',
    ),
    // namespace:
    $namespace,
    // soapaction: (use default)
    false,
    // style: rpc or document
    'rpc',
    // use: encoded or literal
    'encoded',
    // description: documentation for the method
    'LC2WebService v.1.0 get tags');

// --------------------------------------------------------->
// Sqlite
// --------------------------------------------------------->
$server->register(
    // method name:
    'getGames',
    // parameter list:
    // array('name'=>'xsd:string'),
    array(
        'value1' => 'xsd:string',
        'subject' => 'xsd:string',
        'body' => 'xsd:string',
    ),
    // return value(s):
    array(
        'return' => 'xsd:string',
    ),
    // namespace:
    $namespace,
    // soapaction: (use default)
    false,
    // style: rpc or document
    'rpc',
    // use: encoded or literal
    'encoded',
    // description: documentation for the method
    'LC2WebService getGames');

// --------------------------------------------------------->
// Get calender events from DB or Filesystem(soon)...
// --------------------------------------------------------->
$server->register(
    // method name:
    'getFullCalendar',
    // parameter list:
    // array('name'=>'xsd:string'),
    array(
        'value1' => 'xsd:string',
    ),
    // return value(s):
    array(
        'return' => 'xsd:string',
    ),
    // namespace:
    $namespace,
    // soapaction: (use default)
    false,
    // style: rpc or document
    'rpc',
    // use: encoded or literal
    'encoded',
    // description: documentation for the method
    'LC2WebService getFullCalendar');
// --------------------------------------------------------->
// Get linked days from DB or Filesystem(soon)...
// --------------------------------------------------------->
$server->register(
    // method name:
    'getLinkedDays',
    // parameter list:
    // array('name'=>'xsd:string'),
    array(
        'value1' => 'xsd:string',
    ),
    // return value(s):
    array(
        'return' => 'xsd:string',
    ),
    // namespace:
    $namespace,
    // soapaction: (use default)
    false,
    // style: rpc or document
    'rpc',
    // use: encoded or literal
    'encoded',
    // description: documentation for the method
    'LC2WebService getLinkedDays');
// --------------------------------------------------------->
// EOF
// --------------------------------------------------------->
// --------------------------------------------------------->
// Get linked days from DB or Filesystem(soon)...
// --------------------------------------------------------->
$server->register(
    // method name:
    'getGeoLocation',
    // parameter list:
    // array('name'=>'xsd:string'),
    array(
        'value1' => 'xsd:string',
    ),
    // return value(s):
    array(
        'return' => 'xsd:string',
    ),
    // namespace:
    $namespace,
    // soapaction: (use default)
    false,
    // style: rpc or document
    'rpc',
    // use: encoded or literal
    'encoded',
    // description: documentation for the method
    'LC2WebService getGeoLocation');
$server->register(
    // method name:
    'getLog',
    // parameter list:
    // array('name'=>'xsd:string'),
    array(
        'value1' => 'xsd:string',
    ),
    // return value(s):
    array(
        'return' => 'xsd:string',
    ),
    // namespace:
    $namespace,
    // soapaction: (use default)
    false,
    // style: rpc or document
    'rpc',
    // use: encoded or literal
    'encoded',
    // description: documentation for the method
    'LC2WebService getLog');
// --------------------------------------------------------->
// EOF
// --------------------------------------------------------->
