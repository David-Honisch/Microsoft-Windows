<?php
class GoogleImageSnoopySearch {
	/**
	 *
	 * @param string $query        	
	 * @param unknown $page        	
	 * @return string
	 */
	public function search($query, $page) {
		$Operation = "";
		// $search = "";
		$start = 1;
		$end = 1;
		// $result = "";
		if (! empty ( $_REQUEST ["Operation"] )) {
			$Operation = $_REQUEST ["Operation"];
		}
		// if (! empty ( $_REQUEST ["search"] )) {
		// $search = preg_replace ( '@/((\&)?PHPSESSID=[a-zA-Z0-9]+(\&)?)/i@', "", $_REQUEST ["search"] );
		// }
		// if (! empty ( $_REQUEST ["query"] )) {
		// $search = preg_replace ( '@/((\&)?PHPSESSID=[a-zA-Z0-9]+(\&)?)/i@', "", $_REQUEST ["query"] );
		// }
		if (! empty ( $page )) {
			$start = preg_replace ( '@/((\&)?PHPSESSID=[a-zA-Z0-9]+(\&)?)/i@', "", $page );
			if ($start > 1) {
				$start = $start * 18;
				$end = $start * 18 + 18;
			}
		}
		// if (! empty ( $_REQUEST ["end"] )) {
		// $end = preg_replace ( '@/((\&)?PHPSESSID=[a-zA-Z0-9]+(\&)?)/i@', "", $_REQUEST ["end"] );
		// }
		// if (empty ( $query )) {
		// $search = $query;
		// }
		// if (empty ( $search )) {
		// $search = "test";
		// }
		if (! empty ( $query )) {
			$query = preg_replace ( '@/((\&)?PHPSESSID=[a-zA-Z0-9]+(\&)?)/i@', "", $query );
		}
		// $end = preg_replace ( '@/((\&)?PHPSESSID=[a-zA-Z0-9]+(\&)?)/i@', "", $_REQUEST ["end"] );
		// }
		$rsite = "http://images.google.de/images?q=" . $query . "&oe=utf-8&start=" . $start . "&sa=" . $end . "";
		//
		//echo "Debug:". $rsite;
		switch (strtoupper ( $Operation )) {
			case "MULTIPLY" :
				echo " < Result > < Value > " . ($Value1 * $Value2) . " < / Value > < / Result > ";
				exit ();
			
			case " ADD " :
				echo " < Result > < Value > " . ($Value1 + $Value2) . " < / Value > < / Result > ";
				exit ();
			
			case " CONCAT " :
				echo " < Result > < Value > $Value1 $Value2 < / Value > < / Result > ";
				exit ();
			
			default :
				
				// header(" HTTP / 1.1 501 Not supported ");
				// echo " < Result > < Error > The operation is not supported . < / Error > < / Result >";
				// echo $rsite;
				$gi = new GoogleImageSnoopySearch ();
				$result = $gi->GI ( $rsite, $query );
		}
		return $result;
	}
	function getThumbshotCode($url, $scale = 6) {
		$baseurl = "http://www.m-software.de/screenshot/Screenshot.png";
		$owidth = 900;
		$oheight = 600;
		$url = urlencode ( $url );
		$width = $owidth / $scale;
		$height = $oheight / $scale;
		$thumburl = $baseurl . "?url=" . $url . "&scale=" . $scale;
		$code = "<img src='$thumburl' width='$width' height='$height'/>";
		return $code;
	}
	function GI($rsite, $query) {
		$result = "";
		if (file_exists ( "../include/snoopy/Snoopy.class.php" )) {
			require_once ("../include/snoopy/Snoopy.class.php");
		} else {
			echo "404 - Remote Parser Function File not found.";
			die ();
		}
		$snoopy = new Snoopy ();
		$lv = 0;
		// $snoopy->proxy_host = "my.proxy.host";
		// $snoopy->proxy_port = "8080";
		// $rsite = "http://www.phpbuilder.com";
		
		$snoopy->agent = "(compatible; MSIE 4.01; MSN 2.5; AOL 4.0; Windows 98)";
		$snoopy->referer = "http://www.miecrosnot.com/";
		$snoopy->cookies ["SessionID"] = 238472834723489;
		$snoopy->cookies ["favoriteColor"] = "RED";
		$snoopy->rawheaders ["Pragma"] = "no-cache";
		$snoopy->maxredirs = 2;
		$snoopy->offsiteok = false;
		$snoopy->expandlinks = false;
		$snoopy->user = "joe";
		$snoopy->pass = "bloe";
		$result .= "<?xml version=\"1.0\" encoding=\"UTF-8\"?>";
		$result .= "<NewDataSet>";
		$result .= "<Result><Value>";
		if ($snoopy->fetchtext ( $rsite )) {
			$snoopy->fetchlinks ( $rsite );			
			$pos = "";
			foreach ( $snoopy->results as $row ) {
				$result .= $row;
				if (strpos ( ".gif", $row ) || strpos ( ".jpg", $row ) || strpos ( ".png", $row )) 
				// if (eregi(".jpg", $row) || eregi(".gif", $row)|| eregi(".gif", $row))
				{
					// $result = "Debug";
					if (eregi ( ".gif", $row )) {
						$pos = strpos ( $row, ".gif" );
					}
					if (eregi ( ".png", $row )) {
						$pos = strpos ( $row, ".png" );
					}
					if (eregi ( ".jpg", $row )) {
						$pos = strpos ( $row, ".jpg" );
					}
					if (eregi ( ".jpeg", $row )) {
						$pos = strpos ( $row, ".jpeg" );
					}
					if (eregi ( ".html", $row )) {
						$pos = strpos ( $row, ".html" );
					}
					$images = explode ( "/imgres?imgurl=", $row );
					$image = preg_split ( '/&/', $images [1] );
					// print_r($image);
					$imagetitle = preg_split ( '/amp;imgrefurl=/', $image [1] );
					$result .= "<img" . $lv . ">" . $image [0] . "</img" . $lv . ">\n";
					$result .= "<title" . $lv . ">" . $imagetitle [0] . "</title" . $lv . ">";
					// rsite
					$result .= "<site" . $lv . ">" . $rsite . "</site" . $lv . ">\n";
					$lv ++;
				}
			}
			// echo "<img22>".$rsite."<img22>";
		} else {
			$result .= "Can┤t fetch " . $rsite;
		}
		$result .= "</Value></Result>";
		$result .= "</NewDataSet>";
		// echo $result;
		return $result;
	}
}
