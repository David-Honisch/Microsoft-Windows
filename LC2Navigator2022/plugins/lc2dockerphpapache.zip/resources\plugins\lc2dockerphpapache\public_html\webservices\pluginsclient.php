<?php
/*
 * Client v1.0. Service: SOAP endpoint Payload: rpc/encoded Transport: http Authentication: none
 */
require_once "../config/const.cls.php";
require_once $env["include"] . "nusoap/src/nusoap.php";
// require_once('../include/xml2array.cls.php');
// if (strpos($_REQUEST ['isDebug'],"true")===0)
// echo $_REQUEST ['isDebug'];
$isSort = isset($_REQUEST['isSort']) && (strpos($_REQUEST['isSort'], "asc") === "0" || strpos($_REQUEST['sort'], "asc") === 0) ? true : false;
$isDebug = isset($_REQUEST['isDebug']) ? (strpos($_REQUEST['isDebug'], "true") === 0) ? true : false : false;
// $strQuery = isset ( $_POST ['query'] ) ? $_POST ['query'] : '';
$proxyhost = isset($_POST['proxyhost']) ? $_POST['proxyhost'] : '';
$proxyport = isset($_POST['proxyport']) ? $_POST['proxyport'] : '';
$proxyusername = isset($_POST['proxyusername']) ? $_POST['proxyusername'] : '';
$proxypassword = isset($_POST['proxypassword']) ? $_POST['proxypassword'] : '';
$useCURL = isset($_POST['usecurl']) ? $_POST['usecurl'] : '0';
// echo "Debug:".$env["WebServicePlugins"];
$client = new nusoap_client($env["WebServicePlugins"], false, $proxyhost, $proxyport, $proxyusername, $proxypassword);
$result = "";
$err = $client->getError();
if ($err) {
    echo '<h2>Constructor error</h2><pre>' . $err . '</pre>';
    echo '<h2>Debug</h2><pre>' . htmlspecialchars($client->getDebug(), ENT_QUOTES) . '</pre>';
    exit();
}
$client->setUseCurl($useCURL);
$client->soap_defencoding = 'UTF-8';
$client->setCredentials(!empty($_REQUEST["user"]) ? $_REQUEST["user"] : 'anonymous', !empty($_REQUEST["pass"]) ? $_REQUEST["pass"] : "", "basic");

// echo 'You must set your own Google key in the source code to run this client!'; exit();
$_q = isset($_REQUEST["q"]) ? $_REQUEST["q"] : 'error';
$query = isset($_REQUEST["query"]) ? $_REQUEST["query"] : '';
// Debug($query);
switch ($_q) {
    case 'getINFO':
        $params = array(
            'query' => $query,
        );
        $result = $client->call("getINFO", $params, "urn:String");
        break;
    case 'getMsg':
        $params = array(
            'text' => $query,
        );
        $result = $client->call("getMsg", $params, "urn:String");
        break;
    case 'getQR':
        $params = array(
            'query' => $query,
            'pattern' => $query,
        );
        $result = $client->call("getQR", $params, "urn:String");
        break;

    default:
        // echo "Webmethod not found. Displaying Default data";
        $params = array(
            'Key' => '' . $query,
        );
        $result = $client->call("getPage", $query, "urn:String");
        break;
}
$isDebug = false;
if ($isDebug == true) {
    if ($client->fault) {
        echo '<h2>Fault</h2><pre>';
        print_r($result);
        echo '</pre>';
    } else {
        $err = $client->getError();
        if ($err) {
            echo '<h2>Error</h2><pre>' . $err . '</pre>';
        } else {
            if ($isDebug == "yes" || $isDebug == true) {
                echo '<h2>Result</h2><pre>';
                print_r($result);
                echo '</pre>';
            }
        }
    }
}
//echo '<h2>Request</h2><pre>' . htmlspecialchars ( $client->request, ENT_QUOTES ) . '</pre>';
// echo '<h2>Response</h2><pre>' . htmlspecialchars ( $client->response, ENT_QUOTES ) . '</pre>';
//echo '<h2>Debug</h2><pre>' . htmlspecialchars ( $client->getDebug (), ENT_QUOTES ) . '</pre>';

if ($isDebug == "yes") {
    echo "\n";
    echo "<h2>Webservice Client Output:</h2>";
    echo "<hr>";
    echo $result;
    echo "<hr>";
    $result = xml2ArrayFunction::xml2array($result);
    print_r($result);
    foreach ($result as $v1 => $k1) {
        echo $v1;
        echo $k1;
        foreach ($k1 as $v2 => $k2) {
            // echo "-".$k2;
            // echo $v2;
            foreach ($k2 as $v3 => $k3) {
                echo $k3["id"];
                echo $k3["subject"];
            }
        }
    }
}
//echo $result;
if (!is_array($result)) {
    echo $result;
} else {
    echo json_encode($result);
}
