<?php
if (strpos("functions.json.cls.php", $_SERVER['PHP_SELF'])) {
    Header("Location:/index.php");
    die();
}
// get index
function getIndexJSON($value1)
{
    require "../config/const.cls.php";
    $value1 = (!empty($value1)) ? $value1 : 1;
    $rs = $dao->getIndex($value1, true); // it�s cached!!
    unset($rs["page"]);
    $result["list"] = $rs;
    $result["size"] = sizeof($doc["CacheIndex"]);
    $result["currentsize"] = sizeof($rs);
    $responseString = new soapval('return', 'xsd:string', json_encode($result));
    return $responseString;
}
function getFullIndexJSON()
{
    require "../config/const.cls.php";
//     $rs = $dao->getFullIndex();
    //     unset($rs["page"]);
    $result["list"] = $doc["CacheIndex"];
    $result["size"] = sizeof($doc["CacheIndex"]);
    $responseString = new soapval('return', 'xsd:string', json_encode($result));
    return $responseString;
}
function getListHeadersJSON($value1, $value2)
{
    $rs = array();
    $result = array();
    if (file_exists("../config/const.cls.php")) {
        include "../config/const.cls.php";
    }
    $responseData = "";
    // $rs ["pagecount"] = sizeof($doc ["CacheIndex"]);
    $rs = $dao->getList($doc["CacheIndex"], $value1, $value2, true, true);
    unset($rs["page"]);
    $i = 0;
    foreach ($rs as $k => $v) {
        $result[$i]["id"] = utf8_encode($v["id"]);
        $result[$i]["subject"] = utf8_encode($v["subject"]);
        $result[$i]["body"] = rawurlencode(utf8_encode($v["body"]));
        $i++;
    }

    $responseString = new soapval('return', 'xsd:string', json_encode($result));
    return $responseString;
}

/**
 *
 * @param unknown $value1
 * @param unknown $value2
 * @return soapval
 */
function getListJSON($value1, $value2)
{
    $isAllowed = false;
    $value1 = (!empty($value1)) ? $value1 : 1;
    $value2 = (!empty($value2)) ? $value2 : 1;
    $rs = array();
    $result = array();
    if (file_exists("../config/const.cls.php")) {
        include "../config/const.cls.php";
    }
    $responseData = "";
    // $rs ["pagecount"] = sizeof($doc ["CacheIndex"]);
    $rs = $dao->getList($doc["CacheIndex"], $value1, $value2, true, true);
    $page = $rs["page"];
    $catsid = isset($page["catsid"]) ? $page["catsid"] : 0;
    $tableName = isset($page["tableName"]) ? $page["tableName"] : 'Neues';
    $result["tableName"] = $tableName;
    $isAdmin = isset($env["user"]["isAdmin"]) ? $env["user"]["isAdmin"] : false;
    unset($rs["page"]);
    if ($catsid == 0) {
        $isAllowed = true;
    }
    if ($catsid == 1 && $env["userIsLoggedIn"] == 1) {
        $isAllowed = true;
    }
    if ($catsid >= 1 && $env["userIsLoggedIn"] == 1 && $isAdmin) {
        $isAllowed = true;
    }
    $i = 0;
    //print_r($rs);
    foreach ($rs as $k => $v) {
        $sid = isset($v["sid"]) ? $v["sid"] : "0";
        if ($sid == 0) {
            $isAllowed = true;
        }

        if ($sid == 1 && $env["userIsLoggedIn"]) {
            $isAllowed = true;
        }

        if ($sid >= 1 && $env["userIsLoggedIn"] == 1 && $isAdmin) {
            $isAllowed = true;
        }
        // print_r($result);
        $result["row"][$i]["page"] = $value1;
        $result["row"][$i]["table"] = $value2;
        if ($isAllowed) {
            $result["row"][$i]["id"] = utf8_encode($v["id"]);
            $result["row"][$i]["subject"] = utf8_encode($v["subject"]);
            $result["row"][$i]["body"] = rawurlencode(utf8_encode($v["body"]));
            $result["row"][$i]["datestamp"] = $v["datestamp"];
        } else {
            $result["row"][$i]["id"] = 0;
            $result["row"][$i]["subject"] = "503 - Access denied" . $catsid . "-" . $sid;
            $result["row"][$i]["body"] = rawurlencode(utf8_encode("503 - Access denied"));
            $result["row"][$i]["datestamp"] = $v["datestamp"];
        }
        $i++;
    }
    $result["tableName"] = $tableName;
    $result["table"] = $value1;
    $result["page"] = $value2;
    $result["size"] = $page["count"];
    $result["numberofrows"] = sizeof($result);
    // print_r($result);
    $responseString = new soapval('return', 'xsd:string', json_encode($result));
    return $responseString;
}

/**
 *
 * @param unknown $value1
 * @param unknown $value2
 * @return soapval
 */
function getReadJSON($value1, $value2)
{
    $result = array();
    if (file_exists("../config/const.cls.php")) {
        include "../config/const.cls.php";
    } else {
        $result["error"] = "Configuration is missing";
        return new soapval('return', 'xsd:string', json_encode($result));
        die();
    }
    $doc["lang"] = isset($_REQUEST["l"]) ? $_REQUEST["l"] : "de_DE";
    if (empty($value1)) {
        $value1 = "1";
    }
    if (empty($value2)) {
        $value2 = "1";
    }
    // ----------------------------------------------------------------
    // ----------------------------------------------------------------
    if (!empty($value1) && !empty($value2)) {
        if (is_numeric($value1) && is_numeric($value2)) {
            $rs = $dao->getRead($env, $doc["CacheIndex"], $value1, $value2, true);
        }
    }
    $sID = $rs["page"]["sid"];
    $isPHPCode = $rs["page"]["isPHPCode"];
//     unset($rs["page"]);
    foreach ($rs as $k => $v) {
        $result["page"] = $value1;
        $result["table"] = $value2;
        $result["id"] = isset($rs[0]) ? $rs[0]["id"] : "0";
        $result["datestamp"] = isset($rs[0]) ? $rs[0]["datestamp"] : "";
        $result["subject"] = isset($rs[0]) ? utf8_encode($rs[0]["subject"]) : "";
        $result["body"] = isset($rs[0]) ? $rs[0]["body"] : "";
        // $result ["body"] = utf8_encode ( $result ["body"] );
        $result["body"] = "" . Read_Functions::format_body(utf8_decode(utf8_decode($result["body"])));
        $isPlugin = (file_exists("../plugins/" . "plugins-" . $value1 . "-" . $value2 . ".cls.php")) ? true : false;
        if ($isPlugin) {
            $result["body"] = "[target]" . "plugins-" . $value1 . "-" . $value2 . ".html" . "[/target]";
        }
    }
    $result["size"] = $rs["page"]["max"];
    $responseString = new soapval('return', 'xsd:string', json_encode($result));
    // $responseString = new soapval ( 'return', 'xsd:string', json_encode ( $rs ) );
    return $responseString;
}

function getLastContent($value1)
{
    $result = array();
    if (file_exists("../config/const.cls.php")) {
        include "../config/const.cls.php";
    } else {
        die();
    }
    $doc["lang"] = isset($_REQUEST["l"]) ? $_REQUEST["l"] : "de_DE";
    if (empty($value1)) {
        $value1 = "1";
    }
    if (!empty($value1)) {
        if (is_numeric($value1)) {
            $rs = $dao->getLastContent($doc["CacheIndex"], $value1, 1, true);
        }
    }
    foreach ($rs as $k => $v) {
        $result[0]["id"] = utf8_encode($rs[0]["id"]);
        //$result[0]["subject"] = utf8_encode(Read_Functions::format_body(utf8_decode($rs[0]["subject"])));
        $result[0]["subject"] = utf8_encode($rs[0]["subject"]);
        $result[0]["body"] = "" . Read_Functions::format_body(utf8_decode(utf8_decode($rs[0]["body"])));
    }
    $result["size"] = $rs[0]["max"];
    $responseString = new soapval('return', 'xsd:string', json_encode($result));
    return $responseString;
}
function getSearch($query, $value1, $value2, $isSort = "asc")
{
    if (file_exists("../config/const.cls.php")) {
        include "../config/const.cls.php";
    }
    $rs = [];
    $isAllowed = false;

    $result = [];
    $isSort = (!empty($isSort) && ($isSort == "0" || $isSort == "asc")) ? "asc" : "desc";
    $rs = $dao->getSearch($env, $doc["CacheIndex"], $query, $value1, $value2, $isSort, true);
    $page = $rs["page"];
    unset($rs["page"]);
    $i = 0;
    foreach ($rs as $k => $v) {
        $sid = isset($v["sid"]) ? $v["sid"] : "0";
        if ($sid == 0) {
            $isAllowed = true;
        }

        if ($sid == 1 && $env["userIsLoggedIn"]) {
            $isAllowed = true;
        }

        if ($sid >= 1 && $env["userIsLoggedIn"] == 1 && $isAdmin) {
            $isAllowed = true;
        }

        $result[$i]["page"] = $value2;
        $result[$i]["table"] = $value1;
        if ($isAllowed) {
            $s = $v["id"];
            $result[$i]["id"] = $s;
            $result[$i]["subject"] = utf8_encode($v["subject"]);
            $result[$i]["body"] = rawurlencode(utf8_encode($v["body"]));
        } else {
            $result[$i]["id"] = 0;
            $result[$i]["subject"] = "503 - Access denied" . $catsid . "-" . $sid;
            $result[$i]["body"] = rawurlencode(utf8_encode("503 - Access denied"));
        }
        $i++;
    }
    // $rs["subject"] = "test";
    $responseString = new soapval('return', 'xsd:string', json_encode($result));
    return $responseString;
}

//
function getGames($value1, $value2)
{
    require "../config/const.cls.php";
    $rs = IO::readDirToArray($env["root"] . "/games/");
//    $rs = IO::readDirToArray($env["docroot"] . "/games/");
    sort($rs);
    $responseString = new soapval('return', 'xsd:string', json_encode($rs));
    return $responseString;
}
function getEnvironment($q)
{
    $responseData = "";
    //     require ("../config/const.cls.php");
    $env = ["page"];
    $env["page"] = ["env", "success"];
    if (file_exists("../config/const.cls.php")) {
        //         include ("../config/const.cls.php");
    } else {
        $env = ["error", "no config found"];
    }
    //     $env = ["bal","dsfds"];
    $responseString = new soapval('return', 'xsd:string', json_encode($env));
    return $responseString;
}
function getLog($q)
{
    $responseData = "";
    $result = ["status", "true"];    
    $result["page"]["status"] = ["env", "success"];
    $result["page"]["log"] = [];
    $result["page"]["log"]["q"] = $q;
    if (file_exists("../config/const.cls.php")) {
        require "../config/const.cls.php";
    } else {
        $env = ["error", "no config found"];
    }
    // $result["page"]["env"] = $env;
    if (file_exists($env["include"] . "log/log.cls.php")) {
        require $env["include"] . "log/log.cls.php";
        $result["page"]["log"]["log"] = Log::logFile($env["log"]);
    }
    if (file_exists($env["include"] . "log/ipcounter.cls.php")) {
        require $env["include"] . "log/ipcounter.cls.php";
        $result["page"]["log"]["counter"] = IPCountLogger::writeToFilePath($env["log"]);
    }  
    $responseString = new soapval('return', 'xsd:string', json_encode($result));
    return $responseString;
}
