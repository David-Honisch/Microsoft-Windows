<?php
if (strpos("functions.auth.cls.php", $_SERVER['PHP_SELF'])) {
    Header("Location:/index.php");
    die();
}
/**
 *
 * @param unknown $user
 * @param unknown $pwd
 * @return soapval
 */
function getAuth($user, $pwd)
{
    $result[0]["session"] = "anonymous";
    $result[0]["user"] = $user;
    $result[0]["pwd"] = $pwd;
    $rs = null;// array();
    $responseData = "";
    if (file_exists("../config/const.cls.php")) {
        include ("../config/const.cls.php");
        $result[0]["sessiondebug"] = "anonymous";
        // error_reporting(E_ALL);
        if (! isset($dao)) {
            $result[0]["daoset"] = "false";
        } else {
            $result[0]["daoset"] = "true";
        }
        if (! isset($user)) {
            $result[0]["user"] = "false";
        } else {
            $result[0]["user"] = "true";
            $result[0]["userName"] = $user;
        }
        if (! isset($pwd)) {
            $result[0]["pwd"] = "false";
        } else {
            $result[0]["pwd"] = "true";
        }
        // $result[0]["user1"] = $env["dbuser"];

        try {
            $rs = $dao->getAuth($user, $pwd);
            
            if ($rs != null) {
                $result[0]["session"] = $rs[0]["session"];
                $token = str_replace("\"", "", $rs[0]["session"]);
                if ($token != null) {
                    setCachePast();
                    $result[0]["session"] = $env["TokenPREFIX"] . $token;
                } else {
                    setHeaderBad200();
                    setCachePast();
                    $result[0]["session"] = "anonymous";
                }
            } else {
                // setHeaderBad200();
                // setCachePast();
                $result[0]["session"] = "anonymous";
            }
        } catch (Exception $e) {
//             echo 'Message: ' . $e->getMessage();
            $result[0]["error"] = 'Message: ' . $e->getMessage();
        }
    } else {
        // setHeaderBad200();
        $result[0]["session"] = "anonymous access denied";
    }
    $result["data"] = $rs;
    $responseString = new soapval('return', 'xsd:string', json_encode($result));
    return $responseString;
}

/**
 *
 * @param unknown $token
 * @return soapval
 */
function isAuth($token, $env = null, $dao = null)
{
    $result = array();
    $result[0]["requesttoken"] = $token;
    // Debug($token ."!!");
    $rs = array();
    $responseData = "";
    if (file_exists("../config/const.cls.php")) {
        require_once '../config/const.cls.php';
        $token = str_replace($env["TokenPREFIX"], "", $token);
        $rs = $dao->isAuth($token);        
        if (isset($rs)) {
            // $result["data"] = $rs;
            $result[0]["status"] = "true";
            //$result["login"] = $rs["count"] == 1 ? true : false;
            $result[0]["login"] = "true";
            $result[0]["loggedin"] = "true";
            // $result["count"] = $rs["count"];
            $result[0]["counter"] = 0;
            $result[0]["stoken"] = $token;
        } else {
            // $result["temp"] = $rs;
            $result["status"] = "false";
            $result["data"] = "false";
            $result["login"] = "false";
            $result[0]["sux"] = "true";
            $result["count"] = 10;
            $result["stoken"] = $token;
        }
    } else {
        $result[0]["status"] = "false";
        $result[0]["login"] = "false";
        $result[0]["sux"] = "true";
        $result[0]["count"] = 0;
        $result[0]["stoken"] = $token;
    }
    $result["wtf"] = "true";
    $responseString = new soapval('return', 'xsd:string', json_encode($result));
    return $responseString;
}

function delToken($token)
{
    $result["token"] = $token;
    $rs = array();
    $responseData = "";
    // try {
    if (file_exists("../config/const.cls.php")) {
        include ("../config/const.cls.php");
        $token = str_replace($env["TokenPREFIX"], "", $token);
        // $result[0]["token"] = $token;
        $rs = $dao->delToken($token);
        if ($rs != null) {
            $result["data"] = $rs;
        } else {
            $result["data"] = "false";
            $result["logout"] = "false";
        }
    } else {
        $result["error"] = "true";
        $result["logout"] = "false";
    }
    // } catch (Exception $e) {
    // $result["error"] = $e;
    // } finally
    // {
    
    $responseString = new soapval('return', 'xsd:string', json_encode($result));
    // }
    return $responseString;
}

// priva
function setCachePast()
{
    header("Cache-Control: no-cache, must-revalidate"); // HTTP/1.1
    header("Expires: Sat, 26 Jul 1997 05:00:00 GMT"); // Datum in der Vergangenheit
}

function setHeaderBad200()
{
    header('HTTP/1.1 200 Service Temporarily Unavailable');
    header('Status: 200 Service Temporarily Unavailable');
    header('Retry-After: 300'); // 300 seconds
}

function setHeader503()
{
    header('HTTP/1.1 503 Service Temporarily Unavailable');
    header('Status: 503 Service Temporarily Unavailable');
    header('Retry-After: 300'); // 300 seconds
}
///
/**
 * 
 * @param unknown $env
 * @param unknown $db
 * @param unknown $isLoggedIn
 * @param unknown $value1
 * @return number|unknown
 */
function getMaxIndex($env, $db, $isLoggedIn, $value1)
{
    $result["numofentries"] = $env["numofentries"];
    if ($isLoggedIn < 1) {
        $res = $db->fetch_assoc("select max(t1.id) as max from content_forum  as t1 where sid = 0");
        $result["max"] = $res[0]["max"];
    }
    if ($isLoggedIn = 1 && $isLoggedIn < 2) {
        $res = $db->fetch_assoc("select max(t1.id) as max from content_forum  as t1 where sid <= 1");
        $result["max"] = $res[0]["max"];
    }
    if ($isLoggedIn = 2) {
        $res = $db->fetch_assoc("select max(t1.id) as max from content_forum  as t1");
        $result["max"] = $res[0]["max"];
    }
    if ($result["max"] > 0) {
        $result["numofpages"] = ceil($result["max"] / intval($env["numofentries"]));
        $result["lastpage"] = ceil($result["max"] - intval($env["numofentries"]));
        $result["start"] = intval(ceil(($value1 * $env["numofentries"]) - $env["numofentries"]));
        $result["end"] = ($result["start"] - $env["numofentries"]);
    }
    if ($result["start"] <= $result["max"]) {
        if (($result["start"] - $env["numofentries"]) <= intval($result["max"])) {}
    } else {
        $result["start"] = 0;
    }
    return $result;
}

/**
 * 
 * @param unknown $env
 * @param unknown $db
 * @param unknown $tables
 * @param unknown $value2
 * @return unknown
 */
function getMax($env, $db, $tables, $value2)
{
    $result["max"] = $db->mysql_num_rows("select t1.id as max from " . $tables["table_name"] . "  as t1");
    if ($result["max"] > 0) {
        $result["numofpages"] = ceil($result["max"] / intval($env["numofentries"]));
        $result["lastpage"] = ceil($result["max"] - intval($env["numofentries"]));
        $result["start"] = intval(ceil(($value2 * $env["numofentries"]) - $env["numofentries"]));
        $result["end"] = ($start - $env["numofentries"]);
    }
    if ($result["start"] >= intval($result["max"] - $env["numofentries"])) {
        $result["start"] = intval($result["max"] - $env["numofentries"]); // echo "SZUX";
    }
    if (intval($result["start"]) <= intval($env["numofentries"])) {
        $result["start"] = 0;
    }
    $result["numofentries"] = $env["numofentries"];
    return $result;
}

/**
 * Authentication
 */
function doAuthenticate($db)
{
    $result = 0;
    if (isset($_SERVER['PHP_AUTH_USER']) and isset($_SERVER['PHP_AUTH_PW'])) {
        $result = "";
        $user = $_SERVER['PHP_AUTH_USER'];
        $pwd = $_SERVER['PHP_AUTH_PW'];
        $sql = "select *  from users where user = '" . $user . "' and pass = md5('" . $pwd . "')";
        $user = $db->GetAll($sql);
        if (! empty($user[0]["confirmed"])) {
            if ($user[0]["confirmed"] == 1 and $user[0]["locked"] == 0 and $user[0]["deleted"] == 0)
                $result = 1;
            if ($user[0]["confirmed"] == 1 and $user[0]["isAdmin"] == 1 and $user[0]["locked"] == 0 and $user[0]["deleted"] == 0)
                $result = 2;
        } else {
            $result = 0;
        }
    }
    return $result;
}

?>