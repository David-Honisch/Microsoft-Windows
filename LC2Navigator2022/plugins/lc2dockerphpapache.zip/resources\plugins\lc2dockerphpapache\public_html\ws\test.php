<script src="../assets/js/jquery/jquery.min.js"></script>
<?php
require "../config/const.cls.php";
$inputFile = "./json/methods.json";
function printData($data)
{
    foreach ($data as $object) {
        // echo gettype($object);
        if (gettype($object) == "array") {
            // print_r($object);
            foreach ($object as $key => $value) {
                echo $key . $value;
            }
        }
    }
}
$input = file_get_contents($inputFile);
$data = json_decode($input, true);
// printData($data);
?>
<form>

    <select id="q">
        <option value="all">All</option>
        <?php
        foreach ($data["Methods"] as $key => $value)
            echo "<option value=\"" . $key . "\">" . $key . "</option>";
        ?>
    </select>
    <input type="button" name="submit" id="submit" value="submit">
</form>
<div id="cnt"></div>
<script>
    $("#submit").on("click", function() {
        $.ajax({
            url: 'client.php',
            type: 'GET',
            data: jQuery.param({
                q: $("#q").val(),
                value1: "1",
                value2: "1"
            }),
            //contentType: 'application/x-www-form-urlencoded; charset=UTF-8',
            // contentType: 'application/json; charset=UTF-8',
            success: function(response) {
                console.log(JSON.stringify(response));
                $("#cnt").html(JSON.stringify(response));
            },
            error: function() {
                alert("error");
            }
        });
    })
</script>