<?php
require('./config/const.cls.php');
//$conn = $env["db"]["con"];
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} else {
    echo "Connected to MySQL successfully!";
}
// Configuration- change here!
$filename = 'import.sql'; // Your Import File
$maxRuntime = 8; // less then your max script execution limit
// END Configuration!

// Be sure to load utf-8
// header('Content-Type: text/html; charset=UTF-8');
$deadline = time() + $maxRuntime;
$progressFilename = $filename . '_filepointer'; // tmp file for progress
$errorFilename = $filename . '_error'; // tmp file for erro

// $$conn = new mysqli($dbHost, $dbUser, $dbPass, $dbName);
// Check connection
// if ($$conn->connect_errno) {
//     echo "Failed to connect to MySQL: " . $$conn->connect_error;
//     exit();
// }
// if (!mysqli_set_charset($$conn, "utf8")) {
//     printf("Error loading character set utf8: %s\n", $$conn->error);
//     exit();
// }

($fp = fopen($filename, 'r')) or die('failed to open file:' . $filename);

// check for previous errors
if (file_exists($errorFilename)) {
    die('<pre> Previous error: ' . file_get_contents($errorFilename));
}

// automatic reload in browser
echo '<html><head> <meta http-equiv="refresh" content="' . ($maxRuntime + 2) . '"><pre>';

// load previous file position
$filePosition = 0;
if (file_exists($progressFilename)) {
    $filePosition = file_get_contents($progressFilename);
    fseek($fp, $filePosition);
}
$queryCount = 0;
$query = '';
while ($deadline > time() and ($line = fgets($fp, 1024000))) {
    if (substr($line, 0, 2) == '--' or trim($line) == '') {
        continue;
    }

    $query .= $line;

    if (substr(trim($query), -1) == ';') {
        // if (!$result = $mysqli->query($query)) {
        //     // $error = 'Error performing query \'<strong>' . $query . '\': ' . $conn->error();
        //     file_put_contents($errorFilename, $error . "\n");
        //     exit;
        // }
        if ($conn->query($query) === TRUE) {
            echo "New record created successfully";
            // file_put_contents($errorFilename, $error . "\n");
            // exit;
          } else {
            echo "Error: " . $sql . "<br>" . $conn->error;
          }



        $query = '';
        file_put_contents($progressFilename, ftell($fp)); // save current file position
        $queryCount++;
    }
}

if (feof($fp)) {
    echo 'SQL dump successfully restored!';
} else {
    echo ftell($fp) . '/' . filesize($filename) . ' ' . (round(ftell($fp) / filesize($filename), 2) * 100) . '%' . "\n";
    echo $queryCount . ' queries processed! Please reload or wait for automatic browser refresh!';
}
