<?php
//if (ereg("util.php", $_SERVER['PHP_SELF'])) {Header("Location:/index.php");die();}
if(preg_match("/util/", $_SERVER["PHP_SELF"])){Header("Location:/index.php");die();}
/**
 * Die Util.php stellt statische Hilfsmethoden zur Vef�gung,
 * die in der Ausspielung besn�tigt werden.
 *
 * LetzteChance.Org
 * @author david@honisch.org
 */
class Util {

	public static function renderShortEntry($content,$title){
		$result .= "<div id=\"".$title."\"></div>\n";
		$result .= $content;
		$result .= "<!-- ContentDIV EOF-->\n";
		return $result;
	}
	public static function UnEscape($data) {
		if(!empty($data) && is_string($data)) {
			$data = str_replace(array('\\', "\0", "\n", "\r", "'", '"', "\x1a"), array('\\\\', '\\0', '\\n', '\\r', "\\'", '\\"', '\\Z'), $data);
			$data = "'".$data."'";
		}
		return $data;
	}
	
	
	public static function renderEntry($content,$title){
		$result = "";
		$result .= "<!-- Content DIV-->\n";
		$result .= "<div class=\"brundlayer\"><div class=\"backtitel\"><div class=\"rundrt\"><div class=\"rundlt\"><div class=\"ecklb\"><div class=\"eckrb\">\n";
		$result .= "<div class=\"foretitel\"><h5>".$title."<div class=\"maxpanel\"><div class=\"max\" onclick=\"Effect.Appear('".$title."');return true;\"></div>\n";
		$result .= "<div class=\"min\" onclick=\"Effect.Fade('".$title."');return true;\"></div></div></h5></div></div>\n";
		$result .= "</div></div></div></div></div>\n";
		$result .= "<div class=\"ecklm\"><div class=\"eckrm\"><div class=\"ecklb\"><div class=\"eckrb\"></div></div></div></div>\n";
		$result .= "<div class=\"backdialog\"><div class=\"ecklm\"><div class=\"eckrm\"><div class=\"ecklb\"><div class=\"eckrb\"><div class=\"foredialog\">\n";
		$result .= "<div id=\"".$title."\">\n";
		//$result .= "<script src=\"http://www.google.com/jsapi\" type=\"text/javascript\"></script>\n";
		//$result .= "<script type=\"text/javascript\" src=\"./js/google/news.js\"></script>\n";
		//		$result = "{php}\n";
		//		$result = "new List_class(1,15);\n";
		//		$result = "{/php}\n";
		$result .= $content;
		$result .= "</div></div></div></div></div></div></div>\n";
		$result .= "<div class=\"backdialog\"><div class=\"ecklm\"><div class=\"eckrm\"><div class=\"rundrb\"><div class=\"rundlb\"><div class=\"forebuttons\"></div>\n";
		/*
		 $result .= "<div style=\"text-align: center;\">\n";
		 $result .= "<a href=\"javascript:history.go(-1);\" onclick=\"Effect.Puff('content');return true;\">&lt;&lt;&nbsp;</a>\n";
		 $result .= "<input value=\"Zur&uuml;ck\" name=\"btnLogin\" class=\"Pushbutton\" onclick=\"javascript:history.go(-1);\" type=\"submit\" />\n";
		 $result .= "</div>\n";
		 */
		$result .= "</div></div></div></div></div></div>\n";
		$result .= "<!-- ContentDIV EOF-->\n";
		return $result;
	}

	public static function renderSEntry($content, $title){
		$result = "";
		$result .= "<!-- Content DIV-->\n";
		$result .= "<div class=\"rundlayer\"><div class=\"backtitel\"><div class=\"rundrt\"><div class=\"rundlt\"><div class=\"ecklb\"><div class=\"eckrb\">\n";
		$result .= "<div class=\"foretitel\"><h5>".$title."<div class=\"max\" onclick=\"Effect.Appear('".$title."');return true;\"></div>\n";
		$result .= "<div class=\"min\" onclick=\"Effect.Fade('".$title."');return true;\"></div></h5></div>\n";
		$result .= "</div></div></div></div></div>\n";
		$result .= "<div class=\"ecklm\"><div class=\"eckrm\"><div class=\"ecklb\"><div class=\"eckrb\"></div></div></div></div>\n";
		$result .= "<div class=\"backdialog\"><div class=\"ecklm\"><div class=\"eckrm\"><div class=\"ecklb\"><div class=\"eckrb\"><div class=\"foredialog\">\n";
		$result .= "<div id=\"".$title."\">\n";
		//$result .= "<script src=\"http://www.google.com/jsapi\" type=\"text/javascript\"></script>\n";
		//$result .= "<script type=\"text/javascript\" src=\"./js/google/news.js\"></script>\n";
		$result .= $content;
		$result .= "</div></div></div></div></div></div></div>\n";
		$result .= "<div class=\"backdialog\"><div class=\"ecklm\"><div class=\"eckrm\"><div class=\"rundrb\"><div class=\"rundlb\"><div class=\"forebuttons\"></div>\n";

		//		$result .= "<div style=\"text-align: center;\">\n";
		//		$result .= "<a href=\"javascript:history.go(-1);\" onclick=\"Effect.Puff('content');return true;\">&lt;&lt;&nbsp;</a>\n";
		//		$result .= "<input value=\"Zur&uuml;ck\" name=\"btnLogin\" class=\"Pushbutton\" onclick=\"javascript:history.go(-1);\" type=\"submit\" />\n";
		//		$result .= "</div>\n";
		$result .= "</div></div></div></div></div></div>\n";
		$result .= "<!-- ContentDIV EOF-->\n";
		return $result;
	}

	/**
	 * Inkludieren einer Datei per include, wenn sie Existiert
	 *
	 * @param String $fileUrl
	 */
	public static function includeFile($fileUrl){
		if(!empty($fileUrl) && file_exists($fileUrl)){
			@include_once($fileUrl);
		}
	}

	/**
	 * Inkludieren einer Datei per require, wenn sie Existiert
	 *
	 * @param String $fileUrl
	 */
	public static function requireFile($fileUrl){
		if(!empty($fileUrl) && file_exists($fileUrl)){
			@require_once($fileUrl);
		}
	}

	/**
	 * Behandeln eines Textes, um Sicherzugehen das er in <p> Tags eingeschlossen ist,
	 * auch wenn er z.B. nicht aus dem wysiwyg-Editor kommen
	 *
	 * @param string $text
	 * @return string
	 */
	public static function handlePTags($text){

		$addp = 0;

		$tmp = trim($text);
		//    if(!ereg("^\<p\>", $text)){
		if(!preg_match("/^<p>/i", $text)){
			$tmp = "<p>".$tmp;
			$addp = 1;
		}

		//    if(!ereg(".*\<\/p\>$", $text)){
		if($addp) {
			$tmp = $tmp."</p>";
		}

		$text = $tmp;
		return $text;
	}

	/**
	 * Entfernen von Slashes aus einem String
	 *
	 * @param String $text
	 * @return String
	 */
	public static function removeCarriageReturn($text){

		//if(!Util::startsWith("\n", $text)){
		//$text = ereg_replace("\n","<br />",$text);
		$text = preg_replace("/\r|\n/s", "", $text);
		//$text = preg_replace("<br>|<br/>|<br />", "", $text);
		//$text=nl2br($text);

		return $text;
	}
	/**
	 * Entfernen von Doppelslashes aus einem String
	 *
	 * @param String $text
	 * @return String
	 */
	public static function removeDoubleSlash($text){

		if(!Util::startsWith("http", $text)){
			$text = ereg_replace("\/\/","/",$text);
		}
		return $text;
	}

	/**
	 * Ermitteln, ob ein String ($haystack) mit einem anderen String ($needle) beginnt
	 *
	 * @param String $needle
	 * @param String $haystack
	 * @return boolean
	 */
	public static function startsWith($needle, $haystack){

		$ret = false;
		$lengthNeedle = strlen($needle);
		$lengthHaystack = strlen($haystack);

		if($lengthHaystack >= $lengthNeedle && substr($haystack, 0, $lengthNeedle) == $needle){
			$ret = true;
		}

		return $ret;

	}

	/**
	 * Ermitteln und Rückgabe der Inhalte von $dok["metadaten"]
	 *
	 * @param Array $dok
	 * @return Array
	 */
	public static function getMetadaten(&$dok){
		$ret = array();

		if(!empty($dok["metadaten"])){
			$ret = $dok["metadaten"];
		}

		return $ret;
	}

	/**
	 * Anhand eines übergebenen Timestamps überprüfen, ob ein Element
	 * der Webseite gültig ist und somit ausgespielt wird.
	 *
	 * @param int $gueltig
	 * @param String $server
	 * @return boolean
	 */
	public static function isGueltig($gueltig, $server){

		$ret = false;

		if(empty($gueltig) || !empty($gueltig) && $server == "TEST"){
			$ret = true;
		}else if(!empty($gueltig) && $server == "HOT" && $gueltig["von_unix"] <= time() && $gueltig["bis_unix"] >= time()){
			$ret = true;
		}

		return $ret;
	}

	/**
	 * Behandeln von Listen, das diese nicht innerhalb von <p>-Tags auftauchen d�rfen.
	 *
	 * @param String $text
	 * @return String
	 */
	public static function escapeHTMLList($text = "") {

		$ret = "";

		if(!empty($text)){
			//<ul> zu </p><ul>
			$ret = ereg_replace("<ul>", "</p><ul>", $text);

			//</ul> zu </ul><p>
			$ret = ereg_replace("</ul>", "</ul><p>", $ret);
		}

		return $ret;

	}

	/**
	 * Ersetzen von HTML-Tags in einem Text durch andere Tags
	 *
	 * @param String $text
	 * @param Array $tags
	 * @return String
	 */
	public static function replaceHTMLTags($text = "", $tags) {

		$ret = "";

		if(!empty($text) && !empty($tags)){
			$ret = $text;

			for($i=0; $i < count($tags); $i++){
				$ret = ereg_replace($tags[$i]["search"],$tags[$i]["replace"], $ret);
			}

		}

		return $ret;
	}

	/**
	 * Einfügen eines Mehr-Links in einen Text
	 *
	 * @param String $text
	 * @param String $mehrlink
	 * @param String $mehrlinktext
	 * @return string
	 */
	public static function insertMehrlink($text, $mehrlink, $mehrlinktext) {

		$ret = "";

		if(!empty($text)){
			$ret = trim($text);

			//gibt es ein <p> am Ende ?
			if(substr($text, -4,4) == "</p>"){
				$needle = "/(.*)(\<\/p\>)$/";
				$ret = preg_replace($needle, "$1 <a href=\"".$mehrlink."\">".$mehrlinktext."</a></p>", $ret);
			}else{
				$ret .= "<p><a href=\"".$mehrlink."\">".$mehrlinktext."</a></p>";
			}
		}

		return $ret;

	}

	/**
	 * Ersetzen von & durch &amp;
	 *
	 * @param String $text
	 * @param boolean $display
	 * @return String
	 */
	public static function escapeText($text = "", $display = false) {
		$ret = "";

		//& zu &amp umwandeln
		$ret = preg_replace("/&(?!#|amp;)/", "&amp;", $text);
		//$ret = ereg_replace("\"","&quot;", $ret);

		if($display){
			echo $ret;
		}else{
			return $ret;
		}

	}

	/**
	 * Prüfen, ob eine E-Mail Adresse ein g�ltiges Format hat
	 *
	 * @param String $data
	 * @param boolean $strict
	 * @return boolean
	 */
	public static function isValidMailAddress($data, $strict = false) {

		$regex = $strict ?
             '/^([.0-9a-z_-]+)@(([0-9a-z-]+\.)+[0-9a-z]{2,4})$/i' :        '/^([*+!.&#$|\'\\%\/0-9a-z^_`{}=?~:-]+)@(([0-9a-z-]+\.)+[0-9a-z]{2,4})$/i';

		if (preg_match($regex, trim($data), $matches)) {
			return true;
		} else {
			return false;
		}
	}
	public static function isPatternIn($pattern, $value){
		return strpos($pattern, $value);
	}

	/**
	 * Senden einer E-Mail an einen Empf�nger
	 *
	 * @param Array $mail
	 * @return boolean
	 */
	public static function sendEmail($mail) {
		$ret = false;

		$ret = mail ( $mail["empfaenger"] , $mail["betreff"] , $mail["text"],$mail["header"]);
		return $ret;
	}

	/**
	 * Bestimmte Worte in einem Text durch einschliessen in eine CSS-Klasse
	 * farblich hervorheben
	 *
	 * @param String $text
	 * @param Array $suchworte
	 * @param int $left
	 * @param int $right
	 * @return String
	 */
	public static function highlightSuchwort($text, $suchwort, $left = 0, $right = 0){

		$ret = $text;

		if(preg_match('|^[\ \.\,\;\-\:a-zA-Z0-9������]*$|', $suchwort)){
			$needle = "/(.{0,1})(".$suchwort.")(.{0,1})/i";
			//preg_replace("/&(?!#|amp;)/", "&amp;", $text);
			//Suchwort Blau f�rben
			if(is_string($text) && !empty($text) && !empty($suchwort)){
				$ret = preg_replace($needle, "$1<span class=\"highlight\">$2</span>$3", $ret);
			}else if(is_array($text) && !empty($text) && !empty($suchwort)){

				foreach($text AS $key => $value){
					if(is_string($value) && !empty($value)){
						$ret[$key] = preg_replace($needle, "$1<span class=\"highlight\">$2</span>$3", $value);
					}
				}
			}
		}

		return $ret;
	}

	/**
	 * Ermitteln der Navigation
	 *
	 * @param Array $navi
	 * @param Array $env
	 * @return boolean
	 */
	public static function getNavigation($navi, $env){
		$ret = array();
		if(!empty($navi["ebene1"])){
			$eb1Count = 0;

			$startseite = $navi["ebene1"][0];
			$isActive = false;
			if($env["dir"] == "/" && $env["script"] == "index.phtml"){
				$isActive = true;
			}
			$ret[$eb1Count]["linkurl"] = $startseite["linkurl"];
			$ret[$eb1Count]["linktext"] = $startseite["linktext"];
			$ret[$eb1Count]["aktiv"] = $isActive;
			$ret[$eb1Count]["markAsAktiv"] = $isActive;

			$eb1Count++;
			//EBENE 1
			for($i=1; $i < count($navi["ebene1"]); $i++){
				$isActive = false;
				$eb1 = $navi["ebene1"][$i];

				if(!Util::showNavigationspunkt($eb1["need_login"], $env["user"])){
					continue;
				}

				if(Util::startsWith($eb1["linkdir"],$env["dir"]."/")){
					$isActive = true;
				}

				$eb1_linkurl = Util::removeDoubleSlash($env["docrootUrl"].$eb1["linkurl"]);
				$eb1_linktext = $eb1["linktext"];

				$ret[$eb1Count]["linkurl"] = $eb1_linkurl;
				$ret[$eb1Count]["linktext"] = $eb1_linktext;
				$ret[$eb1Count]["aktiv"] = $isActive;
				$ret[$eb1Count]["markAsAktiv"] = $isActive;

				$eb2Count = 0;
				if(array_key_exists("ebene2", $eb1) && Util::startsWith($eb1["linkdir"],$env["dir"]."/")){
					for($a = 0; $a < count($eb1["ebene2"]); $a++){
						$isActive = false;
						$eb2 = $eb1["ebene2"][$a];

						if(!Util::showNavigationspunkt($eb2["need_login"], $env["user"])){
							continue;
						}

						if(Util::startsWith($eb2["linkdir"],$env["dir"]."/")){
							$isActive = true;
							$ret[$eb1Count]["markAsAktiv"] = false;
						}
						$eb2_linkurl = Util::removeDoubleSlash($env["docrootUrl"].$eb2["linkurl"]);
						$eb2_linktext = $eb2["linktext"];

						$ret[$eb1Count]["ebene2"][$eb2Count]["linkurl"] = $eb2_linkurl;
						$ret[$eb1Count]["ebene2"][$eb2Count]["linktext"] = $eb2_linktext;
						$ret[$eb1Count]["ebene2"][$eb2Count]["aktiv"] = $isActive;
						$ret[$eb1Count]["ebene2"][$eb2Count]["markAsAktiv"] = $isActive;
						$eb2Count++;
					}

				}
				$eb1Count++;
			}
		}
		return $ret;
	}

	/**
	 * Ermitteln der Breadcrum der aktuellen Seite
	 *
	 * @param Array $navi
	 * @param String $headline
	 * @return Array
	 */
	public static function getBreadcrumb($navi, $headline){
		$ret = array();
		$bcCount = 0;
		for($i=0; $i < count($navi); $i++){
			if(array_key_exists("aktiv", $navi[$i]) && $navi[$i]["aktiv"]){
				$ret[$bcCount]["linkurl"] = $navi[$i]["linkurl"];
				$ret[$bcCount]["linktext"] = $navi[$i]["linktext"];
				$bcCount++;
				if(!empty($navi[$i]["ebene2"])){
					for($a=0; $a < count($navi[$i]["ebene2"]); $a++){
						if(array_key_exists("aktiv", $navi[$i]["ebene2"][$a]) && $navi[$i]["ebene2"][$a]["aktiv"]){
							$ret[$bcCount]["linkurl"] = $navi[$i]["ebene2"][$a]["linkurl"];
							$ret[$bcCount]["linktext"] = $navi[$i]["ebene2"][$a]["linktext"];
							$bcCount++;
						}
					}
				}
			}
		}
		$ret[$bcCount]["linkurl"] = "";
		$ret[$bcCount]["linktext"] = $headline;
		return $ret;
	}

	/**
	 * Pr�fen, ob ein bestimmter Navigationspunkt angezeigt werden darf, oder nicht
	 *
	 * @param boolean $needLogin
	 * @param Array $user
	 * @return boolean
	 */
	public static function showPoint($needLogin, $user){
		$ret = false;

		if($needLogin == 0 || ($needLogin == 1 && !empty($user))){
			$ret = true;
		}
		return $ret;
	}

	/**
	 * Generieren und zurueckgeben des Links auf Foto
	 *
	 * @param String $u_id
	 * @param String $username
	 * @param String $suchworte
	 * @return string
	 */
	public static function getSecretLink($u_id, $username, $suchworte){
		$w_geheim  = "xx";
		$w_user    = isset($u_id) ? $username : "";
		$w_date    = time();
		$w_confirm = md5("$w_geheim$w_user$w_date");

		$w_url = "./s.aspx?username=$w_user&amp;date=$w_date&amp;confirm=$w_confirm";

		if(!empty($suchworte)){
			$w_url .= "&amp;worte=".$suchworte;
		}

		return $w_url;
	}

	/**
	 * Anhand eines �bergebenen Linktyps das dazu passende
	 * target definieren und zur�ckgeben.
	 *
	 * @param String $typ
	 * @return string
	 */
	public static function getLinkTargetByLinkTyp($typ){
		$ret = "";
		switch($typ){
			case "ardfoto":
				$ret = " target=\"_blank\"";
				break;
			case "audio":
				$ret = " target=\"_blank\"";
				break;
			case "doc":
				$ret = " target=\"_blank\"";
				break;
			case "intern":
				$ret = " target=\"_parent\"";
				break;
			case "pdf":
				$ret = " target=\"_blank\"";
				break;
			case "rtf":
				$ret = " target=\"_blank\"";
				break;
			case "xml":
				$ret = " target=\"_blank\"";
				break;
			case "video":
				$ret = " target=\"_blank\"";
				break;
			case "www":
				$ret = " target=\"_blank\"";
				break;
			default:
				break;

		}
		return $ret;
	}

	/**
	 * Anhand der �bergebenen Datentypenbezeichnung, wird ein image mit dem
	 * dem entsprechenden Icon zur�ckgegeben
	 * z.Bsp. "xml" f�hrt zur Ausgabe eines xml icons
	 * @param unknown_type $typ
	 */

	public static function getCSSImageByLinkTyp($typ){
		$result = "";
		switch($typ){
			case "ardfoto":
				//$result = "<img src=\"".$dir."codebase/img/icon_gallery_red.gif\">&nbsp;";
				$result = "llardfoto";
				break;

			case "audio":
				//$result = "<img src=\"".$dir."codebase/img/icon_audio.gif\">&nbsp;";
				$result = "llaudio";
				break;
			case "doc":
				//$result = "<img src=\"".$dir."codebase/img/icon_doc_red.gif\">&nbsp;";
				$result = "lldoc";
				break;

			case "intern":
				//$result = "<img src=\"".$dir."codebase/img/icon_link_intern.gif\">&nbsp;";
				$result = "llintern";
				break;
			case "pdf":
				//$result = "<img src=\"".$dir."codebase/img/icon_pdf_red.gif\">&nbsp;";
				$result = "llpdf";
				break;
			case "rtf":
				//$result = "<img src=\"".$dir."codebase/img/icon_rtf_red.gif\">&nbsp;";
				$result = "llrtf";
				break;
			case "xml":
				//$result = "<img src=\"".$dir."codebase/img/icon_xml_red.gif\">&nbsp;";
				$result = "llxml";
				break;
			case "video":
				//$result = "<img src=\"".$dir."codebase/img/icon_video.gif\">&nbsp;";
				$result = "llvideo";
				break;
			case "www":
				//$result = "<img src=\"".$dir."codebase/img/icon_link_extern.gif\">&nbsp;";
				$result = "llwww";
				break;
			default:
				break;
		}
		return $result;
	}


	/**
	 * generieren und zurückgeben eines Passwortes
	 *
	 * @return string
	 */
	public static function generatePassword() {
		$pw = "";

		$chars = array("a","b","c","d","e","f","g","h","i","j","k","l","m","n","o","p","q","r","s","t","u","v","x","y","z","0","1","2","3","4","5","6","7","8","9","A","B","C","D","E","F","G","H","I","J","K","L","M","N","O","P","Q","R","S","T","U","V","W","X","Y","Z");

		$pwlength = 7;

		for($i=0; $i < $pwlength; $i++){
			$index = mt_rand(0, (count($chars) -1));
			$pw .= $chars[$index];
		}

		return $pw;
	}

	/**
	 * Navigation f�r die portal zur�ckgeben
	 *
	 * @param Array $env
	 * @return string
	 */
	public static function getNavigationForUserverwaltung($env){
		$ret = array();
		$ret[] = array("linkurl"=>$env["codebaseUrl"]."_intern/portal/index.phtml", "linktext"=>"Benutzerliste", "markAsAktiv"=>"0");
		$ret[] = array("linkurl"=>$env["codebaseUrl"]."_intern/portal/index.phtml?status=locked", "linktext"=>"gesperrte Benutzer", "markAsAktiv"=>"0");
		$ret[] = array("linkurl"=>$env["codebaseUrl"]."_intern/portal/index.phtml?status=notlocked", "linktext"=>"aktive Benutzer", "markAsAktiv"=>"0");
		$ret[] = array("linkurl"=>$env["codebaseUrl"]."_intern/portal/csv.phtml", "linktext"=>"CSV erstellen", "markAsAktiv"=>"0");
		$ret[] = array("linkurl"=>$env["codebaseUrl"]."_intern/portal/csv_hilfe.phtml", "linktext"=>"CSV Hilfe", "markAsAktiv"=>"0");

		return $ret;
	}

	/**
	 * Escapen von Daten (hier Request-Daten) um XSS-Lücken zu vermeiden
	 *
	 * @param array $req  -Array mit Requestdaten
	 * @return array
	 *
	 */
	public static function escapeRequestData($req){
		$ret = array();

		if(!empty($req)){
			foreach($req AS $key => $value){

				if(!is_array($value)){

					$value = strip_tags($value);
					$value =  htmlspecialchars($value);

					$key = strip_tags($key);
					$key =  htmlspecialchars($key);

					$ret[$key] = $value;
				}else{
					$ret[$key] = Util::escapeRequestData($value);
				}
			}
		}

		return $ret;
	}

	/**
	 * Anhand einer Dokumenten-ID ermitteln, ob die jeweilige Kategorie
	 * ein Sendedatum hat, oder nicht.
	 *
	 * @param int $did
	 * @param resource $db
	 * @return boolean
	 */
	public static function kategorieUseSendedatum($did, $db){
		$ret = false;

		$sql = "SELECT has_sendedatum FROM bseiten_kategorien WHERE did = ".intval($did)." AND has_sendedatum = 1";

		$sth = mysql_query($sql, $db);

		if($sth && mysql_num_rows($sth) > 0){
			$ret = true;
		}

		return $ret;
	}

	/**
	 * Anhand einer Dokumenten-ID ermitteln, wie die entsprechende Beitragsseitenkategorie hei�t.
	 *
	 * @param int $did
	 * @param resource $db
	 * @return String
	 */
	public static function getBeitragsseitenKategorieByDid($did, $db){
		$ret = "";

		$sql = "SELECT bezeichnung FROM bseiten_kategorien WHERE did = ".intval($did);

		$sth = mysql_query($sql, $db);

		if($sth && mysql_num_rows($sth) > 0){
			$row = mysql_fetch_array($sth, MYSQL_ASSOC);
			$ret = $row["bezeichnung"];
		}

		return $ret;
	}
	/**
	 *
	 * Getting all News for a whole Month
	 *
	 * @param mysql-class_instance $db
	 * @param date $startdate
	 * @param date $enddate
	 */
	public static function getLinkedDaysFromDB($db, $startdate,$enddate)
	{
		//		$dateStart = 1304200800;
		//		$dateEnd = 1306792800;
		//		echo date("Y-m-d 00:00:00", $startdate )."-". date("Y-m-d 00:00:00", $enddate )."-".$startdate."-".$enddate."<br>";
		//		echo date("d-m-Y hh:mm:ss",1306879200);
		$result = array();

		$sql = "SELECT UNIX_TIMESTAMP(DATE_FORMAT(datestamp, '%Y-%m-%d 00:00:00')) as date FROM neues"
		." WHERE"
		." (datestamp BETWEEN '".date("Y-m-d", $startdate)." 00:00:00' AND '".date("Y-m-d", $enddate)." 23:59:59' )"
		//	."  datestamp < NOW() OR DATE_ADD(NOW(), INTERVAL 30 HOUR) > NOW()"
		." GROUP by datestamp LIMIT 0,31";//This might be deleted !!!
		//echo $sql;
		$tresult= $db->fetch_assoc($sql);
		if (!empty($tresult))
		{
			foreach ($tresult as $value)
			{
				$str = mktime(0,0,0, date("m", $value["date"]),date("d", $value["date"]),date("Y", $value["date"]));
				$result[$str] = $str;
			}
		}
		return $result;
	}

	/**
	 * Sortieren eines Arrays anhand eines Unix Timestamps
	 *
	 * @param Array $a
	 * @param Array $b
	 * @return int
	 */
	public static function sortByDate($a, $b){
		$ret = 0;
		$aSortDate = 0;
		$bSortDate = 0;

		if($a["sdatum_unix"] > 0){
			$aSortDate = $a["sdatum_unix"];
		}elseif ($a["vdatum_unix"] > 0) {
			$aSortDate = $a["vdatum_unix"];
		}

		if($b["sdatum_unix"] > 0){
			$bSortDate = $b["sdatum_unix"];
		}elseif ($b["vdatum_unix"] > 0) {
			$bSortDate = $b["vdatum_unix"];
		}

		if($aSortDate == $bSortDate){
			$ret = 0;
		}else if($aSortDate < $bSortDate){
			$ret = -1;
		}else if($aSortDate > $bSortDate){
			$ret = 1;
		}
		return $ret;
	}
	function webpage2txt($url)
	{
		$user_agent = "Mozilla/4.0 (compatible; MSIE 5.01; Windows NT 5.0)";

		$ch = curl_init();    // initialize curl handle
		curl_setopt($ch, CURLOPT_URL, $url); // set url to post to
		curl_setopt($ch, CURLOPT_FAILONERROR, 1);              // Fail on errors
		curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);    // allow redirects
		curl_setopt($ch, CURLOPT_RETURNTRANSFER,1); // return into a variable
		curl_setopt($ch, CURLOPT_PORT, 80);            //Set the port number
		curl_setopt($ch, CURLOPT_TIMEOUT, 15); // times out after 15s

		curl_setopt($ch, CURLOPT_USERAGENT, $user_agent);

		$document = curl_exec($ch);

		$search = array("@<script[^>]*?>.*?</script>@si�,  // Strip out javascript
�@<style[^>]*?>.*?</style>@siU�,    // Strip style tags properly
�@<[\/\!]*?[^<>]*?>@si�,            // Strip out HTML tags
�@<![\s\S]*?�[ \t\n\r]*>@�,         // Strip multi-line comments including CDATA
�/\s{2,}/",

		);

		$text = preg_replace($search, "\n", html_entity_decode($document));

		$pat[0] = "/^\s+/";
		$pat[2] = "/\s+\$/";
		$rep[0] = "";
		$rep[2] = " ";

		$text = preg_replace($pat, $rep, trim($text));

		return $text;
	}
	public static function URIasArray($show = false)
	{
		$path = $_SERVER['REQUEST_URI'];
		$arr = explode("/", $path);

		$arraynew = array();

		$i=0;
		foreach ($arr as $k => $v) {
			$i > 0 ? $arraynew[] = $arraynew[$i-1] . $v . "/" : $arraynew[] = "/";

			$i++;
		}
		if ($show)
		{
			print_r($arraynew);
		}
		return $arraynew;
	}
	/**
	 * 
	 * @param unknown $list
	 * @param string $query
	 * @return string
	 */
	public static function getURI($list, $query="query=")
	{
		$url = "";
		$p = array();
		//if (!empty($env["uri"]["uri"][1]))
		if (!empty($list))
		{
			//$p = explode("&", $env["uri"]["uri"][1]);
			$p = explode("&", $list);
		}
		foreach ($p as $v)
		{
			if (strpos($v, $query) === 0)
			{
				$vv = explode($query,$v);
				if (!empty($vv[1]))
				{
					$url = urldecode($vv[1]);
				}
			}
		}
		return $url;
	}

}
