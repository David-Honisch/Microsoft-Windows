<?php
/**
 * @name Collection.class.php
 * @author david@honisch.org
 * @version 1.0
 *
 * Abstrakte Klasse zum Abbilden einer Collection. Da eine Collection jedoch typen
 * spezifisch ist, ist diese Klasse abstract.
 * Diese Klasse dient dazu typisierte Arrays anzulegen. Jedes Element ist von EINEM
 * Typ der über den Konstruktor übergeben wird.
 *
 * Änderungshistorie
 * v.1.0	15.02.2013	david@honisch.org	Erstellung
 *
 *
 */
abstract class Collection{

	private $collection;
	private $type;

	public function __construct($type){

		if(is_string($type)){
			$this->type = $type;
			$this->collection = array();
		}else{
			throw new TypeException("String", "Collection::add()" );
		}

	}

	/**
	 * Gibt alle privaten Eigenschaften der Klasse zurück.
	 * @return multitype:string
	 */
	public function __sleep(){
		return array('collection', 'type');
	}

	/**
	 * Fügt ein Objekt der Collection hinzu wenn es dem im Konstruktor
	 * übergebenem Typ entspricht.
	 *
	 * @param Object $obj
	 * @throws TypeException
	 */
	public function add($obj){
			
		if($obj instanceof $this->type){
			$this->collection[] = $obj;
		}else{
			throw new TypeException($this->type, "Collection::add()" );
		}

	}

	/**
	 * Liefert die Collection
	 * @return Ambigous <$type>
	 */
	public function get(){
		return $this->collection;
	}

	/**
	 * Liefert die Größer der Collection
	 * @return number
	 */
	public function getSize(){
		return count($this->collection);
	}

	/**
	 * Liefert den vereinbarten Typ der Collection
	 * @return String
	 */
	public function getType(){
		return $this->type;
	}

}
?>