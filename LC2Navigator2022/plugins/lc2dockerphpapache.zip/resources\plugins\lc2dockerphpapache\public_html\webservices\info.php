<?php
phpinfo	();
echo "LOGGEDIN";
?>
