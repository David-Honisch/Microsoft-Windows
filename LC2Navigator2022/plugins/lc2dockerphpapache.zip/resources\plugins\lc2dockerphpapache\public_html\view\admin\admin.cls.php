<?php
 $cfgScript = '../../config/const.cls.php';
if (file_exists($cfgScript)) {
	require_once ($cfgScript);
} else {
	echo "503 - Page Configuration not found.";
	die();
}

$script = $env["root"] .'/view/admin/admin.func.cls.php';
if (file_exists($script)) {
	require_once ($script);
} else {
	echo "503 - Page not found.";
	die();
}

function
page_header($ji, $n = "", $Va = array(), $ki = "")
{
	global $ca, $ia, $b, $kc, $y;
	page_headers();
	if (is_ajax() && $n) {
		page_messages($n);
		exit;
	}
	$li = $ji . ($ki != "" ? ": $ki" : "");
	$mi = strip_tags($li . (SERVER != "" && SERVER != "localhost" ? h(" - " . SERVER) : "") . " - " . $b->name());
	echo '<!DOCTYPE html>
<html lang="', $ca, '" dir="', lang(81), '">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta name="robots" content="noindex">
<title>', $mi, '</title>
<link rel="stylesheet" type="text/css" href="', h(preg_replace("~\\?.*~", "", ME) . "?file=default.css&version=4.8.1"), '">
', script_src(preg_replace("~\\?.*~", "", ME) . "?file=functions.js&version=4.8.1");
	if ($b->head()) {
		echo '<link rel="shortcut icon" type="image/x-icon" href="', h(preg_replace("~\\?.*~", "", ME) . "?file=favicon.ico&version=4.8.1"), '">
<link rel="apple-touch-icon" href="', h(preg_replace("~\\?.*~", "", ME) . "?file=favicon.ico&version=4.8.1"), '">
';
		foreach ($b->css() as $Ob) {
			echo '<link rel="stylesheet" type="text/css" href="', h($Ob), '">
';
		}
	}
	echo '
<body class="', lang(81), ' nojs">
';
	$q = get_temp_dir() . "/lc2admin.version";
	if (!$_COOKIE["lc2admin_version"] && function_exists('openssl_verify') && file_exists($q) && filemtime($q) + 86400 > time()) {
		$Zi = unserialize(file_get_contents($q));
		$wg = "-----BEGIN PUBLIC KEY-----
MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAwqWOVuF5uw7/+Z70djoK
RlHIZFZPO0uYRezq90+7Amk+FDNd7KkL5eDve+vHRJBLAszF/7XKXe11xwliIsFs
DFWQlsABVZB3oisKCBEuI71J4kPH8dKGEWR9jDHFw3cWmoH3PmqImX6FISWbG3B8
h7FIx3jEaw5ckVPVTeo5JRm/1DZzJxjyDenXvBQ/6o9DgZKeNDgxwKzH+sw9/YCO
jHnq1cFpOIISzARlrHMa/43YfeNRAm/tsBXjSxembBPo7aQZLAWHmaj5+K19H10B
nCpz9Y++cipkVEiKRGih4ZEvjoFysEOdRLj6WiD/uUNky4xGeA6LaJqh5XpkFkcQ
fQIDAQAB
-----END PUBLIC KEY-----
";
		if (openssl_verify($Zi["version"], base64_decode($Zi["signature"]), $wg) == 1) $_COOKIE["lc2admin_version"] = $Zi["version"];
	}
	echo '<script', nonce(), '>
mixin(document.body, {onkeydown: bodyKeydown, onclick: bodyClick', (isset($_COOKIE["lc2admin_version"]) ? "" : ", onload: partial(verifyVersion, '$ia', '" . js_escape(ME) . "', '" . get_token() . "')"); ?>});
document.body.className = document.body.className.replace(/ nojs/, ' js');
var offlineMessage = '<?php echo
						js_escape(lang(82)), '\';
var thousandsSeparator = \'', js_escape(lang(5)), '\';
</script>

<div id="help" class="jush-', $y, ' jsonly hidden"></div>
', script("mixin(qs('#help'), {onmouseover: function () { helpOpen = 1; }, onmouseout: helpMouseout});"), '
<div id="content">
';
						if ($Va !== null) {
							$A = substr(preg_replace('~\b(username|db|ns)=[^&]*&~', '', ME), 0, -1);
							echo '<p id="breadcrumb"><a href="' . h($A ? $A : ".") . '">' . $kc[DRIVER] . '</a> &raquo; ';
							$A = substr(preg_replace('~\b(db|ns)=[^&]*&~', '', ME), 0, -1);
							$M = $b->serverName(SERVER);
							$M = ($M != "" ? $M : lang(34));
							if ($Va === false) echo "$M\n";
							else {
								echo "<a href='" . h($A) . "' accesskey='1' title='Alt+Shift+1'>$M</a> &raquo; ";
								if ($_GET["ns"] != "" || (DB != "" && is_array($Va))) echo '<a href="' . h($A . "&db=" . urlencode(DB) . (support("scheme") ? "&ns=" : "")) . '">' . h(DB) . '</a> &raquo; ';
								if (is_array($Va)) {
									if ($_GET["ns"] != "") echo '<a href="' . h(substr(ME, 0, -1)) . '">' . h($_GET["ns"]) . '</a> &raquo; ';
									foreach ($Va
										as $z => $X) {
										$dc = (is_array($X) ? $X[1] : h($X));
										if ($dc != "") echo "<a href='" . h(ME . "$z=") . urlencode(is_array($X) ? $X[0] : $X) . "'>$dc</a> &raquo; ";
									}
								}
								echo "$ji\n";
							}
						}
						echo "<h2>$li</h2>\n", "<div id='ajaxstatus' class='jsonly hidden'></div>\n";
						restart_session();
						page_messages($n);
						$k = &get_session("dbs");
						if (DB != "" && $k && !in_array(DB, $k, true)) $k = null;
						stop_session();
						define("PAGE_HEADER", 1);
					}
					function
					page_headers()
					{
						global $b;
						header("Content-Type: text/html; charset=utf-8");
						header("Cache-Control: no-cache");
						header("X-Frame-Options: deny");
						header("X-XSS-Protection: 0");
						header("X-Content-Type-Options: nosniff");
						header("Referrer-Policy: origin-when-cross-origin");
						foreach ($b->csp() as $Nb) {
							$Ad = array();
							foreach ($Nb
								as $z => $X) $Ad[] = "$z $X";
							header("Content-Security-Policy: " . implode("; ", $Ad));
						}
						$b->headers();
					}
					function
					csp()
					{
						return
							array(array("script-src" => "'self' 'unsafe-inline' 'nonce-" . get_nonce() . "' 'strict-dynamic'", "connect-src" => "'self'", "frame-src" => "https://www.lc2admin.org", "object-src" => "'none'", "base-uri" => "'none'", "form-action" => "'self'",),);
					}
					function
					get_nonce()
					{
						static $ef;
						if (!$ef) $ef = base64_encode(rand_string());
						return $ef;
					}
					function
					page_messages($n)
					{
						$Mi = preg_replace('~^[^?]*~', '', $_SERVER["REQUEST_URI"]);
						$Re = $_SESSION["messages"][$Mi];
						if ($Re) {
							echo "<div class='message'>" . implode("</div>\n<div class='message'>", $Re) . "</div>" . script("messagesPrint();");
							unset($_SESSION["messages"][$Mi]);
						}
						if ($n) echo "<div class='error'>$n</div>\n";
					}
					function
					page_footer($Ue = "")
					{
						global $b, $qi;
						echo '</div>

';
						switch_lang();
						if ($Ue != "auth") {
							echo '<form action="" method="post">
<p class="logout">
<input type="submit" name="logout" value="', lang(83), '" id="logout">
<input type="hidden" name="token" value="', $qi, '">
</p>
</form>
';
						}
						echo '<div id="menu">
';
						$b->navigation($Ue);
						echo '</div>
', script("setupSubmitHighlight(document);");
					}
					function
					int32($Xe)
					{
						while ($Xe >= 2147483648) $Xe -= 4294967296;
						while ($Xe <= -2147483649) $Xe += 4294967296;
						return (int)$Xe;
					}
					function
					long2str($W, $dj)
					{
						$ah = '';
						foreach ($W
							as $X) $ah .= pack('V', $X);
						if ($dj) return
							substr($ah, 0, end($W));
						return $ah;
					}
					function
					str2long($ah, $dj)
					{
						$W = array_values(unpack('V*', str_pad($ah, 4 * ceil(strlen($ah) / 4), "\0")));
						if ($dj) $W[] = strlen($ah);
						return $W;
					}
					function
					xxtea_mx($pj, $oj, $Nh, $he)
					{
						return
							int32((($pj >> 5 & 0x7FFFFFF) ^ $oj << 2) + (($oj >> 3 & 0x1FFFFFFF) ^ $pj << 4)) ^ int32(($Nh ^ $oj) + ($he ^ $pj));
					}
					function
					encrypt_string($Ih, $z)
					{
						if ($Ih == "") return "";
						$z = array_values(unpack("V*", pack("H*", md5($z))));
						$W = str2long($Ih, true);
						$Xe = count($W) - 1;
						$pj = $W[$Xe];
						$oj = $W[0];
						$xg = floor(6 + 52 / ($Xe + 1));
						$Nh = 0;
						while ($xg-- > 0) {
							$Nh = int32($Nh + 0x9E3779B9);
							$rc = $Nh >> 2 & 3;
							for ($Of = 0; $Of < $Xe; $Of++) {
								$oj = $W[$Of + 1];
								$We = xxtea_mx($pj, $oj, $Nh, $z[$Of & 3 ^ $rc]);
								$pj = int32($W[$Of] + $We);
								$W[$Of] = $pj;
							}
							$oj = $W[0];
							$We = xxtea_mx($pj, $oj, $Nh, $z[$Of & 3 ^ $rc]);
							$pj = int32($W[$Xe] + $We);
							$W[$Xe] = $pj;
						}
						return
							long2str($W, false);
					}
					function
					decrypt_string($Ih, $z)
					{
						if ($Ih == "") return "";
						if (!$z) return
							false;
						$z = array_values(unpack("V*", pack("H*", md5($z))));
						$W = str2long($Ih, false);
						$Xe = count($W) - 1;
						$pj = $W[$Xe];
						$oj = $W[0];
						$xg = floor(6 + 52 / ($Xe + 1));
						$Nh = int32($xg * 0x9E3779B9);
						while ($Nh) {
							$rc = $Nh >> 2 & 3;
							for ($Of = $Xe; $Of > 0; $Of--) {
								$pj = $W[$Of - 1];
								$We = xxtea_mx($pj, $oj, $Nh, $z[$Of & 3 ^ $rc]);
								$oj = int32($W[$Of] - $We);
								$W[$Of] = $oj;
							}
							$pj = $W[$Xe];
							$We = xxtea_mx($pj, $oj, $Nh, $z[$Of & 3 ^ $rc]);
							$oj = int32($W[0] - $We);
							$W[0] = $oj;
							$Nh = int32($Nh - 0x9E3779B9);
						}
						return
							long2str($W, true);
					}
					$g = '';
					$_d = $_SESSION["token"];
					if (!$_d) $_SESSION["token"] = rand(1, 1e6);
					$qi = get_token();
					$eg = array();
					if ($_COOKIE["lc2admin_permanent"]) {
						foreach (explode(" ", $_COOKIE["lc2admin_permanent"]) as $X) {
							list($z) = explode(":", $X);
							$eg[$z] = $X;
						}
					}
					function
					add_invalid_login()
					{
						global $b;
						$nd = file_open_lock(get_temp_dir() . "/lc2admin.invalid");
						if (!$nd) return;
						$ae = unserialize(stream_get_contents($nd));
						$gi = time();
						if ($ae) {
							foreach ($ae
								as $be => $X) {
								if ($X[0] < $gi) unset($ae[$be]);
							}
						}
						$Zd = &$ae[$b->bruteForceKey()];
						if (!$Zd) $Zd = array($gi + 30 * 60, 0);
						$Zd[1]++;
						file_write_unlock($nd, serialize($ae));
					}
					function
					check_invalid_login()
					{
						global $b;
						$ae = unserialize(@file_get_contents(get_temp_dir() . "/lc2admin.invalid"));
						$Zd = ($ae ? $ae[$b->bruteForceKey()] : array());
						$df = ($Zd[1] > 29 ? $Zd[0] - time() : 0);
						if ($df > 0) auth_error(lang(84, ceil($df / 60)));
					}
					$Ja = $_POST["auth"];
					if ($Ja) {
						session_regenerate_id();
						$Yi = $Ja["driver"];
						$M = $Ja["server"];
						$V = $Ja["username"];
						$F = (string)$Ja["password"];
						$l = $Ja["db"];
						set_password($Yi, $M, $V, $F);
						$_SESSION["db"][$Yi][$M][$V][$l] = true;
						if ($Ja["permanent"]) {
							$z = base64_encode($Yi) . "-" . base64_encode($M) . "-" . base64_encode($V) . "-" . base64_encode($l);
							$qg = $b->permanentLogin(true);
							$eg[$z] = "$z:" . base64_encode($qg ? encrypt_string($F, $qg) : "");
							cookie("lc2admin_permanent", implode(" ", $eg));
						}
						if (count($_POST) == 1 || DRIVER != $Yi || SERVER != $M || $_GET["username"] !== $V || DB != $l) redirect(auth_url($Yi, $M, $V, $l));
					} elseif ($_POST["logout"] && (!$_d || verify_token())) {
						foreach (array("pwds", "db", "dbs", "queries") as $z) set_session($z, null);
						unset_permanent();
						redirect(substr(preg_replace('~\b(username|db|ns)=[^&]*&~', '', ME), 0, -1), lang(85) . ' ' . lang(86));
					} elseif ($eg && !$_SESSION["pwds"]) {
						session_regenerate_id();
						$qg = $b->permanentLogin();
						foreach ($eg
							as $z => $X) {
							list(, $gb) = explode(":", $X);
							list($Yi, $M, $V, $l) = array_map('base64_decode', explode("-", $z));
							set_password($Yi, $M, $V, decrypt_string(base64_decode($gb), $qg));
							$_SESSION["db"][$Yi][$M][$V][$l] = true;
						}
					}
					function
					unset_permanent()
					{
						global $eg;
						foreach ($eg
							as $z => $X) {
							list($Yi, $M, $V, $l) = array_map('base64_decode', explode("-", $z));
							if ($Yi == DRIVER && $M == SERVER && $V == $_GET["username"] && $l == DB) unset($eg[$z]);
						}
						cookie("lc2admin_permanent", implode(" ", $eg));
					}
					function
					auth_error($n)
					{
						global $b, $_d;
						$ph = session_name();
						if (isset($_GET["username"])) {
							header("HTTP/1.1 403 Forbidden");
							if (($_COOKIE[$ph] || $_GET[$ph]) && !$_d) $n = lang(87);
							else {
								restart_session();
								add_invalid_login();
								$F = get_password();
								if ($F !== null) {
									if ($F === false) $n .= ($n ? '<br>' : '') . lang(88, target_blank(), '<code>permanentLogin()</code>');
									set_password(DRIVER, SERVER, $_GET["username"], null);
								}
								unset_permanent();
							}
						}
						if (!$_COOKIE[$ph] && $_GET[$ph] && ini_bool("session.use_only_cookies")) $n = lang(89);
						$Rf = session_get_cookie_params();
						cookie("lc2admin_key", ($_COOKIE["lc2admin_key"] ? $_COOKIE["lc2admin_key"] : rand_string()), $Rf["lifetime"]);
						page_header(lang(38), $n, null);
						echo "<form action='' method='post'>\n", "<div>";
						if (hidden_fields($_POST, array("auth"))) echo "<p class='message'>" . lang(90) . "\n";
						echo "</div>\n";
						$b->loginForm();
						echo "</form>\n";
						page_footer("auth");
						exit;
					}
					if (isset($_GET["username"]) && !class_exists("Min_DB")) {
						unset($_SESSION["pwds"][DRIVER]);
						unset_permanent();
						page_header(lang(91), lang(92, implode(", ", $kg)), false);
						page_footer("auth");
						exit;
					}
					stop_session(true);
					if (isset($_GET["username"]) && is_string(get_password())) {
						list($Fd, $gg) = explode(":", SERVER, 2);
						if (preg_match('~^\s*([-+]?\d+)~', $gg, $C) && ($C[1] < 1024 || $C[1] > 65535)) auth_error(lang(93));
						check_invalid_login();
						$g = connect();
						$m = new
							Min_Driver($g);
					}
					$_e = null;
					if (!is_object($g) || ($_e = $b->login($_GET["username"], get_password())) !== true) {
						$n = (is_string($g) ? h($g) : (is_string($_e) ? $_e : lang(32)));
						auth_error($n . (preg_match('~^ | $~', get_password()) ? '<br>' . lang(94) : ''));
					}
					if ($_POST["logout"] && $_d && !verify_token()) {
						page_header(lang(83), lang(95));
						page_footer("db");
						exit;
					}
					if ($Ja && $_POST["token"]) $_POST["token"] = $qi;
					$n = '';
					if ($_POST) {
						if (!verify_token()) {
							$Ud = "max_input_vars";
							$Le = ini_get($Ud);
							if (extension_loaded("suhosin")) {
								foreach (array("suhosin.request.max_vars", "suhosin.post.max_vars") as $z) {
									$X = ini_get($z);
									if ($X && (!$Le || $X < $Le)) {
										$Ud = $z;
										$Le = $X;
									}
								}
							}
							$n = (!$_POST["token"] && $Le ? lang(96, "'$Ud'") : lang(95) . ' ' . lang(97));
						}
					} elseif ($_SERVER["REQUEST_METHOD"] == "POST") {
						$n = lang(98, "'post_max_size'");
						if (isset($_GET["sql"])) $n .= ' ' . lang(99);
					}
					function
					select($H, $h = null, $Ef = array(), $_ = 0)
					{
						global $y;
						$ze = array();
						$x = array();
						$e = array();
						$Ta = array();
						$U = array();
						$I = array();
						odd('');
						for ($t = 0; (!$_ || $t < $_) && ($J = $H->fetch_row()); $t++) {
							if (!$t) {
								echo "<div class='scrollable'>\n", "<table cellspacing='0' class='nowrap'>\n", "<thead><tr>";
								for ($ge = 0; $ge < count($J); $ge++) {
									$o = $H->fetch_field();
									$D = $o->name;
									$Df = $o->orgtable;
									$Cf = $o->orgname;
									$I[$o->table] = $Df;
									if ($Ef && $y == "sql") $ze[$ge] = ($D == "table" ? "table=" : ($D == "possible_keys" ? "indexes=" : null));
									elseif ($Df != "") {
										if (!isset($x[$Df])) {
											$x[$Df] = array();
											foreach (indexes($Df, $h) as $w) {
												if ($w["type"] == "PRIMARY") {
													$x[$Df] = array_flip($w["columns"]);
													break;
												}
											}
											$e[$Df] = $x[$Df];
										}
										if (isset($e[$Df][$Cf])) {
											unset($e[$Df][$Cf]);
											$x[$Df][$Cf] = $ge;
											$ze[$ge] = $Df;
										}
									}
									if ($o->charsetnr == 63) $Ta[$ge] = true;
									$U[$ge] = $o->type;
									echo "<th" . ($Df != "" || $o->name != $Cf ? " title='" . h(($Df != "" ? "$Df." : "") . $Cf) . "'" : "") . ">" . h($D) . ($Ef ? doc_link(array('sql' => "explain-output.html#explain_" . strtolower($D), 'mariadb' => "explain/#the-columns-in-explain-select",)) : "");
								}
								echo "</thead>\n";
							}
							echo "<tr" . odd() . ">";
							foreach ($J
								as $z => $X) {
								$A = "";
								if (isset($ze[$z]) && !$e[$ze[$z]]) {
									if ($Ef && $y == "sql") {
										$Q = $J[array_search("table=", $ze)];
										$A = ME . $ze[$z] . urlencode($Ef[$Q] != "" ? $Ef[$Q] : $Q);
									} else {
										$A = ME . "edit=" . urlencode($ze[$z]);
										foreach ($x[$ze[$z]] as $kb => $ge) $A .= "&where" . urlencode("[" . bracket_escape($kb) . "]") . "=" . urlencode($J[$ge]);
									}
								} elseif (is_url($X)) $A = $X;
								if ($X === null) $X = "<i>NULL</i>";
								elseif ($Ta[$z] && !is_utf8($X)) $X = "<i>" . lang(47, strlen($X)) . "</i>";
								else {
									$X = h($X);
									if ($U[$z] == 254) $X = "<code>$X</code>";
								}
								if ($A) $X = "<a href='" . h($A) . "'" . (is_url($A) ? target_blank() : '') . ">$X</a>";
								echo "<td>$X";
							}
						}
						echo ($t ? "</table>\n</div>" : "<p class='message'>" . lang(12)) . "\n";
						return $I;
					}
					function
					referencable_primary($ih)
					{
						$I = array();
						foreach (table_status('', true) as $Rh => $Q) {
							if ($Rh != $ih && fk_support($Q)) {
								foreach (fields($Rh) as $o) {
									if ($o["primary"]) {
										if ($I[$Rh]) {
											unset($I[$Rh]);
											break;
										}
										$I[$Rh] = $o;
									}
								}
							}
						}
						return $I;
					}
					function
					lc2admin_settings()
					{
						parse_str($_COOKIE["lc2admin_settings"], $rh);
						return $rh;
					}
					function
					lc2admin_setting($z)
					{
						$rh = lc2admin_settings();
						return $rh[$z];
					}
					function
					set_lc2admin_settings($rh)
					{
						return
							cookie("lc2admin_settings", http_build_query($rh + lc2admin_settings()));
					}
					function
					textarea($D, $Y, $K = 10, $pb = 80)
					{
						global $y;
						echo "<textarea name='$D' rows='$K' cols='$pb' class='sqlarea jush-$y' spellcheck='false' wrap='off'>";
						if (is_array($Y)) {
							foreach ($Y
								as $X) echo
							h($X[0]) . "\n\n\n";
						} else
							echo
							h($Y);
						echo "</textarea>";
					}
					function
					edit_type($z, $o, $nb, $jd = array(), $Rc = array())
					{
						global $Jh, $U, $Ki, $sf;
						$T = $o["type"];
						echo '<td><select name="', h($z), '[type]" class="type" aria-labelledby="label-type">';
						if ($T && !isset($U[$T]) && !isset($jd[$T]) && !in_array($T, $Rc)) $Rc[] = $T;
						if ($jd) $Jh[lang(100)] = $jd;
						echo
						optionlist(array_merge($Rc, $Jh), $T), '</select><td><input name="', h($z), '[length]" value="', h($o["length"]), '" size="3"', (!$o["length"] && preg_match('~var(char|binary)$~', $T) ? " class='required'" : "");
						echo ' aria-labelledby="label-length"><td class="options">', "<select name='" . h($z) . "[collation]'" . (preg_match('~(char|text|enum|set)$~', $T) ? "" : " class='hidden'") . '><option value="">(' . lang(101) . ')' . optionlist($nb, $o["collation"]) . '</select>', ($Ki ? "<select name='" . h($z) . "[unsigned]'" . (!$T || preg_match(number_type(), $T) ? "" : " class='hidden'") . '><option>' . optionlist($Ki, $o["unsigned"]) . '</select>' : ''), (isset($o['on_update']) ? "<select name='" . h($z) . "[on_update]'" . (preg_match('~timestamp|datetime~', $T) ? "" : " class='hidden'") . '>' . optionlist(array("" => "(" . lang(102) . ")", "CURRENT_TIMESTAMP"), (preg_match('~^CURRENT_TIMESTAMP~i', $o["on_update"]) ? "CURRENT_TIMESTAMP" : $o["on_update"])) . '</select>' : ''), ($jd ? "<select name='" . h($z) . "[on_delete]'" . (preg_match("~`~", $T) ? "" : " class='hidden'") . "><option value=''>(" . lang(103) . ")" . optionlist(explode("|", $sf), $o["on_delete"]) . "</select> " : " ");
					}
					function
					process_length($we)
					{
						global $Bc;
						return (preg_match("~^\\s*\\(?\\s*$Bc(?:\\s*,\\s*$Bc)*+\\s*\\)?\\s*\$~", $we) && preg_match_all("~$Bc~", $we, $Fe) ? "(" . implode(",", $Fe[0]) . ")" : preg_replace('~^[0-9].*~', '(\0)', preg_replace('~[^-0-9,+()[\]]~', '', $we)));
					}
					function
					process_type($o, $lb = "COLLATE")
					{
						global $Ki;
						return " $o[type]" . process_length($o["length"]) . (preg_match(number_type(), $o["type"]) && in_array($o["unsigned"], $Ki) ? " $o[unsigned]" : "") . (preg_match('~char|text|enum|set~', $o["type"]) && $o["collation"] ? " $lb " . q($o["collation"]) : "");
					}
					function
					process_field($o, $Ci)
					{
						return
							array(idf_escape(trim($o["field"])), process_type($Ci), ($o["null"] ? " NULL" : " NOT NULL"), default_value($o), (preg_match('~timestamp|datetime~', $o["type"]) && $o["on_update"] ? " ON UPDATE $o[on_update]" : ""), (support("comment") && $o["comment"] != "" ? " COMMENT " . q($o["comment"]) : ""), ($o["auto_increment"] ? auto_increment() : null),);
					}
					function
					default_value($o)
					{
						$Yb = $o["default"];
						return ($Yb === null ? "" : " DEFAULT " . (preg_match('~char|binary|text|enum|set~', $o["type"]) || preg_match('~^(?![a-z])~i', $Yb) ? q($Yb) : $Yb));
					}
					function
					type_class($T)
					{
						foreach (array('char' => 'text', 'date' => 'time|year', 'binary' => 'blob', 'enum' => 'set',) as $z => $X) {
							if (preg_match("~$z|$X~", $T)) return " class='$z'";
						}
					}
					function
					edit_fields($p, $nb, $T = "TABLE", $jd = array())
					{
						global $Vd;
						$p = array_values($p);
						$Zb = (($_POST ? $_POST["defaults"] : lc2admin_setting("defaults")) ? "" : " class='hidden'");
						$ub = (($_POST ? $_POST["comments"] : lc2admin_setting("comments")) ? "" : " class='hidden'");
						echo '<thead><tr>
';
						if ($T == "PROCEDURE") {
							echo '<td>';
						}
						echo '<th id="label-name">', ($T == "TABLE" ? lang(104) : lang(105)), '<td id="label-type">', lang(49), '<textarea id="enum-edit" rows="4" cols="12" wrap="off" style="display: none;"></textarea>', script("qs('#enum-edit').onblur = editingLengthBlur;"), '<td id="label-length">', lang(106), '<td>', lang(107);
						if ($T == "TABLE") {
							echo '<td id="label-null">NULL
<td><input type="radio" name="auto_increment_col" value=""><acronym id="label-ai" title="', lang(51), '">AI</acronym>', doc_link(array('sql' => "example-auto-increment.html", 'mariadb' => "auto_increment/", 'sqlite' => "autoinc.html", 'pgsql' => "datatype.html#DATATYPE-SERIAL", 'mssql' => "ms186775.aspx",)), '<td id="label-default"', $Zb, '>', lang(52), (support("comment") ? "<td id='label-comment'$ub>" . lang(50) : "");
						}
						echo '<td>', "<input type='image' class='icon' name='add[" . (support("move_col") ? 0 : count($p)) . "]' src='" . h(preg_replace("~\\?.*~", "", ME) . "?file=plus.gif&version=4.8.1") . "' alt='+' title='" . lang(108) . "'>" . script("row_count = " . count($p) . ";"), '</thead>
<tbody>
', script("mixin(qsl('tbody'), {onclick: editingClick, onkeydown: editingKeydown, oninput: editingInput});");
						foreach ($p
							as $t => $o) {
							$t++;
							$Ff = $o[($_POST ? "orig" : "field")];
							$hc = (isset($_POST["add"][$t - 1]) || (isset($o["field"]) && !$_POST["drop_col"][$t])) && (support("drop_col") || $Ff == "");
							echo '<tr', ($hc ? "" : " style='display: none;'"), '>
', ($T == "PROCEDURE" ? "<td>" . html_select("fields[$t][inout]", explode("|", $Vd), $o["inout"]) : ""), '<th>';
							if ($hc) {
								echo '<input name="fields[', $t, '][field]" value="', h($o["field"]), '" data-maxlength="64" autocapitalize="off" aria-labelledby="label-name">';
							}
							echo '<input type="hidden" name="fields[', $t, '][orig]" value="', h($Ff), '">';
							edit_type("fields[$t]", $o, $nb, $jd);
							if ($T == "TABLE") {
								echo '<td>', checkbox("fields[$t][null]", 1, $o["null"], "", "", "block", "label-null"), '<td><label class="block"><input type="radio" name="auto_increment_col" value="', $t, '"';
								if ($o["auto_increment"]) {
									echo ' checked';
								}
								echo ' aria-labelledby="label-ai"></label><td', $Zb, '>', checkbox("fields[$t][has_default]", 1, $o["has_default"], "", "", "", "label-default"), '<input name="fields[', $t, '][default]" value="', h($o["default"]), '" aria-labelledby="label-default">', (support("comment") ? "<td$ub><input name='fields[$t][comment]' value='" . h($o["comment"]) . "' data-maxlength='" . (min_version(5.5) ? 1024 : 255) . "' aria-labelledby='label-comment'>" : "");
							}
							echo "<td>", (support("move_col") ? "<input type='image' class='icon' name='add[$t]' src='" . h(preg_replace("~\\?.*~", "", ME) . "?file=plus.gif&version=4.8.1") . "' alt='+' title='" . lang(108) . "'> " . "<input type='image' class='icon' name='up[$t]' src='" . h(preg_replace("~\\?.*~", "", ME) . "?file=up.gif&version=4.8.1") . "' alt='↑' title='" . lang(109) . "'> " . "<input type='image' class='icon' name='down[$t]' src='" . h(preg_replace("~\\?.*~", "", ME) . "?file=down.gif&version=4.8.1") . "' alt='↓' title='" . lang(110) . "'> " : ""), ($Ff == "" || support("drop_col") ? "<input type='image' class='icon' name='drop_col[$t]' src='" . h(preg_replace("~\\?.*~", "", ME) . "?file=cross.gif&version=4.8.1") . "' alt='x' title='" . lang(111) . "'>" : "");
						}
					}
					function
					process_fields(&$p)
					{
						$kf = 0;
						if ($_POST["up"]) {
							$qe = 0;
							foreach ($p
								as $z => $o) {
								if (key($_POST["up"]) == $z) {
									unset($p[$z]);
									array_splice($p, $qe, 0, array($o));
									break;
								}
								if (isset($o["field"])) $qe = $kf;
								$kf++;
							}
						} elseif ($_POST["down"]) {
							$ld = false;
							foreach ($p
								as $z => $o) {
								if (isset($o["field"]) && $ld) {
									unset($p[key($_POST["down"])]);
									array_splice($p, $kf, 0, array($ld));
									break;
								}
								if (key($_POST["down"]) == $z) $ld = $o;
								$kf++;
							}
						} elseif ($_POST["add"]) {
							$p = array_values($p);
							array_splice($p, key($_POST["add"]), 0, array(array()));
						} elseif (!$_POST["drop_col"]) return
							false;
						return
							true;
					}
					function
					normalize_enum($C)
					{
						return "'" . str_replace("'", "''", addcslashes(stripcslashes(str_replace($C[0][0] . $C[0][0], $C[0][0], substr($C[0], 1, -1))), '\\')) . "'";
					}
					function
					grant($qd, $sg, $e, $rf)
					{
						if (!$sg) return
							true;
						if ($sg == array("ALL PRIVILEGES", "GRANT OPTION")) return ($qd == "GRANT" ? queries("$qd ALL PRIVILEGES$rf WITH GRANT OPTION") : queries("$qd ALL PRIVILEGES$rf") && queries("$qd GRANT OPTION$rf"));
						return
							queries("$qd " . preg_replace('~(GRANT OPTION)\([^)]*\)~', '\1', implode("$e, ", $sg) . $e) . $rf);
					}
					function
					drop_create($lc, $i, $mc, $di, $oc, $B, $Qe, $Oe, $Pe, $of, $bf)
					{
						if ($_POST["drop"]) query_redirect($lc, $B, $Qe);
						elseif ($of == "") query_redirect($i, $B, $Pe);
						elseif ($of != $bf) {
							$Lb = queries($i);
							queries_redirect($B, $Oe, $Lb && queries($lc));
							if ($Lb) queries($mc);
						} else
							queries_redirect($B, $Oe, queries($di) && queries($oc) && queries($lc) && queries($i));
					}
					function
					create_trigger($rf, $J)
					{
						global $y;
						$ii = " $J[Timing] $J[Event]" . (preg_match('~ OF~', $J["Event"]) ? " $J[Of]" : "");
						return "CREATE TRIGGER " . idf_escape($J["Trigger"]) . ($y == "mssql" ? $rf . $ii : $ii . $rf) . rtrim(" $J[Type]\n$J[Statement]", ";") . ";";
					}
					function
					create_routine($Wg, $J)
					{
						global $Vd, $y;
						$N = array();
						$p = (array)$J["fields"];
						ksort($p);
						foreach ($p
							as $o) {
							if ($o["field"] != "") $N[] = (preg_match("~^($Vd)\$~", $o["inout"]) ? "$o[inout] " : "") . idf_escape($o["field"]) . process_type($o, "CHARACTER SET");
						}
						$ac = rtrim("\n$J[definition]", ";");
						return "CREATE $Wg " . idf_escape(trim($J["name"])) . " (" . implode(", ", $N) . ")" . (isset($_GET["function"]) ? " RETURNS" . process_type($J["returns"], "CHARACTER SET") : "") . ($J["language"] ? " LANGUAGE $J[language]" : "") . ($y == "pgsql" ? " AS " . q($ac) : "$ac;");
					}
					function
					remove_definer($G)
					{
						return
							preg_replace('~^([A-Z =]+) DEFINER=`' . preg_replace('~@(.*)~', '`@`(%|\1)', logged_user()) . '`~', '\1', $G);
					}
					function
					format_foreign_key($r)
					{
						global $sf;
						$l = $r["db"];
						$ff = $r["ns"];
						return " FOREIGN KEY (" . implode(", ", array_map('idf_escape', $r["source"])) . ") REFERENCES " . ($l != "" && $l != $_GET["db"] ? idf_escape($l) . "." : "") . ($ff != "" && $ff != $_GET["ns"] ? idf_escape($ff) . "." : "") . table($r["table"]) . " (" . implode(", ", array_map('idf_escape', $r["target"])) . ")" . (preg_match("~^($sf)\$~", $r["on_delete"]) ? " ON DELETE $r[on_delete]" : "") . (preg_match("~^($sf)\$~", $r["on_update"]) ? " ON UPDATE $r[on_update]" : "");
					}
					function
					tar_file($q, $ni)
					{
						$I = pack("a100a8a8a8a12a12", $q, 644, 0, 0, decoct($ni->size), decoct(time()));
						$fb = 8 * 32;
						for ($t = 0; $t < strlen($I); $t++) $fb += ord($I[$t]);
						$I .= sprintf("%06o", $fb) . "\0 ";
						echo $I, str_repeat("\0", 512 - strlen($I));
						$ni->send();
						echo
						str_repeat("\0", 511 - ($ni->size + 511) % 512);
					}
					function
					ini_bytes($Ud)
					{
						$X = ini_get($Ud);
						switch (strtolower(substr($X, -1))) {
							case 'g':
								$X *= 1024;
							case 'm':
								$X *= 1024;
							case 'k':
								$X *= 1024;
						}
						return $X;
					}
					function
					doc_link($bg, $ei = "<sup>?</sup>")
					{
						global $y, $g;
						$nh = $g->server_info;
						$Zi = preg_replace('~^(\d\.?\d).*~s', '\1', $nh);
						$Oi = array('sql' => "https://dev.mysql.com/doc/refman/$Zi/en/", 'sqlite' => "https://www.sqlite.org/", 'pgsql' => "https://www.postgresql.org/docs/$Zi/", 'mssql' => "https://msdn.microsoft.com/library/", 'oracle' => "https://www.oracle.com/pls/topic/lookup?ctx=db" . preg_replace('~^.* (\d+)\.(\d+)\.\d+\.\d+\.\d+.*~s', '\1\2', $nh) . "&id=",);
						if (preg_match('~MariaDB~', $nh)) {
							$Oi['sql'] = "https://mariadb.com/kb/en/library/";
							$bg['sql'] = (isset($bg['mariadb']) ? $bg['mariadb'] : str_replace(".html", "/", $bg['sql']));
						}
						return ($bg[$y] ? "<a href='" . h($Oi[$y] . $bg[$y]) . "'" . target_blank() . ">$ei</a>" : "");
					}
					function
					ob_gzencode($P)
					{
						return
							gzencode($P);
					}
					function
					db_size($l)
					{
						global $g;
						if (!$g->select_db($l)) return "?";
						$I = 0;
						foreach (table_status() as $R) $I += $R["Data_length"] + $R["Index_length"];
						return
							format_number($I);
					}
					function
					set_utf8mb4($i)
					{
						global $g;
						static $N = false;
						if (!$N && preg_match('~\butf8mb4~i', $i)) {
							$N = true;
							echo "SET NAMES " . charset($g) . ";\n\n";
						}
					}
					function
					connect_error()
					{
						global $b, $g, $qi, $n, $kc;
						if (DB != "") {
							header("HTTP/1.1 404 Not Found");
							page_header(lang(37) . ": " . h(DB), lang(112), true);
						} else {
							if ($_POST["db"] && !$n) queries_redirect(substr(ME, 0, -1), lang(113), drop_databases($_POST["db"]));
							page_header(lang(114), $n, false);
							echo "<p class='links'>\n";
							foreach (array('database' => lang(115), 'privileges' => lang(71), 'processlist' => lang(116), 'variables' => lang(117), 'status' => lang(118),) as $z => $X) {
								if (support($z)) echo "<a href='" . h(ME) . "$z='>$X</a>\n";
							}
							echo "<p>" . lang(119, $kc[DRIVER], "<b>" . h($g->server_info) . "</b>", "<b>$g->extension</b>") . "\n", "<p>" . lang(120, "<b>" . h(logged_user()) . "</b>") . "\n";
							$k = $b->databases();
							if ($k) {
								$dh = support("scheme");
								$nb = collations();
								echo "<form action='' method='post'>\n", "<table cellspacing='0' class='checkable'>\n", script("mixin(qsl('table'), {onclick: tableClick, ondblclick: partialArg(tableClick, true)});"), "<thead><tr>" . (support("database") ? "<td>" : "") . "<th>" . lang(37) . " - <a href='" . h(ME) . "refresh=1'>" . lang(121) . "</a>" . "<td>" . lang(122) . "<td>" . lang(123) . "<td>" . lang(124) . " - <a href='" . h(ME) . "dbsize=1'>" . lang(125) . "</a>" . script("qsl('a').onclick = partial(ajaxSetHtml, '" . js_escape(ME) . "script=connect');", "") . "</thead>\n";
								$k = ($_GET["dbsize"] ? count_tables($k) : array_flip($k));
								foreach ($k
									as $l => $S) {
									$Vg = h(ME) . "db=" . urlencode($l);
									$u = h("Db-" . $l);
									echo "<tr" . odd() . ">" . (support("database") ? "<td>" . checkbox("db[]", $l, in_array($l, (array)$_POST["db"]), "", "", "", $u) : ""), "<th><a href='$Vg' id='$u'>" . h($l) . "</a>";
									$mb = h(db_collation($l, $nb));
									echo "<td>" . (support("database") ? "<a href='$Vg" . ($dh ? "&amp;ns=" : "") . "&amp;database=' title='" . lang(67) . "'>$mb</a>" : $mb), "<td align='right'><a href='$Vg&amp;schema=' id='tables-" . h($l) . "' title='" . lang(70) . "'>" . ($_GET["dbsize"] ? $S : "?") . "</a>", "<td align='right' id='size-" . h($l) . "'>" . ($_GET["dbsize"] ? db_size($l) : "?"), "\n";
								}
								echo "</table>\n", (support("database") ? "<div class='footer'><div>\n" . "<fieldset><legend>" . lang(126) . " <span id='selected'></span></legend><div>\n" . "<input type='hidden' name='all' value=''>" . script("qsl('input').onclick = function () { selectCount('selected', formChecked(this, /^db/)); };") . "<input type='submit' name='drop' value='" . lang(127) . "'>" . confirm() . "\n" . "</div></fieldset>\n" . "</div></div>\n" : ""), "<input type='hidden' name='token' value='$qi'>\n", "</form>\n", script("tableCheck();");
							}
						}
						page_footer("db");
					}
					if (isset($_GET["status"])) $_GET["variables"] = $_GET["status"];
					if (isset($_GET["import"])) $_GET["sql"] = $_GET["import"];
					if (!(DB != "" ? $g->select_db(DB) : isset($_GET["sql"]) || isset($_GET["dump"]) || isset($_GET["database"]) || isset($_GET["processlist"]) || isset($_GET["privileges"]) || isset($_GET["user"]) || isset($_GET["variables"]) || $_GET["script"] == "connect" || $_GET["script"] == "kill")) {
						if (DB != "" || $_GET["refresh"]) {
							restart_session();
							set_session("dbs", null);
						}
						connect_error();
						exit;
					}
					if (support("scheme")) {
						if (DB != "" && $_GET["ns"] !== "") {
							if (!isset($_GET["ns"])) redirect(preg_replace('~ns=[^&]*&~', '', ME) . "ns=" . get_schema());
							if (!set_schema($_GET["ns"])) {
								header("HTTP/1.1 404 Not Found");
								page_header(lang(77) . ": " . h($_GET["ns"]), lang(128), true);
								page_footer("ns");
								exit;
							}
						}
					}
					$sf = "RESTRICT|NO ACTION|CASCADE|SET NULL|SET DEFAULT";
					class
					TmpFile
					{
						var $handler;
						var $size;
						function
						__construct()
						{
							$this->handler = tmpfile();
						}
						function
						write($Eb)
						{
							$this->size += strlen($Eb);
							fwrite($this->handler, $Eb);
						}
						function
						send()
						{
							fseek($this->handler, 0);
							fpassthru($this->handler);
							fclose($this->handler);
						}
					}
					$Bc = "'(?:''|[^'\\\\]|\\\\.)*'";
					$Vd = "IN|OUT|INOUT";
					if (isset($_GET["select"]) && ($_POST["edit"] || $_POST["clone"]) && !$_POST["save"]) $_GET["edit"] = $_GET["select"];
					if (isset($_GET["callf"])) $_GET["call"] = $_GET["callf"];
					if (isset($_GET["function"])) $_GET["procedure"] = $_GET["function"];
					if (isset($_GET["download"])) {
						$a = $_GET["download"];
						$p = fields($a);
						header("Content-Type: application/octet-stream");
						header("Content-Disposition: attachment; filename=" . friendly_url("$a-" . implode("_", $_GET["where"])) . "." . friendly_url($_GET["field"]));
						$L = array(idf_escape($_GET["field"]));
						$H = $m->select($a, $L, array(where($_GET, $p)), $L);
						$J = ($H ? $H->fetch_row() : array());
						echo $m->value($J[0], $p[$_GET["field"]]);
						exit;
					} elseif (isset($_GET["table"])) {
						$a = $_GET["table"];
						$p = fields($a);
						if (!$p) $n = error();
						$R = table_status1($a, true);
						$D = $b->tableName($R);
						page_header(($p && is_view($R) ? $R['Engine'] == 'materialized view' ? lang(129) : lang(130) : lang(131)) . ": " . ($D != "" ? $D : h($a)), $n);
						$b->selectLinks($R);
						$tb = $R["Comment"];
						if ($tb != "") echo "<p class='nowrap'>" . lang(50) . ": " . h($tb) . "\n";
						if ($p) $b->tableStructurePrint($p);
						if (!is_view($R)) {
							if (support("indexes")) {
								echo "<h3 id='indexes'>" . lang(132) . "</h3>\n";
								$x = indexes($a);
								if ($x) $b->tableIndexesPrint($x);
								echo '<p class="links"><a href="' . h(ME) . 'indexes=' . urlencode($a) . '">' . lang(133) . "</a>\n";
							}
							if (fk_support($R)) {
								echo "<h3 id='foreign-keys'>" . lang(100) . "</h3>\n";
								$jd = foreign_keys($a);
								if ($jd) {
									echo "<table cellspacing='0'>\n", "<thead><tr><th>" . lang(134) . "<td>" . lang(135) . "<td>" . lang(103) . "<td>" . lang(102) . "<td></thead>\n";
									foreach ($jd
										as $D => $r) {
										echo "<tr title='" . h($D) . "'>", "<th><i>" . implode("</i>, <i>", array_map('h', $r["source"])) . "</i>", "<td><a href='" . h($r["db"] != "" ? preg_replace('~db=[^&]*~', "db=" . urlencode($r["db"]), ME) : ($r["ns"] != "" ? preg_replace('~ns=[^&]*~', "ns=" . urlencode($r["ns"]), ME) : ME)) . "table=" . urlencode($r["table"]) . "'>" . ($r["db"] != "" ? "<b>" . h($r["db"]) . "</b>." : "") . ($r["ns"] != "" ? "<b>" . h($r["ns"]) . "</b>." : "") . h($r["table"]) . "</a>", "(<i>" . implode("</i>, <i>", array_map('h', $r["target"])) . "</i>)", "<td>" . h($r["on_delete"]) . "\n", "<td>" . h($r["on_update"]) . "\n", '<td><a href="' . h(ME . 'foreign=' . urlencode($a) . '&name=' . urlencode($D)) . '">' . lang(136) . '</a>';
									}
									echo "</table>\n";
								}
								echo '<p class="links"><a href="' . h(ME) . 'foreign=' . urlencode($a) . '">' . lang(137) . "</a>\n";
							}
						}
						if (support(is_view($R) ? "view_trigger" : "trigger")) {
							echo "<h3 id='triggers'>" . lang(138) . "</h3>\n";
							$Bi = triggers($a);
							if ($Bi) {
								echo "<table cellspacing='0'>\n";
								foreach ($Bi
									as $z => $X) echo "<tr valign='top'><td>" . h($X[0]) . "<td>" . h($X[1]) . "<th>" . h($z) . "<td><a href='" . h(ME . 'trigger=' . urlencode($a) . '&name=' . urlencode($z)) . "'>" . lang(136) . "</a>\n";
								echo "</table>\n";
							}
							echo '<p class="links"><a href="' . h(ME) . 'trigger=' . urlencode($a) . '">' . lang(139) . "</a>\n";
						}
					} elseif (isset($_GET["schema"])) {
						page_header(lang(70), "", array(), h(DB . ($_GET["ns"] ? ".$_GET[ns]" : "")));
						$Th = array();
						$Uh = array();
						$ea = ($_GET["schema"] ? $_GET["schema"] : $_COOKIE["lc2admin_schema-" . str_replace(".", "_", DB)]);
						preg_match_all('~([^:]+):([-0-9.]+)x([-0-9.]+)(_|$)~', $ea, $Fe, PREG_SET_ORDER);
						foreach ($Fe
							as $t => $C) {
							$Th[$C[1]] = array($C[2], $C[3]);
							$Uh[] = "\n\t'" . js_escape($C[1]) . "': [ $C[2], $C[3] ]";
						}
						$ri = 0;
						$Qa = -1;
						$ch = array();
						$Hg = array();
						$ue = array();
						foreach (table_status('', true) as $Q => $R) {
							if (is_view($R)) continue;
							$hg = 0;
							$ch[$Q]["fields"] = array();
							foreach (fields($Q) as $D => $o) {
								$hg += 1.25;
								$o["pos"] = $hg;
								$ch[$Q]["fields"][$D] = $o;
							}
							$ch[$Q]["pos"] = ($Th[$Q] ? $Th[$Q] : array($ri, 0));
							foreach ($b->foreignKeys($Q) as $X) {
								if (!$X["db"]) {
									$se = $Qa;
									if ($Th[$Q][1] || $Th[$X["table"]][1]) $se = min(floatval($Th[$Q][1]), floatval($Th[$X["table"]][1])) - 1;
									else $Qa -= .1;
									while ($ue[(string)$se]) $se -= .0001;
									$ch[$Q]["references"][$X["table"]][(string)$se] = array($X["source"], $X["target"]);
									$Hg[$X["table"]][$Q][(string)$se] = $X["target"];
									$ue[(string)$se] = true;
								}
							}
							$ri = max($ri, $ch[$Q]["pos"][0] + 2.5 + $hg);
						}
						echo '<div id="schema" style="height: ', $ri, 'em;">
<script', nonce(), '>
qs(\'#schema\').onselectstart = function () { return false; };
var tablePos = {', implode(",", $Uh) . "\n", '};
var em = qs(\'#schema\').offsetHeight / ', $ri, ';
document.onmousemove = schemaMousemove;
document.onmouseup = partialArg(schemaMouseup, \'', js_escape(DB), '\');
</script>
';
						foreach ($ch
							as $D => $Q) {
							echo "<div class='table' style='top: " . $Q["pos"][0] . "em; left: " . $Q["pos"][1] . "em;'>", '<a href="' . h(ME) . 'table=' . urlencode($D) . '"><b>' . h($D) . "</b></a>", script("qsl('div').onmousedown = schemaMousedown;");
							foreach ($Q["fields"] as $o) {
								$X = '<span' . type_class($o["type"]) . ' title="' . h($o["full_type"] . ($o["null"] ? " NULL" : '')) . '">' . h($o["field"]) . '</span>';
								echo "<br>" . ($o["primary"] ? "<i>$X</i>" : $X);
							}
							foreach ((array)$Q["references"] as $ai => $Ig) {
								foreach ($Ig
									as $se => $Eg) {
									$te = $se - $Th[$D][1];
									$t = 0;
									foreach ($Eg[0] as $yh) echo "\n<div class='references' title='" . h($ai) . "' id='refs$se-" . ($t++) . "' style='left: $te" . "em; top: " . $Q["fields"][$yh]["pos"] . "em; padding-top: .5em;'><div style='border-top: 1px solid Gray; width: " . (-$te) . "em;'></div></div>";
								}
							}
							foreach ((array)$Hg[$D] as $ai => $Ig) {
								foreach ($Ig
									as $se => $e) {
									$te = $se - $Th[$D][1];
									$t = 0;
									foreach ($e
										as $Zh) echo "\n<div class='references' title='" . h($ai) . "' id='refd$se-" . ($t++) . "' style='left: $te" . "em; top: " . $Q["fields"][$Zh]["pos"] . "em; height: 1.25em; background: url(" . h(preg_replace("~\\?.*~", "", ME) . "?file=arrow.gif) no-repeat right center;&version=4.8.1") . "'><div style='height: .5em; border-bottom: 1px solid Gray; width: " . (-$te) . "em;'></div></div>";
								}
							}
							echo "\n</div>\n";
						}
						foreach ($ch
							as $D => $Q) {
							foreach ((array)$Q["references"] as $ai => $Ig) {
								foreach ($Ig
									as $se => $Eg) {
									$Te = $ri;
									$Je = -10;
									foreach ($Eg[0] as $z => $yh) {
										$ig = $Q["pos"][0] + $Q["fields"][$yh]["pos"];
										$jg = $ch[$ai]["pos"][0] + $ch[$ai]["fields"][$Eg[1][$z]]["pos"];
										$Te = min($Te, $ig, $jg);
										$Je = max($Je, $ig, $jg);
									}
									echo "<div class='references' id='refl$se' style='left: $se" . "em; top: $Te" . "em; padding: .5em 0;'><div style='border-right: 1px solid Gray; margin-top: 1px; height: " . ($Je - $Te) . "em;'></div></div>\n";
								}
							}
						}
						echo '</div>
<p class="links"><a href="', h(ME . "schema=" . urlencode($ea)), '" id="schema-link">', lang(140), '</a>
';
					} elseif (isset($_GET["dump"])) {
						$a = $_GET["dump"];
						if ($_POST && !$n) {
							$Hb = "";
							foreach (array("output", "format", "db_style", "routines", "events", "table_style", "auto_increment", "triggers", "data_style") as $z) $Hb .= "&$z=" . urlencode($_POST[$z]);
							cookie("lc2admin_export", substr($Hb, 1));
							$S = array_flip((array)$_POST["tables"]) + array_flip((array)$_POST["data"]);
							$Oc = dump_headers((count($S) == 1 ? key($S) : DB), (DB == "" || count($S) > 1));
							$de = preg_match('~sql~', $_POST["format"]);
							if ($de) {
								echo "-- lc2admin $ia " . $kc[DRIVER] . " " . str_replace("\n", " ", $g->server_info) . " dump\n\n";
								if ($y == "sql") {
									echo "SET NAMES utf8;
SET time_zone = '+00:00';
SET foreign_key_checks = 0;
" . ($_POST["data_style"] ? "SET sql_mode = 'NO_AUTO_VALUE_ON_ZERO';
" : "") . "
";
									$g->query("SET time_zone = '+00:00'");
									$g->query("SET sql_mode = ''");
								}
							}
							$Kh = $_POST["db_style"];
							$k = array(DB);
							if (DB == "") {
								$k = $_POST["databases"];
								if (is_string($k)) $k = explode("\n", rtrim(str_replace("\r", "", $k), "\n"));
							}
							foreach ((array)$k
								as $l) {
								$b->dumpDatabase($l);
								if ($g->select_db($l)) {
									if ($de && preg_match('~CREATE~', $Kh) && ($i = $g->result("SHOW CREATE DATABASE " . idf_escape($l), 1))) {
										set_utf8mb4($i);
										if ($Kh == "DROP+CREATE") echo "DROP DATABASE IF EXISTS " . idf_escape($l) . ";\n";
										echo "$i;\n";
									}
									if ($de) {
										if ($Kh) echo
										use_sql($l) . ";\n\n";
										$Lf = "";
										if ($_POST["routines"]) {
											foreach (array("FUNCTION", "PROCEDURE") as $Wg) {
												foreach (get_rows("SHOW $Wg STATUS WHERE Db = " . q($l), null, "-- ") as $J) {
													$i = remove_definer($g->result("SHOW CREATE $Wg " . idf_escape($J["Name"]), 2));
													set_utf8mb4($i);
													$Lf .= ($Kh != 'DROP+CREATE' ? "DROP $Wg IF EXISTS " . idf_escape($J["Name"]) . ";;\n" : "") . "$i;;\n\n";
												}
											}
										}
										if ($_POST["events"]) {
											foreach (get_rows("SHOW EVENTS", null, "-- ") as $J) {
												$i = remove_definer($g->result("SHOW CREATE EVENT " . idf_escape($J["Name"]), 3));
												set_utf8mb4($i);
												$Lf .= ($Kh != 'DROP+CREATE' ? "DROP EVENT IF EXISTS " . idf_escape($J["Name"]) . ";;\n" : "") . "$i;;\n\n";
											}
										}
										if ($Lf) echo "DELIMITER ;;\n\n$Lf" . "DELIMITER ;\n\n";
									}
									if ($_POST["table_style"] || $_POST["data_style"]) {
										$bj = array();
										foreach (table_status('', true) as $D => $R) {
											$Q = (DB == "" || in_array($D, (array)$_POST["tables"]));
											$Rb = (DB == "" || in_array($D, (array)$_POST["data"]));
											if ($Q || $Rb) {
												if ($Oc == "tar") {
													$ni = new
														TmpFile;
													ob_start(array($ni, 'write'), 1e5);
												}
												$b->dumpTable($D, ($Q ? $_POST["table_style"] : ""), (is_view($R) ? 2 : 0));
												if (is_view($R)) $bj[] = $D;
												elseif ($Rb) {
													$p = fields($D);
													$b->dumpData($D, $_POST["data_style"], "SELECT *" . convert_fields($p, $p) . " FROM " . table($D));
												}
												if ($de && $_POST["triggers"] && $Q && ($Bi = trigger_sql($D))) echo "\nDELIMITER ;;\n$Bi\nDELIMITER ;\n";
												if ($Oc == "tar") {
													ob_end_flush();
													tar_file((DB != "" ? "" : "$l/") . "$D.csv", $ni);
												} elseif ($de) echo "\n";
											}
										}
										if (function_exists('foreign_keys_sql')) {
											foreach (table_status('', true) as $D => $R) {
												$Q = (DB == "" || in_array($D, (array)$_POST["tables"]));
												if ($Q && !is_view($R)) echo
												foreign_keys_sql($D);
											}
										}
										foreach ($bj
											as $aj) $b->dumpTable($aj, $_POST["table_style"], 1);
										if ($Oc == "tar") echo
										pack("x512");
									}
								}
							}
							if ($de) echo "-- " . $g->result("SELECT NOW()") . "\n";
							exit;
						}
						page_header(lang(73), $n, ($_GET["export"] != "" ? array("table" => $_GET["export"]) : array()), h(DB));
						echo '
<form action="" method="post">
<table cellspacing="0" class="layout">
';
						$Vb = array('', 'USE', 'DROP+CREATE', 'CREATE');
						$Vh = array('', 'DROP+CREATE', 'CREATE');
						$Sb = array('', 'TRUNCATE+INSERT', 'INSERT');
						if ($y == "sql") $Sb[] = 'INSERT+UPDATE';
						parse_str($_COOKIE["lc2admin_export"], $J);
						if (!$J) $J = array("output" => "text", "format" => "sql", "db_style" => (DB != "" ? "" : "CREATE"), "table_style" => "DROP+CREATE", "data_style" => "INSERT");
						if (!isset($J["events"])) {
							$J["routines"] = $J["events"] = ($_GET["dump"] == "");
							$J["triggers"] = $J["table_style"];
						}
						echo "<tr><th>" . lang(141) . "<td>" . html_select("output", $b->dumpOutput(), $J["output"], 0) . "\n";
						echo "<tr><th>" . lang(142) . "<td>" . html_select("format", $b->dumpFormat(), $J["format"], 0) . "\n";
						echo ($y == "sqlite" ? "" : "<tr><th>" . lang(37) . "<td>" . html_select('db_style', $Vb, $J["db_style"]) . (support("routine") ? checkbox("routines", 1, $J["routines"], lang(143)) : "") . (support("event") ? checkbox("events", 1, $J["events"], lang(144)) : "")), "<tr><th>" . lang(123) . "<td>" . html_select('table_style', $Vh, $J["table_style"]) . checkbox("auto_increment", 1, $J["auto_increment"], lang(51)) . (support("trigger") ? checkbox("triggers", 1, $J["triggers"], lang(138)) : ""), "<tr><th>" . lang(145) . "<td>" . html_select('data_style', $Sb, $J["data_style"]), '</table>
<p><input type="submit" value="', lang(73), '">
<input type="hidden" name="token" value="', $qi, '">

<table cellspacing="0">
', script("qsl('table').onclick = dumpClick;");
						$mg = array();
						if (DB != "") {
							$db = ($a != "" ? "" : " checked");
							echo "<thead><tr>", "<th style='text-align: left;'><label class='block'><input type='checkbox' id='check-tables'$db>" . lang(123) . "</label>" . script("qs('#check-tables').onclick = partial(formCheck, /^tables\\[/);", ""), "<th style='text-align: right;'><label class='block'>" . lang(145) . "<input type='checkbox' id='check-data'$db></label>" . script("qs('#check-data').onclick = partial(formCheck, /^data\\[/);", ""), "</thead>\n";
							$bj = "";
							$Wh = tables_list();
							foreach ($Wh
								as $D => $T) {
								$lg = preg_replace('~_.*~', '', $D);
								$db = ($a == "" || $a == (substr($a, -1) == "%" ? "$lg%" : $D));
								$pg = "<tr><td>" . checkbox("tables[]", $D, $db, $D, "", "block");
								if ($T !== null && !preg_match('~table~i', $T)) $bj .= "$pg\n";
								else
									echo "$pg<td align='right'><label class='block'><span id='Rows-" . h($D) . "'></span>" . checkbox("data[]", $D, $db) . "</label>\n";
								$mg[$lg]++;
							}
							echo $bj;
							if ($Wh) echo
							script("ajaxSetHtml('" . js_escape(ME) . "script=db');");
						} else {
							echo "<thead><tr><th style='text-align: left;'>", "<label class='block'><input type='checkbox' id='check-databases'" . ($a == "" ? " checked" : "") . ">" . lang(37) . "</label>", script("qs('#check-databases').onclick = partial(formCheck, /^databases\\[/);", ""), "</thead>\n";
							$k = $b->databases();
							if ($k) {
								foreach ($k
									as $l) {
									if (!information_schema($l)) {
										$lg = preg_replace('~_.*~', '', $l);
										echo "<tr><td>" . checkbox("databases[]", $l, $a == "" || $a == "$lg%", $l, "", "block") . "\n";
										$mg[$lg]++;
									}
								}
							} else
								echo "<tr><td><textarea name='databases' rows='10' cols='20'></textarea>";
						}
						echo '</table>
</form>
';
						$bd = true;
						foreach ($mg
							as $z => $X) {
							if ($z != "" && $X > 1) {
								echo ($bd ? "<p>" : " ") . "<a href='" . h(ME) . "dump=" . urlencode("$z%") . "'>" . h($z) . "</a>";
								$bd = false;
							}
						}
					} elseif (isset($_GET["privileges"])) {
						page_header(lang(71));
						echo '<p class="links"><a href="' . h(ME) . 'user=">' . lang(146) . "</a>";
						$H = $g->query("SELECT User, Host FROM mysql." . (DB == "" ? "user" : "db WHERE " . q(DB) . " LIKE Db") . " ORDER BY Host, User");
						$qd = $H;
						if (!$H) $H = $g->query("SELECT SUBSTRING_INDEX(CURRENT_USER, '@', 1) AS User, SUBSTRING_INDEX(CURRENT_USER, '@', -1) AS Host");
						echo "<form action=''><p>\n";
						hidden_fields_get();
						echo "<input type='hidden' name='db' value='" . h(DB) . "'>\n", ($qd ? "" : "<input type='hidden' name='grant' value=''>\n"), "<table cellspacing='0'>\n", "<thead><tr><th>" . lang(35) . "<th>" . lang(34) . "<th></thead>\n";
						while ($J = $H->fetch_assoc()) echo '<tr' . odd() . '><td>' . h($J["User"]) . "<td>" . h($J["Host"]) . '<td><a href="' . h(ME . 'user=' . urlencode($J["User"]) . '&host=' . urlencode($J["Host"])) . '">' . lang(10) . "</a>\n";
						if (!$qd || DB != "") echo "<tr" . odd() . "><td><input name='user' autocapitalize='off'><td><input name='host' value='localhost' autocapitalize='off'><td><input type='submit' value='" . lang(10) . "'>\n";
						echo "</table>\n", "</form>\n";
					} elseif (isset($_GET["sql"])) {
						if (!$n && $_POST["export"]) {
							dump_headers("sql");
							$b->dumpTable("", "");
							$b->dumpData("", "table", $_POST["query"]);
							exit;
						}
						restart_session();
						$Dd = &get_session("queries");
						$Cd = &$Dd[DB];
						if (!$n && $_POST["clear"]) {
							$Cd = array();
							redirect(remove_from_uri("history"));
						}
						page_header((isset($_GET["import"]) ? lang(72) : lang(64)), $n);
						if (!$n && $_POST) {
							$nd = false;
							if (!isset($_GET["import"])) $G = $_POST["query"];
							elseif ($_POST["webfile"]) {
								$Bh = $b->importServerPath();
								$nd = @fopen((file_exists($Bh) ? $Bh : "compress.zlib://$Bh.gz"), "rb");
								$G = ($nd ? fread($nd, 1e6) : false);
							} else $G = get_file("sql_file", true);
							if (is_string($G)) {
								if (function_exists('memory_get_usage')) @ini_set("memory_limit", max(ini_bytes("memory_limit"), 2 * strlen($G) + memory_get_usage() + 8e6));
								if ($G != "" && strlen($G) < 1e6) {
									$xg = $G . (preg_match("~;[ \t\r\n]*\$~", $G) ? "" : ";");
									if (!$Cd || reset(end($Cd)) != $xg) {
										restart_session();
										$Cd[] = array($xg, time());
										set_session("queries", $Dd);
										stop_session();
									}
								}
								$zh = "(?:\\s|/\\*[\s\S]*?\\*/|(?:#|-- )[^\n]*\n?|--\r?\n)";
								$cc = ";";
								$kf = 0;
								$zc = true;
								$h = connect();
								if (is_object($h) && DB != "") {
									$h->select_db(DB);
									if ($_GET["ns"] != "") set_schema($_GET["ns"], $h);
								}
								$sb = 0;
								$Dc = array();
								$Sf = '[\'"' . ($y == "sql" ? '`#' : ($y == "sqlite" ? '`[' : ($y == "mssql" ? '[' : ''))) . ']|/\*|-- |$' . ($y == "pgsql" ? '|\$[^$]*\$' : '');
								$si = microtime(true);
								parse_str($_COOKIE["lc2admin_export"], $ya);
								$qc = $b->dumpFormat();
								unset($qc["sql"]);
								while ($G != "") {
									if (!$kf && preg_match("~^$zh*+DELIMITER\\s+(\\S+)~i", $G, $C)) {
										$cc = $C[1];
										$G = substr($G, strlen($C[0]));
									} else {
										preg_match('(' . preg_quote($cc) . "\\s*|$Sf)", $G, $C, PREG_OFFSET_CAPTURE, $kf);
										list($ld, $hg) = $C[0];
										if (!$ld && $nd && !feof($nd)) $G .= fread($nd, 1e5);
										else {
											if (!$ld && rtrim($G) == "") break;
											$kf = $hg + strlen($ld);
											if ($ld && rtrim($ld) != $cc) {
												while (preg_match('(' . ($ld == '/*' ? '\*/' : ($ld == '[' ? ']' : (preg_match('~^-- |^#~', $ld) ? "\n" : preg_quote($ld) . "|\\\\."))) . '|$)s', $G, $C, PREG_OFFSET_CAPTURE, $kf)) {
													$ah = $C[0][0];
													if (!$ah && $nd && !feof($nd)) $G .= fread($nd, 1e5);
													else {
														$kf = $C[0][1] + strlen($ah);
														if ($ah[0] != "\\") break;
													}
												}
											} else {
												$zc = false;
												$xg = substr($G, 0, $hg);
												$sb++;
												$pg = "<pre id='sql-$sb'><code class='jush-$y'>" . $b->sqlCommandQuery($xg) . "</code></pre>\n";
												if ($y == "sqlite" && preg_match("~^$zh*+ATTACH\\b~i", $xg, $C)) {
													echo $pg, "<p class='error'>" . lang(147) . "\n";
													$Dc[] = " <a href='#sql-$sb'>$sb</a>";
													if ($_POST["error_stops"]) break;
												} else {
													if (!$_POST["only_errors"]) {
														echo $pg;
														ob_flush();
														flush();
													}
													$Fh = microtime(true);
													if ($g->multi_query($xg) && is_object($h) && preg_match("~^$zh*+USE\\b~i", $xg)) $h->query($xg);
													do {
														$H = $g->store_result();
														if ($g->error) {
															echo ($_POST["only_errors"] ? $pg : ""), "<p class='error'>" . lang(148) . ($g->errno ? " ($g->errno)" : "") . ": " . error() . "\n";
															$Dc[] = " <a href='#sql-$sb'>$sb</a>";
															if ($_POST["error_stops"]) break
																2;
														} else {
															$gi = " <span class='time'>(" . format_time($Fh) . ")</span>" . (strlen($xg) < 1000 ? " <a href='" . h(ME) . "sql=" . urlencode(trim($xg)) . "'>" . lang(10) . "</a>" : "");
															$_a = $g->affected_rows;
															$ej = ($_POST["only_errors"] ? "" : $m->warnings());
															$fj = "warnings-$sb";
															if ($ej) $gi .= ", <a href='#$fj'>" . lang(46) . "</a>" . script("qsl('a').onclick = partial(toggle, '$fj');", "");
															$Lc = null;
															$Mc = "explain-$sb";
															if (is_object($H)) {
																$_ = $_POST["limit"];
																$Ef = select($H, $h, array(), $_);
																if (!$_POST["only_errors"]) {
																	echo "<form action='' method='post'>\n";
																	$gf = $H->num_rows;
																	echo "<p>" . ($gf ? ($_ && $gf > $_ ? lang(149, $_) : "") . lang(150, $gf) : ""), $gi;
																	if ($h && preg_match("~^($zh|\\()*+SELECT\\b~i", $xg) && ($Lc = explain($h, $xg))) echo ", <a href='#$Mc'>Explain</a>" . script("qsl('a').onclick = partial(toggle, '$Mc');", "");
																	$u = "export-$sb";
																	echo ", <a href='#$u'>" . lang(73) . "</a>" . script("qsl('a').onclick = partial(toggle, '$u');", "") . "<span id='$u' class='hidden'>: " . html_select("output", $b->dumpOutput(), $ya["output"]) . " " . html_select("format", $qc, $ya["format"]) . "<input type='hidden' name='query' value='" . h($xg) . "'>" . " <input type='submit' name='export' value='" . lang(73) . "'><input type='hidden' name='token' value='$qi'></span>\n" . "</form>\n";
																}
															} else {
																if (preg_match("~^$zh*+(CREATE|DROP|ALTER)$zh++(DATABASE|SCHEMA)\\b~i", $xg)) {
																	restart_session();
																	set_session("dbs", null);
																	stop_session();
																}
																if (!$_POST["only_errors"]) echo "<p class='message' title='" . h($g->info) . "'>" . lang(151, $_a) . "$gi\n";
															}
															echo ($ej ? "<div id='$fj' class='hidden'>\n$ej</div>\n" : "");
															if ($Lc) {
																echo "<div id='$Mc' class='hidden'>\n";
																select($Lc, $h, $Ef);
																echo "</div>\n";
															}
														}
														$Fh = microtime(true);
													} while ($g->next_result());
												}
												$G = substr($G, $kf);
												$kf = 0;
											}
										}
									}
								}
								if ($zc) echo "<p class='message'>" . lang(152) . "\n";
								elseif ($_POST["only_errors"]) {
									echo "<p class='message'>" . lang(153, $sb - count($Dc)), " <span class='time'>(" . format_time($si) . ")</span>\n";
								} elseif ($Dc && $sb > 1) echo "<p class='error'>" . lang(148) . ": " . implode("", $Dc) . "\n";
							} else
								echo "<p class='error'>" . upload_error($G) . "\n";
						}
						echo '
<form action="" method="post" enctype="multipart/form-data" id="form">
';
						$Jc = "<input type='submit' value='" . lang(154) . "' title='Ctrl+Enter'>";
						if (!isset($_GET["import"])) {
							$xg = $_GET["sql"];
							if ($_POST) $xg = $_POST["query"];
							elseif ($_GET["history"] == "all") $xg = $Cd;
							elseif ($_GET["history"] != "") $xg = $Cd[$_GET["history"]][0];
							echo "<p>";
							textarea("query", $xg, 20);
							echo
							script(($_POST ? "" : "qs('textarea').focus();\n") . "qs('#form').onsubmit = partial(sqlSubmit, qs('#form'), '" . js_escape(remove_from_uri("sql|limit|error_stops|only_errors|history")) . "');"), "<p>$Jc\n", lang(155) . ": <input type='number' name='limit' class='size' value='" . h($_POST ? $_POST["limit"] : $_GET["limit"]) . "'>\n";
						} else {
							echo "<fieldset><legend>" . lang(156) . "</legend><div>";
							$wd = (extension_loaded("zlib") ? "[.gz]" : "");
							echo (ini_bool("file_uploads") ? "SQL$wd (&lt; " . ini_get("upload_max_filesize") . "B): <input type='file' name='sql_file[]' multiple>\n$Jc" : lang(157)), "</div></fieldset>\n";
							$Kd = $b->importServerPath();
							if ($Kd) {
								echo "<fieldset><legend>" . lang(158) . "</legend><div>", lang(159, "<code>" . h($Kd) . "$wd</code>"), ' <input type="submit" name="webfile" value="' . lang(160) . '">', "</div></fieldset>\n";
							}
							echo "<p>";
						}
						echo
						checkbox("error_stops", 1, ($_POST ? $_POST["error_stops"] : isset($_GET["import"]) || $_GET["error_stops"]), lang(161)) . "\n", checkbox("only_errors", 1, ($_POST ? $_POST["only_errors"] : isset($_GET["import"]) || $_GET["only_errors"]), lang(162)) . "\n", "<input type='hidden' name='token' value='$qi'>\n";
						if (!isset($_GET["import"]) && $Cd) {
							print_fieldset("history", lang(163), $_GET["history"] != "");
							for ($X = end($Cd); $X; $X = prev($Cd)) {
								$z = key($Cd);
								list($xg, $gi, $uc) = $X;
								echo '<a href="' . h(ME . "sql=&history=$z") . '">' . lang(10) . "</a>" . " <span class='time' title='" . @date('Y-m-d', $gi) . "'>" . @date("H:i:s", $gi) . "</span>" . " <code class='jush-$y'>" . shorten_utf8(ltrim(str_replace("\n", " ", str_replace("\r", "", preg_replace('~^(#|-- ).*~m', '', $xg)))), 80, "</code>") . ($uc ? " <span class='time'>($uc)</span>" : "") . "<br>\n";
							}
							echo "<input type='submit' name='clear' value='" . lang(164) . "'>\n", "<a href='" . h(ME . "sql=&history=all") . "'>" . lang(165) . "</a>\n", "</div></fieldset>\n";
						}
						echo '</form>
';
					} elseif (isset($_GET["edit"])) {
						$a = $_GET["edit"];
						$p = fields($a);
						$Z = (isset($_GET["select"]) ? ($_POST["check"] && count($_POST["check"]) == 1 ? where_check($_POST["check"][0], $p) : "") : where($_GET, $p));
						$Li = (isset($_GET["select"]) ? $_POST["edit"] : $Z);
						foreach ($p
							as $D => $o) {
							if (!isset($o["privileges"][$Li ? "update" : "insert"]) || $b->fieldName($o) == "" || $o["generated"]) unset($p[$D]);
						}
						if ($_POST && !$n && !isset($_GET["select"])) {
							$B = $_POST["referer"];
							if ($_POST["insert"]) $B = ($Li ? null : $_SERVER["REQUEST_URI"]);
							elseif (!preg_match('~^.+&select=.+$~', $B)) $B = ME . "select=" . urlencode($a);
							$x = indexes($a);
							$Gi = unique_array($_GET["where"], $x);
							$_g = "\nWHERE $Z";
							if (isset($_POST["delete"])) queries_redirect($B, lang(166), $m->delete($a, $_g, !$Gi));
							else {
								$N = array();
								foreach ($p
									as $D => $o) {
									$X = process_input($o);
									if ($X !== false && $X !== null) $N[idf_escape($D)] = $X;
								}
								if ($Li) {
									if (!$N) redirect($B);
									queries_redirect($B, lang(167), $m->update($a, $N, $_g, !$Gi));
									if (is_ajax()) {
										page_headers();
										page_messages($n);
										exit;
									}
								} else {
									$H = $m->insert($a, $N);
									$re = ($H ? last_id() : 0);
									queries_redirect($B, lang(168, ($re ? " $re" : "")), $H);
								}
							}
						}
						$J = null;
						if ($_POST["save"]) $J = (array)$_POST["fields"];
						elseif ($Z) {
							$L = array();
							foreach ($p
								as $D => $o) {
								if (isset($o["privileges"]["select"])) {
									$Ga = convert_field($o);
									if ($_POST["clone"] && $o["auto_increment"]) $Ga = "''";
									if ($y == "sql" && preg_match("~enum|set~", $o["type"])) $Ga = "1*" . idf_escape($D);
									$L[] = ($Ga ? "$Ga AS " : "") . idf_escape($D);
								}
							}
							$J = array();
							if (!support("table")) $L = array("*");
							if ($L) {
								$H = $m->select($a, $L, array($Z), $L, array(), (isset($_GET["select"]) ? 2 : 1));
								if (!$H) $n = error();
								else {
									$J = $H->fetch_assoc();
									if (!$J) $J = false;
								}
								if (isset($_GET["select"]) && (!$J || $H->fetch_assoc())) $J = null;
							}
						}
						if (!support("table") && !$p) {
							if (!$Z) {
								$H = $m->select($a, array("*"), $Z, array("*"));
								$J = ($H ? $H->fetch_assoc() : false);
								if (!$J) $J = array($m->primary => "");
							}
							if ($J) {
								foreach ($J
									as $z => $X) {
									if (!$Z) $J[$z] = null;
									$p[$z] = array("field" => $z, "null" => ($z != $m->primary), "auto_increment" => ($z == $m->primary));
								}
							}
						}
						edit_form($a, $p, $J, $Li);
					} elseif (isset($_GET["create"])) {
						$a = $_GET["create"];
						$Uf = array();
						foreach (array('HASH', 'LINEAR HASH', 'KEY', 'LINEAR KEY', 'RANGE', 'LIST') as $z) $Uf[$z] = $z;
						$Gg = referencable_primary($a);
						$jd = array();
						foreach ($Gg
							as $Rh => $o) $jd[str_replace("`", "``", $Rh) . "`" . str_replace("`", "``", $o["field"])] = $Rh;
						$Hf = array();
						$R = array();
						if ($a != "") {
							$Hf = fields($a);
							$R = table_status($a);
							if (!$R) $n = lang(9);
						}
						$J = $_POST;
						$J["fields"] = (array)$J["fields"];
						if ($J["auto_increment_col"]) $J["fields"][$J["auto_increment_col"]]["auto_increment"] = true;
						if ($_POST) set_lc2admin_settings(array("comments" => $_POST["comments"], "defaults" => $_POST["defaults"]));
						if ($_POST && !process_fields($J["fields"]) && !$n) {
							if ($_POST["drop"]) queries_redirect(substr(ME, 0, -1), lang(169), drop_tables(array($a)));
							else {
								$p = array();
								$Da = array();
								$Pi = false;
								$hd = array();
								$Gf = reset($Hf);
								$Ba = " FIRST";
								foreach ($J["fields"] as $z => $o) {
									$r = $jd[$o["type"]];
									$Ci = ($r !== null ? $Gg[$r] : $o);
									if ($o["field"] != "") {
										if (!$o["has_default"]) $o["default"] = null;
										if ($z == $J["auto_increment_col"]) $o["auto_increment"] = true;
										$ug = process_field($o, $Ci);
										$Da[] = array($o["orig"], $ug, $Ba);
										if (!$Gf || $ug != process_field($Gf, $Gf)) {
											$p[] = array($o["orig"], $ug, $Ba);
											if ($o["orig"] != "" || $Ba) $Pi = true;
										}
										if ($r !== null) $hd[idf_escape($o["field"])] = ($a != "" && $y != "sqlite" ? "ADD" : " ") . format_foreign_key(array('table' => $jd[$o["type"]], 'source' => array($o["field"]), 'target' => array($Ci["field"]), 'on_delete' => $o["on_delete"],));
										$Ba = " AFTER " . idf_escape($o["field"]);
									} elseif ($o["orig"] != "") {
										$Pi = true;
										$p[] = array($o["orig"]);
									}
									if ($o["orig"] != "") {
										$Gf = next($Hf);
										if (!$Gf) $Ba = "";
									}
								}
								$Wf = "";
								if ($Uf[$J["partition_by"]]) {
									$Xf = array();
									if ($J["partition_by"] == 'RANGE' || $J["partition_by"] == 'LIST') {
										foreach (array_filter($J["partition_names"]) as $z => $X) {
											$Y = $J["partition_values"][$z];
											$Xf[] = "\n  PARTITION " . idf_escape($X) . " VALUES " . ($J["partition_by"] == 'RANGE' ? "LESS THAN" : "IN") . ($Y != "" ? " ($Y)" : " MAXVALUE");
										}
									}
									$Wf .= "\nPARTITION BY $J[partition_by]($J[partition])" . ($Xf ? " (" . implode(",", $Xf) . "\n)" : ($J["partitions"] ? " PARTITIONS " . (+$J["partitions"]) : ""));
								} elseif (support("partitioning") && preg_match("~partitioned~", $R["Create_options"])) $Wf .= "\nREMOVE PARTITIONING";
								$Ne = lang(170);
								if ($a == "") {
									cookie("lc2admin_engine", $J["Engine"]);
									$Ne = lang(171);
								}
								$D = trim($J["name"]);
								queries_redirect(ME . (support("table") ? "table=" : "select=") . urlencode($D), $Ne, alter_table($a, $D, ($y == "sqlite" && ($Pi || $hd) ? $Da : $p), $hd, ($J["Comment"] != $R["Comment"] ? $J["Comment"] : null), ($J["Engine"] && $J["Engine"] != $R["Engine"] ? $J["Engine"] : ""), ($J["Collation"] && $J["Collation"] != $R["Collation"] ? $J["Collation"] : ""), ($J["Auto_increment"] != "" ? number($J["Auto_increment"]) : ""), $Wf));
							}
						}
						page_header(($a != "" ? lang(44) : lang(74)), $n, array("table" => $a), h($a));
						if (!$_POST) {
							$J = array("Engine" => $_COOKIE["lc2admin_engine"], "fields" => array(array("field" => "", "type" => (isset($U["int"]) ? "int" : (isset($U["integer"]) ? "integer" : "")), "on_update" => "")), "partition_names" => array(""),);
							if ($a != "") {
								$J = $R;
								$J["name"] = $a;
								$J["fields"] = array();
								if (!$_GET["auto_increment"]) $J["Auto_increment"] = "";
								foreach ($Hf
									as $o) {
									$o["has_default"] = isset($o["default"]);
									$J["fields"][] = $o;
								}
								if (support("partitioning")) {
									$od = "FROM information_schema.PARTITIONS WHERE TABLE_SCHEMA = " . q(DB) . " AND TABLE_NAME = " . q($a);
									$H = $g->query("SELECT PARTITION_METHOD, PARTITION_ORDINAL_POSITION, PARTITION_EXPRESSION $od ORDER BY PARTITION_ORDINAL_POSITION DESC LIMIT 1");
									list($J["partition_by"], $J["partitions"], $J["partition"]) = $H->fetch_row();
									$Xf = get_key_vals("SELECT PARTITION_NAME, PARTITION_DESCRIPTION $od AND PARTITION_NAME != '' ORDER BY PARTITION_ORDINAL_POSITION");
									$Xf[""] = "";
									$J["partition_names"] = array_keys($Xf);
									$J["partition_values"] = array_values($Xf);
								}
							}
						}
						$nb = collations();
						$Ac = engines();
						foreach ($Ac
							as $_c) {
							if (!strcasecmp($_c, $J["Engine"])) {
								$J["Engine"] = $_c;
								break;
							}
						}
						echo '
<form action="" method="post" id="form">
<p>
';
						if (support("columns") || $a == "") {
							echo
							lang(172), ': <input name="name" data-maxlength="64" value="', h($J["name"]), '" autocapitalize="off">
';
							if ($a == "" && !$_POST) echo
							script("focus(qs('#form')['name']);");
							echo ($Ac ? "<select name='Engine'>" . optionlist(array("" => "(" . lang(173) . ")") + $Ac, $J["Engine"]) . "</select>" . on_help("getTarget(event).value", 1) . script("qsl('select').onchange = helpClose;") : ""), ' ', ($nb && !preg_match("~sqlite|mssql~", $y) ? html_select("Collation", array("" => "(" . lang(101) . ")") + $nb, $J["Collation"]) : ""), ' <input type="submit" value="', lang(14), '">
';
						}
						echo '
';
						if (support("columns")) {
							echo '<div class="scrollable">
<table cellspacing="0" id="edit-fields" class="nowrap">
';
							edit_fields($J["fields"], $nb, "TABLE", $jd);
							echo '</table>
', script("editFields();"), '</div>
<p>
', lang(51), ': <input type="number" name="Auto_increment" size="6" value="', h($J["Auto_increment"]), '">
', checkbox("defaults", 1, ($_POST ? $_POST["defaults"] : lc2admin_setting("defaults")), lang(174), "columnShow(this.checked, 5)", "jsonly"), (support("comment") ? checkbox("comments", 1, ($_POST ? $_POST["comments"] : lc2admin_setting("comments")), lang(50), "editingCommentsClick(this, true);", "jsonly") . ' <input name="Comment" value="' . h($J["Comment"]) . '" data-maxlength="' . (min_version(5.5) ? 2048 : 60) . '">' : ''), '<p>
<input type="submit" value="', lang(14), '">
';
						}
						echo '
';
						if ($a != "") {
							echo '<input type="submit" name="drop" value="', lang(127), '">', confirm(lang(175, $a));
						}
						if (support("partitioning")) {
							$Vf = preg_match('~RANGE|LIST~', $J["partition_by"]);
							print_fieldset("partition", lang(176), $J["partition_by"]);
							echo '<p>
', "<select name='partition_by'>" . optionlist(array("" => "") + $Uf, $J["partition_by"]) . "</select>" . on_help("getTarget(event).value.replace(/./, 'PARTITION BY \$&')", 1) . script("qsl('select').onchange = partitionByChange;"), '(<input name="partition" value="', h($J["partition"]), '">)
', lang(177), ': <input type="number" name="partitions" class="size', ($Vf || !$J["partition_by"] ? " hidden" : ""), '" value="', h($J["partitions"]), '">
<table cellspacing="0" id="partition-table"', ($Vf ? "" : " class='hidden'"), '>
<thead><tr><th>', lang(178), '<th>', lang(179), '</thead>
';
							foreach ($J["partition_names"] as $z => $X) {
								echo '<tr>', '<td><input name="partition_names[]" value="' . h($X) . '" autocapitalize="off">', ($z == count($J["partition_names"]) - 1 ? script("qsl('input').oninput = partitionNameChange;") : ''), '<td><input name="partition_values[]" value="' . h($J["partition_values"][$z]) . '">';
							}
							echo '</table>
</div></fieldset>
';
						}
						echo '<input type="hidden" name="token" value="', $qi, '">
</form>
';
					} elseif (isset($_GET["indexes"])) {
						$a = $_GET["indexes"];
						$Nd = array("PRIMARY", "UNIQUE", "INDEX");
						$R = table_status($a, true);
						if (preg_match('~MyISAM|M?aria' . (min_version(5.6, '10.0.5') ? '|InnoDB' : '') . '~i', $R["Engine"])) $Nd[] = "FULLTEXT";
						if (preg_match('~MyISAM|M?aria' . (min_version(5.7, '10.2.2') ? '|InnoDB' : '') . '~i', $R["Engine"])) $Nd[] = "SPATIAL";
						$x = indexes($a);
						$ng = array();
						if ($y == "mongo") {
							$ng = $x["_id_"];
							unset($Nd[0]);
							unset($x["_id_"]);
						}
						$J = $_POST;
						if ($_POST && !$n && !$_POST["add"] && !$_POST["drop_col"]) {
							$c = array();
							foreach ($J["indexes"] as $w) {
								$D = $w["name"];
								if (in_array($w["type"], $Nd)) {
									$e = array();
									$xe = array();
									$ec = array();
									$N = array();
									ksort($w["columns"]);
									foreach ($w["columns"] as $z => $d) {
										if ($d != "") {
											$we = $w["lengths"][$z];
											$dc = $w["descs"][$z];
											$N[] = idf_escape($d) . ($we ? "(" . (+$we) . ")" : "") . ($dc ? " DESC" : "");
											$e[] = $d;
											$xe[] = ($we ? $we : null);
											$ec[] = $dc;
										}
									}
									if ($e) {
										$Kc = $x[$D];
										if ($Kc) {
											ksort($Kc["columns"]);
											ksort($Kc["lengths"]);
											ksort($Kc["descs"]);
											if ($w["type"] == $Kc["type"] && array_values($Kc["columns"]) === $e && (!$Kc["lengths"] || array_values($Kc["lengths"]) === $xe) && array_values($Kc["descs"]) === $ec) {
												unset($x[$D]);
												continue;
											}
										}
										$c[] = array($w["type"], $D, $N);
									}
								}
							}
							foreach ($x
								as $D => $Kc) $c[] = array($Kc["type"], $D, "DROP");
							if (!$c) redirect(ME . "table=" . urlencode($a));
							queries_redirect(ME . "table=" . urlencode($a), lang(180), alter_indexes($a, $c));
						}
						page_header(lang(132), $n, array("table" => $a), h($a));
						$p = array_keys(fields($a));
						if ($_POST["add"]) {
							foreach ($J["indexes"] as $z => $w) {
								if ($w["columns"][count($w["columns"])] != "") $J["indexes"][$z]["columns"][] = "";
							}
							$w = end($J["indexes"]);
							if ($w["type"] || array_filter($w["columns"], 'strlen')) $J["indexes"][] = array("columns" => array(1 => ""));
						}
						if (!$J) {
							foreach ($x
								as $z => $w) {
								$x[$z]["name"] = $z;
								$x[$z]["columns"][] = "";
							}
							$x[] = array("columns" => array(1 => ""));
							$J["indexes"] = $x;
						}
						echo '
<form action="" method="post">
<div class="scrollable">
<table cellspacing="0" class="nowrap">
<thead><tr>
<th id="label-type">', lang(181), '<th><input type="submit" class="wayoff">', lang(182), '<th id="label-name">', lang(183), '<th><noscript>', "<input type='image' class='icon' name='add[0]' src='" . h(preg_replace("~\\?.*~", "", ME) . "?file=plus.gif&version=4.8.1") . "' alt='+' title='" . lang(108) . "'>", '</noscript>
</thead>
';
						if ($ng) {
							echo "<tr><td>PRIMARY<td>";
							foreach ($ng["columns"] as $z => $d) {
								echo
								select_input(" disabled", $p, $d), "<label><input disabled type='checkbox'>" . lang(59) . "</label> ";
							}
							echo "<td><td>\n";
						}
						$ge = 1;
						foreach ($J["indexes"] as $w) {
							if (!$_POST["drop_col"] || $ge != key($_POST["drop_col"])) {
								echo "<tr><td>" . html_select("indexes[$ge][type]", array(-1 => "") + $Nd, $w["type"], ($ge == count($J["indexes"]) ? "indexesAddRow.call(this);" : 1), "label-type"), "<td>";
								ksort($w["columns"]);
								$t = 1;
								foreach ($w["columns"] as $z => $d) {
									echo "<span>" . select_input(" name='indexes[$ge][columns][$t]' title='" . lang(48) . "'", ($p ? array_combine($p, $p) : $p), $d, "partial(" . ($t == count($w["columns"]) ? "indexesAddColumn" : "indexesChangeColumn") . ", '" . js_escape($y == "sql" ? "" : $_GET["indexes"] . "_") . "')"), ($y == "sql" || $y == "mssql" ? "<input type='number' name='indexes[$ge][lengths][$t]' class='size' value='" . h($w["lengths"][$z]) . "' title='" . lang(106) . "'>" : ""), (support("descidx") ? checkbox("indexes[$ge][descs][$t]", 1, $w["descs"][$z], lang(59)) : ""), " </span>";
									$t++;
								}
								echo "<td><input name='indexes[$ge][name]' value='" . h($w["name"]) . "' autocapitalize='off' aria-labelledby='label-name'>\n", "<td><input type='image' class='icon' name='drop_col[$ge]' src='" . h(preg_replace("~\\?.*~", "", ME) . "?file=cross.gif&version=4.8.1") . "' alt='x' title='" . lang(111) . "'>" . script("qsl('input').onclick = partial(editingRemoveRow, 'indexes\$1[type]');");
							}
							$ge++;
						}
						echo '</table>
</div>
<p>
<input type="submit" value="', lang(14), '">
<input type="hidden" name="token" value="', $qi, '">
</form>
';
					} elseif (isset($_GET["database"])) {
						$J = $_POST;
						if ($_POST && !$n && !isset($_POST["add_x"])) {
							$D = trim($J["name"]);
							if ($_POST["drop"]) {
								$_GET["db"] = "";
								queries_redirect(remove_from_uri("db|database"), lang(184), drop_databases(array(DB)));
							} elseif (DB !== $D) {
								if (DB != "") {
									$_GET["db"] = $D;
									queries_redirect(preg_replace('~\bdb=[^&]*&~', '', ME) . "db=" . urlencode($D), lang(185), rename_database($D, $J["collation"]));
								} else {
									$k = explode("\n", str_replace("\r", "", $D));
									$Lh = true;
									$qe = "";
									foreach ($k
										as $l) {
										if (count($k) == 1 || $l != "") {
											if (!create_database($l, $J["collation"])) $Lh = false;
											$qe = $l;
										}
									}
									restart_session();
									set_session("dbs", null);
									queries_redirect(ME . "db=" . urlencode($qe), lang(186), $Lh);
								}
							} else {
								if (!$J["collation"]) redirect(substr(ME, 0, -1));
								query_redirect("ALTER DATABASE " . idf_escape($D) . (preg_match('~^[a-z0-9_]+$~i', $J["collation"]) ? " COLLATE $J[collation]" : ""), substr(ME, 0, -1), lang(187));
							}
						}
						page_header(DB != "" ? lang(67) : lang(115), $n, array(), h(DB));
						$nb = collations();
						$D = DB;
						if ($_POST) $D = $J["name"];
						elseif (DB != "") $J["collation"] = db_collation(DB, $nb);
						elseif ($y == "sql") {
							foreach (get_vals("SHOW GRANTS") as $qd) {
								if (preg_match('~ ON (`(([^\\\\`]|``|\\\\.)*)%`\.\*)?~', $qd, $C) && $C[1]) {
									$D = stripcslashes(idf_unescape("`$C[2]`"));
									break;
								}
							}
						}
						echo '
<form action="" method="post">
<p>
', ($_POST["add_x"] || strpos($D, "\n") ? '<textarea id="name" name="name" rows="10" cols="40">' . h($D) . '</textarea><br>' : '<input name="name" id="name" value="' . h($D) . '" data-maxlength="64" autocapitalize="off">') . "\n" . ($nb ? html_select("collation", array("" => "(" . lang(101) . ")") + $nb, $J["collation"]) . doc_link(array('sql' => "charset-charsets.html", 'mariadb' => "supported-character-sets-and-collations/", 'mssql' => "ms187963.aspx",)) : ""), script("focus(qs('#name'));"), '<input type="submit" value="', lang(14), '">
';
						if (DB != "") echo "<input type='submit' name='drop' value='" . lang(127) . "'>" . confirm(lang(175, DB)) . "\n";
						elseif (!$_POST["add_x"] && $_GET["db"] == "") echo "<input type='image' class='icon' name='add' src='" . h(preg_replace("~\\?.*~", "", ME) . "?file=plus.gif&version=4.8.1") . "' alt='+' title='" . lang(108) . "'>\n";
						echo '<input type="hidden" name="token" value="', $qi, '">
</form>
';
					} elseif (isset($_GET["scheme"])) {
						$J = $_POST;
						if ($_POST && !$n) {
							$A = preg_replace('~ns=[^&]*&~', '', ME) . "ns=";
							if ($_POST["drop"]) query_redirect("DROP SCHEMA " . idf_escape($_GET["ns"]), $A, lang(188));
							else {
								$D = trim($J["name"]);
								$A .= urlencode($D);
								if ($_GET["ns"] == "") query_redirect("CREATE SCHEMA " . idf_escape($D), $A, lang(189));
								elseif ($_GET["ns"] != $D) query_redirect("ALTER SCHEMA " . idf_escape($_GET["ns"]) . " RENAME TO " . idf_escape($D), $A, lang(190));
								else
									redirect($A);
							}
						}
						page_header($_GET["ns"] != "" ? lang(68) : lang(69), $n);
						if (!$J) $J["name"] = $_GET["ns"];
						echo '
<form action="" method="post">
<p><input name="name" id="name" value="', h($J["name"]), '" autocapitalize="off">
', script("focus(qs('#name'));"), '<input type="submit" value="', lang(14), '">
';
						if ($_GET["ns"] != "") echo "<input type='submit' name='drop' value='" . lang(127) . "'>" . confirm(lang(175, $_GET["ns"])) . "\n";
						echo '<input type="hidden" name="token" value="', $qi, '">
</form>
';
					} elseif (isset($_GET["call"])) {
						$da = ($_GET["name"] ? $_GET["name"] : $_GET["call"]);
						page_header(lang(191) . ": " . h($da), $n);
						$Wg = routine($_GET["call"], (isset($_GET["callf"]) ? "FUNCTION" : "PROCEDURE"));
						$Ld = array();
						$Lf = array();
						foreach ($Wg["fields"] as $t => $o) {
							if (substr($o["inout"], -3) == "OUT") $Lf[$t] = "@" . idf_escape($o["field"]) . " AS " . idf_escape($o["field"]);
							if (!$o["inout"] || substr($o["inout"], 0, 2) == "IN") $Ld[] = $t;
						}
						if (!$n && $_POST) {
							$Ya = array();
							foreach ($Wg["fields"] as $z => $o) {
								if (in_array($z, $Ld)) {
									$X = process_input($o);
									if ($X === false) $X = "''";
									if (isset($Lf[$z])) $g->query("SET @" . idf_escape($o["field"]) . " = $X");
								}
								$Ya[] = (isset($Lf[$z]) ? "@" . idf_escape($o["field"]) : $X);
							}
							$G = (isset($_GET["callf"]) ? "SELECT" : "CALL") . " " . table($da) . "(" . implode(", ", $Ya) . ")";
							$Fh = microtime(true);
							$H = $g->multi_query($G);
							$_a = $g->affected_rows;
							echo $b->selectQuery($G, $Fh, !$H);
							if (!$H) echo "<p class='error'>" . error() . "\n";
							else {
								$h = connect();
								if (is_object($h)) $h->select_db(DB);
								do {
									$H = $g->store_result();
									if (is_object($H)) select($H, $h);
									else
										echo "<p class='message'>" . lang(192, $_a) . " <span class='time'>" . @date("H:i:s") . "</span>\n";
								} while ($g->next_result());
								if ($Lf) select($g->query("SELECT " . implode(", ", $Lf)));
							}
						}
						echo '
<form action="" method="post">
';
						if ($Ld) {
							echo "<table cellspacing='0' class='layout'>\n";
							foreach ($Ld
								as $z) {
								$o = $Wg["fields"][$z];
								$D = $o["field"];
								echo "<tr><th>" . $b->fieldName($o);
								$Y = $_POST["fields"][$D];
								if ($Y != "") {
									if ($o["type"] == "enum") $Y = +$Y;
									if ($o["type"] == "set") $Y = array_sum($Y);
								}
								input($o, $Y, (string)$_POST["function"][$D]);
								echo "\n";
							}
							echo "</table>\n";
						}
						echo '<p>
<input type="submit" value="', lang(191), '">
<input type="hidden" name="token" value="', $qi, '">
</form>
';
					} elseif (isset($_GET["foreign"])) {
						$a = $_GET["foreign"];
						$D = $_GET["name"];
						$J = $_POST;
						if ($_POST && !$n && !$_POST["add"] && !$_POST["change"] && !$_POST["change-js"]) {
							$Ne = ($_POST["drop"] ? lang(193) : ($D != "" ? lang(194) : lang(195)));
							$B = ME . "table=" . urlencode($a);
							if (!$_POST["drop"]) {
								$J["source"] = array_filter($J["source"], 'strlen');
								ksort($J["source"]);
								$Zh = array();
								foreach ($J["source"] as $z => $X) $Zh[$z] = $J["target"][$z];
								$J["target"] = $Zh;
							}
							if ($y == "sqlite") queries_redirect($B, $Ne, recreate_table($a, $a, array(), array(), array(" $D" => ($_POST["drop"] ? "" : " " . format_foreign_key($J)))));
							else {
								$c = "ALTER TABLE " . table($a);
								$lc = "\nDROP " . ($y == "sql" ? "FOREIGN KEY " : "CONSTRAINT ") . idf_escape($D);
								if ($_POST["drop"]) query_redirect($c . $lc, $B, $Ne);
								else {
									query_redirect($c . ($D != "" ? "$lc," : "") . "\nADD" . format_foreign_key($J), $B, $Ne);
									$n = lang(196) . "<br>$n";
								}
							}
						}
						page_header(lang(197), $n, array("table" => $a), h($a));
						if ($_POST) {
							ksort($J["source"]);
							if ($_POST["add"]) $J["source"][] = "";
							elseif ($_POST["change"] || $_POST["change-js"]) $J["target"] = array();
						} elseif ($D != "") {
							$jd = foreign_keys($a);
							$J = $jd[$D];
							$J["source"][] = "";
						} else {
							$J["table"] = $a;
							$J["source"] = array("");
						}
						echo '
<form action="" method="post">
';
						$yh = array_keys(fields($a));
						if ($J["db"] != "") $g->select_db($J["db"]);
						if ($J["ns"] != "") set_schema($J["ns"]);
						$Fg = array_keys(array_filter(table_status('', true), 'fk_support'));
						$Zh = array_keys(fields(in_array($J["table"], $Fg) ? $J["table"] : reset($Fg)));
						$tf = "this.form['change-js'].value = '1'; this.form.submit();";
						echo "<p>" . lang(198) . ": " . html_select("table", $Fg, $J["table"], $tf) . "\n";
						if ($y == "pgsql") echo
						lang(77) . ": " . html_select("ns", $b->schemas(), $J["ns"] != "" ? $J["ns"] : $_GET["ns"], $tf);
						elseif ($y != "sqlite") {
							$Wb = array();
							foreach ($b->databases() as $l) {
								if (!information_schema($l)) $Wb[] = $l;
							}
							echo
							lang(76) . ": " . html_select("db", $Wb, $J["db"] != "" ? $J["db"] : $_GET["db"], $tf);
						}
						echo '<input type="hidden" name="change-js" value="">
<noscript><p><input type="submit" name="change" value="', lang(199), '"></noscript>
<table cellspacing="0">
<thead><tr><th id="label-source">', lang(134), '<th id="label-target">', lang(135), '</thead>
';
						$ge = 0;
						foreach ($J["source"] as $z => $X) {
							echo "<tr>", "<td>" . html_select("source[" . (+$z) . "]", array(-1 => "") + $yh, $X, ($ge == count($J["source"]) - 1 ? "foreignAddRow.call(this);" : 1), "label-source"), "<td>" . html_select("target[" . (+$z) . "]", $Zh, $J["target"][$z], 1, "label-target");
							$ge++;
						}
						echo '</table>
<p>
', lang(103), ': ', html_select("on_delete", array(-1 => "") + explode("|", $sf), $J["on_delete"]), ' ', lang(102), ': ', html_select("on_update", array(-1 => "") + explode("|", $sf), $J["on_update"]), doc_link(array('sql' => "innodb-foreign-key-constraints.html", 'mariadb' => "foreign-keys/", 'pgsql' => "sql-createtable.html#SQL-CREATETABLE-REFERENCES", 'mssql' => "ms174979.aspx", 'oracle' => "https://docs.oracle.com/cd/B19306_01/server.102/b14200/clauses002.htm#sthref2903",)), '<p>
<input type="submit" value="', lang(14), '">
<noscript><p><input type="submit" name="add" value="', lang(200), '"></noscript>
';
						if ($D != "") {
							echo '<input type="submit" name="drop" value="', lang(127), '">', confirm(lang(175, $D));
						}
						echo '<input type="hidden" name="token" value="', $qi, '">
</form>
';
					} elseif (isset($_GET["view"])) {
						$a = $_GET["view"];
						$J = $_POST;
						$If = "VIEW";
						if ($y == "pgsql" && $a != "") {
							$O = table_status($a);
							$If = strtoupper($O["Engine"]);
						}
						if ($_POST && !$n) {
							$D = trim($J["name"]);
							$Ga = " AS\n$J[select]";
							$B = ME . "table=" . urlencode($D);
							$Ne = lang(201);
							$T = ($_POST["materialized"] ? "MATERIALIZED VIEW" : "VIEW");
							if (!$_POST["drop"] && $a == $D && $y != "sqlite" && $T == "VIEW" && $If == "VIEW") query_redirect(($y == "mssql" ? "ALTER" : "CREATE OR REPLACE") . " VIEW " . table($D) . $Ga, $B, $Ne);
							else {
								$bi = $D . "_lc2admin_" . uniqid();
								drop_create("DROP $If " . table($a), "CREATE $T " . table($D) . $Ga, "DROP $T " . table($D), "CREATE $T " . table($bi) . $Ga, "DROP $T " . table($bi), ($_POST["drop"] ? substr(ME, 0, -1) : $B), lang(202), $Ne, lang(203), $a, $D);
							}
						}
						if (!$_POST && $a != "") {
							$J = view($a);
							$J["name"] = $a;
							$J["materialized"] = ($If != "VIEW");
							if (!$n) $n = error();
						}
						page_header(($a != "" ? lang(43) : lang(204)), $n, array("table" => $a), h($a));
						echo '
<form action="" method="post">
<p>', lang(183), ': <input name="name" value="', h($J["name"]), '" data-maxlength="64" autocapitalize="off">
', (support("materializedview") ? " " . checkbox("materialized", 1, $J["materialized"], lang(129)) : ""), '<p>';
						textarea("select", $J["select"]);
						echo '<p>
<input type="submit" value="', lang(14), '">
';
						if ($a != "") {
							echo '<input type="submit" name="drop" value="', lang(127), '">', confirm(lang(175, $a));
						}
						echo '<input type="hidden" name="token" value="', $qi, '">
</form>
';
					} elseif (isset($_GET["event"])) {
						$aa = $_GET["event"];
						$Yd = array("YEAR", "QUARTER", "MONTH", "DAY", "HOUR", "MINUTE", "WEEK", "SECOND", "YEAR_MONTH", "DAY_HOUR", "DAY_MINUTE", "DAY_SECOND", "HOUR_MINUTE", "HOUR_SECOND", "MINUTE_SECOND");
						$Hh = array("ENABLED" => "ENABLE", "DISABLED" => "DISABLE", "SLAVESIDE_DISABLED" => "DISABLE ON SLAVE");
						$J = $_POST;
						if ($_POST && !$n) {
							if ($_POST["drop"]) query_redirect("DROP EVENT " . idf_escape($aa), substr(ME, 0, -1), lang(205));
							elseif (in_array($J["INTERVAL_FIELD"], $Yd) && isset($Hh[$J["STATUS"]])) {
								$bh = "\nON SCHEDULE " . ($J["INTERVAL_VALUE"] ? "EVERY " . q($J["INTERVAL_VALUE"]) . " $J[INTERVAL_FIELD]" . ($J["STARTS"] ? " STARTS " . q($J["STARTS"]) : "") . ($J["ENDS"] ? " ENDS " . q($J["ENDS"]) : "") : "AT " . q($J["STARTS"])) . " ON COMPLETION" . ($J["ON_COMPLETION"] ? "" : " NOT") . " PRESERVE";
								queries_redirect(substr(ME, 0, -1), ($aa != "" ? lang(206) : lang(207)), queries(($aa != "" ? "ALTER EVENT " . idf_escape($aa) . $bh . ($aa != $J["EVENT_NAME"] ? "\nRENAME TO " . idf_escape($J["EVENT_NAME"]) : "") : "CREATE EVENT " . idf_escape($J["EVENT_NAME"]) . $bh) . "\n" . $Hh[$J["STATUS"]] . " COMMENT " . q($J["EVENT_COMMENT"]) . rtrim(" DO\n$J[EVENT_DEFINITION]", ";") . ";"));
							}
						}
						page_header(($aa != "" ? lang(208) . ": " . h($aa) : lang(209)), $n);
						if (!$J && $aa != "") {
							$K = get_rows("SELECT * FROM information_schema.EVENTS WHERE EVENT_SCHEMA = " . q(DB) . " AND EVENT_NAME = " . q($aa));
							$J = reset($K);
						}
						echo '
<form action="" method="post">
<table cellspacing="0" class="layout">
<tr><th>', lang(183), '<td><input name="EVENT_NAME" value="', h($J["EVENT_NAME"]), '" data-maxlength="64" autocapitalize="off">
<tr><th title="datetime">', lang(210), '<td><input name="STARTS" value="', h("$J[EXECUTE_AT]$J[STARTS]"), '">
<tr><th title="datetime">', lang(211), '<td><input name="ENDS" value="', h($J["ENDS"]), '">
<tr><th>', lang(212), '<td><input type="number" name="INTERVAL_VALUE" value="', h($J["INTERVAL_VALUE"]), '" class="size"> ', html_select("INTERVAL_FIELD", $Yd, $J["INTERVAL_FIELD"]), '<tr><th>', lang(118), '<td>', html_select("STATUS", $Hh, $J["STATUS"]), '<tr><th>', lang(50), '<td><input name="EVENT_COMMENT" value="', h($J["EVENT_COMMENT"]), '" data-maxlength="64">
<tr><th><td>', checkbox("ON_COMPLETION", "PRESERVE", $J["ON_COMPLETION"] == "PRESERVE", lang(213)), '</table>
<p>';
						textarea("EVENT_DEFINITION", $J["EVENT_DEFINITION"]);
						echo '<p>
<input type="submit" value="', lang(14), '">
';
						if ($aa != "") {
							echo '<input type="submit" name="drop" value="', lang(127), '">', confirm(lang(175, $aa));
						}
						echo '<input type="hidden" name="token" value="', $qi, '">
</form>
';
					} elseif (isset($_GET["procedure"])) {
						$da = ($_GET["name"] ? $_GET["name"] : $_GET["procedure"]);
						$Wg = (isset($_GET["function"]) ? "FUNCTION" : "PROCEDURE");
						$J = $_POST;
						$J["fields"] = (array)$J["fields"];
						if ($_POST && !process_fields($J["fields"]) && !$n) {
							$Ff = routine($_GET["procedure"], $Wg);
							$bi = "$J[name]_lc2admin_" . uniqid();
							drop_create("DROP $Wg " . routine_id($da, $Ff), create_routine($Wg, $J), "DROP $Wg " . routine_id($J["name"], $J), create_routine($Wg, array("name" => $bi) + $J), "DROP $Wg " . routine_id($bi, $J), substr(ME, 0, -1), lang(214), lang(215), lang(216), $da, $J["name"]);
						}
						page_header(($da != "" ? (isset($_GET["function"]) ? lang(217) : lang(218)) . ": " . h($da) : (isset($_GET["function"]) ? lang(219) : lang(220))), $n);
						if (!$_POST && $da != "") {
							$J = routine($_GET["procedure"], $Wg);
							$J["name"] = $da;
						}
						$nb = get_vals("SHOW CHARACTER SET");
						sort($nb);
						$Xg = routine_languages();
						echo '
<form action="" method="post" id="form">
<p>', lang(183), ': <input name="name" value="', h($J["name"]), '" data-maxlength="64" autocapitalize="off">
', ($Xg ? lang(19) . ": " . html_select("language", $Xg, $J["language"]) . "\n" : ""), '<input type="submit" value="', lang(14), '">
<div class="scrollable">
<table cellspacing="0" class="nowrap">
';
						edit_fields($J["fields"], $nb, $Wg);
						if (isset($_GET["function"])) {
							echo "<tr><td>" . lang(221);
							edit_type("returns", $J["returns"], $nb, array(), ($y == "pgsql" ? array("void", "trigger") : array()));
						}
						echo '</table>
', script("editFields();"), '</div>
<p>';
						textarea("definition", $J["definition"]);
						echo '<p>
<input type="submit" value="', lang(14), '">
';
						if ($da != "") {
							echo '<input type="submit" name="drop" value="', lang(127), '">', confirm(lang(175, $da));
						}
						echo '<input type="hidden" name="token" value="', $qi, '">
</form>
';
					} elseif (isset($_GET["sequence"])) {
						$fa = $_GET["sequence"];
						$J = $_POST;
						if ($_POST && !$n) {
							$A = substr(ME, 0, -1);
							$D = trim($J["name"]);
							if ($_POST["drop"]) query_redirect("DROP SEQUENCE " . idf_escape($fa), $A, lang(222));
							elseif ($fa == "") query_redirect("CREATE SEQUENCE " . idf_escape($D), $A, lang(223));
							elseif ($fa != $D) query_redirect("ALTER SEQUENCE " . idf_escape($fa) . " RENAME TO " . idf_escape($D), $A, lang(224));
							else
								redirect($A);
						}
						page_header($fa != "" ? lang(225) . ": " . h($fa) : lang(226), $n);
						if (!$J) $J["name"] = $fa;
						echo '
<form action="" method="post">
<p><input name="name" value="', h($J["name"]), '" autocapitalize="off">
<input type="submit" value="', lang(14), '">
';
						if ($fa != "") echo "<input type='submit' name='drop' value='" . lang(127) . "'>" . confirm(lang(175, $fa)) . "\n";
						echo '<input type="hidden" name="token" value="', $qi, '">
</form>
';
					} elseif (isset($_GET["type"])) {
						$ga = $_GET["type"];
						$J = $_POST;
						if ($_POST && !$n) {
							$A = substr(ME, 0, -1);
							if ($_POST["drop"]) query_redirect("DROP TYPE " . idf_escape($ga), $A, lang(227));
							else
								query_redirect("CREATE TYPE " . idf_escape(trim($J["name"])) . " $J[as]", $A, lang(228));
						}
						page_header($ga != "" ? lang(229) . ": " . h($ga) : lang(230), $n);
						if (!$J) $J["as"] = "AS ";
						echo '
<form action="" method="post">
<p>
';
						if ($ga != "") echo "<input type='submit' name='drop' value='" . lang(127) . "'>" . confirm(lang(175, $ga)) . "\n";
						else {
							echo "<input name='name' value='" . h($J['name']) . "' autocapitalize='off'>\n";
							textarea("as", $J["as"]);
							echo "<p><input type='submit' value='" . lang(14) . "'>\n";
						}
						echo '<input type="hidden" name="token" value="', $qi, '">
</form>
';
					} elseif (isset($_GET["trigger"])) {
						$a = $_GET["trigger"];
						$D = $_GET["name"];
						$Ai = trigger_options();
						$J = (array)trigger($D, $a) + array("Trigger" => $a . "_bi");
						if ($_POST) {
							if (!$n && in_array($_POST["Timing"], $Ai["Timing"]) && in_array($_POST["Event"], $Ai["Event"]) && in_array($_POST["Type"], $Ai["Type"])) {
								$rf = " ON " . table($a);
								$lc = "DROP TRIGGER " . idf_escape($D) . ($y == "pgsql" ? $rf : "");
								$B = ME . "table=" . urlencode($a);
								if ($_POST["drop"]) query_redirect($lc, $B, lang(231));
								else {
									if ($D != "") queries($lc);
									queries_redirect($B, ($D != "" ? lang(232) : lang(233)), queries(create_trigger($rf, $_POST)));
									if ($D != "") queries(create_trigger($rf, $J + array("Type" => reset($Ai["Type"]))));
								}
							}
							$J = $_POST;
						}
						page_header(($D != "" ? lang(234) . ": " . h($D) : lang(235)), $n, array("table" => $a));
						echo '
<form action="" method="post" id="form">
<table cellspacing="0" class="layout">
<tr><th>', lang(236), '<td>', html_select("Timing", $Ai["Timing"], $J["Timing"], "triggerChange(/^" . preg_quote($a, "/") . "_[ba][iud]$/, '" . js_escape($a) . "', this.form);"), '<tr><th>', lang(237), '<td>', html_select("Event", $Ai["Event"], $J["Event"], "this.form['Timing'].onchange();"), (in_array("UPDATE OF", $Ai["Event"]) ? " <input name='Of' value='" . h($J["Of"]) . "' class='hidden'>" : ""), '<tr><th>', lang(49), '<td>', html_select("Type", $Ai["Type"], $J["Type"]), '</table>
<p>', lang(183), ': <input name="Trigger" value="', h($J["Trigger"]), '" data-maxlength="64" autocapitalize="off">
', script("qs('#form')['Timing'].onchange();"), '<p>';
						textarea("Statement", $J["Statement"]);
						echo '<p>
<input type="submit" value="', lang(14), '">
';
						if ($D != "") {
							echo '<input type="submit" name="drop" value="', lang(127), '">', confirm(lang(175, $D));
						}
						echo '<input type="hidden" name="token" value="', $qi, '">
</form>
';
					} elseif (isset($_GET["user"])) {
						$ha = $_GET["user"];
						$sg = array("" => array("All privileges" => ""));
						foreach (get_rows("SHOW PRIVILEGES") as $J) {
							foreach (explode(",", ($J["Privilege"] == "Grant option" ? "" : $J["Context"])) as $Fb) $sg[$Fb][$J["Privilege"]] = $J["Comment"];
						}
						$sg["Server Admin"] += $sg["File access on server"];
						$sg["Databases"]["Create routine"] = $sg["Procedures"]["Create routine"];
						unset($sg["Procedures"]["Create routine"]);
						$sg["Columns"] = array();
						foreach (array("Select", "Insert", "Update", "References") as $X) $sg["Columns"][$X] = $sg["Tables"][$X];
						unset($sg["Server Admin"]["Usage"]);
						foreach ($sg["Tables"] as $z => $X) unset($sg["Databases"][$z]);
						$af = array();
						if ($_POST) {
							foreach ($_POST["objects"] as $z => $X) $af[$X] = (array)$af[$X] + (array)$_POST["grants"][$z];
						}
						$rd = array();
						$pf = "";
						if (isset($_GET["host"]) && ($H = $g->query("SHOW GRANTS FOR " . q($ha) . "@" . q($_GET["host"])))) {
							while ($J = $H->fetch_row()) {
								if (preg_match('~GRANT (.*) ON (.*) TO ~', $J[0], $C) && preg_match_all('~ *([^(,]*[^ ,(])( *\([^)]+\))?~', $C[1], $Fe, PREG_SET_ORDER)) {
									foreach ($Fe
										as $X) {
										if ($X[1] != "USAGE") $rd["$C[2]$X[2]"][$X[1]] = true;
										if (preg_match('~ WITH GRANT OPTION~', $J[0])) $rd["$C[2]$X[2]"]["GRANT OPTION"] = true;
									}
								}
								if (preg_match("~ IDENTIFIED BY PASSWORD '([^']+)~", $J[0], $C)) $pf = $C[1];
							}
						}
						if ($_POST && !$n) {
							$qf = (isset($_GET["host"]) ? q($ha) . "@" . q($_GET["host"]) : "''");
							if ($_POST["drop"]) query_redirect("DROP USER $qf", ME . "privileges=", lang(238));
							else {
								$cf = q($_POST["user"]) . "@" . q($_POST["host"]);
								$Zf = $_POST["pass"];
								if ($Zf != '' && !$_POST["hashed"] && !min_version(8)) {
									$Zf = $g->result("SELECT PASSWORD(" . q($Zf) . ")");
									$n = !$Zf;
								}
								$Lb = false;
								if (!$n) {
									if ($qf != $cf) {
										$Lb = queries((min_version(5) ? "CREATE USER" : "GRANT USAGE ON *.* TO") . " $cf IDENTIFIED BY " . (min_version(8) ? "" : "PASSWORD ") . q($Zf));
										$n = !$Lb;
									} elseif ($Zf != $pf) queries("SET PASSWORD FOR $cf = " . q($Zf));
								}
								if (!$n) {
									$Tg = array();
									foreach ($af
										as $if => $qd) {
										if (isset($_GET["grant"])) $qd = array_filter($qd);
										$qd = array_keys($qd);
										if (isset($_GET["grant"])) $Tg = array_diff(array_keys(array_filter($af[$if], 'strlen')), $qd);
										elseif ($qf == $cf) {
											$nf = array_keys((array)$rd[$if]);
											$Tg = array_diff($nf, $qd);
											$qd = array_diff($qd, $nf);
											unset($rd[$if]);
										}
										if (preg_match('~^(.+)\s*(\(.*\))?$~U', $if, $C) && (!grant("REVOKE", $Tg, $C[2], " ON $C[1] FROM $cf") || !grant("GRANT", $qd, $C[2], " ON $C[1] TO $cf"))) {
											$n = true;
											break;
										}
									}
								}
								if (!$n && isset($_GET["host"])) {
									if ($qf != $cf) queries("DROP USER $qf");
									elseif (!isset($_GET["grant"])) {
										foreach ($rd
											as $if => $Tg) {
											if (preg_match('~^(.+)(\(.*\))?$~U', $if, $C)) grant("REVOKE", array_keys($Tg), $C[2], " ON $C[1] FROM $cf");
										}
									}
								}
								queries_redirect(ME . "privileges=", (isset($_GET["host"]) ? lang(239) : lang(240)), !$n);
								if ($Lb) $g->query("DROP USER $cf");
							}
						}
						page_header((isset($_GET["host"]) ? lang(35) . ": " . h("$ha@$_GET[host]") : lang(146)), $n, array("privileges" => array('', lang(71))));
						if ($_POST) {
							$J = $_POST;
							$rd = $af;
						} else {
							$J = $_GET + array("host" => $g->result("SELECT SUBSTRING_INDEX(CURRENT_USER, '@', -1)"));
							$J["pass"] = $pf;
							if ($pf != "") $J["hashed"] = true;
							$rd[(DB == "" || $rd ? "" : idf_escape(addcslashes(DB, "%_\\"))) . ".*"] = array();
						}
						echo '<form action="" method="post">
<table cellspacing="0" class="layout">
<tr><th>', lang(34), '<td><input name="host" data-maxlength="60" value="', h($J["host"]), '" autocapitalize="off">
<tr><th>', lang(35), '<td><input name="user" data-maxlength="80" value="', h($J["user"]), '" autocapitalize="off">
<tr><th>', lang(36), '<td><input name="pass" id="pass" value="', h($J["pass"]), '" autocomplete="new-password">
';
						if (!$J["hashed"]) echo
						script("typePassword(qs('#pass'));");
						echo (min_version(8) ? "" : checkbox("hashed", 1, $J["hashed"], lang(241), "typePassword(this.form['pass'], this.checked);")), '</table>

';
						echo "<table cellspacing='0'>\n", "<thead><tr><th colspan='2'>" . lang(71) . doc_link(array('sql' => "grant.html#priv_level"));
						$t = 0;
						foreach ($rd
							as $if => $qd) {
							echo '<th>' . ($if != "*.*" ? "<input name='objects[$t]' value='" . h($if) . "' size='10' autocapitalize='off'>" : "<input type='hidden' name='objects[$t]' value='*.*' size='10'>*.*");
							$t++;
						}
						echo "</thead>\n";
						foreach (array("" => "", "Server Admin" => lang(34), "Databases" => lang(37), "Tables" => lang(131), "Columns" => lang(48), "Procedures" => lang(242),) as $Fb => $dc) {
							foreach ((array)$sg[$Fb] as $rg => $tb) {
								echo "<tr" . odd() . "><td" . ($dc ? ">$dc<td" : " colspan='2'") . ' lang="en" title="' . h($tb) . '">' . h($rg);
								$t = 0;
								foreach ($rd
									as $if => $qd) {
									$D = "'grants[$t][" . h(strtoupper($rg)) . "]'";
									$Y = $qd[strtoupper($rg)];
									if ($Fb == "Server Admin" && $if != (isset($rd["*.*"]) ? "*.*" : ".*")) echo "<td>";
									elseif (isset($_GET["grant"])) echo "<td><select name=$D><option><option value='1'" . ($Y ? " selected" : "") . ">" . lang(243) . "<option value='0'" . ($Y == "0" ? " selected" : "") . ">" . lang(244) . "</select>";
									else {
										echo "<td align='center'><label class='block'>", "<input type='checkbox' name=$D value='1'" . ($Y ? " checked" : "") . ($rg == "All privileges" ? " id='grants-$t-all'>" : ">" . ($rg == "Grant option" ? "" : script("qsl('input').onclick = function () { if (this.checked) formUncheck('grants-$t-all'); };"))), "</label>";
									}
									$t++;
								}
							}
						}
						echo "</table>\n", '<p>
<input type="submit" value="', lang(14), '">
';
						if (isset($_GET["host"])) {
							echo '<input type="submit" name="drop" value="', lang(127), '">', confirm(lang(175, "$ha@$_GET[host]"));
						}
						echo '<input type="hidden" name="token" value="', $qi, '">
</form>
';
					} elseif (isset($_GET["processlist"])) {
						if (support("kill")) {
							if ($_POST && !$n) {
								$le = 0;
								foreach ((array)$_POST["kill"] as $X) {
									if (kill_process($X)) $le++;
								}
								queries_redirect(ME . "processlist=", lang(245, $le), $le || !$_POST["kill"]);
							}
						}
						page_header(lang(116), $n);
						echo '
<form action="" method="post">
<div class="scrollable">
<table cellspacing="0" class="nowrap checkable">
', script("mixin(qsl('table'), {onclick: tableClick, ondblclick: partialArg(tableClick, true)});");
						$t = -1;
						foreach (process_list() as $t => $J) {
							if (!$t) {
								echo "<thead><tr lang='en'>" . (support("kill") ? "<th>" : "");
								foreach ($J
									as $z => $X) echo "<th>$z" . doc_link(array('sql' => "show-processlist.html#processlist_" . strtolower($z), 'pgsql' => "monitoring-stats.html#PG-STAT-ACTIVITY-VIEW", 'oracle' => "REFRN30223",));
								echo "</thead>\n";
							}
							echo "<tr" . odd() . ">" . (support("kill") ? "<td>" . checkbox("kill[]", $J[$y == "sql" ? "Id" : "pid"], 0) : "");
							foreach ($J
								as $z => $X) echo "<td>" . (($y == "sql" && $z == "Info" && preg_match("~Query|Killed~", $J["Command"]) && $X != "") || ($y == "pgsql" && $z == "current_query" && $X != "<IDLE>") || ($y == "oracle" && $z == "sql_text" && $X != "") ? "<code class='jush-$y'>" . shorten_utf8($X, 100, "</code>") . ' <a href="' . h(ME . ($J["db"] != "" ? "db=" . urlencode($J["db"]) . "&" : "") . "sql=" . urlencode($X)) . '">' . lang(246) . '</a>' : h($X));
							echo "\n";
						}
						echo '</table>
</div>
<p>
';
						if (support("kill")) {
							echo ($t + 1) . "/" . lang(247, max_connections()), "<p><input type='submit' value='" . lang(248) . "'>\n";
						}
						echo '<input type="hidden" name="token" value="', $qi, '">
</form>
', script("tableCheck();");
					} elseif (isset($_GET["select"])) {
						$a = $_GET["select"];
						$R = table_status1($a);
						$x = indexes($a);
						$p = fields($a);
						$jd = column_foreign_keys($a);
						$lf = $R["Oid"];
						parse_str($_COOKIE["lc2admin_import"], $za);
						$Ug = array();
						$e = array();
						$fi = null;
						foreach ($p
							as $z => $o) {
							$D = $b->fieldName($o);
							if (isset($o["privileges"]["select"]) && $D != "") {
								$e[$z] = html_entity_decode(strip_tags($D), ENT_QUOTES);
								if (is_shortable($o)) $fi = $b->selectLengthProcess();
							}
							$Ug += $o["privileges"];
						}
						list($L, $sd) = $b->selectColumnsProcess($e, $x);
						$ce = count($sd) < count($L);
						$Z = $b->selectSearchProcess($p, $x);
						$Bf = $b->selectOrderProcess($p, $x);
						$_ = $b->selectLimitProcess();
						if ($_GET["val"] && is_ajax()) {
							header("Content-Type: text/plain; charset=utf-8");
							foreach ($_GET["val"] as $Hi => $J) {
								$Ga = convert_field($p[key($J)]);
								$L = array($Ga ? $Ga : idf_escape(key($J)));
								$Z[] = where_check($Hi, $p);
								$I = $m->select($a, $L, $Z, $L);
								if ($I) echo
								reset($I->fetch_row());
							}
							exit;
						}
						$ng = $Ji = null;
						foreach ($x
							as $w) {
							if ($w["type"] == "PRIMARY") {
								$ng = array_flip($w["columns"]);
								$Ji = ($L ? $ng : array());
								foreach ($Ji
									as $z => $X) {
									if (in_array(idf_escape($z), $L)) unset($Ji[$z]);
								}
								break;
							}
						}
						if ($lf && !$ng) {
							$ng = $Ji = array($lf => 0);
							$x[] = array("type" => "PRIMARY", "columns" => array($lf));
						}
						if ($_POST && !$n) {
							$kj = $Z;
							if (!$_POST["all"] && is_array($_POST["check"])) {
								$eb = array();
								foreach ($_POST["check"] as $bb) $eb[] = where_check($bb, $p);
								$kj[] = "((" . implode(") OR (", $eb) . "))";
							}
							$kj = ($kj ? "\nWHERE " . implode(" AND ", $kj) : "");
							if ($_POST["export"]) {
								cookie("lc2admin_import", "output=" . urlencode($_POST["output"]) . "&format=" . urlencode($_POST["format"]));
								dump_headers($a);
								$b->dumpTable($a, "");
								$od = ($L ? implode(", ", $L) : "*") . convert_fields($e, $p, $L) . "\nFROM " . table($a);
								$ud = ($sd && $ce ? "\nGROUP BY " . implode(", ", $sd) : "") . ($Bf ? "\nORDER BY " . implode(", ", $Bf) : "");
								if (!is_array($_POST["check"]) || $ng) $G = "SELECT $od$kj$ud";
								else {
									$Fi = array();
									foreach ($_POST["check"] as $X) $Fi[] = "(SELECT" . limit($od, "\nWHERE " . ($Z ? implode(" AND ", $Z) . " AND " : "") . where_check($X, $p) . $ud, 1) . ")";
									$G = implode(" UNION ALL ", $Fi);
								}
								$b->dumpData($a, "table", $G);
								exit;
							}
							if (!$b->selectEmailProcess($Z, $jd)) {
								if ($_POST["save"] || $_POST["delete"]) {
									$H = true;
									$_a = 0;
									$N = array();
									if (!$_POST["delete"]) {
										foreach ($e
											as $D => $X) {
											$X = process_input($p[$D]);
											if ($X !== null && ($_POST["clone"] || $X !== false)) $N[idf_escape($D)] = ($X !== false ? $X : idf_escape($D));
										}
									}
									if ($_POST["delete"] || $N) {
										if ($_POST["clone"]) $G = "INTO " . table($a) . " (" . implode(", ", array_keys($N)) . ")\nSELECT " . implode(", ", $N) . "\nFROM " . table($a);
										if ($_POST["all"] || ($ng && is_array($_POST["check"])) || $ce) {
											$H = ($_POST["delete"] ? $m->delete($a, $kj) : ($_POST["clone"] ? queries("INSERT $G$kj") : $m->update($a, $N, $kj)));
											$_a = $g->affected_rows;
										} else {
											foreach ((array)$_POST["check"] as $X) {
												$gj = "\nWHERE " . ($Z ? implode(" AND ", $Z) . " AND " : "") . where_check($X, $p);
												$H = ($_POST["delete"] ? $m->delete($a, $gj, 1) : ($_POST["clone"] ? queries("INSERT" . limit1($a, $G, $gj)) : $m->update($a, $N, $gj, 1)));
												if (!$H) break;
												$_a += $g->affected_rows;
											}
										}
									}
									$Ne = lang(249, $_a);
									if ($_POST["clone"] && $H && $_a == 1) {
										$re = last_id();
										if ($re) $Ne = lang(168, " $re");
									}
									queries_redirect(remove_from_uri($_POST["all"] && $_POST["delete"] ? "page" : ""), $Ne, $H);
									if (!$_POST["delete"]) {
										edit_form($a, $p, (array)$_POST["fields"], !$_POST["clone"]);
										page_footer();
										exit;
									}
								} elseif (!$_POST["import"]) {
									if (!$_POST["val"]) $n = lang(250);
									else {
										$H = true;
										$_a = 0;
										foreach ($_POST["val"] as $Hi => $J) {
											$N = array();
											foreach ($J
												as $z => $X) {
												$z = bracket_escape($z, 1);
												$N[idf_escape($z)] = (preg_match('~char|text~', $p[$z]["type"]) || $X != "" ? $b->processInput($p[$z], $X) : "NULL");
											}
											$H = $m->update($a, $N, " WHERE " . ($Z ? implode(" AND ", $Z) . " AND " : "") . where_check($Hi, $p), !$ce && !$ng, " ");
											if (!$H) break;
											$_a += $g->affected_rows;
										}
										queries_redirect(remove_from_uri(), lang(249, $_a), $H);
									}
								} elseif (!is_string($Zc = get_file("csv_file", true))) $n = upload_error($Zc);
								elseif (!preg_match('~~u', $Zc)) $n = lang(251);
								else {
									cookie("lc2admin_import", "output=" . urlencode($za["output"]) . "&format=" . urlencode($_POST["separator"]));
									$H = true;
									$pb = array_keys($p);
									preg_match_all('~(?>"[^"]*"|[^"\r\n]+)+~', $Zc, $Fe);
									$_a = count($Fe[0]);
									$m->begin();
									$kh = ($_POST["separator"] == "csv" ? "," : ($_POST["separator"] == "tsv" ? "\t" : ";"));
									$K = array();
									foreach ($Fe[0] as $z => $X) {
										preg_match_all("~((?>\"[^\"]*\")+|[^$kh]*)$kh~", $X . $kh, $Ge);
										if (!$z && !array_diff($Ge[1], $pb)) {
											$pb = $Ge[1];
											$_a--;
										} else {
											$N = array();
											foreach ($Ge[1] as $t => $kb) $N[idf_escape($pb[$t])] = ($kb == "" && $p[$pb[$t]]["null"] ? "NULL" : q(str_replace('""', '"', preg_replace('~^"|"$~', '', $kb))));
											$K[] = $N;
										}
									}
									$H = (!$K || $m->insertUpdate($a, $K, $ng));
									if ($H) $H = $m->commit();
									queries_redirect(remove_from_uri("page"), lang(252, $_a), $H);
									$m->rollback();
								}
							}
						}
						$Rh = $b->tableName($R);
						if (is_ajax()) {
							page_headers();
							ob_start();
						} else
							page_header(lang(53) . ": $Rh", $n);
						$N = null;
						if (isset($Ug["insert"]) || !support("table")) {
							$N = "";
							foreach ((array)$_GET["where"] as $X) {
								if ($jd[$X["col"]] && count($jd[$X["col"]]) == 1 && ($X["op"] == "=" || (!$X["op"] && !preg_match('~[_%]~', $X["val"])))) $N .= "&set" . urlencode("[" . bracket_escape($X["col"]) . "]") . "=" . urlencode($X["val"]);
							}
						}
						$b->selectLinks($R, $N);
						if (!$e && support("table")) echo "<p class='error'>" . lang(253) . ($p ? "." : ": " . error()) . "\n";
						else {
							echo "<form action='' id='form'>\n", "<div style='display: none;'>";
							hidden_fields_get();
							echo (DB != "" ? '<input type="hidden" name="db" value="' . h(DB) . '">' . (isset($_GET["ns"]) ? '<input type="hidden" name="ns" value="' . h($_GET["ns"]) . '">' : "") : "");
							echo '<input type="hidden" name="select" value="' . h($a) . '">', "</div>\n";
							$b->selectColumnsPrint($L, $e);
							$b->selectSearchPrint($Z, $e, $x);
							$b->selectOrderPrint($Bf, $e, $x);
							$b->selectLimitPrint($_);
							$b->selectLengthPrint($fi);
							$b->selectActionPrint($x);
							echo "</form>\n";
							$E = $_GET["page"];
							if ($E == "last") {
								$md = $g->result(count_rows($a, $Z, $ce, $sd));
								$E = floor(max(0, $md - 1) / $_);
							}
							$fh = $L;
							$td = $sd;
							if (!$fh) {
								$fh[] = "*";
								$Gb = convert_fields($e, $p, $L);
								if ($Gb) $fh[] = substr($Gb, 2);
							}
							foreach ($L
								as $z => $X) {
								$o = $p[idf_unescape($X)];
								if ($o && ($Ga = convert_field($o))) $fh[$z] = "$Ga AS $X";
							}
							if (!$ce && $Ji) {
								foreach ($Ji
									as $z => $X) {
									$fh[] = idf_escape($z);
									if ($td) $td[] = idf_escape($z);
								}
							}
							$H = $m->select($a, $fh, $Z, $td, $Bf, $_, $E, true);
							if (!$H) echo "<p class='error'>" . error() . "\n";
							else {
								if ($y == "mssql" && $E) $H->seek($_ * $E);
								$yc = array();
								echo "<form action='' method='post' enctype='multipart/form-data'>\n";
								$K = array();
								while ($J = $H->fetch_assoc()) {
									if ($E && $y == "oracle") unset($J["RNUM"]);
									$K[] = $J;
								}
								if ($_GET["page"] != "last" && $_ != "" && $sd && $ce && $y == "sql") $md = $g->result(" SELECT FOUND_ROWS()");
								if (!$K) echo "<p class='message'>" . lang(12) . "\n";
								else {
									$Pa = $b->backwardKeys($a, $Rh);
									echo "<div class='scrollable'>", "<table id='table' cellspacing='0' class='nowrap checkable'>", script("mixin(qs('#table'), {onclick: tableClick, ondblclick: partialArg(tableClick, true), onkeydown: editingKeydown});"), "<thead><tr>" . (!$sd && $L ? "" : "<td><input type='checkbox' id='all-page' class='jsonly'>" . script("qs('#all-page').onclick = partial(formCheck, /check/);", "") . " <a href='" . h($_GET["modify"] ? remove_from_uri("modify") : $_SERVER["REQUEST_URI"] . "&modify=1") . "'>" . lang(254) . "</a>");
									$Ye = array();
									$pd = array();
									reset($L);
									$Bg = 1;
									foreach ($K[0] as $z => $X) {
										if (!isset($Ji[$z])) {
											$X = $_GET["columns"][key($L)];
											$o = $p[$L ? ($X ? $X["col"] : current($L)) : $z];
											$D = ($o ? $b->fieldName($o, $Bg) : ($X["fun"] ? "*" : $z));
											if ($D != "") {
												$Bg++;
												$Ye[$z] = $D;
												$d = idf_escape($z);
												$Gd = remove_from_uri('(order|desc)[^=]*|page') . '&order%5B0%5D=' . urlencode($z);
												$dc = "&desc%5B0%5D=1";
												echo "<th id='th[" . h(bracket_escape($z)) . "]'>" . script("mixin(qsl('th'), {onmouseover: partial(columnMouse), onmouseout: partial(columnMouse, ' hidden')});", ""), '<a href="' . h($Gd . ($Bf[0] == $d || $Bf[0] == $z || (!$Bf && $ce && $sd[0] == $d) ? $dc : '')) . '">';
												echo
												apply_sql_function($X["fun"], $D) . "</a>";
												echo "<span class='column hidden'>", "<a href='" . h($Gd . $dc) . "' title='" . lang(59) . "' class='text'> ↓</a>";
												if (!$X["fun"]) {
													echo '<a href="#fieldset-search" title="' . lang(56) . '" class="text jsonly"> =</a>', script("qsl('a').onclick = partial(selectSearch, '" . js_escape($z) . "');");
												}
												echo "</span>";
											}
											$pd[$z] = $X["fun"];
											next($L);
										}
									}
									$xe = array();
									if ($_GET["modify"]) {
										foreach ($K
											as $J) {
											foreach ($J
												as $z => $X) $xe[$z] = max($xe[$z], min(40, strlen(utf8_decode($X))));
										}
									}
									echo ($Pa ? "<th>" . lang(255) : "") . "</thead>\n";
									if (is_ajax()) {
										if ($_ % 2 == 1 && $E % 2 == 1) odd();
										ob_end_clean();
									}
									foreach ($b->rowDescriptions($K, $jd) as $Xe => $J) {
										$Gi = unique_array($K[$Xe], $x);
										if (!$Gi) {
											$Gi = array();
											foreach ($K[$Xe] as $z => $X) {
												if (!preg_match('~^(COUNT\((\*|(DISTINCT )?`(?:[^`]|``)+`)\)|(AVG|GROUP_CONCAT|MAX|MIN|SUM)\(`(?:[^`]|``)+`\))$~', $z)) $Gi[$z] = $X;
											}
										}
										$Hi = "";
										foreach ($Gi
											as $z => $X) {
											if (($y == "sql" || $y == "pgsql") && preg_match('~char|text|enum|set~', $p[$z]["type"]) && strlen($X) > 64) {
												$z = (strpos($z, '(') ? $z : idf_escape($z));
												$z = "MD5(" . ($y != 'sql' || preg_match("~^utf8~", $p[$z]["collation"]) ? $z : "CONVERT($z USING " . charset($g) . ")") . ")";
												$X = md5($X);
											}
											$Hi .= "&" . ($X !== null ? urlencode("where[" . bracket_escape($z) . "]") . "=" . urlencode($X) : "null%5B%5D=" . urlencode($z));
										}
										echo "<tr" . odd() . ">" . (!$sd && $L ? "" : "<td>" . checkbox("check[]", substr($Hi, 1), in_array(substr($Hi, 1), (array)$_POST["check"])) . ($ce || information_schema(DB) ? "" : " <a href='" . h(ME . "edit=" . urlencode($a) . $Hi) . "' class='edit'>" . lang(256) . "</a>"));
										foreach ($J
											as $z => $X) {
											if (isset($Ye[$z])) {
												$o = $p[$z];
												$X = $m->value($X, $o);
												if ($X != "" && (!isset($yc[$z]) || $yc[$z] != "")) $yc[$z] = (is_mail($X) ? $Ye[$z] : "");
												$A = "";
												if (preg_match('~blob|bytea|raw|file~', $o["type"]) && $X != "") $A = ME . 'download=' . urlencode($a) . '&field=' . urlencode($z) . $Hi;
												if (!$A && $X !== null) {
													foreach ((array)$jd[$z] as $r) {
														if (count($jd[$z]) == 1 || end($r["source"]) == $z) {
															$A = "";
															foreach ($r["source"] as $t => $yh) $A .= where_link($t, $r["target"][$t], $K[$Xe][$yh]);
															$A = ($r["db"] != "" ? preg_replace('~([?&]db=)[^&]+~', '\1' . urlencode($r["db"]), ME) : ME) . 'select=' . urlencode($r["table"]) . $A;
															if ($r["ns"]) $A = preg_replace('~([?&]ns=)[^&]+~', '\1' . urlencode($r["ns"]), $A);
															if (count($r["source"]) == 1) break;
														}
													}
												}
												if ($z == "COUNT(*)") {
													$A = ME . "select=" . urlencode($a);
													$t = 0;
													foreach ((array)$_GET["where"] as $W) {
														if (!array_key_exists($W["col"], $Gi)) $A .= where_link($t++, $W["col"], $W["val"], $W["op"]);
													}
													foreach ($Gi
														as $he => $W) $A .= where_link($t++, $he, $W);
												}
												$X = select_value($X, $A, $o, $fi);
												$u = h("val[$Hi][" . bracket_escape($z) . "]");
												$Y = $_POST["val"][$Hi][bracket_escape($z)];
												$tc = !is_array($J[$z]) && is_utf8($X) && $K[$Xe][$z] == $J[$z] && !$pd[$z];
												$ei = preg_match('~text|lob~', $o["type"]);
												echo "<td id='$u'";
												if (($_GET["modify"] && $tc) || $Y !== null) {
													$xd = h($Y !== null ? $Y : $J[$z]);
													echo ">" . ($ei ? "<textarea name='$u' cols='30' rows='" . (substr_count($J[$z], "\n") + 1) . "'>$xd</textarea>" : "<input name='$u' value='$xd' size='$xe[$z]'>");
												} else {
													$Ae = strpos($X, "<i>…</i>");
													echo " data-text='" . ($Ae ? 2 : ($ei ? 1 : 0)) . "'" . ($tc ? "" : " data-warning='" . h(lang(257)) . "'") . ">$X</td>";
												}
											}
										}
										if ($Pa) echo "<td>";
										$b->backwardKeysPrint($Pa, $K[$Xe]);
										echo "</tr>\n";
									}
									if (is_ajax()) exit;
									echo "</table>\n", "</div>\n";
								}
								if (!is_ajax()) {
									if ($K || $E) {
										$Ic = true;
										if ($_GET["page"] != "last") {
											if ($_ == "" || (count($K) < $_ && ($K || !$E))) $md = ($E ? $E * $_ : 0) + count($K);
											elseif ($y != "sql" || !$ce) {
												$md = ($ce ? false : found_rows($R, $Z));
												if ($md < max(1e4, 2 * ($E + 1) * $_)) $md = reset(slow_query(count_rows($a, $Z, $ce, $sd)));
												else $Ic = false;
											}
										}
										$Pf = ($_ != "" && ($md === false || $md > $_ || $E));
										if ($Pf) {
											echo (($md === false ? count($K) + 1 : $md - $E * $_) > $_ ? '<p><a href="' . h(remove_from_uri("page") . "&page=" . ($E + 1)) . '" class="loadmore">' . lang(258) . '</a>' . script("qsl('a').onclick = partial(selectLoadMore, " . (+$_) . ", '" . lang(259) . "…');", "") : ''), "\n";
										}
									}
									echo "<div class='footer'><div>\n";
									if ($K || $E) {
										if ($Pf) {
											$Ie = ($md === false ? $E + (count($K) >= $_ ? 2 : 1) : floor(($md - 1) / $_));
											echo "<fieldset>";
											if ($y != "simpledb") {
												echo "<legend><a href='" . h(remove_from_uri("page")) . "'>" . lang(260) . "</a></legend>", script("qsl('a').onclick = function () { pageClick(this.href, +prompt('" . lang(260) . "', '" . ($E + 1) . "')); return false; };"), pagination(0, $E) . ($E > 5 ? " …" : "");
												for ($t = max(1, $E - 4); $t < min($Ie, $E + 5); $t++) echo
												pagination($t, $E);
												if ($Ie > 0) {
													echo ($E + 5 < $Ie ? " …" : ""), ($Ic && $md !== false ? pagination($Ie, $E) : " <a href='" . h(remove_from_uri("page") . "&page=last") . "' title='~$Ie'>" . lang(261) . "</a>");
												}
											} else {
												echo "<legend>" . lang(260) . "</legend>", pagination(0, $E) . ($E > 1 ? " …" : ""), ($E ? pagination($E, $E) : ""), ($Ie > $E ? pagination($E + 1, $E) . ($Ie > $E + 1 ? " …" : "") : "");
											}
											echo "</fieldset>\n";
										}
										echo "<fieldset>", "<legend>" . lang(262) . "</legend>";
										$ic = ($Ic ? "" : "~ ") . $md;
										echo
										checkbox("all", 1, 0, ($md !== false ? ($Ic ? "" : "~ ") . lang(150, $md) : ""), "var checked = formChecked(this, /check/); selectCount('selected', this.checked ? '$ic' : checked); selectCount('selected2', this.checked || !checked ? '$ic' : checked);") . "\n", "</fieldset>\n";
										if ($b->selectCommandPrint()) {
											echo '<fieldset', ($_GET["modify"] ? '' : ' class="jsonly"'), '><legend>', lang(254), '</legend><div>
<input type="submit" value="', lang(14), '"', ($_GET["modify"] ? '' : ' title="' . lang(250) . '"'), '>
</div></fieldset>
<fieldset><legend>', lang(126), ' <span id="selected"></span></legend><div>
<input type="submit" name="edit" value="', lang(10), '">
<input type="submit" name="clone" value="', lang(246), '">
<input type="submit" name="delete" value="', lang(18), '">', confirm(), '</div></fieldset>
';
										}
										$kd = $b->dumpFormat();
										foreach ((array)$_GET["columns"] as $d) {
											if ($d["fun"]) {
												unset($kd['sql']);
												break;
											}
										}
										if ($kd) {
											print_fieldset("export", lang(73) . " <span id='selected2'></span>");
											$Mf = $b->dumpOutput();
											echo ($Mf ? html_select("output", $Mf, $za["output"]) . " " : ""), html_select("format", $kd, $za["format"]), " <input type='submit' name='export' value='" . lang(73) . "'>\n", "</div></fieldset>\n";
										}
										$b->selectEmailPrint(array_filter($yc, 'strlen'), $e);
									}
									echo "</div></div>\n";
									if ($b->selectImportPrint()) {
										echo "<div>", "<a href='#import'>" . lang(72) . "</a>", script("qsl('a').onclick = partial(toggle, 'import');", ""), "<span id='import' class='hidden'>: ", "<input type='file' name='csv_file'> ", html_select("separator", array("csv" => "CSV,", "csv;" => "CSV;", "tsv" => "TSV"), $za["format"], 1);
										echo " <input type='submit' name='import' value='" . lang(72) . "'>", "</span>", "</div>";
									}
									echo "<input type='hidden' name='token' value='$qi'>\n", "</form>\n", (!$sd && $L ? "" : script("tableCheck();"));
								}
							}
						}
						if (is_ajax()) {
							ob_end_clean();
							exit;
						}
					} elseif (isset($_GET["variables"])) {
						$O = isset($_GET["status"]);
						page_header($O ? lang(118) : lang(117));
						$Xi = ($O ? show_status() : show_variables());
						if (!$Xi) echo "<p class='message'>" . lang(12) . "\n";
						else {
							echo "<table cellspacing='0'>\n";
							foreach ($Xi
								as $z => $X) {
								echo "<tr>", "<th><code class='jush-" . $y . ($O ? "status" : "set") . "'>" . h($z) . "</code>", "<td>" . h($X);
							}
							echo "</table>\n";
						}
					} elseif (isset($_GET["script"])) {
						header("Content-Type: text/javascript; charset=utf-8");
						if ($_GET["script"] == "db") {
							$Oh = array("Data_length" => 0, "Index_length" => 0, "Data_free" => 0);
							foreach (table_status() as $D => $R) {
								json_row("Comment-$D", h($R["Comment"]));
								if (!is_view($R)) {
									foreach (array("Engine", "Collation") as $z) json_row("$z-$D", h($R[$z]));
									foreach ($Oh + array("Auto_increment" => 0, "Rows" => 0) as $z => $X) {
										if ($R[$z] != "") {
											$X = format_number($R[$z]);
											json_row("$z-$D", ($z == "Rows" && $X && $R["Engine"] == ($Ah == "pgsql" ? "table" : "InnoDB") ? "~ $X" : $X));
											if (isset($Oh[$z])) $Oh[$z] += ($R["Engine"] != "InnoDB" || $z != "Data_free" ? $R[$z] : 0);
										} elseif (array_key_exists($z, $R)) json_row("$z-$D");
									}
								}
							}
							foreach ($Oh
								as $z => $X) json_row("sum-$z", format_number($X));
							json_row("");
						} elseif ($_GET["script"] == "kill") $g->query("KILL " . number($_POST["kill"]));
						else {
							foreach (count_tables($b->databases()) as $l => $X) {
								json_row("tables-$l", $X);
								json_row("size-$l", db_size($l));
							}
							json_row("");
						}
						exit;
					} else {
						$Xh = array_merge((array)$_POST["tables"], (array)$_POST["views"]);
						if ($Xh && !$n && !$_POST["search"]) {
							$H = true;
							$Ne = "";
							if ($y == "sql" && $_POST["tables"] && count($_POST["tables"]) > 1 && ($_POST["drop"] || $_POST["truncate"] || $_POST["copy"])) queries("SET foreign_key_checks = 0");
							if ($_POST["truncate"]) {
								if ($_POST["tables"]) $H = truncate_tables($_POST["tables"]);
								$Ne = lang(263);
							} elseif ($_POST["move"]) {
								$H = move_tables((array)$_POST["tables"], (array)$_POST["views"], $_POST["target"]);
								$Ne = lang(264);
							} elseif ($_POST["copy"]) {
								$H = copy_tables((array)$_POST["tables"], (array)$_POST["views"], $_POST["target"]);
								$Ne = lang(265);
							} elseif ($_POST["drop"]) {
								if ($_POST["views"]) $H = drop_views($_POST["views"]);
								if ($H && $_POST["tables"]) $H = drop_tables($_POST["tables"]);
								$Ne = lang(266);
							} elseif ($y != "sql") {
								$H = ($y == "sqlite" ? queries("VACUUM") : apply_queries("VACUUM" . ($_POST["optimize"] ? "" : " ANALYZE"), $_POST["tables"]));
								$Ne = lang(267);
							} elseif (!$_POST["tables"]) $Ne = lang(9);
							elseif ($H = queries(($_POST["optimize"] ? "OPTIMIZE" : ($_POST["check"] ? "CHECK" : ($_POST["repair"] ? "REPAIR" : "ANALYZE"))) . " TABLE " . implode(", ", array_map('idf_escape', $_POST["tables"])))) {
								while ($J = $H->fetch_assoc()) $Ne .= "<b>" . h($J["Table"]) . "</b>: " . h($J["Msg_text"]) . "<br>";
							}
							queries_redirect(substr(ME, 0, -1), $Ne, $H);
						}
						page_header(($_GET["ns"] == "" ? lang(37) . ": " . h(DB) : lang(77) . ": " . h($_GET["ns"])), $n, true);
						if ($b->homepage()) {
							if ($_GET["ns"] !== "") {
								echo "<h3 id='tables-views'>" . lang(268) . "</h3>\n";
								$Wh = tables_list();
								if (!$Wh) echo "<p class='message'>" . lang(9) . "\n";
								else {
									echo "<form action='' method='post'>\n";
									if (support("table")) {
										echo "<fieldset><legend>" . lang(269) . " <span id='selected2'></span></legend><div>", "<input type='search' name='query' value='" . h($_POST["query"]) . "'>", script("qsl('input').onkeydown = partialArg(bodyKeydown, 'search');", ""), " <input type='submit' name='search' value='" . lang(56) . "'>\n", "</div></fieldset>\n";
										if ($_POST["search"] && $_POST["query"] != "") {
											$_GET["where"][0]["op"] = "LIKE %%";
											search_tables();
										}
									}
									echo "<div class='scrollable'>\n", "<table cellspacing='0' class='nowrap checkable'>\n", script("mixin(qsl('table'), {onclick: tableClick, ondblclick: partialArg(tableClick, true)});"), '<thead><tr class="wrap">', '<td><input id="check-all" type="checkbox" class="jsonly">' . script("qs('#check-all').onclick = partial(formCheck, /^(tables|views)\[/);", ""), '<th>' . lang(131), '<td>' . lang(270) . doc_link(array('sql' => 'storage-engines.html')), '<td>' . lang(122) . doc_link(array('sql' => 'charset-charsets.html', 'mariadb' => 'supported-character-sets-and-collations/')), '<td>' . lang(271) . doc_link(array('sql' => 'show-table-status.html', 'pgsql' => 'functions-admin.html#FUNCTIONS-ADMIN-DBOBJECT', 'oracle' => 'REFRN20286')), '<td>' . lang(272) . doc_link(array('sql' => 'show-table-status.html', 'pgsql' => 'functions-admin.html#FUNCTIONS-ADMIN-DBOBJECT')), '<td>' . lang(273) . doc_link(array('sql' => 'show-table-status.html')), '<td>' . lang(51) . doc_link(array('sql' => 'example-auto-increment.html', 'mariadb' => 'auto_increment/')), '<td>' . lang(274) . doc_link(array('sql' => 'show-table-status.html', 'pgsql' => 'catalog-pg-class.html#CATALOG-PG-CLASS', 'oracle' => 'REFRN20286')), (support("comment") ? '<td>' . lang(50) . doc_link(array('sql' => 'show-table-status.html', 'pgsql' => 'functions-info.html#FUNCTIONS-INFO-COMMENT-TABLE')) : ''), "</thead>\n";
									$S = 0;
									foreach ($Wh
										as $D => $T) {
										$aj = ($T !== null && !preg_match('~table|sequence~i', $T));
										$u = h("Table-" . $D);
										echo '<tr' . odd() . '><td>' . checkbox(($aj ? "views[]" : "tables[]"), $D, in_array($D, $Xh, true), "", "", "", $u), '<th>' . (support("table") || support("indexes") ? "<a href='" . h(ME) . "table=" . urlencode($D) . "' title='" . lang(42) . "' id='$u'>" . h($D) . '</a>' : h($D));
										if ($aj) {
											echo '<td colspan="6"><a href="' . h(ME) . "view=" . urlencode($D) . '" title="' . lang(43) . '">' . (preg_match('~materialized~i', $T) ? lang(129) : lang(130)) . '</a>', '<td align="right"><a href="' . h(ME) . "select=" . urlencode($D) . '" title="' . lang(41) . '">?</a>';
										} else {
											foreach (array("Engine" => array(), "Collation" => array(), "Data_length" => array("create", lang(44)), "Index_length" => array("indexes", lang(133)), "Data_free" => array("edit", lang(45)), "Auto_increment" => array("auto_increment=1&create", lang(44)), "Rows" => array("select", lang(41)),) as $z => $A) {
												$u = " id='$z-" . h($D) . "'";
												echo ($A ? "<td align='right'>" . (support("table") || $z == "Rows" || (support("indexes") && $z != "Data_length") ? "<a href='" . h(ME . "$A[0]=") . urlencode($D) . "'$u title='$A[1]'>?</a>" : "<span$u>?</span>") : "<td id='$z-" . h($D) . "'>");
											}
											$S++;
										}
										echo (support("comment") ? "<td id='Comment-" . h($D) . "'>" : "");
									}
									echo "<tr><td><th>" . lang(247, count($Wh)), "<td>" . h($y == "sql" ? $g->result("SELECT @@default_storage_engine") : ""), "<td>" . h(db_collation(DB, collations()));
									foreach (array("Data_length", "Index_length", "Data_free") as $z) echo "<td align='right' id='sum-$z'>";
									echo "</table>\n", "</div>\n";
									if (!information_schema(DB)) {
										echo "<div class='footer'><div>\n";
										$Ui = "<input type='submit' value='" . lang(275) . "'> " . on_help("'VACUUM'");
										$yf = "<input type='submit' name='optimize' value='" . lang(276) . "'> " . on_help($y == "sql" ? "'OPTIMIZE TABLE'" : "'VACUUM OPTIMIZE'");
										echo "<fieldset><legend>" . lang(126) . " <span id='selected'></span></legend><div>" . ($y == "sqlite" ? $Ui : ($y == "pgsql" ? $Ui . $yf : ($y == "sql" ? "<input type='submit' value='" . lang(277) . "'> " . on_help("'ANALYZE TABLE'") . $yf . "<input type='submit' name='check' value='" . lang(278) . "'> " . on_help("'CHECK TABLE'") . "<input type='submit' name='repair' value='" . lang(279) . "'> " . on_help("'REPAIR TABLE'") : ""))) . "<input type='submit' name='truncate' value='" . lang(280) . "'> " . on_help($y == "sqlite" ? "'DELETE'" : "'TRUNCATE" . ($y == "pgsql" ? "'" : " TABLE'")) . confirm() . "<input type='submit' name='drop' value='" . lang(127) . "'>" . on_help("'DROP TABLE'") . confirm() . "\n";
										$k = (support("scheme") ? $b->schemas() : $b->databases());
										if (count($k) != 1 && $y != "sqlite") {
											$l = (isset($_POST["target"]) ? $_POST["target"] : (support("scheme") ? $_GET["ns"] : DB));
											echo "<p>" . lang(281) . ": ", ($k ? html_select("target", $k, $l) : '<input name="target" value="' . h($l) . '" autocapitalize="off">'), " <input type='submit' name='move' value='" . lang(282) . "'>", (support("copy") ? " <input type='submit' name='copy' value='" . lang(283) . "'> " . checkbox("overwrite", 1, $_POST["overwrite"], lang(284)) : ""), "\n";
										}
										echo "<input type='hidden' name='all' value=''>";
										echo
										script("qsl('input').onclick = function () { selectCount('selected', formChecked(this, /^(tables|views)\[/));" . (support("table") ? " selectCount('selected2', formChecked(this, /^tables\[/) || $S);" : "") . " }"), "<input type='hidden' name='token' value='$qi'>\n", "</div></fieldset>\n", "</div></div>\n";
									}
									echo "</form>\n", script("tableCheck();");
								}
								echo '<p class="links"><a href="' . h(ME) . 'create=">' . lang(74) . "</a>\n", (support("view") ? '<a href="' . h(ME) . 'view=">' . lang(204) . "</a>\n" : "");
								if (support("routine")) {
									echo "<h3 id='routines'>" . lang(143) . "</h3>\n";
									$Yg = routines();
									if ($Yg) {
										echo "<table cellspacing='0'>\n", '<thead><tr><th>' . lang(183) . '<td>' . lang(49) . '<td>' . lang(221) . "<td></thead>\n";
										odd('');
										foreach ($Yg
											as $J) {
											$D = ($J["SPECIFIC_NAME"] == $J["ROUTINE_NAME"] ? "" : "&name=" . urlencode($J["ROUTINE_NAME"]));
											echo '<tr' . odd() . '>', '<th><a href="' . h(ME . ($J["ROUTINE_TYPE"] != "PROCEDURE" ? 'callf=' : 'call=') . urlencode($J["SPECIFIC_NAME"]) . $D) . '">' . h($J["ROUTINE_NAME"]) . '</a>', '<td>' . h($J["ROUTINE_TYPE"]), '<td>' . h($J["DTD_IDENTIFIER"]), '<td><a href="' . h(ME . ($J["ROUTINE_TYPE"] != "PROCEDURE" ? 'function=' : 'procedure=') . urlencode($J["SPECIFIC_NAME"]) . $D) . '">' . lang(136) . "</a>";
										}
										echo "</table>\n";
									}
									echo '<p class="links">' . (support("procedure") ? '<a href="' . h(ME) . 'procedure=">' . lang(220) . '</a>' : '') . '<a href="' . h(ME) . 'function=">' . lang(219) . "</a>\n";
								}
								if (support("sequence")) {
									echo "<h3 id='sequences'>" . lang(285) . "</h3>\n";
									$mh = get_vals("SELECT sequence_name FROM information_schema.sequences WHERE sequence_schema = current_schema() ORDER BY sequence_name");
									if ($mh) {
										echo "<table cellspacing='0'>\n", "<thead><tr><th>" . lang(183) . "</thead>\n";
										odd('');
										foreach ($mh
											as $X) echo "<tr" . odd() . "><th><a href='" . h(ME) . "sequence=" . urlencode($X) . "'>" . h($X) . "</a>\n";
										echo "</table>\n";
									}
									echo "<p class='links'><a href='" . h(ME) . "sequence='>" . lang(226) . "</a>\n";
								}
								if (support("type")) {
									echo "<h3 id='user-types'>" . lang(26) . "</h3>\n";
									$Si = types();
									if ($Si) {
										echo "<table cellspacing='0'>\n", "<thead><tr><th>" . lang(183) . "</thead>\n";
										odd('');
										foreach ($Si
											as $X) echo "<tr" . odd() . "><th><a href='" . h(ME) . "type=" . urlencode($X) . "'>" . h($X) . "</a>\n";
										echo "</table>\n";
									}
									echo "<p class='links'><a href='" . h(ME) . "type='>" . lang(230) . "</a>\n";
								}
								if (support("event")) {
									echo "<h3 id='events'>" . lang(144) . "</h3>\n";
									$K = get_rows("SHOW EVENTS");
									if ($K) {
										echo "<table cellspacing='0'>\n", "<thead><tr><th>" . lang(183) . "<td>" . lang(286) . "<td>" . lang(210) . "<td>" . lang(211) . "<td></thead>\n";
										foreach ($K
											as $J) {
											echo "<tr>", "<th>" . h($J["Name"]), "<td>" . ($J["Execute at"] ? lang(287) . "<td>" . $J["Execute at"] : lang(212) . " " . $J["Interval value"] . " " . $J["Interval field"] . "<td>$J[Starts]"), "<td>$J[Ends]", '<td><a href="' . h(ME) . 'event=' . urlencode($J["Name"]) . '">' . lang(136) . '</a>';
										}
										echo "</table>\n";
										$Gc = $g->result("SELECT @@event_scheduler");
										if ($Gc && $Gc != "ON") echo "<p class='error'><code class='jush-sqlset'>event_scheduler</code>: " . h($Gc) . "\n";
									}
									echo '<p class="links"><a href="' . h(ME) . 'event=">' . lang(209) . "</a>\n";
								}
								if ($Wh) echo
								script("ajaxSetHtml('" . js_escape(ME) . "script=db');");
							}
						}
					}
					page_footer();
