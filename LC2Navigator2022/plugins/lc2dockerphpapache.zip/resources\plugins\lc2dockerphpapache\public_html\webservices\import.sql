select 'TEST';
INSERT INTO dbtest.products (title, description,price)VALUES ('John', 'john@example.com',1122)