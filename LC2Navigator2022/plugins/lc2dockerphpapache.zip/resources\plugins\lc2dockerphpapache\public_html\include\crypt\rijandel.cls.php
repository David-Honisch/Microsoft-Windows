<?php 
function encryptAES($content,$key,$aes) {
    error_reporting ( 0 );
    // Setzt den Algorithmus
    switch ($aes) {
        case 128:
           $rijndael = 'rijndael-128';
           break;
        case 192:
           $rijndael = 'rijndael-192';
           break;
        case 256:
           $rijndael = 'rijndael-256';
           break;
        case 512:
           $rijndael = 'rijndael-512';
           break;
		case 1024:
           $rijndael = 'rijndael-1024';
           break;		      
        default:
           $rijndael = 'rijndael-256';
    }

    // Setzt den Verschl�sselungsalgorithmus
    // und setzt den Output Feedback (OFB) Modus
    $cp = mcrypt_module_open($rijndael, '', 'ofb', '');
    if(!$cp)
        return 'Modul konnte nicht geladen werden';
    
    // Ermittelt den Initialisierungsvector, der f�r die Modi CBC, CFB und  OFB ben�tigt wird. 
    // Der Initialisierungsvector muss beim Entschl�sseln den selben Wert wie beim Verschl�sseln haben.
    // Windows unterst�tzt nur MCRYPT_RAND
    if (strtoupper(substr(PHP_OS, 0, 3)) === 'WIN')
        $enc['iv'] = mcrypt_create_iv(mcrypt_enc_get_iv_size($cp), 
                         MCRYPT_RAND);
    else
        $enc['iv'] = mcrypt_create_iv(mcrypt_enc_get_iv_size($cp), 
                        MCRYPT_DEV_RANDOM);
        
    // Ermittelt die Anzahl der Bits, welche die Schl�ssell�nge des Keys festlegen
     $ks = mcrypt_enc_get_key_size($cp);
  
     // Erstellt den Schl�ssel, der f�r die Verschl�sselung genutzt wird
     $key = substr(md5($key), 0, $ks);
  
     // Initialisiert die Verschl�sselung
     mcrypt_generic_init($cp, $key, $enc['iv']);
  
     // Verschl�sselt die Daten
     $enc['encrypted'] = mcrypt_generic($cp, $content);
      
     // Deinitialisiert die Verschl�sselung 
     mcrypt_generic_deinit($cp);
  
     // Schlie�t das Modul
     mcrypt_module_close($cp);
  
    // Erstellt einen Hash-Wert um sp�ter pr�fen zu k�nnen, ob ein misslungene
    // Entschl�sselung durchgef�hrt wurde
    $enc['md5']    =    md5($content);
  
    return $enc;
    
}


function decryptAES($content,$iv, $key,$aes) {
    
    // Setzt den Algorithmus
 	switch ($aes) {
        case 128:
           $rijndael = 'rijndael-128';
           break;
        case 192:
           $rijndael = 'rijndael-192';
           break;
        case 256:
           $rijndael = 'rijndael-256';
           break;
        case 512:
           $rijndael = 'rijndael-512';
           break;
		case 1024:
           $rijndael = 'rijndael-1024';
           break;		      
        default:
           $rijndael = 'rijndael-256';
    }

    // Setzt den Verschl�sselungsalgorithmus
    // und setzt den Output Feedback (OFB) Modus
    $cp = mcrypt_module_open($rijndael, '', 'ofb', '');
    
    // Ermittelt die Anzahl der Bits, welche die Schl�ssell�nge des Keys festlegen
    $ks = mcrypt_enc_get_key_size($cp);
  
    // Erstellt den Schl�ssel, der f�r die Verschl�sselung genutzt wird
    $key = substr(md5($key), 0, $ks);
  
    // Initialisiert die Verschl�sselung
    mcrypt_generic_init($cp, $key, $iv);

    // Entschl�sselt die Daten
    $decrypted = mdecrypt_generic($cp, $content);
  
    // Beendet die Verschl�sselung 
    mcrypt_generic_deinit($cp);
  
    // Schlie�t das Modul
    mcrypt_module_close($cp);
	error_reporting ( E_ALL );
    return trim($decrypted);
  
}
function checkDecrypt($decrypted,$md5,$id=0,$database=false) {
    
    if($database) {
        if(md5($decrypted) == $md5) {
            $sqlUpdate = @mysql_query("UPDATE rijndael SET decrypt = NOW() 
                                     WHERE id = $id");
            $message   = "Daten konnten erfolgreich entschl�sselt werden.";        
        } else {
            $sqlUpdate = @mysql_query("UPDATE rijndael SET decryptError = NOW() 
                                     WHERE id = $id");
            $message   = "Daten konnten nicht entschl�sselt werden!";
        }
    } else {
        if(md5($decrypted) == $md5) {
            return true;
        } else {
            return false;
        }
    }
    
    return $message;
    
} 

?>