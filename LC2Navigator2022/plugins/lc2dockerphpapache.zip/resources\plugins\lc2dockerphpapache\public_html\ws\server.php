<?php
error_reporting(0);
echo "Damn";
require "../include/nusoap/lib/nusoap.php";
$inputFile = "./json/methods.json";

//=> 'xsd:string'
function getMethodParameters($data){
    $res = array();
    $t = explode(";",$data);
    // print_r($t);
    foreach ($t as $v)
    {
        // echo $res[$v];
        $res[$v] ='xsd:string';
    }
    return $res;
}
function printRegisterData($server, $namespace, $data)
{
    foreach ($data as $object) {
        // echo gettype($object);
        if (gettype($object) == "array") {
            // print_r($object);
            foreach ($object as $key => $value) {
                // echo "KV:".$key . $value;
                $server->register(
                    // method name:
                    $key,
                    getMethodParameters($value)
                    ,
                    // return value(s):
                    array(
                        'return' => 'xsd:string'
                    ),
                    // namespace:
                    $namespace,
                    // soapaction: (use default)
                    false,
                    // style: rpc or document
                    'rpc',
                    // use: encoded or literal
                    'encoded',
                    // description: documentation for the method
                    'LC2WebService - '.$key
                );
            }
        }
    }
}
//functions
$FuncSearchDirectory = "./include/functions";
$RegisterSearchDirectory = "./include/register";
if (file_exists("../include/io/io.cls.php")) {
    require_once("../include/io/io.cls.php");
    $dir = IO::readDirToArray($FuncSearchDirectory);
    foreach ($dir as $v) {
        $target = $FuncSearchDirectory . "/" . $v;
        // echo  $target;
        require  $target;
    }
} else {
    echo $env["FileNotFound"];
    echo "IO Failure or page not found.";
    die();
}
echo "Damn";

// $namespace = "http://www.letztechance.org/ws";
// $namespace = "https://letztechance.org.org/webservices";
$namespace = "https://letztechance.org.org/ws";
// if (doAuthenticate()){echo "Logged in !!";}else{echo "Not Logged in";}
// create a new soap server
$server = new soap_server();
$server->decode_utf8 = true;
$server->soap_defencoding = 'UTF-8';
// configure our WSDL
// $server->configureWSDL("LetztChance.Org Webservice");
$server->configureWSDL("LC WebServices");
// set our namespace
$server->wsdl->schemaTargetNamespace = $namespace;
$input = file_get_contents($inputFile);
// echo $input;
$data = json_decode($input, true);
printRegisterData($server, $namespace, $data);
// require_once("./include/register-plugins.cls.php");
// Get our posted data if the service is being consumed
// otherwise leave this data blank.
// $POST_DATA = isset($GLOBALS['HTTP_RAW_POST_DATA'])
// ? $GLOBALS['HTTP_RAW_POST_DATA'] : '';
// pass our posted data (or nothing) to the soap service
$server->service($POST_DATA);
//$server->service(file_get_contents("php://input"));
// exit();
echo "Damn";