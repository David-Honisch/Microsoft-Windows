<h1>LC2MySQL Database</h1>
<h4>Attempting MySQL connection from php...</h4>
<a href="showdb.php">showdb.php</a>
<hr>
<?php
$host = 'mysql';
$user = 'root';
$pass = 'rootpassword';
$dbname = "myLCDB";

// Create connection
$conn = new mysqli($host, $user, $pass, $dbname);
// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

//$sql = "SELECT id, firstname, lastname FROM MyGuests";
$sql = "Show databases";
$result = $conn->query($sql);
print_r($result->);
if ($result->num_rows > 0) {
  // output data of each row
  while($row = $result->fetch_assoc()) {
    echo "id: " . $row["id"]. " - Name: " . $row["current_field"]. " " . $row["lastname"]. "<br>";
  }
} else {
  echo "0 results";
}
$conn->close();
?> 