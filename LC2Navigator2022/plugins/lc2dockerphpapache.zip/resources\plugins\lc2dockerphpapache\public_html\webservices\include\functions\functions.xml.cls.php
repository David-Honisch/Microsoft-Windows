<?php

//use PhpParser\Node\Stmt\TryCatch;

if (strpos("functions.xml.cls.php", $_SERVER['PHP_SELF'])) {
    Header("Location:/index.php");
    die();
}
function getINFO()
{
    $responseString = "";
    $responseData["0"] = "test";
    $responseData["1"] = "test";
    $responseString = new soapval('return', 'xsd:string', json_encode($responseData));
    return $responseString;
}
function get_INFO($value1, $value2)
{
    $responseString = "";
    $responseData = "<?xml version=\"1.0\" standalone=\"yes\"?><NewDataSet>";
    try {
        echo "<h1>Fuck now !!!</h1>";
        $responseData .= '<table1>';
       
    } catch (Exception $e) {        
        $responseString = new soapval('return', 'xsd:string', json_encode('Exception abgefangen: '.$e->getMessage()));
    }
    $responseString = new soapval('return', 'xsd:string', json_encode($responseData));
    return $responseString;
}


function getINFOXML($value1, $value2)
{
    $responseString = "";
    $responseData = "<?xml version=\"1.0\" standalone=\"yes\"?><NewDataSet>";
    try {
        echo "Fuck now !!!";
        $responseData .= '<table1>';
        // foreach($rowGetData as $k => $v) {
        $responseData .= "<table_id>" . $value1 . "</table_id>";
        // $responseData .= "<".utf8_decode(utf8_decode(utf8_decode($k))).">".rawurldecode(utf8_decode(utf8_decode($v)))."</".utf8_encode(utf8_decode(utf8_decode($k))).">";

        $responseData .= "<link>" . $value2 . "</link>";

        if (isset($value1)) {
            $responseData .= "<login>1</login>\n";
        } else {
            $responseData .= "<login>0</login>\n";
        }
        $responseData .= "<id>11</id>";
        $responseData .= "<page>11</page>";
        $responseData .= "<path>11</path>";
        $responseData .= "<pagefile>12</pagefile>";
        $responseData .= "<title>11</title>";
        $responseData .= "<sid>11</sid>";
        $responseData .= '</table1>';
        /* EOF WHILE LOOP WORKING */
        $responseData .= '</NewDataSet>';
        // $responseString = new soapval('return', 'xsd:string', $responseData);
    } catch (Exception $e) {        
        $responseString = new soapval('return', 'xsd:string', json_encode('Exception abgefangen: '.$e->getMessage()));
    }
    $responseString = new soapval('return', 'xsd:string', json_encode($responseData));
    return $responseString;
}
