
<?php

// XML-Quelle laden
$xml = new DOMDocument;
$xml->load('collection.xml');

$xsl = new DOMDocument;
$xsl->load('collection.xslt');

// Prozessor instanziieren und konfigurieren
$proc = new XSLTProcessor;
$proc->importStyleSheet($xsl); // die XSL-Regeln anhängen

$proc->transformToURI($xml, 'file:///tmp/out.html');

?>