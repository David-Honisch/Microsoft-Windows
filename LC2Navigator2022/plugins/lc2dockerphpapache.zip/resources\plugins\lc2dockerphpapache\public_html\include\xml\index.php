<?PHP
// This file is part of Web-XML
include ("class.inc.php");
$info = array ();

if (empty ( $_GET ['file'] )) {
	$error = "\nPlease Select a File to Edit\n";
} else {
	$id = pull ( $_GET ['file'] );
	$info = read ( $id );
}

// < is &#60
// > is &#62

?>
<html>
<head>
<title>URI XML Parser</title>
<META NAME="ROBOTS" CONTENT="NOINDEX">
<META HTTP-EQUIV="imagetoolbar" CONTENT="no">


<head>


<body>
	<div align="center">
		<img src="" alt="Teh Logo"><br> <select
			onchange="location = this.options[this.selectedIndex].value;"
			size="1" name="select">
			<option>XML File List</option>
			<option value="index.php"></option>
			<option value="index.php?file=1">Security News</option>
		</select> <br>

<?PHP
if (! empty ( $error )) {
	print ($error) ;
	exit ();
}
?>

<form method="post" action="write.php">
			<input type="hidden" name="id" value="<?PHP print($_GET['file']); ?>">
			<textarea name="xml" cols="115" rows="25"><?PHP  call($info);?></textarea>
			<br> <input type="submit" value="Edit Now">
		</form>

	</div>
</body>
</html>
<?PHP
function call($info) {
	$i = 0;
	while ( $info [$i] != NULL ) {
		print($info[$i++]);
	}
}
?>
