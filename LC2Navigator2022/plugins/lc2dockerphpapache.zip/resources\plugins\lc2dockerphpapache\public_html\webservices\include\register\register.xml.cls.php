<?php
/**
 * ProcessSimpleType method
 * @param string $who name of the person we'll say hello to
 * @return string $helloText the hello  string
 */
if (strpos("register.xml.cls.php", $_SERVER['PHP_SELF'])) {
    Header("Location:/index.php");
    die();
}
$server->register(
    // method name:
    'getINFO',
    // parameter list:
    array(
        // 'value1' => 'xsd:string',
        // 'value2' => 'xsd:string',
    ),
    // return value(s):
    array(
        'return' => 'xsd:string',
    ),
    // namespace:
    $namespace,
    // soapaction: (use default)
    false,
    // style: rpc or document
    'rpc',
    // use: encoded or literal
    'encoded',
    // description: documentation for the method
    'LC2WebService v.1.0 getINFO v.1.01a');
$server->register(
    // method name:
    'getINFO',
    // parameter list:
    array(
        'value1' => 'xsd:string',
        'value2' => 'xsd:string',
    ),
    // return value(s):
    array(
        'return' => 'xsd:string',
    ),
    // namespace:
    $namespace,
    // soapaction: (use default)
    false,
    // style: rpc or document
    'rpc',
    // use: encoded or literal
    'encoded',
    // description: documentation for the method
    'LC2WebService v.1.0 getINFO v.1.01a');
$server->register(
    // method name:
    'getMsg',
    // parameter list:
    array(
        'text' => 'xsd:string'        
    ),
    // return value(s):
    array(
        'return' => 'xsd:string',
    ),
    // namespace:
    $namespace,
    // soapaction: (use default)
    false,
    // style: rpc or document
    'rpc',
    // use: encoded or literal
    'encoded',
    // description: documentation for the method
    'LC2WebService v.1.0 getMsg v.1.01a');

$server->register(
    // method name:
    'getQR',
    // parameter list:
    array(
        'pattern' => 'xsd:string',
    ),
    // return value(s):
    array(
        'return' => 'xsd:string',
    ),
    // namespace:
    $namespace,
    // soapaction: (use default)
    false,
    // style: rpc or document
    'rpc',
    // use: encoded or literal
    'encoded',
    // description: documentation for the method
    'LC2WebService v.1.0 getQR v.1.01a');

// $server->register(
//     // method name:
//     'getList',
//     // parameter list:
//     array(
//         'value1' => 'xsd:string',
//         'value2' => 'xsd:string'
//     ),
//     // return value(s):
//     array(
//         'return' => 'xsd:string'
//     ),
//     // namespace:
//     $namespace,
//     // soapaction: (use default)
//     false,
//     // style: rpc or document
//     'rpc',
//     // use: encoded or literal
//     'encoded',
//     // description: documentation for the method
//     'LC2WebService v.1.0 List');
// $server->register(
//     // method name:
//     'getSearch',
//     // parameter list:
//     array(
//         'query' => 'xsd:string',
//         'value1' => 'xsd:string',
//         'value2' => 'xsd:string',
//         'isSort' => 'xsd:string'
//     ),
//     // return value(s):
//     array(
//         'return' => 'xsd:string'
//     ),
//     // namespace:
//     $namespace,
//     // soapaction: (use default)
//     false,
//     // style: rpc or document
//     'rpc',
//     // use: encoded or literal
//     'encoded',
//     // description: documentation for the method
//     'LC2WebService v.1.0 getSearch');
// $server->register(
//     // method name:
//     'getRead',
//     // parameter list:
//     array(
//         'value1' => 'xsd:string',
//         'value2' => 'xsd:string'
//     ),
//     // return value(s):
//     array(
//         'return' => 'xsd:string'
//     ),
//     // namespace:
//     $namespace,
//     // soapaction: (use default)
//     false,
//     // style: rpc or document
//     'rpc',
//     // use: encoded or literal
//     'encoded',
//     // description: documentation for the method
//     'LC2WebService v.1.0 Read');
// // --------------------------------------------------------->
// // get language
// // --------------------------------------------------------->
// $server->register(
//     // method name:
//     'getLang',
//     // parameter list:
//     array(
//         'value1' => 'xsd:string'
//     ),
//     // return value(s):
//     array(
//         'return' => 'xsd:string'
//     ),
//     // namespace:
//     $namespace,
//     // soapaction: (use default)
//     false,
//     // style: rpc or document
//     'rpc',
//     // use: encoded or literal
//     'encoded',
//     // description: documentation for the method
//     'LC2WebService v.1.0 get language');
// // --------------------------------------------------------->
// // get Tags
// // --------------------------------------------------------->
// $server->register(
//     // method name:
//     'getTags',
//     // parameter list:
//     array(),
//     // return value(s):
//     array(
//         'return' => 'xsd:string'
//     ),
//     // namespace:
//     $namespace,
//     // soapaction: (use default)
//     false,
//     // style: rpc or document
//     'rpc',
//     // use: encoded or literal
//     'encoded',
//     // description: documentation for the method
//     'LC2WebService v.1.0 get tags');
// // --------------------------------------------------------->
// // --------------------------------------------------------->
// // PLUGINS
// // --------------------------------------------------------->
// // function create($value1, $value2, $subject, $body, $sid, $isPHPCode) {
// $server->register(
//     // method name:
//     'getCreateDate',
//     // parameter list:
//     array(
//         'date' => 'xsd:string',
//         'subject' => 'xsd:string'
//     ),
//     // return value(s):
//     array(
//         'return' => 'xsd:string'
//     ),
//     // namespace:
//     $namespace,
//     // soapaction: (use default)
//     false,
//     // style: rpc or document
//     'rpc',
//     // use: encoded or literal
//     'encoded',
//     // description: documentation for the method
//     'LC2WebService v.1.0 Date');
// // --------------------------------------------------------->
// // --------------------------------------------------------->
// $server->register(
//     // method name:
//     'getCreateSingle',
//     // parameter list:
//     array(
//         'value1' => 'xsd:string',
//         'value2' => 'xsd:string',
//         'date' => 'xsd:string',
//         'subject' => 'xsd:string',
//         'body' => 'xsd:string',
//         'sid' => 'xsd:string'
//     ), // ,'sid'=>'xsd:string','isPHPCode'=>'xsd:string'),
//        // return value(s):
//     array(
//         'return' => 'xsd:string'
//     ),
//     // namespace:
//     $namespace,
//     // soapaction: (use default)
//     false,
//     // style: rpc or document
//     'rpc',
//     // use: encoded or literal
//     'encoded',
//     // description: documentation for the method
//     'LC2WebService v.1.0 Create');
// // --------------------------------------------------------->
// // --------------------------------------------------------->
// $server->register(
//     // method name:
//     'getDeleteSingle',
//     // parameter list:
//     array(
//         'value1' => 'xsd:string',
//         'value2' => 'xsd:string',
//         'date' => 'xsd:string',
//         'subject' => 'xsd:string',
//         'body' => 'xsd:string',
//         'sid' => 'xsd:string'
//     ), // ,'sid'=>'xsd:string','isPHPCode'=>'xsd:string'),
//        // return value(s):
//     array(
//         'return' => 'xsd:string'
//     ),
//     // namespace:
//     $namespace,
//     // soapaction: (use default)
//     false,
//     // style: rpc or document
//     'rpc',
//     // use: encoded or literal
//     'encoded',
//     // description: documentation for the method
//     'LC2WebService v.1.0 Delete');
// // --------------------------------------------------------->
// // --------------------------------------------------------->

// // PLUGINS
// // --------------------------------------------------------->
// $server->register(
//     // method name:
//     'getImageSearch',
//     // parameter list:
//     // array('name'=>'xsd:string'),
//     array(
//         'query' => 'xsd:string',
//         'page' => 'xsd:string'
//     ),
//     // return value(s):
//     array(
//         'return' => 'xsd:string'
//     ),
//     // namespace:
//     $namespace,
//     // soapaction: (use default)
//     false,
//     // style: rpc or document
//     'rpc',
//     // use: encoded or literal
//     'encoded',
//     // description: documentation for the method
//     'LC2WebService Google Image Search v.1.0');
// --------------------------------------------------------->
// EOF
// --------------------------------------------------------->
