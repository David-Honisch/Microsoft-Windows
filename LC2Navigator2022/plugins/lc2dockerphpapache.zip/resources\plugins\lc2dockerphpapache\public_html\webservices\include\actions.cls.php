<?php //Direkt Aufruf verhindern....
//if (eregi("/include/tables/mysql_tables.php", $_SERVER['PHP_SELF'])) {Header("Location:/index.php");die();}
if (strpos("actions.php", $_SERVER['PHP_SELF'])){Header("Location:/index.php");die();}
?>
<?php
//--------------------------------------------------------------------------------
//require("../../config/const.php");
//--------------------------------------------------------------------------------
//Filename zusammensetzen !!
//--------------------------------------------------------------------------------
class dbActions{
	
	public static function getTopMenu()
	{
		require("./config/const.php");
		//echo "Debug:".$dbhost. $defaultdb. $dbuser. $dbpassword;
		$t = "";

		echo "<?xml version=\"1.0\" encoding=\"UTF-8\"?><Result><Value>";
		$table_name = "content_topmenu";
		$sql = "SELECT * FROM $table_name ORDER BY id";
		//$db = new mySQL_class($dbhost, $defaultdb, $dbuser, $dbpassword);
		$eintragsanzahl = $db->mysql_num_rows($sql);
		$seitenanzahl = ceil($eintragsanzahl / $numofentries);
		//echo $eintragsanzahl.$seitenanzahl;
		if ($_GET['page'] == "") {
			$sql = "SELECT * FROM $table_name ORDER BY parent, id";
			$sql2 = "SELECT * FROM content_forum ORDER BY id DESC";    
			//echo "<sql>".$sql."</sql>";
			$result = $db->fetch_assoc($sql);
			$result2 = $db->fetch_assoc($sql2);
			$i = 0;
			//print_r($result);
			//print_r( array_keys($result));
			//			echo "<Title>".$result[0]["id"]."</Title>\n";
			echo "<Title>TopMenu</Title>\n";
			//echo "<Rows>".$eintragsanzahl."</Rows>\n";
			echo "<Rows>4</Rows>\n";
			foreach ($result as $key => $value) {
				//echo $key["id"].$value["id"];
				//echo  "<V".$i."><id>". $key ."</id><title>". $value["id"]." </title><V".$i."/>\n";
				echo  "<V".$i."><id>". ($key+1) ."</id>".
				"<subject>". $value["subject"]."</subject>".
				//"<body>". $value["id"]."</body>".
				"<url>". $value["url"]."</url>".
				"<parent>". $value["parent"]."</parent>".
				"<parent".intval($value["id"]).">".intval($value["parent"])."</parent".intval($value["id"]).">".//Hard coded !!!!				
				"<child>". $value["child"]."</child>".
				"</V".$i.">\n";
				$i++;
			}

			foreach ($result2 as $key => $value) {
				//echo $key["id"].$value["id"];
				//echo  "<V".$i."><id>". $key ."</id><title>". $value["id"]." </title><V".$i."/>\n";
				echo  "<V".$i."><id>". ($key+1) ."</id>".
				"<subject>".utf8_encode($value["name"])."</subject>".
				//"<body>". $value["id"]."</body>".
				"<url>list-". $value["id"]."-1.html</url>".
				"<parent>2</parent>".
				"<parent2>2</parent2>".
				"<child>2</child>".
				"</V".$i.">\n";
				$i++;
			}


		}
		echo "</Value></Result>";
	}
	
	/**
	 *
	 * Enter description here ...
	 */
	public static function getMenu()
	{
		require("./config/const.php");
		//echo "Debug:".$dbhost. $defaultdb. $dbuser. $dbpassword;

		echo "<?xml version=\"1.0\" encoding=\"UTF-8\"?><Result><Value>";
		$table_name = "content_leftmenu";
		$sql = "SELECT * FROM $table_name ORDER BY id";
		//$db = new mySQL_class($dbhost, $defaultdb, $dbuser, $dbpassword);
		$eintragsanzahl = $db->mysql_num_rows($sql);
		$seitenanzahl = ceil($eintragsanzahl / $numofentries);
		//echo $eintragsanzahl.$seitenanzahl;
		if ($_GET['page'] == "") {
			$sql = "SELECT * FROM $table_name ORDER BY id LIMIT 0,$numofentries";
			$result = $db->fetch_assoc($sql);
			$i = 0;
			//print_r($result);
			//print_r( array_keys($result));
			//			echo "<Title>".$result[0]["id"]."</Title>\n";
			//echo "<Title>Menu</Title>\n";
			foreach ($result as $key => $value) {
				//echo $key["id"].$value["id"];
				//echo  "<V".$i."><id>". $key ."</id><title>". $value["id"]." </title><V".$i."/>\n";
				echo  "<V".$i."><key>". $key ."</key>".
				"<body>". $value["id"]."</body>".
				"<name>". $value["name"]."</name>".
				"<link>". $value["link"]."</link>".
				"</V".$i.">\n";
				$i++;
			}


		}
		echo "</Value></Result>";
	}

	//!!
	public static function getLastContent($userData, $value1, $value2, $value3)
	{
		//echo "Debug:".$value1.$value2;
		require("./config/const.php");
		echo "<?xml version=\"1.0\" encoding=\"UTF-8\"?><Result><Value>";
		$table_name = "content_forum";
		$table = "neues";
		$name = "Neuigkeiten";
		$page = 1;
		$tableid = 1;
		$id = 1;
		$sqlwhere = "";
		//Secure ID if  > 2 loogin if  > 3 admin
		$sid = 3;
		$sid2 = 3;
		$startprocess = false;
		//Boolean ack;default false
		$isReadable = false;
		$isMsgReadable = false;
		$isAdmin = false;
		if ($userData[0]["isAdmin"] == 1)
		{
			$isAdmin = true;
		}
		//Read Table
		if (!empty($value1))
		{
			$value1 = intval($value1);
		}
		//Read ID
		if (!empty($value2))
		{
			$value2 = intval($value2);
		}
		//--------------------------------------------------------------->
		//Default SQL String
		//--------------------------------------------------------------->
		//--------------------------------------------------------------->
		$sql = "SELECT * FROM $table_name WHERE id = $value1 AND sid = 0";
		//If Logged SQL String
		if ($userData["isLoggedIn"])
		{
			$sql = "SELECT * FROM $table_name WHERE id = $value1";
		}
		//echo $sql;
		$tresult = $db->fetch_assoc($sql);
		//Reading table_name from content_forum !!!
		if (isset($tresult[0]["table_name"]))
		{
			$table = $tresult[0]["table_name"];
		}
		if (isset($tresult[0]["name"]))
		{
			$name = $tresult[0]["name"];
		}
		//Reading sid from content_forum !!!
		if (isset($tresult[0]["sid"]))
		{
			$sid = intval($tresult[0]["sid"]);
		}
		if (isset($tresult[0]["pagefile"]))
		{
			$pagefile = intval($tresult[0]["pagefile"]);
		}
		//----------------------------------------------------------------->
		//echo "Debug SID:".$sid;
		//Wenn sid = 0 und nicht eingeloggt !!!
		if (($sid == 0 && !$userData["isLoggedIn"])|| ($sid < 2 && $userData["isLoggedIn"])|| ($sid <= 3 && $userData[0]["isAdmin"] == 1) )
		{
			$isforumReadable = true;
			//echo "Debug:0:".$isforumReadable;
		}
		//Wenn eingeloggt aber nicht 3 !!!
		if( $sid == 0 || ($sid <1 && $userData["isLoggedIn"]) || ($sid <3 && $userData["isLoggedIn"]) || ($userData[0]["isAdmin"] == 1 && $sid <= 3 ) )
		{
			$ack = true;
		}
		//--------------------------------------------------------------->
		//Get all forums
		//--------------------------------------------------------------->
		//--------------------------------------------------------------->
		$fsql = "SELECT * FROM $table WHERE sid = 0";
		//If Logged SQL String
		if ($userData["isLoggedIn"])
		{
			$fsql = "SELECT * FROM $table";
		}
		$eintragsanzahl = $db->mysql_num_rows($fsql);
		$seitenanzahl = ceil($eintragsanzahl / $numofentries);
		//--------------------------------------------------------------->

		//--------------------------------------------------------------->
		//Abfragen ob eine Nachricht gelesen werden darf
		//--------------------------------------------------------------->
		$sql = "SELECT t.*, tb.body FROM $table as t ,".$table."_bodies as tb".
			       " WHERE t.id = (SELECT max(id) FROM $table)".
			       " AND tb.id = t.id".
		$sqlwhere.
			       " ORDER BY t.id LIMIT 0,1";
		$sql2 = "SELECT t.filename,t.message_id FROM ".$table."_attachments as t".
			       " WHERE t.message_id = (SELECT max(id) FROM ".$table."_attachments)".
		$sqlwhere.
			       " ORDER BY t.message_id LIMIT 0,100";
		//echo $sql."<br>".$sql2;
		$result = $db->fetch_assoc($sql);
		if (!isset($result[0]["sid"]))
		{
			$sid2 = intval($result[0]["sid"]);
		}
		//echo "Debug:". $sid2."-".$userData[0]["isAdmin"];
		if($id = 21 || $sid2 == 0 || ($sid <1 && $userData["isLoggedIn"]) || ($sid <=3 && $userData["isLoggedIn"] && $userData[0]["isAdmin"] == 1) )
		{
			$ack =  true;
		}
		//echo "Debug:".$isforumReadable . $ismessageReadable . $sid2;
		if ($ack)
		{
			//echo "Debug:Readable !!".$sql;
			$result2 = $db->fetch_assoc($sql2);
			$i = 0;
			//print_r($result);
			echo "<Title>".$name."</Title>\n";
			//$eintragsanzahl
			echo "<NumofPages>".$seitenanzahl."</NumofPages>\n";
			echo "<NumofEntries>".$eintragsanzahl."</NumofEntries>\n";
			//echo "<FSQL>".$fsql."</FSQL>\n";
			echo "<Entry>".$value2."</Entry>\n";
			echo "<PageFile>".$pagefile."</PageFile>\n";
			//echo "<ID>".$eintragsanzahl."</ID>\n";
			//echo "<SQL>".$sql."</SQL>\n";
			//foreach ($result as $key => $value) {
			foreach ($result as $value) {
				$j = 0;
				echo  "<V".$i.">".
				//"<key>". $key ."</key>".
				"<id>". $value["id"]."</id>".
				//"<subject>".utf8_encode($value["subject"])."</subject>".
				"<subject>".Util::escapeText(utf8_encode($value["subject"]))."</subject>".				
				//"<body>".utf8_encode(Util::escapeText($value["body"]))."</body>\n";
				//"<body>".utf8_encode(Util::escapeText($value["body"]))."</body>\n";
				"<body>".rawurlencode(utf8_encode(Util::escapeText($value["body"])))."</body>\n";
				//"<body>".$value["body"]."</body>\n";
				foreach ($result2 as $filename) {
					echo "<filename".$j.">".Util::escapeText(utf8_encode($filename["filename"]))."</filename".$j.">\n";
					$j++;
				}
				echo "</V".$i.">\n";
				$i++;
			}
		}
		else
		{
			echo "<Title>Error</Title>\n";
			echo "<NumofPages>0</NumofPages>\n";
			echo "<V0>";
			echo "<id>1</id>";
			echo "<subject><h1>Not logged in</h1></subject>";
			echo "<body><h1>Not logged in</h1></body>";
			echo "</V0>";
		}
		echo "</Value></Result>";

	}



	/**
	 *
	 * Enter description here ...
	 * @param $userData
	 * @param $value1
	 * @param $value2
	 * @param $value3
	 */
	public static function getRead($userData, $value1, $value2, $value3)
	{
		//echo $value1.$value2;
		require("./config/const.php");
		echo "<?xml version=\"1.0\" encoding=\"UTF-8\"?><Result><Value>";
		$table_name = "content_forum";
		$table = "neues";
		$name = "Neuigkeiten";
		$page = 1;
		$pagefile = "index.tpl";
		$max = 0;
		$tableid = 1;
		$id = 1;
		$sqlwhere = "";
		//Secure ID if  > 2 loogin if  > 3 admin
		$sid = 3;
		$sid2 = 3;
		$startprocess = false;
		//Boolean ack;default false
		$isReadable = false;
		$isMsgReadable = false;
		$isAdmin = false;
		$isPHPCode = 0;
		if ($userData[0]["isAdmin"] == 1)
		{
			$isAdmin = true;
		}
		//echo $Value1.$Value2.$Value3;
		//Read Table
		if (!empty($value1))
		{
			$value1 = intval($value1);
		}
		//Read ID
		if (!empty($value2))
		{
			$value2 = intval($value2);
		}
		//--------------------------------------------------------------->
		//get current tables !!
		//--------------------------------------------------------------->
		$sql = "SELECT * FROM $table_name WHERE id = $value1 AND sid = 0";
		//If Logged SQL String
		if ($userData["isLoggedIn"])
		{
			$sql = "SELECT * FROM $table_name WHERE id = $value1";
		}
		//echo $sql;
		$tresult = $db->fetch_assoc($sql);
		//Reading table_name from content_forum !!!
		if (isset($tresult[0]["table_name"]))
		{
			$table = $tresult[0]["table_name"];
		}
		if (isset($tresult[0]["name"]))
		{
			$name = $tresult[0]["name"];
		}
		//Reading sid from content_forum !!!
		if (isset($tresult[0]["sid"]))
		{
			$sid = intval($tresult[0]["sid"]);
		}
		//Reading sid from content_forum !!!
		if (isset($tresult[0]["isPHPCode"]))
		{
			$isPHPCode = intval($tresult[0]["isPHPCode"]);
		}
		if (isset($tresult[0]["pagefile"]))
		{
			$pagefile = intval($tresult[0]["pagefile"]);
		}
		//----------------------------------------------------------------->
		//echo "Debug SID:".$sid;
		//Wenn sid = 0 und nicht eingeloggt !!!
		if (($sid == 0 && !$userData["isLoggedIn"])|| ($sid < 2 && $userData["isLoggedIn"])|| ($sid <= 3 && $userData[0]["isAdmin"] == 1) )
		{
			$isforumReadable = true;
			//echo "Debug:0:".$isforumReadable;
		}
		//Wenn eingeloggt aber nicht 3 !!!
		//		if ($sid < 2 && $userData["isLoggedIn"])
		//		{
		//			$isforumReadable = true;
		//			echo "Debug:Readable";
		//		}
		//if ($sid != 3 && $sid > 0 && $userData["isLoggedIn"])
		//echo "Debug:". $sid."-".$userData[0]["isAdmin"];
		//print_r($userData);
		if( $sid == 0 || ($sid <1 && $userData["isLoggedIn"]) || ($sid <3 && $userData["isLoggedIn"]) || ($userData[0]["isAdmin"] == 1 && $sid <= 3 ) )
		{
			$ack = true;
		}
		//--------------------------------------------------------------->
		//--------------------------------------------------------------->
		//Abfragen ob eine Nachricht gelesen werden darf
		$sql = "SELECT * FROM $table";
		$eintragsanzahl = $db->mysql_num_rows($sql);
		$seitenanzahl = ceil($eintragsanzahl / $numofentries);
		//--------------------------------------------------------------->
		$sql = "SELECT (SELECT max(mt.id) from $table as mt) as max,t.*, tb.body FROM $table as t ,".$table."_bodies as tb".
			       " WHERE t.id = $value2".
			       " AND tb.id = t.id".
		$sqlwhere.
			       " ORDER BY t.id LIMIT 0,1";
		$sql2 = "SELECT t.filename,t.message_id FROM ".$table."_attachments as t".
			       " WHERE t.message_id = $value2".
		$sqlwhere.
			       " ORDER BY t.message_id LIMIT 0,100";
		//echo $sql."<br>".$sql2;
		$result = $db->fetch_assoc($sql);
		if (isset($result[0]["sid"]))
		{
			//echo "<Found>Max</Found>";
			$sid2 = intval($result[0]["sid"]);
			$max = intval($result[0]["max"]);
			$pagefile = $result[0]["pagefile"];
		}
		//echo "Debug:". $sid2."-".$userData[0]["isAdmin"];
		if( $sid2 == 0 || ($sid <1 && $userData["isLoggedIn"]) || ($sid <=3 && $userData["isLoggedIn"] && $userData[0]["isAdmin"] == 1) )
		{
			$ack =  true;
		}
		//echo "Debug:".$isforumReadable . $ismessageReadable . $sid2;
		if ($ack)
		{
			//Reading Attachment Links
			//echo "Debug:Readable !!".$sql;
			$result2 = $db->fetch_assoc($sql2);
			$i = 0;
			//print_r($result);
			echo "<Title>".$name."-".$value1."-".$value2."</Title>\n";
			//$eintragsanzahl
			echo "<NumofPages>".$seitenanzahl."</NumofPages>\n";
			echo "<NumofEntries>".$eintragsanzahl."</NumofEntries>\n";
			echo "<Entry>".$value2."</Entry>\n";
			echo "<Max>".$max."</Max>\n";
			echo "<isPHPCode>".$isPHPCode."</isPHPCode>\n";
			echo "<LINK>".$table."</LINK>\n";
			echo "<PageFile>".$pagefile."</PageFile>\n";
			//echo "<ID>".$eintragsanzahl."</ID>\n";
			//echo "<SQL>".$sql."</SQL>\n";
			//foreach ($result as $key => $value) {
			foreach ($result as $value) {
				$j = 0;
				echo  "<V".$i.">".
				//"<key>". $key ."</key>".
				"<id>". $value["id"]."</id>".
				//"<subject>".utf8_encode($value["subject"])."</subject>".
				//"<subject>".rawurlencode(Util::escapeText(utf8_encode($value["subject"])))."</subject>".
				"<subject>".rawurlencode(Util::escapeText($value["subject"]))."</subject>".
				//"<body>".utf8_encode(Util::escapeText($value["body"]))."</body>\n";
				//"<body>".utf8_encode(Util::escapeText($value["body"]))."</body>\n";
				//"<body>".rawurlencode(utf8_encode(Util::escapeText($value["body"])))."</body>\n";
				"<body>".rawurlencode(Util::escapeText($value["body"]))."</body>\n";
				//"<body>".$value["body"]."</body>\n";
				foreach ($result2 as $filename) {
					echo "<filename".$j.">".Util::escapeText(utf8_encode($filename["filename"]))."</filename".$j.">\n";
					$j++;
				}
				echo "</V".$i.">\n";
				$i++;
			}
		}
		else
		{
			echo "<Title>Error</Title>\n";
			echo "<NumofPages>0</NumofPages>\n";
			echo "<V0>";
			echo "<id>1</id>";
			echo "<subject><h1>Not logged in</h1></subject>";
			echo "<body><h1>Not logged in</h1></body>";
			echo "</V0>";
		}
		echo "</Value></Result>";

	}
	/**
	 *
	 * Enter description here ...
	 * @param unknown_type $userData
	 * @param unknown_type $value1
	 */
	public static function getSearch($userData, $value1, $value2)
	{
		require("./config/const.php");
		ini_set('max_execution_time', 300); //240 seconds = 4 minutes
		$sql = "";
		$table_name = "content_forum";
		$tableid = 0;
		$start = 0;
		$query = strtoupper($value1);
		//echo "Debug:".$dbhost. $defaultdb. $dbuser. $dbpassword.$value1;
		if (empty($value1)){$value1 = 0;}
		//echo $value1;
		echo "<?xml version=\"1.0\" encoding=\"UTF-8\"?><Result><Value>";
		if ($userData)
		{
			$sql = "SELECT * FROM $table_name ORDER BY id DESC LIMIT 0,5000";
			//$sql = "SELECT a.id FROM ".$table_name." as a, ".$table_name."_bodies as b ORDER BY a.id DESC";
		}
		else
		{
			$sql = "SELECT * FROM $table_name WHERE sid = 0 ORDER BY id DESC LIMIT 0,500";
			//$sql = "SELECT a.id FROM ".$table_name." as a, ".$table_name."_bodies as b WHERE a.sid = 0 ORDER BY a.id DESC";
		}
		//$db = new mySQL_class($dbhost, $defaultdb, $dbuser, $dbpassword);
		//echo "<sql>".$sql."</sql>\n";
		$eintragsanzahl = $db->mysql_num_rows($sql);
		if ($eintragsanzahl >0)
		{
			$seitenanzahl = ceil($eintragsanzahl / $numofentries);
			$end = ($start - $numofentries);
			//echo "<".$eintragsanzahl.$seitenanzahl;
			if (!empty($value2) && $value2 > 1) {
				//$start = intval(($eintragsanzahl -($value1 * $numofentries))+$numofentries);
				$start = intval($value2 * $numofentries);
				//$start = $eintragsanzahl - $start;
				//$sql = "SELECT * FROM $table_name ORDER BY id DESC LIMIT $start,$numofentries";
				//$start = 0;
			}
			//print_r($forums);
			$lv = 0;
			echo "<Title>Seaching ".$value1."</Title>\n";
			echo "<NumofPages>$seitenanzahl</NumofPages>\n";
			//Fetch all Information from found tables
			$forums = $db->fetch_assoc($sql);
			$i = 0;
			foreach ($forums as $value) {
				if (!empty($value["table_name"]))
				{
					//echo $value;
					$table_name = $value["table_name"];
					if (!empty($value["id"]))
					{
						$tableid = $value["id"];
					}
					$lv++;
					//			$fromstring .= " ".$value["table_name"] ."_bodies as b".$lv.",";
					//			$lv++;
					if ($userData["isLoggedIn"] == 1)
					{
						//$sql = "SELECT * FROM $table_name ORDER BY id ASC LIMIT $start,$numofentries";
						//$sql = "SELECT a.*, b.body FROM ".$table_name." as a, ".$table_name."_bodies as b WHERE a.subject rlike = '%".$value1."%' OR b.body like = '%".$value1."%' ORDER BY a.id DESC GROUP BY a.id LIMIT $start,$numofentries";
						$sql = "SELECT a.* FROM ".$table_name." as a".
						   " WHERE a.sid IS NOT NULL".
						   " AND UPPER(a.subject) like '%".$query."%'".
						//   " OR a.subject like '%".$value1."%'".
						//" b.body like '%".$value1."%'".
						   " GROUP by a.id ORDER BY a.id".
						   " DESC"	 
						//   " DESC  LIMIT $start,$numofentries"
						;
					}
					else
					{
						//echo "Debug";
						$sql = "SELECT a.* FROM ".$table_name." as a".
						   " WHERE a.sid = 0 AND a.sid IS NOT NULL AND".
						   " UPPER(a.subject) like '%".$query."%'".
						//" b.body like '%".$value1."%'".
						   " GROUP by a.id ORDER BY a.id".
						   " DESC" 
						   //" DESC  LIMIT $start,$numofentries"
						;
					}
					//echo "\n<sql>".$sql."</sql>\n";
					$result2 = $db->fetch_assoc($sql);
					//echo "\n<sql2>".$sql."</sql2>\n";
					//$i = 0;
					foreach ($result2 as $key2 => $value2) {
						//echo $key["id"].$value["id"];
						//echo  "<V".$i."><id>". $key ."</id><title>". $value["id"]." </title><V".$i."/>\n";
							
						echo  "<V".$i.">".
					"<id>". $value2["id"]."</id>".
					"<tableid>".rawurlencode(utf8_encode($tableid))."</tableid>".
					"<subject>".rawurlencode(utf8_encode($value2["subject"]))."</subject>".
						//"<sql>". $sql."</sql>".
						//"<sid>". $value2["sid"]."</sid>".
					"</V".$i.">\n";
						$i++;
					}
				}
			}
		}
		echo "</Value></Result>";
		//Next Pages
		//}
	}

	/**
	 *
	 * Index of the Forum
	 * Reads all index names (subject) of database table
	 * @string $Value1
	 */
	public static function getIndex($userData, $value1, $value2)
	{
		require("./config/const.php");
		$sql = "";
		$table_name = "content_forum";
		$start = 0;
		//echo "Debug:".$dbhost. $defaultdb. $dbuser. $dbpassword.$value1;
		if ($value2 > $numofentries && $value2 < 999)
		{
			$numofentries = $value2;
		}
		if (empty($value1)){$value1 = 0;}
		else
		{$value1 = intval($value1);}
		//echo $value1;
		echo "<?xml version=\"1.0\" encoding=\"UTF-8\"?><Result><Value>";
		if ($userData)
		{
			$sql = "SELECT id FROM $table_name ORDER BY id DESC";
		}
		else
		{
			$sql = "SELECT id FROM $table_name WHERE sid = 0 ORDER BY id DESC";
		}
		//$db = new mySQL_class($dbhost, $defaultdb, $dbuser, $dbpassword);
		$eintragsanzahl = $db->mysql_num_rows($sql);
		$seitenanzahl = ceil($eintragsanzahl / $numofentries);
		//echo "<".$eintragsanzahl.$seitenanzahl;
		if (!empty($value1) && $value1 > 1) {
			$start = intval(($eintragsanzahl -($value1 * $numofentries))+$numofentries);
			//$start = intval(($eintragsanzahl -((($value1) * $numofentries))+$numofentries));
			//$start = intval(($eintragsanzahl -($value1+1 * $numofentries))+($numofentries));
			$start = $eintragsanzahl - $start;
			//$sql = "SELECT * FROM $table_name ORDER BY id DESC LIMIT $start,$numofentries";
		}
		$end = ($start + $numofentries);
		//print_r($userData);
		//echo "Debug:".$userData["isLoggedIn"];
		if ($userData["isLoggedIn"] == 1)
		{
			$sql = "SELECT * FROM $table_name ORDER BY id ASC LIMIT $start,$numofentries";
		}
		else
		{
			//echo "Debug";
			$sql = "SELECT * FROM $table_name WHERE sid = 0 ORDER BY id ASC LIMIT $start,$numofentries";
		}
		//echo $sql;
		$result = $db->fetch_assoc($sql);
		$i = 0;
		//print_r($result);
		//print_r( array_keys($result));
		//			echo "<Title>".$result[0]["id"]."</Title>\n";
		echo "<Title>Index</Title>\n";
		echo "<NumofPages>$seitenanzahl</NumofPages>\n";
		echo "<NumofEntries>$numofentries</NumofEntries>\n";
		echo "<Start>$start</Start>\n";
		echo "<End>$end</End>\n";
		//echo "<SQL>$sql</SQL>\n";
		foreach ($result as $key => $value) {
			//echo $key["id"].$value["id"];
			//echo  "<V".$i."><id>". $key ."</id><title>". $value["id"]." </title><V".$i."/>\n";
			echo  "<V".$i.">".
			//"<key>". $key ."</key>".
				"<id>". $value["id"]."</id>".
				"<name>". $value["table_name"]."</name>".
				"<subject>". $value["name"]."</subject>".
				"<sid>". $value["sid"]."</sid>".
				"</V".$i.">\n";
			$i++;
		}
		echo "</Value></Result>";
		//Next Pages
		//}
	}

	/**
	 *
	 * List all Subject of DB Table
	 * @param $Value1
	 * @param $Value2
	 */
	public static function getCalendarList($value1)
	{
		require("./config/const.php");
		$sql = "";
		$table_name = "content_forum";
		$currenttableid = 0;
		$value1 = intval($value1);
		$value2 = intval($value1);
		echo "<?xml version=\"1.0\" encoding=\"UTF-8\"?><Result><Value>";
		//$table_name = "content_forum";
		$table_name = "neues";
		//$table = "neues";
		$sql = "SELECT * FROM $table_name WHERE sid = 0 AND id = 1 ORDER BY id ASC LIMIT 0,1";
		//echo  "<VT>".$value1."<VT>";
		//echo  "<SQL>".$sql."<SQL>";
		$result = $db->fetch_assoc($sql);
		foreach ($result as $key => $value) {
			$currenttableid = $value["id"];
		}
		//echo $currenttableid;
		if (empty($value1)){$value1 =1; }
		$sql = "SELECT * FROM $table_name"
		." WHERE"
		." (datestamp BETWEEN '".date("Y-m-d", $value1)." 00:00:00' AND '".date("Y-m-d", $value1)." 23:59:59' )"
		." ORDER BY id DESC LIMIT 0,30";
		//		echo $sql;
		//$tresult = $db->fetch_assoc($sql);
		$result = $db->fetch_assoc($sql);
		$i = 0;
		//print_r($result);
		//echo "<Title>".$result[0]["id"]."</Title>\n";
		echo "<Title>Day ".date("Y-m-d",$value1)."</Title>\n";
		//echo "<NumofPages>$seitenanzahl</NumofPages>\n";
		//foreach ($result as $key => $value) {
		foreach ($result as $value) {
			//echo $key["id"].$value["id"];
			//echo  "<V".$i."><id>". $key ."</id><title>". $value["id"]." </title><V".$i."/>\n";
			echo  "<V".$i.">".
			//"<key>". $key ."</key>".
				"<id>". $value["id"]."</id>".
				"<tableid>". $currenttableid."</tableid>".
			//"<key>". $value["id"]."</key>".
				"<subject>".Util::escapeText(utf8_encode($value["subject"]))."</subject>".				
			//"<body>".Util::escapeText(utf8_encode($value["body"]))."</body>".
				"</V".$i.">\n";
			$i++;
		}


		//}
		echo "</Value></Result>";
	}


	/**
	 *
	 * List all Subject of DB Table
	 * @param array() $userData
	 * @param string $value1
	 * @param string $value2
	 * @param string $value3
	 */
	public static function getList($userData, $value1, $value2, $value3)
	{
		//echo $value1.$value2.$value3;
		require("./config/const.php");
		$sql = "";
		$table_name = "content_forum";
		$table = "neues";
		$isPHPCode = 0;
		//value1
		$value1 = intval($value1);
		//value2
		if (empty($value2))
		{
			$value2 = 1;
		}
		else
		{
			$value2 = intval($value2);
		}
		//value3
		if (!empty($value3) && intval($value3))
		{
			$numofentries = $value3;
		}
		//XML
		echo "<?xml version=\"1.0\" encoding=\"UTF-8\"?><Result><Value>";
			
		if ($value3 > $numofentries && $value3 < 999)
		{
			$numofentries = $value3;
		}

		$name = "Neuigkeiten";
		if (empty($value1)){$value1 =1; }
		if (!empty($value2))
		{
			$sql = "SELECT * FROM $table_name WHERE id = $value1";
		}else
		{
			$sql = "SELECT * FROM $table_name WHERE id = $value1 AND sid = 0";
		}
		//echo "<SQL>".$sql."</SQL>\n";
		$tresult = $db->fetch_assoc($sql);
		//print_r($tresult);
		if (!empty($tresult[0]["table_name"]))
		{
			$table = $tresult[0]["table_name"];
		}
		if (!empty($tresult[0]["name"]))
		{
			$name = $tresult[0]["name"];
		}
		if (!empty($tresult[0]["PHP"]))
		{
			$isPHPCode = $tresult[0]["PHP"];
		}
		//echo $table;
		$sql = "SELECT id FROM $table";
		//echo $sql;
		//		//$db = new mySQL_class($dbhost, $defaultdb, $dbuser, $dbpassword);
		$eintragsanzahl = $db->mysql_num_rows($sql);
		$seitenanzahl = ceil($eintragsanzahl / $numofentries);
		//$start = intval($eintragsanzahl -($value2 * $numofentries));
		$start = intval(($value2 * $numofentries)-$numofentries);

		$end = ($start - $numofentries);
		//echo "Debug:".$start."-".$end;
		if (!empty($value2))
		{
			$numofentries = intval($numofentries);
		}
		//$userData["isLoggedIn"]
		if ($value2 == 1) {
			//$start = 0;
			$sql = "SELECT *, UNIX_TIMESTAMP(datestamp) as date FROM $table ORDER BY id DESC LIMIT 0,$numofentries";
		}
		if ($value2 != "" && $value2 != 1 && $value2 > 1) {
			$sql = "SELECT *, UNIX_TIMESTAMP(datestamp) as date FROM $table ORDER BY id DESC LIMIT $start,$numofentries";
		}
		if (!empty($sql))
		{
			//echo "<SQL2>".$sql."</SQL2>\n";
			$result = $db->fetch_assoc($sql);
			$i = 0;
			//print_r($result);
			//echo "<Title>".$result[0]["id"]."</Title>\n";
			//echo "<Title>".$name."-".$value1."-".$start."</Title>\n";
			echo "<Title>".$name."</Title>\n";
			echo "<NumofPages>".$seitenanzahl."</NumofPages>\n";
			echo "<NumofEntries>".$eintragsanzahl."</NumofEntries>\n";
			echo "<Entry>".$value2."</Entry>\n";
			echo "<isPHPCode>".$isPHPCode."</isPHPCode>\n";
			echo "<LINK>".$table."</LINK>\n";
			//foreach ($result as $key => $value) {
			foreach ($result as $value) {
				//echo $key["id"].$value["id"];
				//echo  "<V".$i."><id>". $key ."</id><title>". $value["id"]." </title><V".$i."/>\n";
				echo  "<V".$i.">".
				//"<key>". $key ."</key>".
				"<id>". $value["id"]."</id>".
				"<date>". $value["date"]."</date>".
				//"<key>". $value["id"]."</key>".
				"<subject>".Util::escapeText(utf8_encode($value["subject"]))."</subject>".
				"<name>".$value["name"]."</name>".
				//"<body>".Util::escapeText(utf8_encode($value["body"]))."</body>".
				"</V".$i.">\n";
				$i++;
			}


			//}
			echo "</Value></Result>";
		}
	}

	public static function getFullList($userData, $value1, $value2, $value3)
	{
		require("./config/const.php");
		$sql = "";
		$table_name = "content_forum";
		$start = 0;
		//echo "Debug:".$dbhost. $defaultdb. $dbuser. $dbpassword.$value1;
		if (empty($value1)){$value1 = 0;}
		else
		{$value1 = intval($value1);}
		//echo $value1;
		echo "<?xml version=\"1.0\" encoding=\"UTF-8\"?><Result><Value>";
		if ($userData)
		{
			$sql = "SELECT id FROM $table_name ORDER BY id DESC";
		}
		else
		{
			$sql = "SELECT id FROM $table_name WHERE sid = 0 ORDER BY id DESC";
		}
		//$db = new mySQL_class($dbhost, $defaultdb, $dbuser, $dbpassword);
		$eintragsanzahl = $db->mysql_num_rows($sql);
		$seitenanzahl = ceil($eintragsanzahl / $numofentries);
		$end = ($start - $numofentries);
		//echo "<".$eintragsanzahl.$seitenanzahl;
		if (!empty($value1) && $value1 > 1) {
			//$start = intval(($eintragsanzahl -($value1 * $numofentries))+$numofentries);
			$start = intval($eintragsanzahl -((($value1-1) * $numofentries)));
			$start = $eintragsanzahl - $start;
			//$sql = "SELECT * FROM $table_name ORDER BY id DESC LIMIT $start,$numofentries";
		}
		if ($userData)
		{
			$sql = "SELECT * FROM $table_name ORDER BY id ASC";
		}
		else
		{
			//echo "Debug";
			$sql = "SELECT * FROM $table_name WHERE sid = 0 ORDER BY id ASC";
		}
		//echo $sql;
		$result = $db->fetch_assoc($sql);
		$i = 0;
		//print_r($result);
		//print_r( array_keys($result));
		//			echo "<Title>".$result[0]["id"]."</Title>\n";
		echo "<Title>Index</Title>\n";
		echo "<NumofPages>$seitenanzahl</NumofPages>\n";
		//echo "<SQL>$sql</SQL>\n";
		foreach ($result as $key => $value) {
			//echo $key["id"].$value["id"];
			//echo  "<V".$i."><id>". $key ."</id><title>". $value["id"]." </title><V".$i."/>\n";
			echo  "<V".$i.">".
			//"<key>". $key ."</key>".
				"<id>". $value["id"]."</id>".
				"<name>". $value["table_name"]."</name>".
				"<subject>". $value["name"]."</subject>".
				"<sid>". $value["sid"]."</sid>".
				"</V".$i.">\n";
			$i++;
		}
		echo "</Value></Result>";
		//Next Pages
		//}
	}


	/**
	 *
	 * Enter description here ...
	 */
	public static function CountTables()
	{
		//---------------------------------------------------------------------------------->
		//Filename zusammensetzen !!
		//---------------------------------------------------------------------------------->
		$table_name = "neues";
		//---------------------------------------------------------------------------------->
		$query = "SELECT * FROM $table_name";
		require_once ("./include/mysql-class.php");
		$dbconnect = new mySQL_class($db_server,$db_name, $db_user, $db_passwd);
		$suchmuster = '/_messages/';
		$temptables = mysql_list_tables( $db_name);
		$tables = array();
		$j = 1;
		while($data = mysql_fetch_array ($temptables,MYSQL_BOTH))
		{
			//echo !preg_match($suchmuster, $data[0]);
			if (preg_match($suchmuster, $data[0])==0){
				$j++;
				array_push ($tables,$data[0]);
			}
		}
		$all = count($tables);
		echo "<Result><Value>".$all."</Value></Result>";
	}
	/**
	 *
	 * Enter description here ...
	 * @param unknown_type $userData
	 * @param unknown_type $value1
	 * @param unknown_type $value2
	 */
	public static function getCacheDate($userData, $value1,$value2)
	{
		require("./config/const.php");
		$sql = "";
		$i = 0;
		echo "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n<Result><Value>";
		echo "<Value1>".$value1."</Value1>\n";
		echo "<Value2>".$value2."</Value2>\n";
		//echo "<Result><Value>\n";
		echo "<Title>Linked Days</Title>\n";

		$sql = "SELECT UNIX_TIMESTAMP(DATE_FORMAT(datestamp, '%Y-%m-%d 00:00:00')) as date FROM cache"
		." WHERE"
		." ID = 0";

		//echo $sql;
		$tresult= $db->fetch_assoc($sql);
		if (!empty($tresult))
		{
			foreach ($tresult as $value)
			{
				$str = mktime(0,0,0, date("m", $value["date"]),date("d", $value["date"]),date("Y", $value["date"]));
				//$result[$str] = $str;
				echo "<V".$i.">".$str."</V".$i.">\n";
				$i++;
			}
		}
		echo "</Value></Result>";
	}

	/**
	 *
	 * Enter description here ...
	 * @param unknown_type $userData
	 * @param unknown_type $value1
	 * @param unknown_type $value2
	 */
	public static function getLinkedDays($userData, $value1,$value2)
	{
		require("./config/const.php");
		$sql = "";
		$i = 0;
		echo "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n<Result><Value>";
		echo "<Value1>".$value1."</Value1>\n";
		echo "<Value2>".$value2."</Value2>\n";
		//echo "<Result><Value>\n";
		echo "<Title>Linked Days</Title>\n";

		$sql = "SELECT UNIX_TIMESTAMP(DATE_FORMAT(datestamp, '%Y-%m-%d 00:00:00')) as date FROM neues"
		." WHERE"
		." (datestamp BETWEEN '".date("Y-m-d", $value1)." 00:00:00' AND '".date("Y-m-d", $value2)." 23:59:59' )"
		//	."  datestamp < NOW() OR DATE_ADD(NOW(), INTERVAL 30 HOUR) > NOW()"
		." GROUP by datestamp LIMIT 0,100";//This might be deleted !!!
		//echo $sql;
		$tresult= $db->fetch_assoc($sql);
		if (!empty($tresult))
		{
			foreach ($tresult as $value)
			{
				$str = mktime(0,0,0, date("m", $value["date"]),date("d", $value["date"]),date("Y", $value["date"]));
				$result[$str] = $str;
				echo "<V".$i.">".$str."</V".$i.">\n";
				$i++;
			}
		}
		echo "</Value></Result>";
	}
	/**
	 *
	 * Enter description here ...
	 * @param $u_id
	 */
	public static function isLoggedIn($user, $password)
	{
		require("./config/const.php");
		$result = array();
		$result["loggedin"] = false;
		if (!empty($user) && !empty($user))
		{
			$sql = "SELECT u.*"
			." FROM users as u,"
			." session as s"
			." WHERE u.user = '$user'"
			." AND u.pass = '$password'"
			." AND s.u_id = u.u_id"
			." LIMIT 0,1";//HMm11??
			//echo $sql;
			$result = $db->mysql_num_rows($sql);
			if (!empty($result) && $result == 1)//Grmpf
			{
				$result = $db->fetch_assoc($sql);
				$result["isLoggedIn"] = true;
			}
		}
		//print_r($result);
		return $result;
	}


	public static function isMessageUpdated($userData,$value1,$value2, $subject, $body)
	{
		//echo "Debug:". $value1.$value2.$subject.$body;
		require("./config/const.php");
		if ($userData)
		{

			echo "<?xml version=\"1.0\" encoding=\"UTF-8\"?><Result><Value>";
			$table_name = "content_forum";
			$table = "neues";
			$name = "Neuigkeiten";
			$page = 1;
			$tableid = 1;
			$id = 1;
			$sqlwhere = "";
			//Secure ID if  > 2 loogin if  > 3 admin
			$sid = 3;
			$startprocess = false;
			//Boolean ack;default false
			$isforumReadable = false;
			$ismessageReadable = false;
			//echo $Value1.$Value2.$Value3;
			//Read Table
			if (!empty($value1))
			{
				$value1 = intval($value1);
			}
			//--------------------------------------------------------------->
			//Default SQL String
			$sql = "SELECT * FROM $table_name WHERE id = $value1 AND sid = 0";
			//If Logged SQL String
			if ($userData)
			{
				$sql = "SELECT * FROM $table_name WHERE id = $value1";
			}
			//echo $sql;
			$tresult = $db->fetch_assoc($sql);
			//echo $sql;
			//Reading table_name from content_forum !!!
			if (isset($tresult[0]["table_name"]))
			{
				$table = $tresult[0]["table_name"];
			}
			if (isset($tresult[0]["name"]))
			{
				$name = $tresult[0]["name"];
			}
			//echo "Debug:".$table_name.$name;
			//Reading sid from content_forum !!!
			if (isset($tresult[0]["sid"]))
			{
				$sid = intval($tresult[0]["sid"]);
			}
			//Wenn sid = 0 und nicht eingeloggt !!!
			if ($sid == 0 && !$userData["isLoggedIn"] == 1)
			{
				$isforumReadable = true;
				//echo "Debug:0:".$isforumReadable;
			}
			//Wenn eingeloggt aber nicht 3 !!!
			if ($sid != 3 && $userData)
			{
				$isforumReadable = true;
			}
			if ($sid != 3 && $sid > 0 && $userData["isLoggedIn"] == 1)
			{
				$ack = true;
			}
			if ($userData["isLoggedIn"] == 1)//Okay, this have to be fixed - s00n !!
			{
				//			$sql = "INSERT INTO `lc`.`".$table."` ( `datestamp`, `thread`, `parent`, `author`, `subject`, `email`, `host`, `email_reply`, `approved`, `msgid`, `modifystamp`, `userid`, `closed`)
				//		VALUES ( NOW(), '0', '0', '', '".$value2."', '', '', 'N', 'N', '', '0', '0', '0')";
				$sql = "UPDATE `".$table."` SET `subject` = '".$subject."' WHERE `".$table."`.`id` = ".$value2.";";
				//echo "<SQL1>".$sql."</SQL1>\n";
				$result = $db->query($sql);
				//$sql = "UPDATE `lc`.`".$table."_bodies` SET `body` = '".Util::escapeText($body)."' WHERE `".$table."_bodies`.`id` = ".$value2.";";
				$sql = "UPDATE `".$table."_bodies` SET `body` = '".$body."' WHERE `".$table."_bodies`.`id` = ".$value2.";";
				//echo "<SQL2>".$sql."</SQL2>\n";
				$result = $db->query($sql);
			}
		}
		echo "<Title>Insert</Title>\n";
		echo "<NumofPages>0</NumofPages>\n";
		echo "<V0>";
		echo "<id>".$value2."</id>";
		//echo "<subject><h1>".Util::escapeText($subject)."</h1></subject>";
		echo "<subject><h1>".$subject."</h1></subject>";
		//echo "<body><h1>".Util::escapeText($body)."</h1></body>";
		echo "<body><h1>".$body."</h1></body>";
		echo "</V0>";
		echo "</Value></Result>";
	}

	/**
	 *
	 * Enter description here ...
	 * @param $u_id
	 */
	public static function isMessageInserted($userData,$value1,$value2, $value3)
	{
		//echo $value1.$value2;
		require("./config/const.php");
		if ($userData)
		{

			echo "<?xml version=\"1.0\" encoding=\"UTF-8\"?><Result><Value>";
			$table_name = "content_forum";
			$table = "neues";
			$name = "Neuigkeiten";
			$page = 1;
			$tableid = 1;
			$id = 1;
			$sqlwhere = "";
			//Secure ID if  > 2 loogin if  > 3 admin
			$sid = 3;
			$startprocess = false;
			//Boolean ack;default false
			$isforumReadable = false;
			$ismessageReadable = false;
			//echo $Value1.$Value2.$Value3;
			//Read Table
			if (!empty($value1))
			{
				$value1 = intval($value1);
			}
			//--------------------------------------------------------------->
			//Default SQL String
			$sql = "SELECT * FROM $table_name WHERE id = $value1 AND sid = 0";
			//If Logged SQL String
			if ($userData)
			{
				$sql = "SELECT * FROM $table_name WHERE id = $value1";
			}
			//echo "<SQL1>".$sql."</SQL1>\n";
			$tresult = $db->fetch_assoc($sql);
			//echo $sql;
			//Reading table_name from content_forum !!!
			if (isset($tresult[0]["table_name"]))
			{
				$table = $tresult[0]["table_name"];
			}
			if (isset($tresult[0]["name"]))
			{
				$name = $tresult[0]["name"];
			}
			//echo "Debug:".$table_name.$name;
			//Reading sid from content_forum !!!
			if (isset($tresult[0]["sid"]))
			{
				$sid = intval($tresult[0]["sid"]);
			}
			//Wenn sid = 0 und nicht eingeloggt !!!
			if ($sid == 0 && !$userData)
			{
				$isforumReadable = true;
				//echo "Debug:0:".$isforumReadable;
			}
			//Wenn eingeloggt aber nicht 3 !!!
			if ($sid != 3 && $userData)
			{
				$isforumReadable = true;
			}
			if ($sid != 3 && $sid > 0 && $userData)
			{
				$ack = true;
			}
			//VALUES ( NOW(), `0`, `0`, ``, `".$value2."`, ``, ``, `N`, `N`, ``, NOW(), `0`, `0`)";
			//$sql = "INSERT INTO `".$table."` ( `datestamp`, `thread`, `parent`, `author`, `subject`, `email`, `host`, `email_reply`, `approved`, `msgid`, `modifystamp`, `userid`, `closed`)
			//VALUES (NULL , '', NOW(), '0', '0', '', '".Util::escapeText($value2)."', '', '', 'N', 'N', '0', '0', '0'
			$sql = "INSERT INTO `".$table."` (
					`id` ,
					`sid` ,
					`datestamp` ,
					`thread` ,
					`parent` ,
					`author` ,
					`subject` ,
					`email` ,
					`host` ,
					`email_reply` ,
					`approved` ,
					`modifystamp` ,
					`userid` ,
					`closed`)
VALUES (NULL , '', NOW(), '0', '0', '', '".$value2."', '', '', 'N', 'N', '0', '0', '0'
);";
			//echo "<Debug>".$sql."</Debug>\n";
			$result = $db->query($sql);
			//$sql = "INSERT INTO `".$table."_bodies` ( `body`, `thread`) VALUES ('".Util::escapeText($value3)."', '0')";
			$sql = "INSERT INTO `".$table."_bodies` ( `body`, `thread`) VALUES ('".$value3."', '0')";
			//echo "<SQL2>".$sql."</SQL2>\n";
			$result = $db->query($sql);
		}
		echo "<Title>Insert</Title>\n";
		echo "<NumofPages>0</NumofPages>\n";
		echo "<V0>";
		echo "<id>".Util::escapeText($value1)."</id>";
		//------------------------------------------>
		//Reading last Database Entry
		$sql = "SELECT max(id) as max FROM $table";
		$tresult = $db->fetch_assoc($sql);
		if (isset($tresult[0]["max"]))
		{
			echo "<max>".Util::escapeText($tresult[0]["max"])."</max>";
		}
		//------------------------------------------>
		//echo "<subject><h1>".Util::escapeText($value2)."</h1></subject>";
		echo "<subject><h1>".$value2."</h1></subject>";
		//echo "<body><h1>".Util::escapeText($value3)."</h1></body>";
		//echo "<body>".$value3."</body>";
		echo "</V0>";

		echo "</Value></Result>";
	}

	public static function isMessageDeleted($userData,$value1,$value2, $value3)
	{
		//echo $value1.$value2;
		require("./config/const.php");
		if ($userData)
		{

			echo "<?xml version=\"1.0\" encoding=\"UTF-8\"?><Result><Value>";
			$table_name = "content_forum";
			$table = "neues";
			$name = "Neuigkeiten";
			$page = 1;
			$tableid = 1;
			$id = 1;
			$sqlwhere = "";
			//Secure ID if  > 2 loogin if  > 3 admin
			$sid = 3;
			$startprocess = false;
			//Boolean ack;default false
			$isforumReadable = false;
			$ismessageReadable = false;
			//echo $Value1.$Value2.$Value3;
			//Read Table
			if (!empty($value1))
			{
				$value1 = intval($value1);
			}
			//--------------------------------------------------------------->
			//Default SQL String
			$sql = "SELECT * FROM $table_name WHERE id = $value1 AND sid = 0";
			//If Logged SQL String
			if ($userData)
			{
				$sql = "SELECT * FROM $table_name WHERE id = $value1";
			}
			//echo "<SQL1>".$sql."</SQL1>\n";
			$tresult = $db->fetch_assoc($sql);
			//echo $sql;
			//Reading table_name from content_forum !!!
			if (isset($tresult[0]["table_name"]))
			{
				$table = $tresult[0]["table_name"];
			}
			if (isset($tresult[0]["name"]))
			{
				$name = $tresult[0]["name"];
			}
			//echo "Debug:".$table_name.$name;
			//Reading sid from content_forum !!!
			if (isset($tresult[0]["sid"]))
			{
				$sid = intval($tresult[0]["sid"]);
			}
			//Wenn sid = 0 und nicht eingeloggt !!!
			if ($sid == 0 && !$userData)
			{
				$isforumReadable = true;
				//echo "Debug:0:".$isforumReadable;
			}
			//Wenn eingeloggt aber nicht 3 !!!
			if ($sid != 3 && $userData)
			{
				$isforumReadable = true;
			}
			if ($sid != 3 && $sid > 0 && $userData)
			{
				$ack = true;
			}
			//VALUES ( NOW(), `0`, `0`, ``, `".$value2."`, ``, ``, `N`, `N`, ``, NOW(), `0`, `0`)";
			//$sql = "INSERT INTO `".$table."` ( `datestamp`, `thread`, `parent`, `author`, `subject`, `email`, `host`, `email_reply`, `approved`, `msgid`, `modifystamp`, `userid`, `closed`)
			//VALUES (NULL , '', NOW(), '0', '0', '', '".Util::escapeText($value2)."', '', '', 'N', 'N', '0', '0', '0'
			$sql = "DELETE FROM `".$table."` WHERE `".$table."`.`id` = ".$value2.";";
			echo "<Debug>".$sql."</Debug>\n";
			$result = $db->query($sql);
			//$sql = "INSERT INTO `".$table."_bodies` ( `body`, `thread`) VALUES ('".Util::escapeText($value3)."', '0')";
			$sql = "DELETE FROM `".$table."_bodies` WHERE `".$table."_bodies`.`id` = ".$value2.";";
			//echo "<SQL2>".$sql."</SQL2>\n";
			$result = $db->query($sql);
		}
		echo "<Title>Insert</Title>\n";
		echo "<NumofPages>0</NumofPages>\n";
		echo "<V0>";
		echo "<id>.Util::escapeText($value2).</id>";
		//echo "<subject><h1>".Util::escapeText($value2)."</h1></subject>";
		echo "<subject><h1>Die Nachricht ".$value2." wurde erfolgreich gel�scht.</h1></subject>";
		//echo "<body><h1>".Util::escapeText($value3)."</h1></body>";
		echo "<body><h1>".$value3."</h1></body>";
		echo "</V0>";

		echo "</Value></Result>";
	}

	public static function getTags($userData, $value1, $value2)
	{
		require("./config/const.php");
		//include "./plugins/tools/lc2searchsite/settings/database.php";
		//include "./plugins/tools/lc2searchsite/settings/conf.php";
		if($_SERVER["SERVER_NAME"] == "localhost")
		{
			$defaultdb = "nc";
		}
		else
		{
			$defaultdb = "db1079780-content";
		}
		
		$db = new mySQL_class($defaultdb, $dbuser, $dbpassword);
		
		$sql = "";
		$table_name = "query_log";
		$start = 0;
		//echo "Debug:".$dbhost. $defaultdb. $dbuser. $dbpassword.$value1;
		if ($value2 > $numofentries && $value2 < 999)
		{
			$numofentries = $value2;
		}
		if (empty($value1)){$value1 = 0;}
		else
		{$value1 = intval($value1);}
		//echo $value1;
		echo "<?xml version=\"1.0\" encoding=\"UTF-8\"?><Result><Value>";

		$sql = "SELECT query AS tag, COUNT(*) AS quantity
FROM query_log
WHERE results > 0
GROUP BY query
ORDER BY query ASC
LIMIT 20";
		
		//$db = new mySQL_class($dbhost, $defaultdb, $dbuser, $dbpassword);
		$eintragsanzahl = $db->mysql_num_rows($sql);
		$seitenanzahl = ceil($eintragsanzahl / $numofentries);
		//echo "<".$eintragsanzahl.$seitenanzahl;
		if (!empty($value1) && $value1 > 1) {
			$start = intval(($eintragsanzahl -($value1 * $numofentries))+$numofentries);
			//$start = intval(($eintragsanzahl -((($value1) * $numofentries))+$numofentries));
			//$start = intval(($eintragsanzahl -($value1+1 * $numofentries))+($numofentries));
			$start = $eintragsanzahl - $start;
			//$sql = "SELECT * FROM $table_name ORDER BY id DESC LIMIT $start,$numofentries";
		}
		$end = ($start + $numofentries);
		$result = $db->fetch_assoc($sql);
		$i = 0;
		//print_r($result);
		//print_r( array_keys($result));
		//			echo "<Title>".$result[0]["id"]."</Title>\n";
		echo "<Title>Index</Title>\n";
		echo "<NumofPages>$seitenanzahl</NumofPages>\n";
		echo "<NumofEntries>$numofentries</NumofEntries>\n";
		echo "<Start>$start</Start>\n";
		echo "<End>$end</End>\n";
		echo "<SQL>$sql</SQL>\n";
		foreach ($result as $key => $value) {
			//echo $key["id"].$value["id"];
			//echo  "<V".$i."><id>". $key ."</id><title>". $value["id"]." </title><V".$i."/>\n";
			echo  "<V".$i.">".
			//"<key>". $key ."</key>".
				"<id>". $i."</id>".
				"<subject>". $value["tag"]."</subject>".
				"<quantity>". $value["quantity"]."</quantity>".
				"</V".$i.">\n";
			$i++;
		}
		echo "</Value></Result>";
		//Next Pages
		//}
	}


}

?>