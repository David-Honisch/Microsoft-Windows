import os
def runPrint(command):
   out = os.system(command)
   return out