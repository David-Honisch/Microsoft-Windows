import tkinter as tk

root= tk.Tk()

canvas1 = tk.Canvas(root, width = 300, height = 300)
canvas1.pack()
lblMain = tk.Label(root, text= 'LC2Navigator v.1.0', fg='green', font=('helvetica', 12, 'bold'))
canvas1.create_window(100, 10, window=lblMain)
def welcomeMessage():  
    label1 = tk.Label(root, text= 'Welcome to LC2Navigator', fg='green', font=('helvetica', 12, 'bold'))
    canvas1.create_window(150, 200, window=label1)
    
button1 = tk.Button(text='Start',command=welcomeMessage, bg='grey',fg='white')
canvas1.create_window(150, 150, window=button1)

root.mainloop()