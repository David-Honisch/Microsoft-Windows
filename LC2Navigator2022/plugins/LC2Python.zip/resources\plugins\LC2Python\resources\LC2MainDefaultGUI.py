import os
import tkinter as tk
import json
class Application(tk.Frame):    
    def __init__(self, master=None):
        super().__init__(master)
        self.master = master
        self.cwd = os.getcwd()
        self.wd = os.path.dirname(os.path.abspath(__file__))
        # self.sep = os.sep
        print(os.path.join(self.wd,'cfg.json'))
        with open(os.path.join(self.wd,'cfg.json')) as f:
            self.cfg = json.load(f)
            print(self.cfg["name"])
            self.master.title(self.cfg["name"])
            canvas1 = tk.Canvas(self, width=400, height=380)
            self.pack()
            self.create_widgets(self.cfg)
            canvas1.pack()

    def create_widgets(self, data):
        self.lblMain = tk.Label(self)
        self.lblMain["text"] = data["welcometo"]+""+data["name"]+"\nproud to present"
        self.lblMain.pack(side="top")

        self.hi_there = tk.Button(self)
        self.hi_there["text"] = data["start"]
        self.hi_there["command"] = self.say_HI
        self.hi_there.pack(side="top")
        self.hi_there.bind("<Enter>", self.turn_red)
        self.hi_there["command"] = self.say_HI

        self.lblOut = tk.Label(self)
        self.lblOut.pack()

        self.quit = tk.Button(self, text="QUIT", fg="red",
                              command=self.master.destroy)
        self.quit.pack(side="bottom")

    def turn_red(self, event):
        event.widget["activeforeground"] = "red"

    def say_HI(self):
        out =  self.cfg["out"]
        print(out)
        self.lblOut["text"] = out



root = tk.Tk()
app = Application(master=root)

app.mainloop()
