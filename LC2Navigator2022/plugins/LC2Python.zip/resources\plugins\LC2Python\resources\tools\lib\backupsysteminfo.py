# will create bios & eeprom backup and XBMCSystemInfo to  /System/Systeminfo/
import xbmc
xbmc.executehttpapi("execbuiltin(backupsysteminfo)")

