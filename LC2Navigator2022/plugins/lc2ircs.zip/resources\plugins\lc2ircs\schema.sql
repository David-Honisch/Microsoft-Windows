select '<p>lc2ircs IMPORT</p>';
drop table IF EXISTS lc2ircs;
drop table IF EXISTS lc2ircstemp;
CREATE TABLE lc2ircs( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE IF NOT EXISTS lc2ircstemp (
 name TEXT,
 --pid DECIMAL(10,5),
 pid TEXT,
 ftype TEXT,
 tpid TEXT,
 mem TEXT
);
.separator ","
.import .\\resources\\plugins\\lc2ircs\\import\\import.csv lc2ircstemp
select 'COUNT:'+count(*) from lc2ircstemp;
INSERT INTO lc2ircs(first_name,name,zipcode, city, description) select name,name, pid,ftype,tpid  from lc2ircstemp;
select 'Process count:';
select 'COUNT:'+count(*) from lc2ircs;
.exit