select '<h4>lc2postgresdocker Plugin SQL Import</h4>';
drop table IF EXISTS lc2postgresdocker;
drop table IF EXISTS lc2postgresdockertemp;
CREATE TABLE lc2postgresdocker ( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
create table IF NOT EXISTS lc2postgresdockertemp ( name TEXT, url TEXT, type TEXT, tpid TEXT, mem TEXT);
-- .separator "\t"
.separator ";"
.import .\\resources\\plugins\\lc2postgresdocker\\import\\import.csv lc2postgresdockertemp
INSERT INTO lc2postgresdocker (first_name,name, url) select name,name,url from lc2postgresdockertemp;
select '<p>lc2postgresdocker count:';
select count(*) from lc2postgresdocker;
select '</p>';
.exit