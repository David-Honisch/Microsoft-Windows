var hostName = "http://localhost:5000";
var pluginName = "PhaserEditor_2D_Downloader";
const pluginInstallDirectories = [
    'resources\\plugins\\PhaserEditor_2D_Downloader\\libs',
    'resources\\plugins\\PhaserEditor_2D_Downloader\\resources',
    'resources\\plugins\\lcwebclient_final',
    'resources\\plugins\\lcwebclient_final\\lcwebclient_final_lib',
    'resources\\plugins\\org.letztechance.domain.web.GrabUrls',
    'resources\\plugins\\org.letztechance.domain.web.GrabUrls\\org.letztechance.domain.web.GrabUrls_lib',

];
const rlibs = [
    'jquery',
    'https',
    'stream',
    'line-reader',
    'fs',
    'request',
    'runtime-npm-install',
    'decompress-zip',
    // 'extract-zip',
    'csv',
    'jszip',
    'sax',
    'xlsx',
    'xlsx-to-json',
    'xlsx-to-json-lc',
    'xml2js',
    'xmlbuilder',
    'xmldom',
    'xml-js',
    'xmljson',
    'xslt-processor'
];

var pluginDownloadUrls = [{
        path: "https://www.letztechance.org/LC2Intro.v.4.0/assets/",
        file: "lclogo.png",
    },
    {
        path: "https://raw.githubusercontent.com/David-Honisch/Microsoft-Windows/master/LC2Navigator2022/plugins/",
        file: "apache-maven.zip",
    },
    {
        path: "https://raw.githubusercontent.com/David-Honisch/Microsoft-Windows/master/LC2Navigator2022/plugins/",
        file: "apache-ant.zip",
    },
    {
        path: "https://raw.githubusercontent.com/David-Honisch/Microsoft-Windows/master/LC2Navigator2022/plugins/",
        file: "LC2JXMLTransform.zip",
    }
    // ,
    // {
    // path: "https://updates.phasereditor2d.com/v3.33.1/",
    // file: "PhaserEditor2D-allInOne-3.33.1-windows.zip",
    // }

];