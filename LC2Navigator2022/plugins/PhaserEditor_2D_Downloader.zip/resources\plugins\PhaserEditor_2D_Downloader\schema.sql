select '<h4>PhaserEditor_2D_Downloader Plugin SQL Import</h4>'; 
drop table IF EXISTS PhaserEditor_2D_Downloader;
drop table IF EXISTS PhaserEditor_2D_Downloadertemp;
CREATE TABLE PhaserEditor_2D_Downloader ( 'person_id' INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, 'created' TIMESTAMP DEFAULT CURRENT_TIMESTAMP NULL, 'modified' TIMESTAMP DEFAULT CURRENT_TIMESTAMP NULL, 'enddate' TIMESTAMP DEFAULT CURRENT_TIMESTAMP NULL, 'name' TEXT NOT NULL, 'first_name' TEXT NULL, 'description' TEXT NULL, 'zipcode' TEXT NULL, 'city' TEXT NULL,	 'street' TEXT NULL,	 'url' TEXT NULL);
create table IF NOT EXISTS PhaserEditor_2D_Downloadertemp ( name varchar(255), menu TEXT, url varchar(255), subtext TEXT);
.separator ';'
.import .\\resources\\plugins\\PhaserEditor_2D_Downloader\\import\\import.csv PhaserEditor_2D_Downloadertemp
INSERT INTO PhaserEditor_2D_Downloader (first_name,name, description,url) select name,name, menu,url  from PhaserEditor_2D_Downloadertemp;
select '<p>PhaserEditor_2D_Downloader count:';
select count(*) from PhaserEditor_2D_Downloader;
select '</p>';
.exit
