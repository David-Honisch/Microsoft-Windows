export const KnownFonts = [
    {
        name: "Font Awesome 5 Free Solid",
        url: "https://raw.githubusercontent.com/FortAwesome/Font-Awesome/master/otfs/Font%20Awesome%205%20Free-Solid-900.otf"
    },
    {
        name: "Font Awesome 5 Free Regular",
        url: "https://raw.githubusercontent.com/FortAwesome/Font-Awesome/master/otfs/Font%20Awesome%205%20Free-Solid-900.otf"
    },
]