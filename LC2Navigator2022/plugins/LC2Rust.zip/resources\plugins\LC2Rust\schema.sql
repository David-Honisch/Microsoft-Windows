select '<h4>LC2Rust Plugin SQL Import</h4>'; 
drop table IF EXISTS LC2Rust;
drop table IF EXISTS LC2Rusttemp;
CREATE TABLE LC2Rust ( 'person_id' INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, 'created' TIMESTAMP DEFAULT CURRENT_TIMESTAMP NULL, 'modified' TIMESTAMP DEFAULT CURRENT_TIMESTAMP NULL, 'enddate' TIMESTAMP DEFAULT CURRENT_TIMESTAMP NULL, 'name' TEXT NOT NULL, 'first_name' TEXT NULL, 'description' TEXT NULL, 'zipcode' TEXT NULL, 'city' TEXT NULL,	 'street' TEXT NULL,	 'url' TEXT NULL);
create table IF NOT EXISTS LC2Rusttemp ( name varchar(255), menu TEXT, url varchar(255), subtext TEXT);
.separator ';'
.import .\\resources\\plugins\\LC2Rust\\import\\import.csv LC2Rusttemp
INSERT INTO LC2Rust (first_name,name, description,url) select name,name, menu,url  from LC2Rusttemp;
select '<p>LC2Rust count:';
select count(*) from LC2Rust;
select '</p>';
.exit
