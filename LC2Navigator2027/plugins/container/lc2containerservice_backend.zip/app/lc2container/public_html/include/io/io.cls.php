<?php
// Direkt Aufruf verhindern....
if (strpos("io.cls.php", $_SERVER['PHP_SELF'])) {
	Header("Location:/index.php");
	die();
}
// class IO 
class IO
{

	public static function printDir($path)
	{
		if ($handle = opendir($path)) {
			echo "<ul class=\"listul\">";
			while (false !== ($entry = readdir($handle))) {
				if ($entry != "." && $entry != "..")
					echo "<li><a href=\"$path/$entry\" target=\"$entry\">$entry\n</a></li>";
			}
			echo "</ul>";
			while ($entry = readdir($handle)) {
				echo "$entry\n";
			}
			closedir($handle);
		}
	}

	public static function readDirToArray($path)
	{
		$result = array();
		$i = 0;
		$ordner = opendir("" . $path);
		while ($datei = readdir($ordner)) {
			if ($datei !== "*" && $datei !== "." && $datei !== "..") {
				// echo $datei;
				$result[$i] = $datei;
			}
			$i++;
		}
		closedir($ordner);
		return $result;
	}
}
