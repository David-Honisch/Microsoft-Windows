<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE html 
     PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
    "DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
<head>
<title>Smarty Calendar Plugin Example</title>
<style type="text/css">
TABLE.calendar {literal}{ margin-left: 20px; }{/literal}
</style>
</head>

<body>

<h1>Smarty Calendar Plugin Example</h1>

{calendar url_format=$url_format
  year=$year month=$month day=$day}

</body>
</html>
