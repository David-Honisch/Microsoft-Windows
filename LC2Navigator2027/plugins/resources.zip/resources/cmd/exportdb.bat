@echo off
SET "LT=^<"
SET "RT=^>"
SETLOCAL
REM set SQLFILE=%1
cls
set "resdir=%cd%\resources\"
set "sexec=%resdir%app\sqlite\sqlite3.exe"
REM set "dbfile=%cd%\release-builds\lc2search-win32-ia32\resources\lc.db"
set "dbfile=%cd%\lc.db"
set "table=importscripts"
SET "QUERY=select * from %table% limit 1000000;"
SET "QUERY2=INSERT INTO %table% (name) values ('Test');"
set "RPATH=https://raw.githubusercontent.com/David-Honisch/Microsoft-Windows/master/LC2Navigator2019/"
call %cd%\resources\cmd\htmlelem.bat h1 IMPORT
@echo off
echo %LT%div class='container-fluid cm-container-white' %RT%
call %cd%\resources\cmd\config.bat h5 UPDATECONFIG
@echo off
set "BR=%LT%hr%RT%"
set LINE==================================
REM set SQLFILE=%1
set IMPORTFILE=%1
echo %LT%hr%RT%
REM echo %SQLFILE%
REM echo %LINE%
echo IMPORTFILE:%IMPORTFILE%
echo %LT%hr%RT%

echo %LT%hr%RT%
echo READING CSV files
echo %LT%hr%RT%

REM sqlite3.exe -csv logsql.sqlite "SELECT local_port AS port, COUNT(local_port) AS hitcount FROM connections  WHERE connection_type = 'accept' GROUP BY local_port ORDER BY hitcount DESC;" > output.csv
REM %sexec% %dbfile% -csv test.sqlite "CREATE TABLE test (name varchar(255) not null, blah varchar(255) not null);" .import ./output.csv test
call %sexec% %dbfile% .schema > schema.sql
type schema.sql
@echo off
call %sexec% %dbfile% .dump > dump.sql
REM type dump.sql
echo %LT%/div%RT%
@echo on