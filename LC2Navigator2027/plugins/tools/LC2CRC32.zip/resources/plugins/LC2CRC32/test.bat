@echo off
SET "LT=^<"
SET "RT=^>"
cls
call %~dp0config.bat
@echo off
set "outFile=%1"
echo %LT%div id="run_cnt"%RT% %LT%h1%RT% %plugin% TEST BASICS %LT%/h1%RT%    %LT%/div%RT%
REM call %cd%\resources\plugins\%plugin%\app\LC2CRC32\LC2CRC32CLI.exe "%cd%\resources\plugins\%plugin%\LC2CRC32CLI.exe" 1f943296 -validate
call %cd%\resources\plugins\%plugin%\app\test %1 %2 %3
echo %LT%h1%RT% %plugin% TEST BASICS DONE %LT%/h1%RT%