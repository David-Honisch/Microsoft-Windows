@echo off
REM docker run -d --name oracle23cxe  container-registry.oracle.com/database/express:21.3.0-xe
call LC2CRC32CLI.exe ".\LC2CRC.exe" close
call LC2CRC32CLI.exe ".\LC2CRC.exe" 1f943296 -validate
REM @echo off
REM timeout 0 > NUL 
@echo on 