@echo off
SET "LT=^<"
SET "RT=^>"
cls
call %~dp0config.bat
@echo off
set "outFile=%1"
echo %LT%div id="run_cnt"%RT% %LT%h1%RT% %plugin% TEST %LT%/h1%RT%    %LT%/div%RT%
call %cd%\resources\plugins\%plugin%\LC2CRC32CLI.exe "%cd%\resources\plugins\%plugin%\LC2CRC32CLI.exe" 1f943296 -validate
REM docker run -d --name oracle23cxe  container-registry.oracle.com/database/express:21.3.0-xe
echo %LT%h1%RT% %plugin% TEST DONE %LT%/h1%RT%