@echo off
%~dp0..\lc2self-extract-go\lc2packer.exe  -source . -output LC2CRC32.resource -entry LC2CRC.exe