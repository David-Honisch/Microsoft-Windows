@echo off
SET "LT=^<"
SET "RT=^>"
cls
call %~dp0config.bat
@echo off
set "outFile=%1"
set "defaultFile=%~dp0csv\default.csv"
set "tabFile=%~dp0csv\tabs.csv"
set "dropdownFile=%~dp0csv\dropdown.csv"
set "helpFile=%~dp0csv\help.csv"
set "importFile=%~dp0csv\%plugin%.csv"
set "sexec=%cd%\resources\app\sqlite\sqlite3.exe"
set "dbfile=%cd%\resources\lc.db"
echo %LT%input id="pluginName" type="hidden" value="%plugin%"/%RT%
REM echo %LT%script%RT%
REM echo var pluginName = "%plugin%";
REM echo %LT%/script%RT%
echo %LT%div class="row" %RT%
REM APP
echo %LT%div class="panel panel-default" %RT%
echo %LT%div class="panel-heading" %RT% %plugin% %LT%/div%RT%
echo %LT%div class="panel-body" %RT%
REM -------------------------------------------
call %~dp0resources\tab-header.bat
for /f "usebackq tokens=1-5 delims=;" %%a in ("%tabFile%") do (
	call %~dp0resources\tabs\%%a
)
call %~dp0resources\dropdown\dropdown.bat
call %~dp0resources\tab-footer.bat
REM -------------------------------------------
echo %LT%div id="myTabContent" class="tab-content"%RT%
REM -------------------------------------------
REM eof app tab
REM echo %LT%h4%RT% App %importFile% %LT%/h4%RT%
for /f "usebackq tokens=1-5 delims=;" %%a in ("%tabFile%") do (
	call %~dp0resources\tab\%%a
)
REM -------------------------------------------
REM echo %LT%/div%RT%
REM type %~dp0resources\html\menu.content.html
echo %LT%/div%RT%

REM echo %LT%hr%RT%
REM echo %LT%div id="appcnt"%RT%%LT%/div%RT%
echo %LT%div id="app_cnt"%RT%%LT%/div%RT%
echo %LT%div id="test_cnt"%RT%%LT%/p%RT% %LT%/div%RT%
echo %LT%div id="appcntprogress" onload="pluginINIT()"%RT%%LT%/div%RT%
REM EOF APP

REM SQL
REM echo %LT%div class="panel panel-default" %RT%
REM echo %LT%div class="panel-heading" %RT% SQL %LT%/div%RT%
REM echo %LT%div class="panel-body" %RT%

REM echo %LT%div id="sql_cnt"%RT%%LT%/div%RT%
REM echo %LT%div id="sql_cntcnt"%RT%%LT%/div%RT%

REM echo %LT%div id="reg_cnt"%RT%%LT%/div%RT%
REM echo %LT%div id="dlg"%RT%%LT%/div%RT%

echo %LT%/div%RT%
echo %LT%/div%RT%
REM EOF DL

echo %LT%/div%RT%
REM type %updateshtml%

type %cd%\resources\html\clearbutton.html
@echo off
echo %LT%script src="../../resources/plugins/%plugin%/config.js"%RT%%LT%/script%RT%
REM echo %LT%script src="../../resources/plugins/%plugin%/index.js"%RT%%LT%/script%RT%
REM echo %LT%script src="./resources/plugins/%plugin%/index.js"%RT%%LT%/script%RT%
REM echo %LT%script src="index.js"%RT%%LT%/script%RT%
REM echo %LT%script%RT%
REM type %~dp0config.js
REM @echo off
REM echo %LT%/script%RT%
REM timeout 0 > NUL 
REM @echo on 