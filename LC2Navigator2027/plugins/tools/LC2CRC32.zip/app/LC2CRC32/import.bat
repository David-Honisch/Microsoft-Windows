@echo off
cls
call "%~dp0\config.bat"
@echo off
set QUERY=%1
set "resdir=%~dp0..\..\..\resources\"
set "sexec=%~dp0..\..\app\sqlite\sqlite3.exe"
set "dbfile=%~dp0..\..\lc.db"
REM call "%sexec%" "%dbfile%" "select name||'<br>' from %QUERY%"
echo call "%sexec%" "%dbfile%" %QUERY%
REM call "%sexec%" "%dbfile%" %QUERY%
call "%sexec%" "%dbfile%" "create table IF NOT EXISTS LC2CRC32temp (name TEXT,url TEXT, description TEXT NULL, zipcode TEXT NULL, first_name TEXT NULL, last_name TEXT NULL, city TEXT NULL, street TEXT NULL);"
call "%sexec%" "%dbfile%" %QUERY%
@echo on