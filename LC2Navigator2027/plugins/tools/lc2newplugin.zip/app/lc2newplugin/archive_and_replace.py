import os
import shutil
import argparse
def archive_directory(source_dir, archive_name):
    # Create a zip file for the directory
    shutil.make_archive(archive_name, 'zip', source_dir)
    print(f"Directory '{source_dir}' archived as '{archive_name}.zip'")
def replace_string_in_files(source_dir, old_string, new_string):
    # Traverse through the directory and its subdirectories
    for root, dirs, files in os.walk(source_dir):
        for name in files:
            file_path = os.path.join(root, name)
            try:
            # Read the file content
                with open(file_path, 'r', encoding='utf-8') as file:
                    content = file.read()
                    # Replace the old string with the new string
                    new_content = content.replace(old_string, new_string)
                    # Write the new content back to the file
                    with open(file_path, 'w', encoding='utf-8') as file:
                        file.write(new_content)
                        print(f"Replaced '{old_string}' with '{new_string}' in file: {file_path}")
            except Exception as e:
                print(f"Error processing file {file_path}: {e}")
                for name in dirs:
                    dir_path = os.path.join(root, name)
                    try:
                        # Replace the old string with the new string in directory names
                        new_dir_path = os.path.join(root, name.replace(old_string, new_string))
                        os.rename(dir_path, new_dir_path)
                        print(f"Renamed directory: {dir_path} to {new_dir_path}")
                    except Exception as e:
                        print(f"Error renaming directory {dir_path}: {e}")
                        
def main():
    print("LC2fileReplaceAndArchiver (c) by David Honisch (2024-06-01)")
    print("This script will archive a directory and optionally replace a string in filenames, folder names, and file contents.")
    parser = argparse.ArgumentParser(description='Archive a directory and optionally replace a string in filenames, folder names, and file contents.')
    parser.add_argument('source_dir', type=str, help='The directory to archive')
    parser.add_argument('--archive_name', type=str, help='The name of the archive file (without extension)', default='archive')
    parser.add_argument('--replace', action='store_true', help='Replace a string in filenames, folder names, and file contents')
    parser.add_argument('--old_string', type=str, help='The string to replace')
    parser.add_argument('--new_string', type=str, help='The new string to replace with')
    args = parser.parse_args()
    if args.replace:
        if not args.old_string or not args.new_string:
            print("Error: --old_string and --new_string must be provided when using --replace")
            return
        replace_string_in_files(args.source_dir, args.old_string, args.new_string)
        archive_directory(args.source_dir, args.archive_name)
        
if __name__ == '__main__':
    main()