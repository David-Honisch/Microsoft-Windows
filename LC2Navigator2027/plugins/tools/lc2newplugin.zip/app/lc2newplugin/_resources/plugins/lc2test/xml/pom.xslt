<?xml version="1.0" encoding="UTF-8"?>
<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform">
  <xsl:variable name="color" select='"red"' />
  <xsl:template match="/">
    <root>
      <xsl:template match="/">
        <html>
          <body>

            <div class="panel panel-default">
              <div class="panel-heading ">
                <xsl:value-of select="project/groupId" />
              </div>
			  <p class="panel2">
                <xsl:value-of select="project/artifactId" />				
              </p>
			  <p class="panel2">
                <xsl:value-of select="project/name" />
              </p>
			  <div class="panel">
                <xsl:value-of select="project/description" />
              </div>
              <div class="panel-body demo-btn " style="min-height: 252px; ">
                <!-- <h2>
                  <xsl:value-of select="root/title" />
                </h2> -->
                <!-- <center> -->
                <table border="1" style="width:85%;">
                  <tr bgcolor="#9acd32">
                    <th>artifactId</th>
                    <th>groupId</th>
                    <th>Scope</th>
                  </tr>
                  <xsl:for-each select="project/dependencies/dependency">
                    <tr>
                      <td>
                        <xsl:value-of select="artifactId" />
                      </td>
                      <td>
                        <xsl:value-of select="groupId" />
                      </td>
                      <td>

                        <xsl:element name="a">

                          <xsl:value-of select="scope" />
                          <!-- <xsl:attribute name="href">javascript:openBrowser('<xsl:value-of select="url" />');</xsl:attribute> -->
                          <xsl:attribute name="href">
                            <xsl:value-of select="scope" />
                          </xsl:attribute>                          
                        </xsl:element>


                      </td>
                    </tr>
                  </xsl:for-each>
                </table>
				
				<table border="1" style="width:85%;">
                  <tr bgcolor="#9acd32">
                    <th>Plugin</th>
                    <th>Updated</th>
                    <th>Scope</th>
                  </tr>
                  <xsl:for-each select="project/build/plugins/plugin">
                    <tr>
                      <td>
                        <xsl:value-of select="artifactId" />
                      </td>
                      <td>
                        <xsl:value-of select="groupId" />
                      </td>
                      <td>

                        <xsl:element name="a">

                          <xsl:value-of select="scope" />
                          <!-- <xsl:attribute name="href">javascript:openBrowser('<xsl:value-of select="url" />');</xsl:attribute> -->
                          <xsl:attribute name="href">
                            <xsl:value-of select="scope" />
                          </xsl:attribute>                          
                        </xsl:element>


                      </td>
                    </tr>
                  </xsl:for-each>
                </table>
				
              </div>
            </div>


            <!-- </center> -->
          </body>
        </html>
      </xsl:template>


    </root>
  </xsl:template>
</xsl:stylesheet>   