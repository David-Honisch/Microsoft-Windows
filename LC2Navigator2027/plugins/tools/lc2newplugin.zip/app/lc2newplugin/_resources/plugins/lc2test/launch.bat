@echo off
cd %~dp0
call py build.py %1
REM docker run -d --name oracle23cxe  container-registry.oracle.com/database/express:21.3.0-xe
REM call newPluginCLI.exe ".\LC2CRC.exe" close
REM call newPluginCLI.exe ".\LC2CRC.exe" 1f943296 -validate
REM @echo off
REM timeout 0 > NUL 
@echo on 