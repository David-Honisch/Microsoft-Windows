@echo off
SET "LT=^<"
SET "RT=^>"
REM cls
set plugin=lc2default
set table=%plugin%
set plugintable=%plugin%_data
set plugindatatable=%plugin%_procdata
set "table=%plugin%"
set title=%plugin% Plugin
set version=v.0.1.22
set "defaultFile=%~dp0csv\default.csv"
set "tabFile=%~dp0csv\tabs.csv"
set "dropdownFile=%~dp0csv\dropdown.csv"
set "helpFile=%~dp0csv\help.csv"
REM set "helpFile=%~dp0..\..\csv\help.csv"
set "importFile=%~dp0csv\%plugin%.csv"
set "defaultFile=%~dp0..\..\csv\default.csv"
set "workFile=%~dp0csv\%plugin%work.csv"
set "dataFile=%~dp0csv\%plugin%data.csv"
set "selectFile=%~dp0csv\select.csv"
set "gresdir=%~dp0..\..\..\..\resources\"
set "resdir=%~dp0\resources\"
set "getlink=%gresdir%cmd\link.bat"
set "sexec=%gresdir%app\sqlite\sqlite3.exe"
set "dbfile=%resdir%..\..\..\%plugin%.db"
set "outFile=%1"
set openjs=%LT% script%RT%
set closejs=%LT%/script%RT%
::global startup
set gstartup=C:\ProgramData\Microsoft\Windows\Start Menu\Programs\StartUp
::current user startup
set startup=%USERPROFILE%\AppData\Roaming\Microsoft\Windows\Start Menu\Programs\Startup
