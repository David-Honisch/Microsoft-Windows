select '<hr/><h2>Import lc2default processes</h2>';
select '<p>drop plugin tables</p>';
drop table IF EXISTS lc2default;
drop table IF EXISTS lc2default_main;
drop table IF EXISTS lc2default_install;
drop table IF EXISTS lc2default_help;
drop table IF EXISTS lc2default_data;
drop table IF EXISTS lc2default_info;
drop table IF EXISTS lc2default_work;
drop table IF EXISTS lc2default_procdata;
drop table IF EXISTS lc2defaulttemp;
drop table IF EXISTS lc2default_datatemp;
drop table IF EXISTS lc2default_worktemp;
drop table IF EXISTS lc2default_proc;
drop table IF EXISTS lc2default_tests;
drop table IF EXISTS lc2default_proctemp;
---------------------------------------------------------------
select '<span>Creating tables</span>';
---------------------------------------------------------------
CREATE TABLE lc2default( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,  "url" TEXT NULL);
CREATE TABLE lc2default_main( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE lc2default_install( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE lc2default_help( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE lc2default_data( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE lc2default_info( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE lc2default_work( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
--CREATE TABLE lc2default_proc( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE lc2default_proc( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
---------------------------------------------------------------
CREATE TABLE lc2default_tests( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE lc2default_procdata( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
---------------------------------------------------------------
CREATE TABLE IF NOT EXISTS lc2defaulttemp (
"name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "url" TEXT NULL
);
CREATE TABLE IF NOT EXISTS lc2default_proctemp( "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "url" TEXT NULL);
---------------------------------------------------------------
-- import menu
select '<span>start import to plugin tables</span>';
---------------------------------------------------------------
.separator ";"
--.import .\\resources\\plugins\\lc2default\\import\\import.csv lc2defaulttemp
-- INSERT INTO lc2default(first_name,name,zipcode, city, description) select first_name,name,zipcode, city, description  from lc2defaulttemp;
.import .\\resources\\plugins\\lc2default\\import\\import.csv lc2default
.import .\\resources\\plugins\\lc2default\\import\\main.csv lc2default_main
.import .\\resources\\plugins\\lc2default\\import\\install.csv lc2default_install
.import .\\resources\\plugins\\lc2default\\import\\help.csv lc2default_help
.import .\\resources\\plugins\\lc2default\\import\\info.csv lc2default_info
.import .\\resources\\plugins\\lc2default\\import\\data.csv lc2default_data
.import .\\resources\\plugins\\lc2default\\import\\work.csv lc2default_work
.import .\\resources\\plugins\\lc2default\\import\\proc.csv lc2default_proc
.import .\\resources\\plugins\\lc2default\\import\\tests.csv lc2default_tests
---------------------------------------------------------------
-- import procs
-- select '<span>importing processes</span>';
-------------------------------------------------------------
-- .separator ","
-- .import '.\\resources\\plugins\\lc2default\\import\\proc.csv' lc2default_proctemp
-- .separator ";"
-- INSERT INTO lc2default_proc(first_name,name,zipcode, description,url) select first_name,name,zipcode, description,url  from lc2default_proctemp;
-- select 'lc2default_work count:';
-- select count(*) from lc2default_proc;
-- eof insert work data
-- eof insert work data
---------------------------------------------------------------
-- done
select '<span>import done</span>';
---------------------------------------------------------------
select 'lc2default count:';
select count(*) from lc2default;
select '<p>start data import to plugin tables</p>';
-- delete from lc2default_datatemp;
--
select '<p>lc2default count:';
select count(*) from lc2default;
select 'lc2default_data count:';
select count(*) from lc2default_data;
select 'lc2default_info count:';
select count(*) from lc2default_info;
select 'lc2default_help count:';
select count(*) from lc2default_help;
select 'lc2default_procdata count:';
select count(*) from lc2default_procdata;
select 'lc2default_work count:';
select count(*) from lc2default_work;
select 'lc2default_proc count:';
select count(*) from lc2default_proc;
select 'lc2default_proctemp count:';
select count(*) from lc2default_proctemp;

drop table IF EXISTS lc2defaulttemp;
-- drop table IF EXISTS lc2default_proctemp;
-- select '<p>Import done</p>';
select '<h4>Import lc2default processes done.</h4>';
.exit