select '<hr/><h2>Import lc2self_extract_go processes</h2>';
select '<p>drop plugin tables</p>';
drop table IF EXISTS lc2self_extract_go;
drop table IF EXISTS lc2self_extract_go_main;
drop table IF EXISTS lc2self_extract_go_install;
drop table IF EXISTS lc2self_extract_go_help;
drop table IF EXISTS lc2self_extract_go_data;
drop table IF EXISTS lc2self_extract_go_info;
drop table IF EXISTS lc2self_extract_go_work;
drop table IF EXISTS lc2self_extract_go_procdata;
drop table IF EXISTS lc2self_extract_gotemp;
drop table IF EXISTS lc2self_extract_go_datatemp;
drop table IF EXISTS lc2self_extract_go_worktemp;
drop table IF EXISTS lc2self_extract_go_proc;
drop table IF EXISTS lc2self_extract_go_tests;
drop table IF EXISTS lc2self_extract_go_proctemp;
---------------------------------------------------------------
select '<span>Creating tables</span>';
---------------------------------------------------------------
CREATE TABLE lc2self_extract_go( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,  "url" TEXT NULL);
CREATE TABLE lc2self_extract_go_main( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE lc2self_extract_go_install( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE lc2self_extract_go_help( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE lc2self_extract_go_data( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE lc2self_extract_go_info( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE lc2self_extract_go_work( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
--CREATE TABLE lc2self_extract_go_proc( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE lc2self_extract_go_proc( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
---------------------------------------------------------------
CREATE TABLE lc2self_extract_go_tests( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE lc2self_extract_go_procdata( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
---------------------------------------------------------------
CREATE TABLE IF NOT EXISTS lc2self_extract_gotemp (
"name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "url" TEXT NULL
);
CREATE TABLE IF NOT EXISTS lc2self_extract_go_proctemp( "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "url" TEXT NULL);
---------------------------------------------------------------
-- import menu
select '<span>start import to plugin tables</span>';
---------------------------------------------------------------
.separator ";"
--.import .\\resources\\plugins\\lc2self_extract_go\\import\\import.csv lc2self_extract_gotemp
-- INSERT INTO lc2self_extract_go(first_name,name,zipcode, city, description) select first_name,name,zipcode, city, description  from lc2self_extract_gotemp;
.import .\\resources\\plugins\\lc2self_extract_go\\import\\import.csv lc2self_extract_go
.import .\\resources\\plugins\\lc2self_extract_go\\import\\main.csv lc2self_extract_go_main
.import .\\resources\\plugins\\lc2self_extract_go\\import\\install.csv lc2self_extract_go_install
.import .\\resources\\plugins\\lc2self_extract_go\\import\\help.csv lc2self_extract_go_help
.import .\\resources\\plugins\\lc2self_extract_go\\import\\info.csv lc2self_extract_go_info
.import .\\resources\\plugins\\lc2self_extract_go\\import\\data.csv lc2self_extract_go_data
.import .\\resources\\plugins\\lc2self_extract_go\\import\\work.csv lc2self_extract_go_work
.import .\\resources\\plugins\\lc2self_extract_go\\import\\proc.csv lc2self_extract_go_proc
.import .\\resources\\plugins\\lc2self_extract_go\\import\\tests.csv lc2self_extract_go_tests
---------------------------------------------------------------
-- import procs
-- select '<span>importing processes</span>';
-------------------------------------------------------------
-- .separator ","
-- .import '.\\resources\\plugins\\lc2self_extract_go\\import\\proc.csv' lc2self_extract_go_proctemp
-- .separator ";"
-- INSERT INTO lc2self_extract_go_proc(first_name,name,zipcode, description,url) select first_name,name,zipcode, description,url  from lc2self_extract_go_proctemp;
-- select 'lc2self_extract_go_work count:';
-- select count(*) from lc2self_extract_go_proc;
-- eof insert work data
-- eof insert work data
---------------------------------------------------------------
-- done
select '<span>import done</span>';
---------------------------------------------------------------
select 'lc2self_extract_go count:';
select count(*) from lc2self_extract_go;
select '<p>start data import to plugin tables</p>';
-- delete from lc2self_extract_go_datatemp;
--
select '<p>lc2self_extract_go count:';
select count(*) from lc2self_extract_go;
select 'lc2self_extract_go_data count:';
select count(*) from lc2self_extract_go_data;
select 'lc2self_extract_go_info count:';
select count(*) from lc2self_extract_go_info;
select 'lc2self_extract_go_help count:';
select count(*) from lc2self_extract_go_help;
select 'lc2self_extract_go_procdata count:';
select count(*) from lc2self_extract_go_procdata;
select 'lc2self_extract_go_work count:';
select count(*) from lc2self_extract_go_work;
select 'lc2self_extract_go_proc count:';
select count(*) from lc2self_extract_go_proc;
select 'lc2self_extract_go_proctemp count:';
select count(*) from lc2self_extract_go_proctemp;

drop table IF EXISTS lc2self_extract_gotemp;
-- drop table IF EXISTS lc2self_extract_go_proctemp;
-- select '<p>Import done</p>';
select '<h4>Import lc2self_extract_go processes done.</h4>';
.exit