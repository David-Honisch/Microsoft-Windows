$("#plugin_version").html(pluginVersion);
setTimeout(() => {
    console.log("Plugin:" + pluginName + "");
    evalCMD("resources\\plugins\\" + pluginName + "\\check.bat "+pluginName);
    // evalCMD("resources\\plugins\\" + pluginName + "\\check.bat maven_check_out install", "pout", true, false);
}, 1000);