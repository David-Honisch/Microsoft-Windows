@echo off
echo var divOUT = "%1";
type %~dp0check.js