console.log(pluginName+" CHECK FILES div:" +  divOUT);
var divOUTObj = document.getElementById(divOUT);
divOUTObj.innerHTML = "Checking files for " + pluginName + ":<br/>";
// filePath = "update\\check.bat";
do_checkFiles("../../resources/plugins/"+pluginName+"/install.json", divOUT);
console.log(pluginName+"CHECK FILES DONE.");