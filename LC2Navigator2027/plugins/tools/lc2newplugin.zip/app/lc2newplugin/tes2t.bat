@echo off
call py archive_and_replace.py
echo call py archive_and_replace.py test --archive_name my_test
call py archive_and_replace.py test --archive_name my_test.zip
call py archive_and_replace.py test --archive_name my_testarchive.zip --replace --old_string "test" --new_string "new_text"