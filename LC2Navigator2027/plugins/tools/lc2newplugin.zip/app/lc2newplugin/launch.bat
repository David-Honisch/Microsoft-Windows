@echo off
SET "LT=^<"
SET "RT=^>"
set tempFile=%temp%\lc2newplugin_files.csv
set ren="%~dp0..\app\lc2replaceinfile\lc2replaceinfile.exe"
echo %LT%pre%RT%
echo %LT%h1%RT%Building %1%LT%/h1%RT%
cd %~dp0
echo %LT%/pre%RT%
echo %LT%pre%RT%
rmdir /S /Q %~dp0src
mkdir %~dp0src
echo %LT%/pre%RT%
echo %LT%pre%RT%
REM echo call py unzip.py resources\src.zip src
call py unzip.py %~dp0backup\src.zip %~dp0src
echo renaming...
call move "src\resources\sql\lc2default.zip.sql" "src\resources\sql\%1.zip.sql"
call move "src\resources\plugins\lc2default" "src\resources\plugins\%1"
dir /b /s src\*.*>%tempFile%
for /f "usebackq tokens=1-20 delims=," %%a in ("%tempFile%") do (
 REM echo replacing in %ren% %%a lc2default %1
 %ren% %%a lc2default %1
)
echo %LT%/pre%RT%
echo %LT%pre%RT%
REM timeout 3
REM echo call py build.py %1
call py build.py %~dp0src %1
echo %LT%/pre%RT%
echo %LT%pre%RT%
copy "src\build\%1.zip" "build\%1.zip"
echo %LT%/pre%RT%
echo %LT%pre%RT%
REM type  "src\resources\plugins\%1\config.bat" | findstr "%1"
echo replacing config
type  "src\resources\plugins\%1\config.js" | findstr "%1"
echo replacing schema
type  "src\resources\plugins\%1\schema.sql" | findstr "%1"
echo replacing app xml
type  "src\resources\plugins\%1\xml\app.xml" | findstr "%1"
echo replacing app xslt
type  "src\resources\plugins\%1\xml\app.xslt" | findstr "%1"
echo replacing done.
echo %LT%/pre%RT%