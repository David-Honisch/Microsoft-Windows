@echo off
SET "LT=^<"
SET "RT=^>"
cls
call %~dp0config.bat
@echo off
set "outFile=%1"
echo %LT%div id="run_cnt"%RT% %LT%h1%RT% %plugin% TEST BASICS %LT%/h1%RT%    %LT%/div%RT%
REM call %cd%\resources\plugins\%plugin%\app\lc2tts\lc2ttsCLI.exe "%cd%\resources\plugins\%plugin%\lc2ttsCLI.exe" 1f943296 -validate
call %~dp0\launch.bat lc2test
echo %LT%h1%RT% %plugin% TEST BASICS DONE %LT%/h1%RT%