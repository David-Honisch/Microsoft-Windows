@echo off
SET "LT=^<"
SET "RT=^>"
echo %LT%pre%RT%
echo %LT%h1%RT%Extracting %1%LT%/h1%RT%
cd %~dp0
echo call py unzip.py resources\%1.zip resources\plugins
REM call py unzip.py build\%1.zip ..\..\resources\plugins
call py unzip.py build\%1.zip ..\..\
echo done.