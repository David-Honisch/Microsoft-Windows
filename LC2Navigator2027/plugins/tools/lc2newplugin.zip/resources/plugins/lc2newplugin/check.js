console.log(pluginName+" CHECK FILES div:" +  divOUT);
// filePath = "update\\check.bat";
do_checkFiles("../../resources/plugins/"+pluginName+"/install.json", divOUT);
console.log(pluginName+"CHECK FILES DONE.");