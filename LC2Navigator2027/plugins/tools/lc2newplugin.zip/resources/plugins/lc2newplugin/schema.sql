select '<hr/><h2>Import lc2newplugin processes</h2>';
select '<p>drop plugin tables</p>';
drop table IF EXISTS lc2newplugin;
drop table IF EXISTS lc2newplugin_main;
drop table IF EXISTS lc2newplugin_install;
drop table IF EXISTS lc2newplugin_help;
drop table IF EXISTS lc2newplugin_data;
drop table IF EXISTS lc2newplugin_info;
drop table IF EXISTS lc2newplugin_work;
drop table IF EXISTS lc2newplugin_procdata;
drop table IF EXISTS lc2newplugintemp;
drop table IF EXISTS lc2newplugin_datatemp;
drop table IF EXISTS lc2newplugin_worktemp;
drop table IF EXISTS lc2newplugin_proc;
drop table IF EXISTS lc2newplugin_tests;
drop table IF EXISTS lc2newplugin_proctemp;
---------------------------------------------------------------
select '<span>Creating tables</span>';
---------------------------------------------------------------
CREATE TABLE lc2newplugin( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,  "url" TEXT NULL);
CREATE TABLE lc2newplugin_main( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE lc2newplugin_install( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE lc2newplugin_help( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE lc2newplugin_data( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE lc2newplugin_info( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE lc2newplugin_work( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
--CREATE TABLE lc2newplugin_proc( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE lc2newplugin_proc( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
---------------------------------------------------------------
CREATE TABLE lc2newplugin_tests( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE lc2newplugin_procdata( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
---------------------------------------------------------------
CREATE TABLE IF NOT EXISTS lc2newplugintemp (
"name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "url" TEXT NULL
);
CREATE TABLE IF NOT EXISTS lc2newplugin_proctemp( "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "url" TEXT NULL);
---------------------------------------------------------------
-- import menu
select '<span>start import to plugin tables</span>';
---------------------------------------------------------------
.separator ";"
--.import .\\resources\\plugins\\lc2newplugin\\import\\import.csv lc2newplugintemp
-- INSERT INTO lc2newplugin(first_name,name,zipcode, city, description) select first_name,name,zipcode, city, description  from lc2newplugintemp;
.import .\\resources\\plugins\\lc2newplugin\\import\\import.csv lc2newplugin
.import .\\resources\\plugins\\lc2newplugin\\import\\main.csv lc2newplugin_main
.import .\\resources\\plugins\\lc2newplugin\\import\\install.csv lc2newplugin_install
.import .\\resources\\plugins\\lc2newplugin\\import\\help.csv lc2newplugin_help
.import .\\resources\\plugins\\lc2newplugin\\import\\info.csv lc2newplugin_info
.import .\\resources\\plugins\\lc2newplugin\\import\\data.csv lc2newplugin_data
.import .\\resources\\plugins\\lc2newplugin\\import\\work.csv lc2newplugin_work
.import .\\resources\\plugins\\lc2newplugin\\import\\proc.csv lc2newplugin_proc
.import .\\resources\\plugins\\lc2newplugin\\import\\tests.csv lc2newplugin_tests
---------------------------------------------------------------
-- import procs
-- select '<span>importing processes</span>';
-------------------------------------------------------------
-- .separator ","
-- .import '.\\resources\\plugins\\lc2newplugin\\import\\proc.csv' lc2newplugin_proctemp
-- .separator ";"
-- INSERT INTO lc2newplugin_proc(first_name,name,zipcode, description,url) select first_name,name,zipcode, description,url  from lc2newplugin_proctemp;
-- select 'lc2newplugin_work count:';
-- select count(*) from lc2newplugin_proc;
-- eof insert work data
-- eof insert work data
---------------------------------------------------------------
-- done
select '<span>import done</span>';
---------------------------------------------------------------
select 'lc2newplugin count:';
select count(*) from lc2newplugin;
select '<p>start data import to plugin tables</p>';
-- delete from lc2newplugin_datatemp;
--
select '<p>lc2newplugin count:';
select count(*) from lc2newplugin;
select 'lc2newplugin_data count:';
select count(*) from lc2newplugin_data;
select 'lc2newplugin_info count:';
select count(*) from lc2newplugin_info;
select 'lc2newplugin_help count:';
select count(*) from lc2newplugin_help;
select 'lc2newplugin_procdata count:';
select count(*) from lc2newplugin_procdata;
select 'lc2newplugin_work count:';
select count(*) from lc2newplugin_work;
select 'lc2newplugin_proc count:';
select count(*) from lc2newplugin_proc;
select 'lc2newplugin_proctemp count:';
select count(*) from lc2newplugin_proctemp;

drop table IF EXISTS lc2newplugintemp;
-- drop table IF EXISTS lc2newplugin_proctemp;
-- select '<p>Import done</p>';
select '<h4>Import lc2newplugin processes done.</h4>';
.exit