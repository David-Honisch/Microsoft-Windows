var hostName = "http://localhost:5000";
var pluginName = "LC2ShortCutCLI";
var pluginVersion = 1.01;
var pluginTable = "LC2ShortCutCLI";
var installDirectories = [
    // 'lcwebclient_final_lib',
    // 'org.letztechance.domain.web.GrabUrls',
    // 'org.letztechance.domain.web.GrabUrls\\org.letztechance.domain.web.GrabUrls_lib',
    'resources\\plugins\\lcwebclient_final',
    'resources\\plugins\\lcwebclient_final\\lcwebclient_final_lib',
    'resources\\plugins\\org.letztechance.domain.web.GrabUrls',
    'resources\\plugins\\org.letztechance.domain.web.GrabUrls\\org.letztechance.domain.web.GrabUrls_lib',

];
var corelibs = [
    'jquery',
    'https',
    'stream',
    'line-reader',
    'fs',
    'request',
    'runtime-npm-install',
    'decompress-zip',
    // 'extract-zip',
    'csv',
    'jszip',
    'sax',
    'xlsx',
    'xlsx-to-json',
    'xlsx-to-json-lc',
    'xml2js',
    'xmlbuilder',
    'xmldom',
    'xml-js',
    'xmljson',
    'xml2json'
];

var downloadUrls = [
	{
        path: "https://www.letztechance.org/img.png?width=400&height=400&image=logo.png&text=LC2ShortCutCLI&r=20&g=20&b=20&test=.",
        file: "logo.png"
    }
	// ,
    // {
        // path: "https://raw.githubusercontent.com/David-Honisch/LC2Navigator2024/main/LC2Navigator2024/plugins/build/",
        // file: "apache-maven.zip",
    // },
    // {
        // path: "https://raw.githubusercontent.com/David-Honisch/LC2Navigator2024/main/LC2Navigator2024/plugins/build/",
        // file: "apache-ant.zip",
    // }
];