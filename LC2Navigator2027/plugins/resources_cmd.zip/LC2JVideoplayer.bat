@echo off
REM call git commit -a -m "Updates on https://www.letztechance.org %1"
REM timeout 3
REM call git push
REM LC2Search . --q=lc2process --page=lc2process --arg1=value1 --arg2=value2
REM LC2Search . --q=LC2JSVideoPlayer --page=LC2JSVideoPlayer --q="G:\temp\.temp\tmp\hollybody.mp4" -  -arg1=value1 --arg2=value2
LC2Search . --q=LC2JSVideoPlayer --page=LC2JSVideoPlayer --query="G:\temp\.temp\tmp\hollybody.mp4" --arg1="G:\temp\.temp\tmp\hollybody.mp4"

timeout 3