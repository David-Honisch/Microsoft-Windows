@echo off
call %~dp0resources\cmd\config.bat
@echo off
SET "LT=^<"
SET "RT=^>"
SET tabFile=%~dp0resources\cmd\tabs.csv
SET serverFile=%~dp0resources\cmd\servers.csv
REM cls
call %cd%\resources\cmd\register.config.bat
call %~dp0resources\cmd\tab-header.bat
for /f "usebackq tokens=1-5 delims=;" %%a in ("%tabFile%") do (
	call %~dp0resources\cmd\tabs\%%a
)
call %~dp0resources\cmd\dropdown\dropdown.bat
call %~dp0resources\cmd\tab-footer.bat
REM -------------------------------------------
echo %LT%div id="myTabContent" class="tab-content"%RT%
REM -------------------------------------------
for /f "usebackq tokens=1-5 delims=;" %%a in ("%tabFile%") do (
	call %~dp0resources\cmd\tab\%%a
)
echo %LT%div id="menu_cnt" class="container-fluid cm-container-white"%RT%
echo %LT%/div%RT%
REM timeout 0 > NUL
REM @echo on