@echo off
setlocal
call "%~dp0resources\cmd\config.bat"
:: Set the directory and filename to check
set "directory=%~dp0resources\cmd"
set "filename=%1.bat"
:: Check if the file exists in the directory
if exist "%directory%\%filename%" (
echo File found: %filename%
:: Execute the file
call "%directory%\%filename%" %2 %3 %4 %5 %6 %7 %8 %9
) else (
echo File not found: %filename%
)
endlocal