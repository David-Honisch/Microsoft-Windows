@echo off
REM call dism /online /get-features /format:table
REM Get-WindowsOptionalFeature -Online
dism optionalfeatures
timeout 3
@echo on