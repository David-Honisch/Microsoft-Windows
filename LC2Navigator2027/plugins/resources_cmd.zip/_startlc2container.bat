@echo off
SET "LT=^<"
SET "RT=^>"
cd resources\plugins\lc2container
call %~dp0config.bat
@echo off
set "outFile=%1"
call type %~dp0logo.txt
REM echo %LT%div class="panel panel-default" %RT%
REM echo %LT%div class="panel-heading" %RT% %plugin% %LT%/div%RT%
REM echo %LT%div class="panel-body" %RT%
cd %~dp0
IF "podman"=="" ECHO podman is NOT defined
REM set found=
REM set prog=podman.exe
REM for %%i in (%path%) do ( 
	REM if exist %%i\%prog% set found=%%i 
	REM echo "%found%"
REM )	
REM if "%found%"==""

echo init podman docker-compose up
REM if exist podman ( 
REM if exist "podman" ( 
	echo call start podman compose up
	start podman compose up
REM ) else ( 
	REM echo no podman found !!! Please install
REM )
echo init docker docker-compose up
REM if docker ( 
	echo call start docker-compose up
	start docker-compose up
REM ) else ( 
	REM echo no docker-compose found !!! Please install
REM )
echo docker-compose done.
REM echo %LT%/div%RT%
REM echo %LT%/div%RT%
REM EOF DL
REM echo %LT%/div%RT%
exit