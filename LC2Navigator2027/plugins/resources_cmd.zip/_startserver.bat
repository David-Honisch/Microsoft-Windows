@echo off
SET "LT=^<"
SET "RT=^>"
REM call %~dp0config.bat
REM @echo off
set "outFile=%1"
REM call type %~dp0logo.txt
java -jar LC2UIBackend-0.0.1-SNAPSHOT.jar