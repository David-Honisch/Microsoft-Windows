@echo off
echo FOLDERS
echo quit
echo exit
echo Bye