@echo off
"%~dp0app\lc2self-extract-go\lc2packer.exe" %1 %2 %3 %4 %5 %6 %7 %8 %9