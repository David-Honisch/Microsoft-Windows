@echo off
setlocal enabledelayedexpansion
:: Define the output file name
set "outputFile=output.csv"
:: Define the schema
set "schema=name,description,category,employment_type,department,maven_version,team,maven_project,salary,start_date,end_date,contact_email,contact_phone,contact_url,location_id,build_command,download_info"
:: Create the output file and write the schema
echo %schema% > %outputFile%
:: Loop through each file in the current directory
for /f "tokens=*" %%i in ('dir /b /a-d') do (
set "fileName=%%i"
set "description=%%i File Description"
set "category=Other"
set "employment_type=%%iFile Zip Type"
set "department=%%i File Department"
set "maven_version=File %%i Version"
set "team= %%i File Team"
set "maven_project=File %%i Project"
set "salary=€0"
set "start_date=2026-05-15T23:59:59Z"
set "end_date=2026-05-15T23:59:59Z"
set "contact_email=%%i@%%i.net"
set "contact_phone=+49123456789"
set "contact_url=webmaster@letztechance.org"
set "location_id=%%i"
set "build_command=exec.bat %%i"
set "download_info=%%i"
:: Get file size
for /f "tokens=3" %%j in ('dir /b /a-d /o-d "%%i" ^| findstr /i /c:"%%i"') do (
set "fileSize=%%j"
)
:: Get file modification date
for /f "tokens=2" %%k in ('dir /b /a-d /o-d "%%i" ^| findstr /i /c:"%%i"') do (
set "modDate=%%k"
)
:: Get file creation date
for /f "tokens=2" %%l in ('dir /b /a-d /o-d "%%i" ^| findstr /i /c:"%%i"') do (
set "creationDate=%%l"
)
:: Write the data to the output file
echo !fileName!,!description!,!category!,!employment_type!,!department!,!maven_version!,!team!,!maven_project!,!salary!,!start_date!,!end_date!,!contact_email!,!contact_phone!,!contact_url!,!location_id!,!build_command!,!download_info! >> %outputFile%
)
echo Data has been successfully converted and saved to %outputFile%