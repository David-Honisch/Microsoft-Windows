@echo off
set procs=~procs.csv
tasklist | findstr lc2navigator2025.exe > %procs%
for /f "usebackq tokens=1-4 delims= " %%a in ("%procs%") do (	  
 echo - %%a taskkill /F /PID %%b
 taskkill /F /PID %%b
)
