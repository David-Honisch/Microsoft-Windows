@echo off
cls
call "%cd%\resources\cmd\config.bat"
@echo off
set QUERY=%1
set "exec=%cd%\resources\app\sqlite\SQLite3.exe"
set "dbfile=%cd%\resources\lc.db"
set "dbfile2=%cd%\resources\_lc.db"
REM call "%sexec%" "%dbfile%" "select name||'<br>' from %QUERY%"
call "%sexec%" "%dbfile%" .help>sqlite.md
call "%sexec%" "%dbfile%" ".read _dump.sql"
REM call "%sexec%" "%dbfile%" %QUERY%
@echo on