@echo off
cls
call "%~dp0resources\cmd\config.bat"
@echo off
set dbfile=%1
set QUERY=%2
set "exec=%~dp0resources\app\sqlite\SQLite3.exe"
call "%sexec%" %dbfile% %QUERY%
@echo on