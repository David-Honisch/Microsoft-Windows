@echo off
type test.html
call selectdb "select * from application"
call %~dp0lc2sqlite.exe