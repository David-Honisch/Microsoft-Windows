@echo off
SET "LT=^<"
SET "RT=^>"
cls
echo %LT%div class='container-fluid cm-container-white' %RT%
echo %LT%p%RT%LC Help Menu v.0.1 Loader%LT%/p%RT%
type %cd%\resources\html\home.html
type %cd%\resources\html\menutabs.html
echo %LT%/div%RT%
timeout 0 > NUL
@echo on