@echo off
cls
echo  %1 %2 %3 %4 %5 %6 %7 %8  %9
py "resources\python\agents\lc2agent.py" %1 %2 %3 %4 %5 %6 %7 %8  %9