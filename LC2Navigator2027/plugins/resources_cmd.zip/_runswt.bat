@echo off
java -jar target\org.letztechance.domain.swt.app.JarLoader-0.0.1-SNAPSHOT.jar -bean home
timeout 3
@echo on