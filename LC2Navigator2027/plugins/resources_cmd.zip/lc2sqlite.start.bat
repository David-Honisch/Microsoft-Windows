@echo off
call "%~dp0..\..\resources\cmd\config.bat"
@echo off
set all_file=%temp%\lc2alltables.csv
set app_file=%temp%\lc2apps_tables.csv
echo %LT%h1%RT% LC2Sqlite %LT%/h1%RT%
echo %LT%pre%RT%
echo %LT%a href="javascript:open(%app_file%)"%RT%%app_file%%LT%/a%RT%
echo %LT%a href="javascript:open(%all_file%)"%RT%%all_file%%LT%/a%RT%
call selectdb "select * from application limit 100" > %app_file%
for /f "usebackq tokens=1-20 delims=|" %%a in ("%app_file%") do (
	echo %LT%a href="%%g" title="%%e" target="_blank"%RT%%%e%LT%/a%RT%
)
call selectdb "SELECT *  FROM sqlite_schema WHERE type ='table' AND name NOT LIKE 'sqlite_%';" > %all_file%
for /f "usebackq tokens=1-20 delims=|" %%a in ("%all_file%") do (
	echo %LT%a href="%%b" title="%%a %%b" target="_blank"%RT%%%a %%b%LT%/a%RT%
)
echo %LT%/pre%RT%
echo %LT%script%RT%
REM echo alert('test');
echo %LT%/script%RT%