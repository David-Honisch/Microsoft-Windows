@echo off
java -jar .\LC2CLI-0.0.1-SNAPSHOT.jar -bean home
timeout 3
@echo on