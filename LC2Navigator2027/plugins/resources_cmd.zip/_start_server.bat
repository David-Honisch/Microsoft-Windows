@echo off
start "resources\plugins\lc2container\_start_server.bat"