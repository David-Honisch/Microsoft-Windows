@echo off
cd "app\lc2container\"
call "_start_server.bat"