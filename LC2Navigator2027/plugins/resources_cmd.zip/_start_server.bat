@echo off
cd "resources\plugins\lc2container\"
call "_start_server.bat"