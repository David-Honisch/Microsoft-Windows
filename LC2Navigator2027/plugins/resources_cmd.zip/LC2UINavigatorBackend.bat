@echo off
java -jar LC2UINavigatorBackend-0.0.1-SNAPSHOT.jar