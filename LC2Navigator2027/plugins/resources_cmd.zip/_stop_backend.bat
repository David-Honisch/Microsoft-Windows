@echo off
call "app\lc2container\_stop_server.bat"