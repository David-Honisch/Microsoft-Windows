@echo off
call "resources\plugins\lc2container\_stop_server.bat"