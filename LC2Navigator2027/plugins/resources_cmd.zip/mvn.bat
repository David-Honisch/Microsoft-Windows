@echo off
"%~dp0app\apache-maven\bin\mvn.cmd" %1 %2 %3 %4 %5 %6 %7 %8 %9