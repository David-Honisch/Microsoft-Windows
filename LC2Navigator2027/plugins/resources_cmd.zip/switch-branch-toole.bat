@echo off
call environment.bat

git -C "%~dp0webui" fetch

echo Current branch and commit:
git -C "%~dp0webui" rev-parse --abbrev-ref HEAD
git -C "%~dp0webui" describe --tags --long --always

echo.
echo Select branch to switch to or exit:
echo 1. master
echo 2. release_candidate
echo 3. dev
echo 4. Exit scipt (no change)
echo.
echo As of 2025-05-01 webui v1.10.1
echo Nvidai 50 series GPUs should use the dev branch.
echo.
set /p choice=Enter number (1-4) then press Enter: 
echo.

if "%choice%"=="1" (
    git -C "%~dp0webui" switch master
) else if "%choice%"=="2" (
    git -C "%~dp0webui" switch release_candidate
) else if "%choice%"=="3" (
    git -C "%~dp0webui" switch dev
) else if "%choice%"=="4" (
    exit
) else (
    echo Invalid choice.
)

echo.
:done
pause
