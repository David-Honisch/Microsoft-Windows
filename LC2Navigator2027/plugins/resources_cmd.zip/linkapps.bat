@echo off
set outFile=exes.csv
dir /ad>appdirs.csv
dir /b /s *.exe>%outFile%
for /f "usebackq tokens=1-5 delims=;" %%a in ("%outFile%") do (
	echo call %~dp0LC2ShortCutCLI\LC2ShortCutCLI.exe %%~na%%~xa %%a %%~na%%~xa.lnk
	call %~dp0LC2ShortCutCLI\LC2ShortCutCLI.exe %%~na%%~xa %%a .
)