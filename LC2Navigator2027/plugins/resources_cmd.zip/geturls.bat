@echo off
REM start "http://localhost/tools/LC2DeEncrypt/generator.html?pwd=test&url=U2FsdGVkX1/QnFdLmo+jfeBPlAq0J1f/0d2SPCjXA1xqDc/ngoZzBc/TNlHDEj/t
REM start http://localhost/tools/LC2DeEncrypt/index.html?pwd=LetzteChance.Org-Encypt-DeCrypter-Login_v_.1.01a&url=U2FsdGVkX19Dt3rYad8F84jp6y4jqgk6JtUBCAbdivmwOLae5nYPXUX02Yd5xPUoZ2fgHOQa5iHcmx7uK9G3Xg==
start http://localhost/tools/LC2DeEncrypt/index.html?pwd=LetzteChance.Org-Encypt-DeCrypter-Login_v_.1.01a&url=U2FsdGVkX19L7foPt4rcs8u6APW6o2VQBa4yWl1n52BQt/v41wAdQojFmh+KuAly
