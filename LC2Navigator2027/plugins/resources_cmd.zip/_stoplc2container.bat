@echo off
SET "LT=^<"
SET "RT=^>"
cd resources\plugins\lc2container
call %~dp0config.bat
@echo off
set "outFile=%1"
call type %~dp0logo.txt
REM echo %LT%div class="panel panel-default" %RT%
REM echo %LT%div class="panel-heading" %RT% %plugin% %LT%/div%RT%
REM echo %LT%div class="panel-body" %RT%
cd %~dp0
REM call docker compose down
pause
call podman compose down
echo docker-compose down done.

echo call start docker-compose down
call start docker-compose down
REM echo %LT%/div%RT%
REM echo %LT%/div%RT%
REM EOF DL
REM echo %LT%/div%RT%
exit