@echo off
REM call python "app\lc2aiagent\aiagent.py" %1 "Qwen/Qwen3.5-27B" --max_length 400 --num_return_sequences 20
REM call python "resources\python\lc2aiagent\aiagent.py" %1 "Qwen/Qwen3.5-27B" --max_length 400 --num_return_sequences 20
call python "resources\python\lc2aiagent\aiagent.py" %1 "Qwen2.5-Coder-7B-Instruct-q4f32_1-MLC" --max_length 400 --num_return_sequences 20