@echo off
cls
call %cd%\resources\cmd\htmlelem.bat h1 UPDATES
@echo off
REM echo %LT%div class='container-fluid cm-container-white' %RT%
call %cd%\resources\cmd\update.config.bat h1 UPDATES
@echo off
echo %LT%div class='container-fluid cm-container-white' %RT%
call %cd%\resources\cmd\dlandextract.bat %RPATH% %UPDATEFILE% %UPDATEFILE% true autodownload
@echo off
call %cd%\resources\cmd\updatesnofluid.bat %RPATH% %UPDATEFILE%  true autodownload
@echo off
call %cd%\resources\cmd\getlnk.bat menu.bat menu.bat appcnt
@echo off
call %cd%\resources\cmd\getlnk.bat echo. Clear appcnt
@echo off
echo %LT%/div%RT%
@echo on