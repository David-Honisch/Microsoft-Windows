@echo off
set link=%1
@echo off
set title=%2
SET "LT=^<"
SET "RT=^>"
REM set link< call %cd%\resources\cmd\deqoute.bat
REM @echo off
REM set /p link2=<call %cd%\resources\cmd\deqoute.bat %link%
set /p link=<call %cd%\resources\cmd\deqoute.bat "%link%"
echo %LT%input class="btnMenu" type="button" value="%title%" onclick="new HttpRequest().execCMD('%link%', 'cnt')"%RT%%LT%/input%RT%
