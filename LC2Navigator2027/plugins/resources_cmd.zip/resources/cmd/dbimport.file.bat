@echo off
cls
REM echo call "%cd%\resources\cmd\config.bat"
call "%cd%\resources\cmd\config.bat"
@echo off
set "value=%1"
set table=%2
set source=%1
set target=%2
echo ^<h4^>SQL import into %table% running...^</h4^>
echo ^<h4^>import into %table% ^</h4^>
echo %sexec% %dbfile% -csv "create table if not exists %table% ('person_id' INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,'name' TEXT NOT NULL, 'first_name' TEXT NULL, 'description' TEXT NULL, 'zipcode' TEXT NULL, 'city' TEXT NULL, 'street' TEXT NULL, 'url' TEXT NULL UNIQUE);"
call %sexec% %dbfile% -csv "create table if not exists %table% ('person_id' INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,'name' TEXT NOT NULL, 'first_name' TEXT NULL, 'description' TEXT NULL, 'zipcode' TEXT NULL, 'city' TEXT NULL, 'street' TEXT NULL, 'url' TEXT NULL UNIQUE);"
@echo off
REM %sexec% %dbfile% -csv "INSERT INTO files(name,path, mime,content) VALUES('%%~na','%%~da%%~pa','%%~xa',readfile('%%a'));"
call %sexec% %dbfile% -csv "INSERT INTO %table%(name,first_name, description,url) VALUES(REPLACE('%value%','\','\\'),REPLACE('%value%','\','\\'),REPLACE('%value%','\','\\'),readfile('%%a'));"
@echo off
echo ^<h4^>SQL import done...^</h4^>
REM timeout 1 > NUL
@echo on