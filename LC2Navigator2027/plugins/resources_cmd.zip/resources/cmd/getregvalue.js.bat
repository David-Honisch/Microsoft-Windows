@echo off
set key=%1
set val=%2
REM call %~dp0..\config.bat
echo var keytype = document.getElementById('regtype').value;
echo var key = keytype+ document.getElementById('registryinputKey').value;
echo var value = document.getElementById('registryinputValue').value;
echo var regout = document.getElementById('registryout');
echo regout.innerHTML += '^<code^>Key:'+key+' Value:'+value+'^</code^>^<hr^>';
REM echo alert(key);
REM echo execCMD('echo call .\\resources\\cmd\\getregvalue.bat "'+key+'" "'+value+'"', 'regout');
echo execCMD('call .\\resources\\cmd\\getregvalue.bat "'+key+'" "'+value+'"', 'registryresult');
echo regout.innerHTML += 'Key:'+key+' Value:'+value+'done.^<hr^>';