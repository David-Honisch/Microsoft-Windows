@echo off
@ECHO OFF
SetLocal EnableDelayedExpansion
rem set "in=D:\temp\*.*"
set "out=.\dir.csv"
dir /a:d /b > _dir.csv
type nul> %out%
REM for /r %%a in (*) do for /f "tokens=5" %%b in ('dir /q "%%~fxa" ^| findstr "%%~nxa"') do (
REM for /f "tokens=5" %%a in ('dir /a:d /b') do (
for /f "usebackq tokens=1-4 delims=|" %%a in ("_dir.csv") do (
    REM echo "%%~dpa","%%~nxa","%%~za","%%b">> %out%
	echo "%cd%\%%a" >> %out%
	echo "%cd%\%%a"
)
pause
type %out%