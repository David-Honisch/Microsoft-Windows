@echo off
cls
call "%~dp0config.bat"
@echo off
set DB=%1
set QUERY=%2
set "dbfile=%cd%\resources\%1.db"
set "outfile=%cd%\resources\data\showdb-%1-db.csv"
echo %LT%h1%RT% %QUERY% %LT%/h1%RT%
echo ^<fieldset^>
echo ^<button type="button" class="btn btn-default" onclick="if(getConfirmation('Show DB  now?')){window.location = 'list.html?db=%1&table=%1'};"^>Show DB^</button^>
echo ^<br^>
REM echo  ^<legend^>Result:^</legend^>
echo ^<input type="text" id="inputKey" value="quake"/^>^<br^>
REM echo %importFile%
REM echo ^<select id="inputKey2"^>
REM for /f "usebackq tokens=1-5 delims=|" %%a in ("%workFile%") do (
REM echo ^<option value="%%c" ^>%%b^</option^>
REM )
REM echo ^</select^>
echo ^<button type="button" class="btn btn-default" onclick="if(getConfirmation('Start task '+document.getElementById('inputKey').value+' now?')){execCMD('.\\resources\\cmd\\searchdb.bat %DB% '+document.getElementById('inputKey').value+'', 'out')};"^>Query^</button^>
echo ^<div id="showdbresult"^>^</div^>
call "%sexec%" "%dbfile%" "select * from %DB% order by name desc">%outfile%
REM call "%~dp0loadmenupiped.bat" %outfile%
echo %LT%ul class="listul"%RT%
for /f "usebackq tokens=1-8 delims=|" %%a in (%outfile%) do (	
	REM echo %%a %%b %%c %%d %%e %%f %%g %%h
    echo %LT%li%RT%
	echo %LT%input
	set va=%%a
	echo.%va%| FIND /I "exec">Nul && ( 
	echo type="button" value="%%b" class="btn %css% %%d" onclick="if(getConfirmation('Start %%b - %%g now?')){execFile('%%h','showdbresult')};" 
	) || (
	@REM echo.Did not find "pom"
	echo type="button" value="%%b" class="btn %css% %%c" onclick="if(getConfirmation('Start %%b - %%g now?')){%%h};" 
	@REM echo type="button" value="a %%b" class="btn %css% %%d" onclick="%%h" 
	)
	
	REM echo type="button" value="%%b" onclick="%%c" 
	echo /%RT%
	echo %LT%span class="btn-default"%RT%%%b-%%g%LT%/span%RT%
	echo %LT%/li%RT%	
)
echo %LT%/ul%RT%
echo ^</div^>
echo ^</fieldset^>
REM echo call "%sexec%" "%dbfile%" "select name||'<br>' from %QUERY%"
REM call "%sexec%" "%dbfile%" "select name||'<br>'||'<a href=^"'||url||'^">'||name||'<a>' from %DB%" order by name desc
REM echo call "%sexec%" "%dbfile%" "select name||'<br>'||'<a href=^"'||url||'^">'||name||'<a>' from %QUERY%" limit 1000

@echo on