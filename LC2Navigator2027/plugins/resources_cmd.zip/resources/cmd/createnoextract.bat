@echo off
echo.>%NOEXTRACT%
@echo on