@echo off
SET "LT=^<"
SET "RT=^>"
set tempFile=%temp%\~lc2_newplugin_files.csv
REM set "ren=%~dp0..\..\app\lc2replaceinfile\lc2replaceinfile.exe"
REM set "ren=%~dp0..\..\lc2replaceinfile.exe"
set "ren=%~dp0..\..\app\lc2replaceinfile\launch.bat"
set "rentest=%~dp0..\..\app\lc2replaceinfile\test.bat"
echo %LT%pre%RT%
echo %LT%span%RT%CREATING NEW PLUGIN%LT%/span%RT%
echo %LT%h1%RT%%1%LT%/h1%RT%
echo %LT%p%RT%CREATING NEW PLUGIN %1%LT%/p%RT%
REM cd %~dp0
REM echo rmdir /S /Q %~dp0..\..\resources\plugin\src
REM rmdir /S /Q  %~dp0..\..\resources\plugin\src
echo mkdir %~dp0 %~dp0..\..\resources\plugin\src 
mkdir %~dp0 %~dp0..\..\resources\plugin\src 
echo call py  %~dp0..\..\resources\python\unzip.py  %~dp0..\..\resources\plugin\src.zip src
call py resources\python\unzip.py resources\src.zip  %~dp0..\..\resources\plugin\src
echo %LT%/pre%RT%
echo %LT%pre%RT%
echo %LT%p%RT%Renaming %1%LT%/p%RT%
call move "%~dp0..\..\resources\plugin\src\resources\sql\lc2default.zip.sql" " %~dp0..\..\resources\plugin\src\resources\sql\%1.zip.sql"
call move "%~dp0..\..\resources\plugin\src\resources\plugins\lc2default" "%~dp0..\..\resources\plugin\src\resources\plugin\src\resources\plugins\%1"
REM type %tempFile%
echo %LT%/pre%RT%
echo %LT%pre%RT%
echo %LT%span%RT%Renaming %1%LT%/span%RT%
REM cd %~dp0..\..\
REM echo call %rentest%
call %rentest%
echo %LT%/pre%RT%
echo %LT%pre%RT%
REM echo call %ren%
call %ren%
echo call %ren% done
echo %LT%/pre%RT%
echo %LT%pre%RT%
dir /b /s %~dp0..\..\resources\plugin\src\*.*>%tempFile%
for /f "usebackq tokens=1-20 delims=," %%a in ("%tempFile%") do (
 REM echo modifying:%%a lc2default %1
 call %ren% %%a lc2default %1
)
echo %LT%/pre%RT%
echo %LT%pre%RT%
echo %LT%span%RT%BUILDING %1%LT%/span%RT%
REM timeout 3
REM echo call py build.py %1
call py %~dp0..\..\resources\python\build.py %1
echo %LT%/pre%RT%
echo %LT%pre%RT%
REM type  "src\resources\plugins\%1\config.bat" | findstr "%1"
type  "src\resources\plugins\%1\config.js" | findstr "%1"
type  "src\resources\plugins\%1\schema.sql" | findstr "%1"
type  "src\resources\plugins\%1\xml\app.xml" | findstr "%1"
type  "src\resources\plugins\%1\xml\app.xslt" | findstr "%1"
echo %LT%p%RT%Successfully %1 done.%LT%/p%RT%
echo %LT%/pre%RT%