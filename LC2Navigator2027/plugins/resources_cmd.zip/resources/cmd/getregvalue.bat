@echo off
REM setlocal ENABLEEXTENSIONS
set "result="
set KEY_NAME=%1
set VALUE_NAME=%2
set VALUE_TIME=%time%
REM echo Key:%KEY_NAME% Value:%VALUE_NAME%
for /f "tokens=2*" %%a in ('%SYSTEMROOT%\SysWOW64\reg query %KEY_NAME% /v %VALUE_NAME%') do (
    set type=%%a
    set data=%%b
)
set "result=%data%"
echo %result%