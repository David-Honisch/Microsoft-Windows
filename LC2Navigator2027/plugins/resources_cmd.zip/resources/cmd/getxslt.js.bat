@echo off
REM echo var source = ".\\resources\\plugins\\LC2JXMLTransform\\xml\\urls.xml";
REM echo var target = ".\\resources\\plugins\\LC2JXMLTransform\\xml\\urlsext.xslt";
echo var source = "%1";
echo var target = "%2";
echo var outXmlString = getXsltProcess(source, target);
echo console.log(outXmlString);
echo document.getElementById('app_cnt').innerHTML += outXmlString;
call type %~dp0xslt.js
@echo off