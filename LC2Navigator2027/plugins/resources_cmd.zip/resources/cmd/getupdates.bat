@echo off
REM %~dp0
set extracted=%temp%\~extracted.files.csv
set extractedlink=%temp%\~extracted.files.link.csv
cls
call "%cd%\resources\cmd\config.bat"
@echo off
REM BEGIN DOWNLOAD !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
echo %LT%div class="row"%RT%

echo %LT%div class="col-sm-4"%RT%
echo %LT%div class="panel panel-default"%RT%
echo %LT%div class="panel-heading"%RT% Dowload %LT%/div%RT%
echo %LT%div class="panel-body"%RT%
REM echo %LINE%
set RPATH=%1
set UPDATEFILE=%2
set TARGETFILE=%3
set XTARGETFILE=..\\..\\%3
REM set TARGETFILE=%~dp0..\..\%TARGETFILE%
REM echo %LINE%
call %cd%\resources\cmd\getbutton.bat menu.bat Menu
@echo off
echo %LT%h4%RT% CHECKING DOWNLOAD%LT%/h4%RT%
REM echo %LT%p%RT%%RPATH%%UPDATEFILE%%LT%/p%RT%
echo UPDATEFILE=%UPDATEFILE%
echo TARGETFILE=%TARGETFILE%
echo TARGET=%XTARGETFILE%
REM echo %LINE%
if exist "%NODOWNLOAD%" (
	echo %LT%h3%RT%Download NOT accepted%LT%/h3%RT%
) else (
	echo %LT%h3%RT%Download accepted%LT%/h3%RT%
	if exist "%TARGETFILE%" (
		del %TARGETFILE%
		REM @echo off
		echo %LT%h3%RT%Download cleared%LT%/h3%RT%
	)
	REM echo call "%cd%\resources\cmd\dl.bat" %UPDATEFILE% %TARGETFILE%  true autodownload
	REM echo call "%cd%\resources\cmd\dl.bat" %RPATH%%UPDATEFILE% %TARGETFILE%  true autodownload
	call "%cd%\resources\cmd\dl.bat" %RPATH%%UPDATEFILE%-crc.sfv %TARGETFILE%-crc.sfv  true autodownload
	REM @echo off
	call "%cd%\resources\cmd\dl.bat" %RPATH%%UPDATEFILE% %TARGETFILE%  true autodownload
	REM @echo off
	if not ERRORLEVEL 1 (
		REM @echo off
		echo %LT%h5%RT%Oh, the download or auto extraction may be failed %LT%/h5%RT%
		REM @echo off
		REM exit /b 1
	)
	if ERRORLEVEL 1 (
		REM @echo off
		echo %LT%h2%RT%Successfully downloaded and extracted %LT%/h2%RT%
	)
)
echo %LT%/div%RT%
echo %LT%/div%RT%
echo %LT%/div%RT%
REM EOF DOWNLOAD !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
echo %LT%div class="col-sm-4"%RT%
echo %LT%div class="panel panel-default"%RT%
echo %LT%div class="panel-heading"%RT% CRC CHECK %LT%/div%RT%
echo %LT%div class="panel-body"%RT%
call %cd%\resources\plugins\LC2CRC32\LC2CRC32CLI.exe "%cd%\resources\plugins\LC2CRC32\LC2CRC32CLI.exe" fc951ec4 -validate
for /f "skip=1 usebackq tokens=1-7 delims= " %%a in ("%TARGETFILE%-crc.sfv") do (
	REM echo %LT%li class="btn btn-default"%RT%
	echo %LT%a
	echo onclick="if(getConfirmation('See crc checksum %%a now?')){exeCMD('notepad %TARGETFILE%-crc.sfv','menu_cnt')};" 
	echo %RT%
	call %cd%\resources\plugins\LC2CRC32\LC2CRC32CLI.exe "%TARGETFILE%" %%a -validate
	call %cd%\resources\plugins\LC2CRC32\LC2CRC32CLI.exe "%TARGETFILE%" %%a -validate> %TARGETFILE%.validate.sfv
	REM echo %TARGETFILE%.validate.sfv
	if NOT exist "%TARGETFILE%.validate.sfv"  (
		echo %LT%h1 class="btn btn-danger"%RT%IS NOT VALID%LT%/h1%RT%
		echo %LT%h2%RT%Execution will now terminated%LT%/h2%RT%
		del %TARGETFILE%.invalide-crc.sfv
		exit
	) else (
		echo %TARGETFILE%:
		echo %LT%h1 class="btn btn-success"%RT%IS VALID%LT%/h1%RT%
	)
	REM @echo off
	echo %LT%/a%RT% %LT%/br%RT%
)

echo %LT%/div%RT%
echo %LT%/div%RT%
echo %LT%/div%RT%
REM BEGIN EXTRACT
echo %LT%div class="col-sm-4"%RT%
echo %LT%div class="panel panel-default"%RT%
echo %LT%div class="panel-heading"%RT% EXTRACTION %LT%/div%RT%
echo %LT%div class="panel-body"%RT%
REM echo %LINE%
echo %LT%h6%RT% CHECKING EXTRACTION %LT%/h6%RT%
REM echo %LINE%
echo %LT%p%RT% Extraction %TARGETFILE% in progress... %LT%/p%RT%

echo FILE:%XTARGETFILE%!!
if not exist "%XTARGETFILE%" (
	echo %LT%h6%RT%Extraction NOT accepted%LT%/h6%RT%
) else (
    echo %LT%h6%RT%Extraction accepted %LT%/h6%RT%
	REM echo %LT%h5%RT% call %~dp0..\..\extract "%XTARGETFILE%" %LT%/h5%RT
	call "%~dp0..\..\extract" "%XTARGETFILE%" >%extracted%
	@echo off
)
echo %LT%br%RT%%LT%h6%RT%Extraction done.%LT%/h6%RT%

echo %LT%/div%RT%

echo %LT%/div%RT%
echo %LT%/div%RT%

REM SQL !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
echo %LT%div class="col-sm-4"%RT%
echo %LT%div class="panel panel-default"%RT%
echo %LT%div class="panel-heading"%RT% SQL IMPORT %LT%/div%RT%
echo %LT%div class="panel-body"%RT%

call %cd%\resources\cmd\str_replace.bat %extracted% \ \\ > %extractedlink%
@echo off
set /p REPLACED=< call %cd%\resources\cmd\deqoute.bat < %extractedlink% > nul
@echo off
echo %LT%br%RT%
call %cd%\resources\cmd\getbuttonout.bat %REPLACED% Show
@echo off
REM echo %1 %2 %3 %4 %5 %6 %7 %8 %9
set SQLFILE=%cd%\resources\sql\%TARGETFILE%.sql
echo %LT%h6%RT%Importing SQL File: %LT%/h6%RT%
REM echo %SQLFILE%
echo %LT%h6%RT%Importing data...%LT%/h6%RT%
if exist "%SQLFILE%" (
	echo %LT%h4%RT% %SQLFILE% sql import accepted%LT%/h4%RT%
	call "%sexec%" "%dbfile%" ".read '%SQLFILE%'"
	@echo off
	echo %LT%h2%RT% SQL IMPORT DONE. %LT%/h2%RT%
	
) 
if NOT exist "%SQLFILE%" (
	echo %LT%p%RT% %SQLFILE% sql import NOT accepted%LT%p%RT%	
	echo %LT%h2%RT% SQL IMPORT NOT DONE. PLUGIN NOT IMPORTED %LT%/h2%RT%
)
echo %LT%/div%RT%

echo %LT%/div%RT%
echo %LT%/div%RT%
REM EOF ROW !!!!
echo %LT%/div%RT%
REM call %cd%\resources\cmd\getbutton.bat menu.bat Menu
REM @echo off