@echo off
set "NEW_PATH=%1"
setx PATH "%NEW_PATH%;%PATH%" /M
echo The PATH variable has been updated.
pause