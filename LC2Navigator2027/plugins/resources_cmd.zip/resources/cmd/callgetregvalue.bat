@echo off
echo test
REM echo call %~dp0getregvalue.bat
REM echo call %~dp0getregvalue.bat "%1" "%2"
REM call getregvalue.bat "%1" "%2"
REM @echo off