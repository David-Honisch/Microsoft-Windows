@echo off
SETLOCAL
REM set SQLFILE=%1
cls
set "resdir=%cd%\resources\"
set "sexec=%resdir%app\sqlite\sqlite3.exe"
REM set "dbfile=%cd%\release-builds\lc2search-win32-ia32\resources\lc.db"
set "dbfile=%cd%\lc.db"
set "table=importscripts"
SET "QUERY=select * from %table% limit 1000000;"
SET "QUERY2=INSERT INTO %table% (name) values ('Test');"
set "RPATH=https://raw.githubusercontent.com/David-Honisch/Microsoft-Windows/master/LC2Navigator2019/"
call %cd%\resources\cmd\htmlelem.bat h1 IMPORT
@echo off
echo %LT%div class='container-fluid cm-container-white' %RT%
call %cd%\resources\cmd\update.config.bat h5 UPDATECONFIG
@echo off
set "BR=%LT%hr%RT%"
set LINE==================================
REM set SQLFILE=%1
set IMPORTFILE=%1
echo %LINE%%BR%
REM echo %SQLFILE%
REM echo %LINE%
echo IMPORTFILE:%IMPORTFILE%
echo %LINE%%BR%
REM dir /b /s *.csv > import.csv
REM @ECHO OFF
REM echo %LINE%
REM echo SQLITE IMPORT
REM echo %LINE%
REM echo %sexec% %dbfile% ".read %SQLFILE%"
REM call %sexec% %dbfile% ".read %SQLFILE%"
REM echo %LINE%

echo %LINE%%BR%
echo READING CSV files
echo %LINE%%BR%

REM sqlite3.exe -csv logsql.sqlite "SELECT local_port AS port, COUNT(local_port) AS hitcount FROM connections  WHERE connection_type = 'accept' GROUP BY local_port ORDER BY hitcount DESC;" > output.csv
REM %sexec% %dbfile% -csv test.sqlite "CREATE TABLE test (name varchar(255) not null, blah varchar(255) not null);" .import ./output.csv test
call %sexec% %dbfile% -csv "DROP TABLE files;"
call %sexec% %dbfile% -csv "CREATE TABLE files (name varchar(255) not null, path varchar(255) not null, mime varchar(255) not null, content blob);"
REM timeout 3
echo %BR%%LINE%%BR%
echo Importing files
echo %BR%%LINE%%BR%
for /f "usebackq tokens=1-4 delims=," %%a in ("%IMPORTFILE%") do (
	 echo %LINE%%BR%
      echo %%a %%b %%c %%d 
	  ECHO filedrive=%%~da
	  ECHO filepath=%%~pa
	  ECHO filename=%%~na
	  ECHO fileextension=%%~xa
	  echo %LINE%%BR%
	  REM %sexec% %dbfile% -csv "CREATE TABLE files (name varchar(255) not null, path varchar(255) not null, mime varchar(255) not null, content blob);"
	  %sexec% %dbfile% -csv "INSERT INTO files(name,path, mime,content) VALUES('%%~na','%%~da%%~pa','%%~xa',readfile('%%a'));"

)
REM timeout 3
echo %BR%%LINE%%BR%
echo Importing files done
echo %BR%%LINE%%BR%

echo %BR%%LINE%%BR%
echo call %sexec% %dbfile% -csv "select 'COUNT:'|| count(*) from files;"
echo %BR%%LINE%%BR%
call %sexec% %dbfile% -csv "select 'COUNT:'||count(*) from files;"

echo %LINE%%BR%
echo call %sexec% %dbfile% -csv "select name from files limit 1000;"
echo %LINE%%BR%
call %sexec% %dbfile% -csv "select path||name||mime from files limit 1000;"



REM @echo off
REM echo %LINE%
REM echo %LT%p%RT%IMPORTING %cd%\%UPDATEFILE% DONE %LT%/p%RT%
REM echo %LINE%
REM type %resdir%\html\clearbutton.html
REM type %resdir%\html\execbutton.html EXECUTE
REM call %resdir%\cmd\htmlelem.bat h5 IMPORT_DONE
REM @echo off
REM echo %LINE%
REM echo %LINE%

echo %LT%/div%RT%
@echo on