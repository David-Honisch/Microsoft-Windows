@echo off
SET "LT=^<"
SET "RT=^>"
set "csvFile=%1"
set css=%2
REM echo %LT%p%RT% %importFile% %LT%/p%RT%
echo %LT%ul class="listul"%RT%
for /f "usebackq tokens=1-7 delims=|" %%a in (%csvFile%) do (
	IF NOT "%%b" == "" (
    echo %LT%li%RT%
	echo %LT%input
	REM echo type="button" value="%%b" onclick="execCMD('%%c','app_cnt')" 
	echo type="button" value="%%b" class="btn %css% %%d" onclick="if(getConfirmation('Start %%e now?')){execCMD('start %%c','out')};" 
	REM echo type="button" value="%%b" onclick="%%c" 
	echo /%RT%
	echo %LT%span class="btn-default"%RT% %%e%LT%/span%RT%
	echo %LT%/li%RT%
	) ELSE ( echo %LT%li%RT%%LT%hr%RT%%LT%/li%RT%	)
)
echo %LT%/ul%RT%