@echo off
SET "LT=^<"
SET "RT=^>"
cls
echo %LT%div class='container-fluid cm-container-white' %RT%
echo %LT%p%RT%LC Menu v.0.1 Loader%LT%/p%RT%

del "%cd%\release-builds\lc2search-win32-ia32\resources\lc.db"

echo %LT%/div%RT%
timeout 0 > NUL
@echo on