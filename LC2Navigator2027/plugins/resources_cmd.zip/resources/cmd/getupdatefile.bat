@echo off
REM %~dp0
set extracted=%temp%\~extracted.files.csv
set extractedlink=%temp%\~extracted.files.link.csv
cls
call "%cd%\resources\cmd\config.bat"
@echo off
REM BEGIN DOWNLOAD !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
echo %LT%div class="row"%RT%

echo %LT%div class="col-sm-4"%RT%
echo %LT%div class="panel panel-default"%RT%
echo %LT%div class="panel-heading"%RT% Dowload %LT%/div%RT%
echo %LT%div class="panel-body"%RT%
REM echo %LINE%
set UPDATEFILE=%1
set TARGETFILE=%2
REM echo %LINE%
call %cd%\resources\cmd\getbutton.bat menu.bat Menu
@echo off
echo %LT%h6%RT% CHECKING DOWNLOAD%LT%/h6%RT%
echo %LT%p%RT%%RPATH%%UPDATEFILE%%LT%/p%RT%
echo UPDATEFILE=%UPDATEFILE%
echo TARGETFILE=%TARGETFILE%
REM echo %LINE%
REM if %TARGETFILE% = ".\\resources\\cmd\\getupdates.bat" (
	REM echo overwriting getupdates denied. terminating process...
	REM exit
REM )
if exist "%NODOWNLOAD%" (
	echo %LT%h1%RT%Download NOT accepted%LT%/h1%RT%
) else (
	echo %LT%h1%RT%Download accepted%LT%/h1%RT%
	if exist "%TARGETFILE%" (
		del %TARGETFILE%
	)
	REM echo call "%cd%\resources\cmd\dl.bat" %UPDATEFILE% %TARGETFILE%  true autodownload
	call "%cd%\resources\cmd\dl.bat" %UPDATEFILE% %TARGETFILE%  true autodownload
	@echo off
)
echo %LT%/div%RT%

echo %LT%/div%RT%
echo %LT%/div%RT%


REM EOF DOWNLOAD !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

echo %LT%div class="col-sm-4"%RT%
echo %LT%div class="panel panel-default"%RT%
echo %LT%div class="panel-heading"%RT% EXTRACTION %LT%/div%RT%
echo %LT%div class="panel-body"%RT%
REM echo %LINE%
echo %LT%h6%RT% CHECKING EXTRACTION %LT%/h6%RT%
REM echo %LINE%
echo %LT%p%RT% Extraction %TARGETFILE% in progress... %LT%/p%RT%
echo FILE:%TARGETFILE%
if not exist "%TARGETFILE%" (
	echo %LT%h6%RT%Extraction NOT accepted%LT%/h6%RT%
) else (
    echo %LT%h6%RT%Extraction accepted %LT%/h6%RT%
	echo %LT%h5%RT% call lc2extract "%cd%\%TARGETFILE%" %LT%/h5%RT
	call "%cd%\lc2extract" "%cd%\%TARGETFILE%" >%extracted%
	@echo off
)
echo %LT%br%RT%%LT%h6%RT%Extraction done.%LT%/h6%RT%

echo %LT%/div%RT%

echo %LT%/div%RT%
echo %LT%/div%RT%

REM SQL !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
echo %LT%div class="col-sm-4"%RT%
echo %LT%div class="panel panel-default"%RT%
echo %LT%div class="panel-heading"%RT% SQL IMPORT %LT%/div%RT%
echo %LT%div class="panel-body"%RT%

call %cd%\resources\cmd\str_replace.bat %extracted% \ \\ > %extractedlink%
@echo off
set /p REPLACED=< call %cd%\resources\cmd\deqoute.bat < %extractedlink% > nul
@echo off
echo %LT%br%RT%
call %cd%\resources\cmd\getbuttonout.bat %REPLACED% Show
@echo off
REM echo %1 %2 %3 %4 %5 %6 %7 %8 %9
set SQLFILE=%cd%\resources\sql\%TARGETFILE%.sql
echo %LT%h6%RT%Importing SQL File: %LT%/h6%RT%
echo %SQLFILE%
echo %LT%h6%RT%Importing data...%LT%/h6%RT%
if exist "%SQLFILE%" (
	echo %LT%h4%RT% %SQLFILE% sql import accepted%LT%/h4%RT%
	call "%sexec%" "%dbfile%" ".read '%SQLFILE%'"
	@echo off
	echo %LT%h2%RT% SQL IMPORT DONE. %LT%/h2%RT%
	
) else (
	echo %LT%p%RT% %SQLFILE% sql import NOT accepted%LT%p%RT%	
	echo %LT%h2%RT% SQL IMPORT NOT DONE. PLUGIN NOT IMPORTED %LT%/h2%RT%
)
%LT%/div%RT%

echo %LT%/div%RT%
echo %LT%/div%RT%
REM EOF ROW !!!!
echo %LT%/div%RT%
call %cd%\resources\cmd\getbutton.bat menu.bat Menu

REM echo %LT%div class="row"%RT%
REM echo %LT%div class="col-sm-4"%RT%
REM echo %LT%div class="panel panel-default"%RT%
REM echo %LT%div class="panel-heading"%RT% Dowload %LT%/div%RT%
REM echo %LT%div class="panel-body"%RT% Dowload %LT%/div%RT%

REM echo %LT%/div%RT%
REM echo %LT%/div%RT%
REM echo %LT%/div%RT%

@echo off