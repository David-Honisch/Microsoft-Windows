@echo off
cls
call "%cd%\resources\cmd\config.bat" h1 IMPORT
@echo off
set SQLFILE=%1
echo %LT%h2%RT%LC SQL FILE READER%LT%/h2%RT%
echo call "%sexec%" "%dbfile%" ".read %SQLFILE%"
call "%sexec%" "%dbfile%" ".read %SQLFILE%"
@echo off
@echo on