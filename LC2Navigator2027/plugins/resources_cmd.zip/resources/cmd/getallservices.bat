@echo off
sc query type= service state= all
REM sc qc SecureLine