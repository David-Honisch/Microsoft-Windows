@echo off
REM set SQLFILE=%1
cls
call "%cd%\resources\cmd\config.bat" h1 IMPORT
@echo off
REM echo %LT%div class='container-fluid cm-container-white' %RT%
REM call %cd%\resources\cmd\update.config.bat h5 UPDATECONFIG
REM @echo off
set SQLFILE=%cd%\resources\sql\%1.sql"
echo %LT%h2%RT% INIT SQL IMPORT%LT%/h2%RT%
echo call "%sexec%" "%dbfile%" ".read %SQLFILE%"
call "%sexec%" "%dbfile%" ".read %SQLFILE%"
REM echo %LT%h3%RT% DB Agent: %LT%/h3%RT%
REM echo %LT%p%RT% %sexec% %LT%/p%RT%
REM echo %LT%p%RT% %SQLFILE%%LT%/p%RT%
REM echo %LT%h2%RT% SQL File%LT%/h2%RT%
REM REM echo %LINE%
REM echo call %sexec% %dbfile% "%QUERY%"
REM call %sexec% %dbfile% "%QUERY%"
REM call %sexec% %dbfile% "%QUERY2%"
REM echo %LINE%
REM echo %LT%/div%RT%
echo %LT%h2%RT% IMPORT SQL DONE%LT%/h2%RT%
@echo on