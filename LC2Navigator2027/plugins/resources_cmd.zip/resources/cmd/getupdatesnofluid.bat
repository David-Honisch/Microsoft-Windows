@echo off
cls
call %cd%\resources\\cmd\htmlelem.bat hr
REM echo %LT%div class='container-fluid cm-container-white' %RT%
call %cd%\resources\\cmd\htmlelem.bat h1 GETUPDATES
@echo off
REM echo %LT%div class='container-fluid cm-container-white' %RT%
call %cd%\resources\cmd\update.config.bat h1 GETUPDATES_CONFIG
@echo off
REM set TSQLFILE=%1.sql
@echo off
echo %LINE%
echo %LT%h1%RT%SET CONFIG %LT%/h1%RT%
echo %LINE%
set UPDATEFILE=%1
set XUPDATEFILE=%2
REM set TSQLFILE=.\\resources\\sql\\%UPDATEFILE%.sql
set "TSQLFILE=.\\resources\\sql\\%XUPDATEFILE%.sql"
REM echo %LT%div class='container-fluid cm-container-white' %RT%
echo %UPDATEFILE% %XUPDATEFILE%
DEL %XUPDATEFILE%
call %cd%\resources\cmd\dlandextractnofluid.bat %RPATH%/ %UPDATEFILE% %XUPDATEFILE%  true autodownload
@echo off
REM call %cd%\resources\cmd\updatesnofluid.bat %RPATH%/plugins/ %UPDATEFILE%  true autodownload
echo %LINE%
echo %LT%h1%RT%RUNNING SQL IMPORT %LT%/h1%RT%
echo %LINE%
echo call %cd%\resources\cmd\importsql.bat "%TSQLFILE%"
call %cd%\resources\cmd\importsql.bat "%TSQLFILE%"
@echo off
REM call %cd%\resources\cmd\importsql.bat "%SQLFILE%"
call %cd%\resources\cmd\getlnk.bat menu.bat menu.bat appcnt
@echo off
call %cd%\resources\cmd\getlnk.bat echo. Clear appcnt
@echo off
REM echo %LT%/div%RT%
@echo on