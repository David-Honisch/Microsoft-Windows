@echo off
REM title=call copy "%USERPROFILE%\Downloads\Neues*Gespr*.md"
echo %~dp0x_copy.bat "%USERPROFILE%\Downloads\Neues*Gespr*.md" ".\resources\data\"
%~dp0x_copy.bat "%USERPROFILE%\Downloads\Neues*Gespr*.md" ".\resources\data\"
echo done.