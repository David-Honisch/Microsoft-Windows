if not exist %1  (
	mkdir %1
) else (
	echo %1 exists
)