@echo off
cls
SET "LT=^<"
SET "RT=^>"
SETLOCAL
call %~dp0config.bat
@echo off
echo %LT%div class='container-fluid cm-container-white' %RT%
copy %dbfile% %dbfile%_backup.db
REM echo call %sexec%
call %sexec% %dbfile% .version
call %sexec% %dbfile% -csv .databases
call %sexec% %dbfile% -csv .databases
call %sexec% %dbfile% .schema > %datadir%schema.sql
@echo off
call %sexec% %dbfile% .dump > %datadir%dump.sql
REM show
echo %LT%hr/%RT%
call %~dp0href.bat schema.sql %datadir%schema.sql #menuout
echo %LT%br/%RT%
call %~dp0href.bat dump.sql %datadir%dump.sql #menuout
echo %LT%hr/%RT%
type  %datadir%schema.sql
type  %datadir%dump.sql
echo %LT%/div%RT%
@echo on