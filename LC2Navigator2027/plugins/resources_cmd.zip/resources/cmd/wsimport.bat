@echo off
cls
REM echo call "%cd%\resources\cmd\config.bat"
call "%cd%\resources\cmd\config.bat"
@echo off
set "value=%1"
set source=%1
set table=%2
set tableId=%3
set jarGrabUrl=%~dp0..\plugins\org.letztechance.domain.web.GrabUrls/org.letztechance.domain.web.GrabUrls.jar
set jarWebClient=%~dp0..\plugins\lcwebclient_final/lcwebclient_final.jar
set outFile=%temp%\urls.csv
set logFile=%temp%\urls.log.csv
echo ^<h4^>SQL import into running...^</h4^>
echo ^<h4^>import into %table% ^</h4^>
echo %sexec% %dbfile% -csv "create table if not exists %table% ('person_id' INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,'name' TEXT(255,0) NOT NULL, 'first_name' TEXT(255,0) NULL, 'description' TEXT(255,0) NULL, 'zipcode' TEXT(255,0) NULL, 'city' TEXT(255,0) NULL, 'street' TEXT(255,0) NULL, 'url' TEXT NULL UNIQUE);"
call %sexec% %dbfile% -csv "create table if not exists %table% ('person_id' INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,'name' TEXT(255,0) NOT NULL, 'first_name' TEXT(255,0) NULL, 'description' TEXT(255,0) NULL, 'zipcode' TEXT(255,0) NULL, 'city' TEXT(255,0) NULL, 'street' TEXT(255,0) NULL, 'url' TEXT NULL UNIQUE);"
@echo off
call %sexec% %dbfile% -csv "INSERT INTO %table%(name,first_name, description,url) VALUES(REPLACE('%value%','\','\\'),REPLACE('%value%','\','\\'),REPLACE('%value%','\','\\'),REPLACE('%value%','\','\\'));"
@echo off
echo ^<h4^>SQL import done...^</h4^>
echo ^<h4^>Start Webservice import...^</h4^>
echo %source%
type nul >%outFile%
echo ^<h4^>looping...^</h4^>
for /f "usebackq tokens=1-3 delims=;" %%a in (%source%) do (	
	echo %LT%hr%RT%%%a
	call java -jar %jarGrabUrl% "%%a" >>%outFile%
	@echo off
	
)
REM type %outFile%
echo %LT%/br%RT%%LT%a href="#outcnterror"
echo onclick="new HttpRequest().execCMD('call type %outFile%', 'outcnterror')" 
echo %RT%
echo Urls
echo %LT%/a%RT%%LT%/br%RT%
type nul >%logFile%
for /f "usebackq tokens=1-3 delims=;" %%a in (%outFile%) do (
	set url=[url]%%a[/url]
	echo %LT%hr%RT%
	java -jar %jarWebClient% -url "%host%/webservices/client.php?q=doInsert&value1=%tableId%&subject=%%b&body=%%a" -user %user% -password %pwd% - port:%port% >>%logFile%
	@echo off
)
echo %LT%hr%RT%
echo %LT%input
echo type="button" value="View Import Log" onclick="new HttpRequest().getExtFile('file://%logFile%	',400,600);" 
echo /%RT%
echo ^<h4^>Importing to Webservice done.^</h4^>
REM timeout 1 > NUL
@echo on