@echo off
SET "LT=^<"
SET "RT=^>"
echo %LT%h3%RT%Please Install %1%LT%/h3%RT%
echo %LT%input onclick="openBrowser('https://docker.com')" value="Install %1"  type="button"  class="btn btn-default"%RT%%LT%/input%RT%