@echo off
SetLocal EnableDelayedExpansion
SET "LT=^<"
SET "RT=^>"
set "csvFile=%1"
Set "rk=HKLM\SOFTWARE\Microsoft\NET Framework Setup\NDP"
Set/A "vi=ri=0"
echo %LT%h3%RT%Checking Install .NET - %1%LT%/h3%RT%
echo %LT%input type="button" onclick="openBrowser('https://learn.microsoft.com/en-us/dotnet/core/install/windows#net-installer')" value="Install %1"%RT%%LT%/input%RT%
echo %LT%h3%RT%Installed .NET packages%1%LT%/h3%RT%
REM cd C:\Windows\Microsoft.NET\Framework
for /d %%D in (C:\Windows\Microsoft.NET\Framework*) do echo %%~fD
for /d %%D in (C:\Windows\Microsoft.NET\Framework\*) do echo %%~fD
for /d %%D in (C:\Windows\Microsoft.NET\Framework64\*) do echo %%~fD
echo %LT%h3%RT%Installed .NET versions%1%LT%/h3%RT%
For /F "Tokens=3*" %%A In ('Reg Query "%rk%" /F v /K') Do If "%%B"=="" (
    If Not "%%~xA"=="" (Set/A "vi+=1"
        For /F "Tokens=2*" %%C In (
            'Reg Query "%rk%\%%~nxA" /V Version 2^>Nul^|Find /V "\"'
        ) Do Set "_v!vi!=%%D"
    ) Else (Set/A "ri+=1"
        For /F "Tokens=2*" %%E In (
            'Reg Query "%rk%\%%~nxA\Full" /V Release 2^>Nul^|Find /V "\"'
        ) Do Set/A "_r!ri!=%%F"))
If %ri% Gtr 0 (Set/A "vi+=1"
    For /F "Tokens=2" %%A In ('FindStr/B "!_r%ri%!" "%~f0"'
    ) Do Set "_v%vi%=%%A") 

If %vi% Gtr 0 For /F "Tokens=1* Delims==" %%A In ('Set _v') Do Echo([%%B]
echo %LT%h3%RT%Checking .NET package versions%1%LT%/h3%RT%
reg query "HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\NET Framework Setup\NDP"
echo %LT%h3%RT%Installed .NET package v2.0.50727%1%LT%/h3%RT%
reg query "HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\NET Framework Setup\NDP\v2.0.50727"
echo %LT%h3%RT%Installed .NET package v3.0%1%LT%/h3%RT%
reg query "HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\NET Framework Setup\NDP\v3.0"
echo %LT%h3%RT%Installed .NET package v4.0%1%LT%/h3%RT%
reg query "HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\NET Framework Setup\NDP\v4.0"
echo %LT%h3%RT%Installed .NET package v4.5%1%LT%/h3%RT%
reg query "HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\NET Framework Setup\NDP\v4.5"
echo %LT%h3%RT%Installed .NET package v4.5%1%LT%/h3%RT%
reg query "HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\NET Framework Setup\NDP\v5.0"

REM Timeout 3
GoTo :EOF


