@echo off
SetLocal EnableDelayedExpansion
SET "LT=^<"
SET "RT=^>"
set "csvFile=%1"
Set "rk=HKLM\SOFTWARE\Microsoft\NET Framework Setup\NDP"
Set/A "vi=ri=0"
echo %LT%h3%RT%Please Install .NET%1%LT%/h3%RT%
echo %LT%input type="button" onclick="openBrowser('https://learn.microsoft.com/en-us/dotnet/core/install/windows#net-installer')" value="Install %1"%RT%%LT%/input%RT%
echo %LT%h3%RT%Installed .NET packages%1%LT%/h3%RT%
reg query "HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\NET Framework Setup\NDP"

echo %LT%h3%RT%Installed .NET package v2.0.50727%1%LT%/h3%RT%
reg query "HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\NET Framework Setup\NDP\v2.0.50727"
echo %LT%h3%RT%Installed .NET package v3.0%1%LT%/h3%RT%
reg query "HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\NET Framework Setup\NDP\v3.0"
echo %LT%h3%RT%Installed .NET package v4.0%1%LT%/h3%RT%
reg query "HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\NET Framework Setup\NDP\v4.0"
echo %LT%h3%RT%Installed .NET package v4.5%1%LT%/h3%RT%
reg query "HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\NET Framework Setup\NDP\v4.5"
echo %LT%h3%RT%Installed .NET package v4.5%1%LT%/h3%RT%
reg query "HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\NET Framework Setup\NDP\v5.0"

REM cd C:\Windows\Microsoft.NET\Framework
REM for /d %%D in (C:\Windows\Microsoft.NET\Framework*) do echo %%~fD
REM for /d %%D in (C:\Windows\Microsoft.NET\Framework\*) do echo %%~fD
REM for /d %%D in (C:\Windows\Microsoft.NET\Framework64\*) do echo %%~fD
REM echo %LT%h3%RT%Installed .NET versions%1%LT%/h3%RT%
REM For /F "Tokens=3*" %%A In ('Reg Query "%rk%" /F v /K') Do If "%%B"=="" (
    REM If Not "%%~xA"=="" (Set/A "vi+=1"
        REM For /F "Tokens=2*" %%C In (
            REM 'Reg Query "%rk%\%%~nxA" /V Version 2^>Nul^|Find /V "\"'
        REM ) Do Set "_v!vi!=%%D"
    REM ) Else (Set/A "ri+=1"
        REM For /F "Tokens=2*" %%E In (
            REM 'Reg Query "%rk%\%%~nxA\Full" /V Release 2^>Nul^|Find /V "\"'
        REM ) Do Set/A "_r!ri!=%%F"))
REM If %ri% Gtr 0 (Set/A "vi+=1"
    REM For /F "Tokens=2" %%A In ('FindStr/B "!_r%ri%!" "%~f0"'
    REM ) Do Set "_v%vi%=%%A") 

REM If %vi% Gtr 0 For /F "Tokens=1* Delims==" %%A In ('Set _v') Do Echo([%%B]
REM Timeout 3
GoTo :EOF


