@echo off
SET "LT=^<"
SET "RT=^>"
set "csvFile=%1"
echo %LT%h3%RT%Please Install %1%LT%/h3%RT%
echo %LT%input type="button" onclick="openBrowser('https://maven.apache.org/')" value="Install %1"%RT%%LT%/input%RT%