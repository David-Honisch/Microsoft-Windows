@echo off
chcp 65001 > nul
:: Hier die Pfade anpassen (Benutzername ersetzen!)
set "QUELLE=%1"
set "ZIEL=%2"
echo Kopiere Dateien...
xcopy "%QUELLE%" "%ZIEL%\" /Y /I
echo Done!
REM pause