@echo off
set link=< call %cd%\resources\cmd\deqoute.bat < %1
set title=%2
SET "LT=^<"
SET "RT=^>"
REM set link< call %cd%\resources\cmd\deqoute.bat
REM set /p REPLACED=< call %cd%\resources\cmd\deqoute.bat < echo %link%
@echo off
echo %LT%input class="btnMenu" type="button" value="%title%" onclick="new HttpRequest().execCMD('exec type %link%', 'cnt')"%RT%%LT%/input%RT%
