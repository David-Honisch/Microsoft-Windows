@echo off
call "%~dp0config.bat"
@echo off
SET HOUR=%time:~0,2%
SET dtStamp9=%date:~-4%%date:~4,2%%date:~7,2%_0%time:~1,1%%time:~3,2%%time:~6,2% 
SET dtStamp24=%date:~-4%%date:~4,2%%date:~7,2%_%time:~0,2%%time:~3,2%%time:~6,2%
if "%HOUR:~0,1%" == " " (SET dtStamp=%dtStamp9%) else (SET dtStamp=%dtStamp24%)
SET dtStamp=~lc-%dtStamp24%-dirtmp.csv
SET cdir=~lc-%dtStamp24%-dir.csv
@echo off
dir /b /s %1>%temp%\%dtStamp%
@echo off
type nul>%temp%\%cdir%
for /f "usebackq tokens=1-7 delims= " %%a in ("%temp%\%dtStamp%") do (
	
	call %~dp0replacebs.bat %%a >>%temp%\%cdir% | echo ;%%a >>%temp%\%cdir%

)
echo %LT%ul class="listul"%RT%
for /f "usebackq tokens=1-7 delims=;" %%a in ("%temp%\%cdir%") do (
	echo %LT%li class="btn btn-default"%RT%
	echo %LT%a onclick="alert('%%a');execCMD('%%a','out_cnt');" %RT%	
	REM call %~dp0replacebs.bat %%a
	echo %%a
	echo %LT%/a%RT% %LT%/br%RT%
	echo %LT%/li%RT%
)
echo %LT%/ul%RT%