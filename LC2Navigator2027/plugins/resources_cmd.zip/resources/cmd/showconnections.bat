@echo off
SET "LT=^<"
SET "RT=^>"
REM cls
REM call %~dp0..\config.bat
@echo off
set "outFile=%1"
set "defaultFile=%~dp0..\..\csv\default.csv"
set "helpFile=%~dp0..\..\csv\help.csv"
set "importFile=%~dp0..\..\csv\%plugin%.csv"
set "workFile=%~dp0..\..\csv\%plugin%work.csv"
set "sexec=%cd%\resources\app\sqlite\sqlite3.exe"
set "dbfile=%cd%\resources\lc.db"
set "load=%cd%\resources\cmd\loadmenupiped.bat"
REM -------------------------------------------
echo ^<fieldset^>
echo ^<legend^>Coonections^</legend^>
netstat -ano
route print
arp -A
netsh wlan show profile

echo ^</fieldset^>
REM timeout 0 > NUL