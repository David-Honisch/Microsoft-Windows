@echo off
SETLOCAL
call %cd%\resources\cmd\config.bat h5 UPDATECONFIG
@echo off
REM set SQLFILE=%1
cls
set "BR=%LT%hr%RT%"
set LINE==================================
REM set SQLFILE=%1
set IMPORTFILE=%1
set table=%2
set btable=%2_bin
set "resdir=%cd%\resources\"
set "dbfile2=%cd%\resources\%2.db"
REM set "sexec=%resdir%app\sqlite\sqlite3.exe"
REM set "sexec=%cd%\sqlite3.exe"
REM set "dbfile=%cd%\release-builds\lc2search-win32-ia32\resources\lc.db"
REM set "dbfile=%cd%\lc.db"
REM SET "QUERY=select * from %table% limit 1000000;"
REM SET "QUERY2=INSERT INTO %table% (name) values ('Test');"
set "RPATH=https://raw.githubusercontent.com/David-Honisch/Microsoft-Windows/master/LC2Navigator2023/"
call %cd%\resources\cmd\htmlelem.bat h1 IMPORT
@echo off
REM echo %LT%hr%RT%
REM echo IMPORTFILE:%IMPORTFILE% 
echo %LT%p%RT%Importing %IMPORTFILE% to %table% inside %dbfile%%LT%p%RT%
REM echo %LT%hr%RT%
REM echo %LT%hr%RT%
REM echo READING CSV %table% to %dbfile%
echo %LT%hr%RT%
REM call %sexec% %dbfile% -csv "INSERT INTO systables(name,first_name, description,url)VALUES('%table% Data','%table%','%table%','execCMD(\\'.\\\\resources\\\\cmd\\\\showdb.bat %table%\\', \\'out\\')');"
REM call %sexec% %dbfile% -csv "INSERT INTO systables(name,first_name, description,url)VALUES('%table% Data','%table%','%table%','execCMD(''.\\resources\\cmd\\showdb.bat %table%'', ''out'')');"
REM echo call %sexec% %dbfile% -csv "INSERT INTO systables(name,first_name, description,url)VALUES('%table%','%table%','%table%','execCMD(''.\\resources\\cmd\\showdb.bat %table%'', ''out'')');"
call %sexec% %dbfile% -csv "INSERT INTO systables(name,first_name, description,url)VALUES('%table%','%table%','%table%','execCMD(''.\\resources\\cmd\\showdb.bat %table%'', ''out'')');"
echo Creating table %table%
call %sexec% %dbfile% -csv "CREATE TABLE %table% ( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);"
echo importing..
call %sexec% %dbfile% -csv "INSERT INTO %table%(name,first_name, description,url)VALUES('%table%','%table%','%table%','execCMD(''.\\resources\\cmd\\showdb.bat %table%'', ''out'')');"
call %sexec% %dbfile% -csv "INSERT INTO %table%(name,first_name, description,url)VALUES('%table% List','%table%','%table%','showDB(''%table%'')');"
REM real table
call %sexec% %dbfile2% -csv "CREATE TABLE %table% ( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);"
echo %LT%p%RT%Importing %IMPORTFILE% to %table% inside %dbfile2%%LT%p%RT%
for /f "usebackq tokens=1-4 delims=," %%a in ("%IMPORTFILE%") do (
	  %sexec% %dbfile2% -csv "INSERT INTO %table%(first_name,name, description,url) VALUES(REPLACE('%%a','\','\\'),REPLACE('%%a','\','\\'),REPLACE('%%a','\','\\'),'execCMD(''\""'||REPLACE('%%a','\','\\')||'\""'',''out'')');"
	  REM %sexec% %dbfile2% -csv "INSERT INTO %table%(first_name,name, description,url) VALUES(REPLACE('%%a','\','\\'),REPLACE('%%a','\','\\'),readfile('%%a'),'execCMD(''\""'||REPLACE('%%a','\','\\')||'\""'',''out'')');"
	  REM @echo off
	  REM %sexec% %dbfile2% -csv "INSERT INTO %table%(first_name,name, description,url) VALUES(REPLACE('%%a','\','\\'),REPLACE('%%a','\','\\'),REPLACE('%%a','\','\\'),readfile('%%a')');"
	  REM %sexec% %dbfile2% -csv "INSERT INTO %table%(name,path, description,url) VALUES('%%~na','%%~da%%~pa%%~na','%%~xa',readfile('%%a'));"
	  REM @echo off
)
echo %LT%hr%RT%%LT%hr%RT%
echo Importing files done
echo %LT%hr%RT%%LT%hr%RT%
echo %LT%h1%RT%
call %sexec% %dbfile2% -csv "select count(*) from %table%;"
echo %LT%/h1%RT%
type %resdir%\html\clearbutton.html