@echo off
rem Author:David Honisch
rem ============= PLEASE CONFIGURE THE ENVIRONMENT =============
set "_os=64"
if "%PROCESSOR_ARCHITECTURE%"=="x86" (if not defined PROCESSOR_ARCHITEW6432 set "_os=32")
REM echo %_os%
call %~dp0setregvalue.bat "hkey_current_user\software\letztechance.org\LC2Navigator2024" "user" "%username%" > nul
call %~dp0setregvalue.bat "hkey_current_user\software\letztechance.org\LC2Navigator2024" "password" "xxx" > nul
call %~dp0setregvalue.bat "hkey_current_user\software\letztechance.org\LC2Navigator2024" "server" "localhost" > nul
call %~dp0setregvalue.bat "hkey_current_user\software\letztechance.org\LC2Navigator2024" "instance" "test"> nul
call %~dp0setregvalue.bat "hkey_current_user\software\letztechance.org\LC2Navigator2024" "port" "1433"> nul
call %~dp0setregvalue.bat "hkey_current_user\software\letztechance.org\LC2Navigator2024" "dbfinal" "masterdatalivecopy"> nul
call %~dp0setregvalue.bat "hkey_current_user\software\letztechance.org\LC2Navigator2024\author" "author" "david honisch"> nul
call %~dp0setregvalue.bat "hkey_current_user\software\letztechance.org\LC2Navigator2024" "author" "david honisch"> nul
call %~dp0setregvalue.bat "hkey_current_user\software\letztechance.org\LC2Navigator2024" "time" "%time%"> nul
call %~dp0setregvalue.bat "hkey_current_user\software\letztechance.org\LC2Navigator2024" "os" "%_os%"> nul
echo Registered User:
call %~dp0getregvalue.bat "HKEY_CURRENT_USER\SOFTWARE\LETZTECHANCE.ORG\LC2Navigator2024" "user"
echo OS:
call %~dp0getregvalue.bat "HKEY_CURRENT_USER\SOFTWARE\LETZTECHANCE.ORG\LC2Navigator2024" "os"
echo Bit
@echo off