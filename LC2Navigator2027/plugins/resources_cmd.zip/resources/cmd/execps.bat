@echo off
PowerShell.exe -ExecutionPolicy Bypass -Command "& '%1'"
REM timeout 3