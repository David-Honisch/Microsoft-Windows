@echo off
echo ^<video width="320" height="240" controls^>
echo   ^<source src="%1" type="video/mp4"^>
REM echo   ^<source src="movie.ogg" type="video/ogg"^>
echo Your browser does not support the video tag.
echo ^</video^> 