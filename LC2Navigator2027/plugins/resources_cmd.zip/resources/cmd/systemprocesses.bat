@echo off
call "%~dp0config.bat"
@echo off
set outFile=%temp%\lc2procesess.csv
REM tasklist /v /fi "username eq system"
tasklist > %outFile%
@echo off
echo %LT%ul class="listul"%RT%
for /f "skip=4 usebackq tokens=1-7 delims= " %%a in ("%outFile%") do (
		echo %LT%li class="btn btn-danger"%RT%
	echo %LT%a
	REM echo onclick="alert('%%b');execCMD('taskkill /f /PID %%b','menu_cnt');" 
	REM echo onclick="showConfirmDialog('#dialog','Realy kill task %%a now?','Realy kill task %%a now?',{},alert('%%b'));" 
	echo onclick="if(getConfirmation('Kill task %%a now?')){execCMD('taskkill /f /PID %%b','menu_cnt')};" 
	echo %RT%
	echo %%a
	echo %LT%/a%RT% %LT%/br%RT%
	echo %%b %%c %%d %%e
	echo %LT%/li%RT%
)
echo %LT%/ul%RT%
