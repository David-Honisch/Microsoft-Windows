SET string=%1
SET modified=%string:\=\\%
REM ECHO %string%
ECHO %modified%