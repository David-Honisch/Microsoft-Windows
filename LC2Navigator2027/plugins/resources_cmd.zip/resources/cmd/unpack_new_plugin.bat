@echo off
SET "LT=^<"
SET "RT=^>"
set tempFile=%temp%\~lc2_newplugin_files.csv
set ren="%~dp0..\..\app\lc2replaceinfile\lc2replaceinfile.exe"
echo %LT%pre%RT%
echo %LT%span%RT%CREATING NEW PLUGIN%LT%/span%RT%
echo %LT%h1%RT%%1%LT%/h1%RT%
echo %LT%p%RT%CREATING NEW PLUGIN %1%LT%/p%RT%
call py resources\python\unzip.py build\%1.zip  %~dp0..\..\
REM cd %~dp0
REM echo rmdir /S /Q %~dp0..\..\resources\plugin\src
REM rmdir /S /Q  %~dp0..\..\resources\plugin\src
REM echo mkdir %~dp0 %~dp0..\..\resources\plugin\src 
REM mkdir %~dp0 %~dp0..\..\resources\plugin\src 
REM echo call py  %~dp0..\..\resources\python\unzip.py  %~dp0..\..\resources\plugin\src.zip src
REM call py resources\python\unzip.py resources\src.zip  %~dp0..\..\resources\plugin\src
REM echo %LT%/pre%RT%
REM echo %LT%pre%RT%
REM echo %LT%p%RT%Renaming %1%LT%/p%RT%
REM call move "%~dp0..\..\resources\plugin\src\resources\sql\lc2default.zip.sql" " %~dp0..\..\resources\plugin\src\resources\sql\%1.zip.sql"
REM call move "%~dp0..\..\resources\plugin\src\resources\plugins\lc2default" "%~dp0..\..\resources\plugin\src\resources\plugin\src\resources\plugins\%1"
REM echo %LT%span%RT%Renaming %1%LT%/span%RT%
REM dir /b /s %~dp0..\..\resources\plugin\src\*.*>%tempFile%
REM type %tempFile%
REM for /f "usebackq tokens=1-20 delims=," %%a in ("%tempFile%") do (
 REM echo modify:%%a
 REM %ren% %%a lc2default %1
REM )
REM echo %LT%/pre%RT%
REM echo %LT%pre%RT%
REM echo %LT%span%RT%BUILDING %1%LT%/span%RT%
REM timeout 3
REM echo call py build.py %1
REM call py %~dp0..\..\resources\python\build.py %1
REM echo %LT%/pre%RT%
echo %LT%pre%RT%
REM type  "src\resources\plugins\%1\config.bat" | findstr "%1"

echo %LT%p%RT%Successfully %1 done.%LT%/p%RT%
echo %LT%/pre%RT%