@echo off
setlocal enabledelayedexpansion
echo dir2csv
echo %1 %2
echo dir /b /s %1 > %2
dir /b /s %1 > %2
endlocal