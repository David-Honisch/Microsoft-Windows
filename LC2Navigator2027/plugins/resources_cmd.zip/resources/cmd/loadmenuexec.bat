@echo off
SET "LT=^<"
SET "RT=^>"
REM echo %LT%h1%RT% OUT: %outFile% %LT%/h1%RT%
for /f "usebackq tokens=1-5 delims=;" %%a in ("%outFile%") do (	
	set value=%%a
	echo %LT%input
	echo type="button" value="%%a"
	echo  onclick="if(getConfirmation('Start %%a now?')){execCMD('start %%c','core_cnt')};"
	echo /%RT%%LT%br/%RT%
)