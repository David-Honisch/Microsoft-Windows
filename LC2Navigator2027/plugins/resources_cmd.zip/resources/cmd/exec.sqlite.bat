@echo off
SETLOCAL
title=EXEC SQLITE
call %cd%\resources\cmd\config.bat h5 SQLIT3
%sexec% %dbfile% %2 "%1"
@echo on