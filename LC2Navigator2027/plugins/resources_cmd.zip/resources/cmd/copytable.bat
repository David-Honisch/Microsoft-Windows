@echo off
cls
call "%cd%\resources\cmd\config.bat"
@echo off
set QUERY=%1
set "exec=%cd%\resources\app\sqlite\SQLite3.exe"
call %sexec% %dbfile% -csv "drop table if exists %QUERY%_new;"
call %sexec% %dbfile% -csv "create table if not exists %QUERY%_new ('person_id' INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,'name' TEXT NOT NULL, 'first_name' TEXT NULL, 'last_name' TEXT NULL, 'description' TEXT NULL, 'zipcode' TEXT NULL, 'city' TEXT NULL, 'street' TEXT NULL, 'url' TEXT NULL);"
call "%sexec%" "%dbfile%" -header "select count(*) from %QUERY%_new;"
call "%sexec%" "%dbfile%" -header "select count(*) from %QUERY%;"
REM call "%sexec%" "%dbfile%" "ALTER TABLE az900 RENAME COLUMN \"name\" TO \"name_old\";" 
REM call "%sexec%" "%dbfile%" "ALTER TABLE az900 RENAME COLUMN 'new_name' TO 'name';" 
call "%sexec%" "%dbfile%" -header "select * from %QUERY% limit 1;"
call "%sexec%" "%dbfile%" "insert into %QUERY%_new (name, first_name, city, street, zipcode, url)  select name, first_name,  city, street, zipcode, url from %QUERY%;"
call %sexec% %dbfile% "ALTER TABLE %QUERY% RENAME TO %QUERY%_old;"
call %sexec% %dbfile% "ALTER TABLE %QUERY% RENAME TO %QUERY%;"
call %sexec% %dbfile% -csv "drop table if exists %QUERY%_old;"