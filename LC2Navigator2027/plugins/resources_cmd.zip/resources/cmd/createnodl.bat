@echo off
echo.>%NODOWNLOAD%
@echo on