@echo off
SET "LT=^<"
SET "RT=^>"
REM cls
REM call %~dp0..\config.bat
@echo off
set "outFile=%1"
set "networkFile=%cd%\resources\cmd\csv\network.csv"
set "serverFile=%cd%\resources\cmd\csv\server.csv"
set "sexec=%cd%\resources\app\sqlite\sqlite3.exe"
set "dbfile=%cd%\resources\lc.db"
set "load=%cd%\resources\cmd\loadmenupipedext.bat"
REM -------------------------------------------
echo %LT%div role="tabpanel" class="tab-pane fade" id="network" aria-labelledby="network-tab"%RT%
echo %LT%div class="panel panel-default"%RT%
echo %LT%div class="panel-body demo-btn" style="min-height: 252px;"%RT%
echo ^<legend^>Services:^</legend^>
REM ^<br/^>
echo ^<select id="networkServer"^>
for /f "usebackq tokens=1-5 delims=;" %%a in ("%serverFile%") do (
	echo ^<option value="%%c" ^>%%b^</option^>
)
echo ^</select^>
REM echo ^<input type="button" class="btn btn-default" value="Show" onclick="openBrowser(''+document.getElementById('networkServer').value);"^>^</input^>^<br/^>
echo ^<input type="button" class="btn btn-default" value="Show" onclick="if(getConfirmation('Start '+document.getElementById('networkServer').value+' now?')){openBrowser(''+document.getElementById('networkServer').value)};"^>^</input^>^<br/^>
echo ^<input type="button" class="btn btn-default" value="Show Window" onclick="if(getConfirmation('Start '+document.getElementById('networkServer').value+' now?')){getExtFile(''+document.getElementById('networkServer').value,'out')};"^>^</input^>^<br/^>
echo ^</fieldset^>
REM -------------------------------------------
echo ^<fieldset^>
echo ^<legend^>Network related:^</legend^>
call %load% "%networkFile%" btn
echo %LT%h4 class="panel panel-heading2"%RT% %title% %version% %LT%/h4%RT%
echo ^<button type="button" class="btn btn-success" onclick="execCMD('call .\\resources\\cmd\\showconnections.bat', 'menu_cnt');"^>Show Connections^</button^>
echo %LT%div id="networkout"%RT%%LT%/div%RT%
echo ^</fieldset^>
REM -------------------------------------------
REM -------------------------------------------

echo %LT%/div%RT%
echo %LT%/div%RT%
echo %LT%/div%RT%
REM echo %LT%script src="../../js/test.js"%RT%%LT%/script%RT%
REM timeout 0 > NUL