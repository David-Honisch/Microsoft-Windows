@echo off
SET "LT=^<"
SET "RT=^>"
call %~dp0..\config.bat
@echo off
set "outFile=%1"
set "defaultFile=%~dp0..\..\csv\default.csv"
set "requirementFile=%~dp0..\..\csv\default.csv"
set "importFile=%~dp0..\..\csv\%plugin%.csv"
set "sexec=%cd%\resources\app\sqlite\sqlite3.exe"
set "dbfile=%cd%\resources\lc.db"
set "load=%cd%\resources\cmd\loadmenupiped.bat"
echo %LT%div role="tabpanel" class="tab-pane fade in" id="requirement" aria-labelledby="requirement-tab"%RT%
echo %LT%div class="panel panel-default"%RT%
echo %LT%div class="panel-body demo-btn" style="min-height: 252px;"%RT%
echo ^<input type="button" value="Reload Menu" onclick="execCMD('.\\menu.bat', 'out')" class="btn btn-default"^>
echo %LT%textarea rows="1" cols="120" style="min-width:96%%"%RT%
echo Go to
echo %LT%/textarea%RT%
echo %LT%a onclick="openBrowser('https://www.letztechance.org/read-20-48.html');"%RT%more...%LT%/a%RT%
echo %LT%/div%RT%
echo %LT%/div%RT%
echo %LT%/div%RT%