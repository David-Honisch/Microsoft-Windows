@echo off
SET "LT=^<"
SET "RT=^>"
REM cls
call %~dp0..\config.bat
@echo off
set "outFile=%1"
set "defaultFile=%~dp0..\..\csv\default.csv"
set "installFile=%~dp0..\..\csv\install.csv"
set "importFile=%~dp0..\..\csv\%plugin%.csv"
set "checkFile=%~dp0..\csv\check.csv"
set "sexec=%cd%\resources\app\sqlite\sqlite3.exe"
set "dbfile=%cd%\resources\lc.db"
set "load=%cd%\resources\cmd\loadmenupiped.bat"
set "check=%cd%\resources\cmd\check.bat"
echo %LT%div role="tabpanel" class="tab-pane fade in" id="checkinstall" aria-labelledby="checkinstall-tab"%RT%
echo %LT%div class="panel panel-default"%RT%
echo %LT%div class="panel-body demo-btn" style="min-height: 252px;"%RT%
echo ^<input type="button" value="Reload Menu" onclick="execCMD('.\\menu.bat', 'out')" class="btn btn-default"^>
REM echo ^<input id="importLinks" type="button" class="btn btn-default" value="Show Import UI" onclick="getOpenDialog('#import_cnt','.\\resources\\html\\import.html','Install',{ minWidth: 250,  minHeight: 150, width: 400});"^>^</input^>                    
echo ^<fieldset^>
echo ^<legend^>Requirements^</legend^>
REM echo call %check% "%checkFile%" btn
call %check% "%checkFile%" btn
REM ^<br/^>
REM echo ^<!-- ^<input id="importLinks" type="button" value="Import Links" onclick="getExtFile('file://'+__dirname+'\\..\\..\\..\\resources\\plugins\\lc2mysqldocker\\install.html',400,600);getExtFile('file://'+__dirname+'\\..\\..\\..\\resources\\html\\import.html');"^>^</input^> --^>
REM IF "java"=="" echo ^<input type="button" value="Install Java" onclick="execCMD('.\\resources\\install\\java.bat', 'out')" class="btn btn-warning"^>
REM call java --version
REM echo ^<input id="importLinks" type="button" class="btn btn-default" value="Show server" onclick="getExtFile('http://localhost:8888/index.html',400,600);"^>^</input^>
REM echo ^<input id="importLinks" type="button" class="btn btn-default" value="http://localhost:8888" onclick="openBrowser('http://localhost:8888/index.html',400,600);"^>^</input^>
@REM echo ^<div id="import_cnt" style="min-width:100%;width:100%;"^>
@REM echo     ^<div id="import_cnt_cnt" style="min-width:100%;width:100%;"^>^</div^>
@REM echo ^</div^>
echo ^</fieldset^>

echo ^<fieldset^>
echo ^<legend^>Show Files^</legend^>
REM echo ^<label^>CLI:^</label^>
echo ^<input id="infopattern" type="text" value="..\..\..\*.*"^>^</input^>
echo ^<input type="button" value="Submit" onclick="execCMD('call .\\resources\\cmd\\sdir.bat '+$('#infopattern').val(), 'menu_cnt');"^>^</input^>
REM echo ^</form^>
echo ^</fieldset^>




REM call type "%~dp0..\html\install.html"
REM @echo off
REM call %load% "%defaultFile%" btn
REM @echo off
REM call %cd%\resources\cmd\loadmenupiped.bat "%importFile%" btn
REM @echo off
REM echo done
echo %LT%/div%RT%
echo %LT%/div%RT%
echo %LT%/div%RT%
REM echo %LT%h6%RT% import %importFile% done. %LT%/h6%RT%
REM timeout 0 > NUL