@echo off
SET "LT=^<"
SET "RT=^>"
REM cls
call %~dp0..\config.bat
@echo off
set "outFile=%1"
set "defaultFile=%~dp0..\..\csv\default.csv"
set "infoFile=%~dp0..\..\csv\info.csv"
set "importFile=%~dp0..\..\csv\info.csv"
set "sexec=%cd%\resources\app\sqlite\sqlite3.exe"
set "dbfile=%cd%\resources\lc.db"
set "load=%~dp0resources\cmd\loadmenupiped.bat"
echo %LT%div role="tabpanel" class="tab-pane fade in" id="info" aria-labelledby="info-tab"%RT%
echo %LT%div class="panel panel-default"%RT%
echo %LT%div class="panel-body demo-btn" style="min-height: 252px;"%RT%
echo %LT%h1%RT% %plugin% Info %LT%/h1%RT%
echo  ^<input type="button" value="Reload Menu" onclick="execCMD('.\\menu.bat', 'out')" class="btn btn-default"^>^<br/^>
REM call %cd%\resources\cmd\registerplugin.bat
REM echo %LT%img src="resources/plugins/%plugin%/lclogo.png"%RT%%LT%/img%RT%
echo ^<fieldset^>
echo ^<legend^>System:^</legend^>
echo ^<button type="button" class="btn btn-default" onclick="execCMD('call .\\resources\\cmd\\systeminfo.bat', 'menu_cnt');"^>Show System Info^</button^>
echo ^<button type="button" class="btn btn-midnight" onclick="execCMD('call .\\resources\\cmd\\systemprocesses.bat', 'menu_cnt');"^>Show System Processes^</button^>
echo ^</fieldset^>

echo ^<fieldset^>
echo ^<legend^>Import File^</legend^>
REM echo  ^<input id="importLinks" type="button" class="btn btn-default" value="Show Import UI" onclick="getOpenDialog('#menu_cnt','.\\resources\\html\\import.html','Install',{ minWidth: 250,  minHeight: 150, width: 400});"^>^</input^>                    
REM echo  ^<!-- ^<input id="importLinks" type="button" value="Import Links" onclick="getExtFile('file://'+__dirname+'\\..\\..\\..\\resources\\plugins\\lc2mysqldocker\\install.html',400,600);getExtFile('file://'+__dirname+'\\..\\..\\..\\resources\\html\\import.html');"^>^</input^> --^>
REM echo  ^<input id="importLinks" type="button" class="btn btn-default" value="Show server" onclick="getExtFile('http://localhost:8888/index.html',400,600);"^>^</input^>
REM echo  ^<input id="importLinks" type="button" class="btn btn-default" value="http://localhost:8888" onclick="openBrowser('http://localhost:8888/index.html',400,600);"^>^</input^>

echo  ^</fieldset^>

echo ^<fieldset^>
echo ^<legend^>Import File^</legend^>
echo ^<label^>CLI:^</label^>
echo ^<input id="scanpattern" type="text" value=".\*.csv"^>^</input^>
echo ^<input id="btnSubmit" type="button" value="Submit" onclick="execCMD('call .\\resources\\cmd\\sdir.bat '+$('#scanpattern').val(), 'menu_cnt');"^>^</input^>
echo ^</form^>
echo ^</fieldset^>

echo ^<fieldset^>
echo ^<legend^>Database related:^</legend^>
echo ^<button type="button" class="btn btn-default" onclick="execCMD('call .\\resources\\cmd\\exportdb.bat', 'menu_cnt');"^>Export^</button^>
echo ^<button type="button" class="btn btn-default" onclick="execCMD('call .\\resources\\cmd\\creategetallfiles.bat', 'menu_cnt');"^>Create Index^</button^>
echo ^<br^>
echo ^<button type="button" class="btn btn-default" onclick="execCMD('call .\\resources\\cmd\\getallfiles.bat', 'menu_cnt');"^>Get Index^</button^>
echo ^<br^>
echo ^<button type="button" class="btn btn-default" onclick="execCMD('call .\\resources\\cmd\\showtemp.bat', 'menu_cnt');"^>Show temp^</button^>
echo ^</fieldset^>


REM call %load% "%defaultFile%" btn
REM @echo off
REM call %cd%\resources\cmd\loadmenupiped.bat "%importFile%" btn
REM @echo off
REM @echo off
REM call %load% "%defaultFile%" "btn btn-info"
REM @echo off
REM echo %LT%hr/%RT%
REM echo call %load% "%importFile%" "btn btn-info"
REM call %load% "%importFile%" "btn btn-info"
REM @echo off
REM echo done
echo %LT%/div%RT%
echo %LT%/div%RT%
echo %LT%/div%RT%
REM echo %LT%h6%RT% import %importFile% done. %LT%/h6%RT%
REM timeout 0 > NUL