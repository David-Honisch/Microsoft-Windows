@echo off
@echo off
SET "LT=^<"
SET "RT=^>"
REM cls
REM call %~dp0..\config.bat
@echo off
set "outFile=%1"
set "defaultFile=%~dp0..\..\csv\default.csv"
set "helpFile=%~dp0..\..\csv\help.csv"
set "importFile=%~dp0..\..\csv\%plugin%.csv"
set "workFile=%~dp0..\..\csv\%plugin%work.csv"
set "sexec=%cd%\resources\app\sqlite\sqlite3.exe"
set "dbfile=%cd%\resources\lc.db"
set "load=%cd%\resources\cmd\loadmenupiped.bat"
REM -------------------------------------------
echo %LT%div role="tabpanel" class="tab-pane fade active in" id="appp" aria-labelledby="appp-tab"%RT%
echo %LT%div class="panel panel-default"%RT%
echo %LT%div class="panel-body demo-btn" style="min-height: 252px;"%RT%
REM -------------------------------------------
echo ^<fieldset^>
echo ^<legend^>%title% %version%^</legend^>
REM echo %LT%h4 class="panel panel-heading2"%RT% %title% %version% %LT%/h4%RT%
echo ^<input type="button" value="Reload Menu" onclick="execCMD('.\\menu.bat', 'out')" class="btn btn-default"^>
echo ^<input id="importLinks" type="button" class="btn btn-default" value="Show Import UI" onclick="getOpenDialog('#import_cnt','.\\resources\\html\\import.html','Import',{ minWidth: 250,  minHeight: 150, width: 400});"^>^</input^>
REM echo ^</br^>
REM echo ^<button type="button" class="btn btn-primary" onclick="execCMD('systeminfo','menu_cnt');"^>Systeminfo^</button^>
echo ^</fieldset^>
REM -------------------------------------------
echo ^<fieldset^>
echo ^<legend^>Registered applications:^</legend^>
echo ^<button type="button" class="btn btn-success" onclick="execCMD('call .\\resources\\cmd\\showapps.bat', 'appsmenu');"^>Show Applications^</button^>
echo ^<div id="appsmenu"^>^</div^>
echo ^</fieldset^>
REM -------------------------------------------
echo ^<fieldset^>
echo ^<legend^>Installation and requirements related:^</legend^>
echo ^<button type="button" class="btn btn-warning" onclick="evalCMD('.\\resources\\cmd\\installmodule.js.bat pluginsmenu', 'pluginsmenu');"^>Check and install Requirements^</button^>
echo ^<button type="button" class="btn btn-primary" onclick="execCMD('call .\\resources\\cmd\\showplugins.bat','pluginsmenu');"^>Show Plugin Downloaders^</button^>
echo ^<div id="pluginsmenu"^>^</div^>
echo ^</fieldset^>
REM -------------------------------------------
REM -------------------------------------------
echo ^<fieldset^>
echo ^<legend^>Database related:^</legend^>
echo ^<button type="button" class="btn btn-default" onclick="execCMD('call .\\resources\\cmd\\exportdb.bat', 'menu_cnt');"^>Export^</button^>%LT%/br%RT%
echo ^<label^>Tabelle:^</label^>
echo ^<input id="importtable" type="text" value="%title%"^>^</input^>^<br^>
echo ^<label^>Import File:^</label^>

echo %LT%/br%RT%
echo ^<input id="importpattern" type="text" value="C:\\tools\LETZTECHANCE.ORG\\LC2Navigator2022\\app.csv"^>^</input^>%LT%/br%RT%
echo ^<input id="importLinks" type="button" class="btn btn-default" value="Import Links" onclick="execCMD('call .\\resources\\cmd\\import.from.csv.to.sqlite.bat '+$('#importpattern').val()+' '+$('#importtable').val(), 'menu_cnt');"^>^</input^>                    
echo ^<input id="importFiles" type="button" class="btn btn-default" value="Import Files" onclick="execCMD('call .\\resources\\cmd\\import.files.from.csv.to.sqlite.bat '+$('#importpattern').val()+' '+$('#importtable').val(), 'menu_cnt');"^>^</input^>
echo ^<label^>File to Base64:^</label^>
echo ^<input id="importfile" type="file" value=".\\app.csv"^>^</input^>%LT%/br%RT%
REM echo ^<input id="btnmenutobase64" type="button" class="btn btn-default" value="Encode file"^>^</input^>%LT%/br%RT%
echo ^<input id="btnmenutobase64" type="button" class="btn btn-default" value="Encode file" onclick="getToBase('#importfile','#base64file');"^>^</input^>%LT%/br%RT%
echo ^<textarea id="base64file" type="file" rows="1" cols="120" style="width:96%%"^>^</textarea^>%LT%/br%RT%
echo ^</fieldset^>
REM -------------------------------------------
echo ^<fieldset^>
echo ^<legend^>System:^</legend^>
echo ^<button type="button" class="btn btn-default" onclick="execCMD('call .\\resources\\cmd\\systeminfo.bat', 'menu_cnt');"^>Show System Info^</button^>
echo ^<button type="button" class="btn btn-midnight" onclick="execCMD('call .\\resources\\cmd\\systemprocesses.bat', 'menu_cnt');"^>Show System Processes^</button^>
echo ^</fieldset^>
REM -------------------------------------------

echo %LT%/div%RT%
echo %LT%/div%RT%
echo %LT%/div%RT%
REM echo %LT%script src="../../js/test.js"%RT%%LT%/script%RT%
REM timeout 0 > NUL