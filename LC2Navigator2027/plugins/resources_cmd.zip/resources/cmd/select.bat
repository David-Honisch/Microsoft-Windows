@echo off
setlocal
call "%~dp0config.bat"
set dbfile=%1
set QUERY=%2
REM set "sexec=%~dp0resources\app\sqlite\SQLite3.exe"
call "%sexec%" %dbfile% %QUERY%
endlocal