@echo off
echo %LT%div role="tabpanel" class="tab-pane fade %2 in" id="%1" aria-labelledby="%1-tab"%RT%
echo %LT%div class="panel panel-default"%RT%
echo %LT%div class="panel-body demo-btn" style="min-height: 252px;"%RT%
call %2 %3 %4 %5 %6 %7 %8
@echo off
echo %LT%/div%RT%
echo %LT%/div%RT%
echo %LT%/div%RT%