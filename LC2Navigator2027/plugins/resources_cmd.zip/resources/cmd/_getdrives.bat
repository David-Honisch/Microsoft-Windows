@echo off
cls
setlocal enabledelayedexpansion
set "_DRIVE.LETTERS.FREE=Z Y X W V U T S R Q P O N M L K J I H G F E D C B A "
for /f "skip=1 tokens=1,2 delims=: " %%a in ('wmic logicaldisk get deviceid^,volumename') do (
   set "_DRIVE.LETTERS.USED=!_DRIVE.LETTERS.USED!%%a,%%b@"
   set "_DRIVE.LETTERS.FREE=!_DRIVE.LETTERS.FREE:%%a =!"
)
set _DRIVE.LETTERS.USED=%_DRIVE.LETTERS.USED:~0,-2%
set _DRIVE.LETTERS.USED=%_DRIVE.LETTERS.USED:,@=, @%
set _DRIVE.LETTERS