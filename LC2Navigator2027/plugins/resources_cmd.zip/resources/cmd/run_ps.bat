@echo off
cls
REM powershell.exe -ExecutionPolicy Bypass -File "%SCRIPT_PATH%" -args -database "%DB_NAME%" -user "%DB_USER%" -pass "%DB_PASS%" -MaxRetries "%RETRY_COUNT%"
powershell.exe -ExecutionPolicy Bypass -File "%1" -args %2 %3 %4 %5 %6 %7 %8 %9