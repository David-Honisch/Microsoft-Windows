@echo off
set "table=application"
cls
call %cd%\resources\cmd\htmlelem.bat h1 UPDATES
@echo off
REM echo %LT%div class='container-fluid cm-container-white' %RT%
call %cd%\resources\cmd\update.config.bat h1 UPDATES
@echo off
echo %LINE%
echo %LT%p%RT% Creating %showhtml% %LT%/p%RT%
REM %sexec% %dbfile% -line -csv "select * from application limit 10"
REM %sexec% %dbfile% -html "select * from application limit 10" > %showhtml%
REM type %showhtml%
echo %LT%p%RT% eof creating %showhtml% %LT%/p%RT%
call %cd%\resources\cmd\selectToCSV.bat %table%
@echo off
echo %LT%p%RT% eof creating %SQLFILE% %LT%/p%RT%
call %cd%\resources\cmd\importsql.bat "%SQLFILE%"
@echo off
echo %LT%p%RT% eof SQL IMPORT %LT%/p%RT%
@echo on