@echo off
cls
call "%~dp0config.bat"
@echo off
set DB=%1
set QUERY=%2
set "dbfile=%cd%\resources\%1.db"
set "outfile=%cd%\resources\data\searchdb-search.db.csv"
echo %LT%h1%RT% Searching %DB% with query: %QUERY% %LT%/h1%RT%
echo ^<fieldset^>
REM echo  ^<legend^>Result:^</legend^>
echo ^<input type="text" id="inputKey" value="%QUERY%"/^>^<br^>
echo ^<button type="button" class="btn btn-default" onclick="if(getConfirmation('Start task '+document.getElementById('inputKey').value+' now?')){execCMD('.\\resources\\cmd\\searchdb.bat %1 '+document.getElementById('inputKey').value, 'out')};"^>Query^</button^>
echo ^<div id="showdbresult"^>
REM call "%sexec%" "%dbfile%" "select * from %DB% as db WHERE db.url like '%QUERY%'" > %outfile%
REM echo call "%sexec%" "%dbfile%" "select * from %DB% as db WHERE db.url like '%%%%%QUERY%%%%%'"
call "%sexec%" "%dbfile%" "select 'Found:'||count(*) from %DB% as db WHERE db.url like '%%%%%QUERY%%%%%'"
call "%sexec%" "%dbfile%" "select * from %DB% as db WHERE db.url like '%%%%%QUERY%%%%%'" > %outfile%
REM call "%~dp0loadmenupiped.bat" %outfile%
echo %LT%ul class="listul"%RT%
for /f "usebackq tokens=1-7 delims=|" %%a in (%outfile%) do (
	IF NOT "%%b" == "" (
    echo %LT%li%RT%
	echo %LT%input
	REM echo type="button" value="%%b" onclick="execCMD('%%c','app_cnt')" 
	echo type="button" value="%%b" class="btn %css% %%d" onclick="if(getConfirmation('Start %%e now?')){execFile('%%c','out')};" 
	REM echo type="button" value="%%b" onclick="%%c" 
	echo /%RT%
	echo %LT%span class="btn-default"%RT% %%e%LT%/span%RT%
	echo %LT%/li%RT%
	) ELSE ( echo %LT%li%RT%%LT%hr%RT%%LT%/li%RT%	)
)
echo %LT%/ul%RT%
echo ^</div^>
echo ^</fieldset^>

@echo on