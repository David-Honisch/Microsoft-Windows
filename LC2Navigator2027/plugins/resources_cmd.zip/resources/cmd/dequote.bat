@Echo Off
Setlocal
Set _mypath=%1
CALL :dequote _mypath
Echo %_mypath%
Goto :eof
:DeQuote
for /f "delims=" %%A in ('echo %%%1%%') do set %1=%%~A
Goto :eof
REM @echo off