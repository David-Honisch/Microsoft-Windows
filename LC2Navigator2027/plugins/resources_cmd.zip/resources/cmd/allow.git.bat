@echo off
git config --global --add safe.directory "F:\git\Microsoft-Windows\"