@echo off
REM cls
SET SCRIPT_PATH=%~dp0..\ps\check-mysql.ps1

REM Define the arguments you want to pass
SET DB_NAME=dbtest
SET DB_USER=root
SET DB_PASS=rootpassword
SET RETRY_COUNT=3

REM --- Method 1: Passing arguments by position (Simpler) ---
@REM powershell.exe -ExecutionPolicy Bypass -File "%SCRIPT_PATH%" "%DB_NAME%" "%DB_USER%" "%RETRY_COUNT%"
REM --- Method 2: Passing arguments by name (More robust) ---
REM This method uses the -args parameter and lets you name the variables as defined in the param() block
powershell.exe -ExecutionPolicy Bypass -File "%SCRIPT_PATH%" -args -database "%DB_NAME%" -user "%DB_USER%" -pass "%DB_PASS%" -MaxRetries "%RETRY_COUNT%"