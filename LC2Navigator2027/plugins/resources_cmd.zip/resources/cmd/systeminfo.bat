@echo off
REM tasklist /v /fi "username eq system"
@echo off
call "%~dp0config.bat"
@echo off
set outFile=%~dp0..\..\lc2sysinfo.csv
set userFile=%~dp0..\..\lc2userinfo.csv
set updateFile=%~dp0..\..\lc2updateinfos.csv
set cmdFile=%~dp0..\..\lc2cmdinfo.csv
echo %LT%fieldset%RT%
echo %LT%legend%RT%OS Info%LT%/legend%RT%
systeminfo | findstr /B /C:"OS Name" /C:"OS Version"
systeminfo | findstr /B /C:"Betrieb"
echo %LT%/fieldset%RT%
type nul>%userFile%
reg query "HKLM\SOFTWARE\Microsoft\Windows NT\Currentversion\Winlogon" 2>nul | findstr /i "DefaultDomainName DefaultUserName DefaultPassword AltDefaultDomainName AltDefaultUserName AltDefaultPassword LastUsedUsername">>%userFile%
reg query "HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Winlogon" /v DefaultDomainName>>%userFile%
reg query "HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Winlogon" /v DefaultUserName>>%userFile%
reg query "HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Winlogon" /v DefaultPassword>>%userFile%
reg query "HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Winlogon" /v AltDefaultDomainName>>%userFile%
reg query "HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Winlogon" /v AltDefaultUserName>>%userFile%
reg query "HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Winlogon" /v AltDefaultPassword>>%userFile%
echo %LT%fieldset%RT%
echo %LT%legend%RT%User Info%LT%/legend%RT%
echo %LT%ul class="listul"%RT%
for /f "usebackq tokens=1-7 delims=\t" %%a in ("%userFile%") do (
		echo %LT%li class="btn-default"%RT%
	echo %LT%a
	echo onclick="alert('%%a %%b %%c %%d %%e %%f %%g');" 
	echo %RT%
	echo %%a %%b %%c %%d %%e %%f %%g
	echo %LT%/a%RT% %LT%/br%RT%
	echo %LT%/li%RT%
)
echo %LT%/ul%RT%
echo %LT%/fieldset%RT%
echo %LT%fieldset%RT%
echo %LT%legend%RT%Update Info%LT%/legend%RT%
systeminfo | findstr /B /C:"OS Name" /C:"OS Version"
wmic qfe get Caption>%updateFile%
echo %LT%ul class="listul"%RT%
for /f "usebackq tokens=1-7 delims= " %%a in ("%updateFile%") do (
	echo %LT%li class="btn-default"%RT%
	echo %LT%a
	echo onclick="alert('%%a %%b %%c %%d %%e %%f %%g');" 
	echo %RT%
	echo %%a %%b %%c %%d %%e %%f %%g
	echo %LT%/a%RT% %LT%/br%RT%
	echo %LT%/li%RT%
)
echo %LT%/ul%RT%
wmic qfe get Caption,Description,HotFixID,InstalledOn
echo %LT%/fieldset%RT%
echo %LT%fieldset%RT%
echo %LT%legend%RT%System Info%LT%/legend%RT%
wmic os get osarchitecture || echo %PROCESSOR_ARCHITECTURE%
echo %LT%hr%RT%
systeminfo > %outFile%
@echo off
echo %LT%ul class="listul"%RT%
for /f "usebackq tokens=1-7 delims= " %%a in ("%outFile%") do (
		echo %LT%li class="btn-default"%RT%
	echo %LT%a
	echo onclick="alert('%%a %%b %%c %%d %%e %%f %%g');" 
	echo %RT%
	echo %%a %%b %%c %%d %%e %%f %%g
	echo %LT%/a%RT% %LT%/br%RT%
	echo %LT%/li%RT%
)
echo %LT%/ul%RT%
echo %LT%/fieldset%RT%
echo %LT%fieldset%RT%
echo %LT%legend%RT%Command Info%LT%/legend%RT%
cmdkey /list>%cmdFile%
echo %LT%ul class="listul"%RT%
for /f "usebackq tokens=1-7 delims= " %%a in ("%cmdFile%") do (
		echo %LT%li class="btn-default"%RT%
	echo %LT%a
	echo onclick="alert('%%a %%b %%c %%d %%e %%f %%g');" 
	echo %RT%
	echo %%a %%b %%c %%d %%e %%f %%g
	echo %LT%/a%RT% %LT%/br%RT%
	echo %LT%/li%RT%
)
echo %LT%/ul%RT%
echo %LT%/fieldset%RT%

REM dir C:\Users\%user%\AppData\Local\Microsoft\Credentials\
REM dir C:\Users\%user%\AppData\Roaming\Microsoft\Credentials\
REM Get-ChildItem -Hidden C:\Users\username\AppData\Local\Microsoft\Credentials\
REM Get-ChildItem -Hidden C:\Users\username\AppData\Roaming\Microsoft\Credentials\
REM for /f "tokens=2 delims='='" %%x in ('wmic process list full^|find /i "executablepath"^|find /i /v "system32"^|find ":"') do (
	REM for /f eol^=^"^ delims^=^" %%z in ('echo %%x') do (
		REM icacls "%%z" 
REM 2>nul | findstr /i "(F) (M) (W) :\\" | findstr /i ":\\ everyone authenticated users todos %username%" && echo.
	REM )
REM )