@echo off
cls
call "%cd%\resources\cmd\config.bat"
@echo off
set "dequoteFile=%resdir%\dequoteFile.json"
set "updateshtml=%resdir%\html\updates.html"
set openjs=%LT% script%RT%
set closejs=%LT%/script%RT%
set table=application
set outFile=%table%.csv
echo %LT%div id="showapps_bat" class="container-fluid cm-container-white"%RT%
echo %LT%h2%RT%Applications%LT%/h2%RT%
@REM echo %LT%h4%RT%Menu v.1.01a%LT%/h4%RT%
call "%sexec%" "%dbfile%" "select person_id, url,name,description from %table% order by person_id asc, name asc limit 1000" > %outFile%
echo %LT%select id="showapps_bat_menuinputKey"%RT%
for /f "usebackq tokens=1-5 delims=|" %%a in ("%outFile%") do (
	echo ^<option value="%%b" ^>%%c^</option^>
)
echo %LT%/select%RT%
echo %LT%button type="button" value="search" class="btn btn-default" onclick="eval(document.getElementById('showapps_bat_menuinputKey').value)" %RT%
echo START
echo %LT%/button%RT%
echo %LT%ul class="listul"%RT%
for /f "usebackq tokens=1-4 delims=|" %%a in ("%outFile%") do (
	echo %LT%li%RT%
	echo %LT%a
	REM echo onclick="new HttpRequest().execCMD('%%b', 'cnt')" 
	echo onclick="%%b" 
	echo %RT%%%c%LT%/a%RT%
	echo %LT%/li%RT%
)
echo %LT%/ul%RT%
@REM echo %LT%hr%RT%
echo %LT%h6%RT% Please check %LT%strong%RT%application tab%LT%/strong%RT% for updates. %LT%/h6%RT%
@REM echo %LT%hr%RT%
echo %LT%h6%RT% All Plugins sucessfully loaded. %LT%/h6%RT%
REM type %updateshtml%
REM type %cd%\resources\html\clearbutton.html
REM type %cd%\resources\html\execbutton.html Refresh
REM echo %LT%/div%RT%
echo %LT%/div%RT%
REM @echo on