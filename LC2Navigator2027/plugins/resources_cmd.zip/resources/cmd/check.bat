@echo off
SET "LT=^<"
SET "RT=^>"
set "csvFile=%1"
set css=%2
REM echo %LT%p%RT% %importFile% %LT%/p%RT%
REM echo %LT%h1%RT%Checking requirements%LT%/h1%RT%
echo %LT%ul class="black dlistul"%RT%
for /f "usebackq tokens=1-7 delims=;" %%a in (%checkFile%) do (	
		call %%c>nul 2>&1 && (
			echo %LT%li onclick="alert('%%d','out_cnt')"%RT%%LT%span class="btn btn-success black"%RT%%%a found%LT%/span%RT%%LT%/li%RT%
			call %%c
		) || (
			echo %LT%li onclick="alert('resources\\cmd\\check\\%%e.bat','out_cnt')"%RT%%LT%span class="btn %%d black"%RT%%%a NOT found%LT%/span%RT%%LT%/li%RT%			
			call %~dp0check\%%e %%a
		) 
		
	) 
)
echo %LT%/ul%RT%