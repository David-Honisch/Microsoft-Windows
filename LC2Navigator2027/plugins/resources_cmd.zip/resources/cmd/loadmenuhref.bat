for /f "usebackq tokens=1-4 delims=;" %%a in ("%outFile%") do (	
	echo %LT%a
	REM echo onclick="new HttpRequest().execCMD('exec.bat .\\resources\\plugins\\%%~nb%%~xb %%a', 'core_cnt')" 
	echo onclick="%%c" 
	echo %RT%
	echo %%a
	echo %LT%/a%RT%-%%d %LT%/br%RT%
)