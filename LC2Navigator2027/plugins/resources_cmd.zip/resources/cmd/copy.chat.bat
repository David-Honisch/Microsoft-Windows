@echo off
setlocal

:: Define source and target directories
set "sourceFolder=download"
set "targetFolder=resources\data\chat"

:: Check if source folder exists
if not exist "%sourceFolder%" (
    echo Error: The folder "%sourceFolder%" does not exist.
    pause
    exit /b 1
)

:: Check if target folder exists, create if not
if not exist "%targetFolder%" (
    echo Creating folder: "%targetFolder%"
    md "%targetFolder%"
)

:: Copy all files containing "gespräch" in the source folder to target folder
echo Copying files containing "gespräch" from "%sourceFolder%" to "%targetFolder%"
for /r "%sourceFolder%" %%f in (*.*) do (
    if /i "%%f" neq "%sourceFolder%\*" (
        echo Checking: "%%f"
        if /i "%%~nf" geq "gespräch" (
            echo Copying: "%%f" to "%targetFolder%"
            copy "%%f" "%targetFolder%"
        )
    )
)

echo Done.
REM pause
