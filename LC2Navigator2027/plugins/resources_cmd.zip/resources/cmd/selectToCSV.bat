@echo off
cls
call %cd%\resources\cmd\htmlelem.bat h1 SELECTTOCSV
@echo off
REM echo %LT%div class='container-fluid cm-container-white' %RT%
call %cd%\resources\cmd\update.config.bat h1 SELECTTOCSV
@echo off
set "table=%1"

echo %LINE%
echo %LT%p%RT% Creating %showhtml% %table% %LT%/p%RT%
%sexec% %dbfile% -line -csv "select * from %table% limit 10"
%sexec% %dbfile% -html "select * from %table% limit 10" > %showhtml%
type %showhtml%
@echo off
echo %LINE%
echo %LT%p%RT% eof creating %showhtml% %LT%/p%RT%
echo %LINE%
REM echo call %sexec% %dbfile% "%QUERY%"
REM call %sexec% %dbfile% "%QUERY%"
REM call %sexec% %dbfile% "%QUERY2%"
REM echo %LINE%
REM echo %LT%/div%RT%
@echo on