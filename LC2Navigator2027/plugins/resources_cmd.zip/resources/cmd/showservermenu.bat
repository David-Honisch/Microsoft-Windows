@echo off
cls
call "%cd%\resources\cmd\config.bat"
@echo off
REM @echo on
REM echo offset 
set "dequoteFile=%resdir%\dequoteFile.json"
set "updateshtml=%resdir%\html\updates.html"
set openjs=%LT% script%RT%
set closejs=%LT%/script%RT%
set outFile=application.csv
set table=application
REM set LINEBR=%LT%hr%RT%
REM echo %LT%hr%RT%
REM echo %LT%hr%RT%
REM echo OUT:%outFile%
REM call "%sexec%" "%dbfile%" "select url,name from %table% limit 2" 
call "%sexec%" "%dbfile%" "select person_id, url,name,description from %table% order by name asc,person_id desc limit 1000" > %outFile%
REM @echo on
REM @echo off

REM echo %LT%hr%RT%
REM echo %LT%hr%RT%
echo %LT%h2%RT% Applications Menu v.1.01a %LT%/h2%RT%
echo %LT%hr%RT%
echo %LT%ul class="listul"%RT%
for /f "usebackq tokens=1-4 delims=|" %%a in ("%outFile%") do (
	echo %LT%li%RT%
	echo %LT%a
	REM echo onclick="new HttpRequest().execCMD('%%b', 'cnt')" 
	echo onclick="%%b" 
	echo %RT%
	echo %%c
	echo %LT%/a%RT% %LT%/br%RT%
	echo %LT%/li%RT%
)
echo %LT%/ul%RT%
echo %LT%hr%RT%
echo %LT%h6%RT% Please check %LT%strong%RT%application tab%LT%/strong%RT% for updates. %LT%/h6%RT%
echo %LT%hr%RT%
echo %LT%h6%RT% All Plugins sucessfully loaded. %LT%/h6%RT%
REM type %updateshtml%
type %cd%\resources\html\clearbutton.html
REM type %cd%\resources\html\execbutton.html Refresh
@echo on