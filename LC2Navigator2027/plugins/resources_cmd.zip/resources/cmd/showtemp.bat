@echo off
cls
call %cd%\resources\cmd\htmlelem.bat p SHOW_TEMP
REM @echo on
REM @echo off
set "resdir=%cd%\resources\"
REM set "getlink=%resdir%cmd\getllink.bat"
set "getlink=%resdir%cmd\link.bat"
set "sexec=%resdir%app\sqlite\sqlite3.exe"
set "dbfile=%cd%\release-builds\lc2search-win32-ia32\resources\lc.db"
set "table=plugins"
set "outFile=%resdir%\temp.csv"
set "dequoteFile=%resdir%\dequoteFile.json"
set "updateshtml=%resdir%\html\updates.html"
set openjs=%LT% script%RT%
set closejs=%LT%/script%RT%
REM set LINEBR=%LT%hr%RT%
REM echo %LT%hr%RT%
REM echo %LT%hr%RT%
REM call %sexec% %dbfile% "select url,name from %table% limit 1000" > %outFile%
dir /b /s %temp% > %outFile%
REM @echo on
REM @echo off

REM echo %LT%hr%RT%
echo %LT%hr%RT%
echo %LT%h1%RT% Temp Menu v.0.1a %LT%/h1%RT%
echo %LT%hr%RT%
for /f "usebackq tokens=1-4 delims=|" %%a in ("%outFile%") do (
	echo %LT%a
	REM echo href="#" onclick="new HttpRequest().execCMD('call .\\resources\\cmd\\callnotepad.bat \"%%a\"', 'cli_cnt')" 
	echo onclick="new HttpRequest().execCMD('call .\\resources\\cmd\\callnotepad.bat \"%%a\"', 'cli_cnt')" 
	echo %RT%
	echo X
	echo %LT%/a%RT% %LT%/br%RT%
	
	echo %LT%a
	REM echo href="#" onclick="new HttpRequest().execCMD('call .\\resources\\cmd\\callnotepad.bat \"%%a\"', 'cli_cnt')" 
	REM echo onclick="new HttpRequest().execCMD('type \"%%a\"', 'cli_cnt')" 
	echo onclick="new HttpRequest().execCMD('type < (str_replace.bat %%a \ \\)', 'cli_cnt')"
	REM echo onclick="new HttpRequest().execCMD('type \"
	REM %cd%\resources\cmd\str_replace.bat %%a \ \\
	REM @echo off
	REM echo \"', 'cli_cnt')"
	echo %RT%
	%cd%\resources\cmd\str_replace.bat %%a \ \\
	@echo off
	REM echo %%a
	echo %LT%/a%RT% %LT%/br%RT%
)
echo %LT%hr%RT%
echo %LT%hr%RT%
echo %LT%h6%RT% Sucessfully loaded. %LT%/h6%RT%
REM type %updateshtml%
type %cd%\resources\html\clearbutton.html
@echo off
REM type %cd%\resources\html\execbutton.html Refresh
@echo on