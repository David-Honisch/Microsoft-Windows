@echo off
rem Author:David Honisch
rem ============= PLEASE CONFIGURE THE ENVIRONMENT =============
set plugin=%1
set "_os=64"
if "%PROCESSOR_ARCHITECTURE%"=="x86" (if not defined PROCESSOR_ARCHITEW6432 set "_os=32")
call %cd%\resources\cmd\setregvalue.bat "hkey_current_user\software\letztechance.org\LC2Navigator2024\plugins\%plugin%" "user" "%username%" > nul
call %cd%\resources\cmd\setregvalue.bat "hkey_current_user\software\letztechance.org\LC2Navigator2024\plugins\%plugin%" "password" "xxx" > nul
call %cd%\resources\cmd\setregvalue.bat "hkey_current_user\software\letztechance.org\LC2Navigator2024\plugins\%plugin%" "server" "localhost" > nul
call %cd%\resources\cmd\setregvalue.bat "hkey_current_user\software\letztechance.org\LC2Navigator2024\plugins\%plugin%" "instance" "test"> nul
call %cd%\resources\cmd\setregvalue.bat "hkey_current_user\software\letztechance.org\LC2Navigator2024\plugins\%plugin%" "port" "1433"> nul
call %cd%\resources\cmd\setregvalue.bat "hkey_current_user\software\letztechance.org\LC2Navigator2024\plugins\%plugin%" "dbfinal" "masterdatalivecopy"> nul
call %cd%\resources\cmd\setregvalue.bat "hkey_current_user\software\letztechance.org\LC2Navigator2024\plugins\%plugin%\author" "author" "david honisch"> nul
call %cd%\resources\cmd\setregvalue.bat "hkey_current_user\software\letztechance.org\LC2Navigator2024\plugins\%plugin%" "author" "david honisch"> nul
call %cd%\resources\cmd\setregvalue.bat "hkey_current_user\software\letztechance.org\LC2Navigator2024\plugins\%plugin%" "time" "%time%"> nul
call %cd%\resources\cmd\setregvalue.bat "hkey_current_user\software\letztechance.org\LC2Navigator2024\plugins\%plugin%" "os" "%_os%"> nul
call %cd%\resources\cmd\setregvalue.bat "hkey_current_user\software\letztechance.org\LC2Navigator2024\plugins\%plugin%" "version" "%version%" > nul
call %cd%\resources\cmd\setregvalue.bat "hkey_current_user\software\letztechance.org\LC2Navigator2024\plugins\%plugin%" "plugin" "%plugin%"> nul
echo Registered User:
call %cd%\resources\cmd\getregvalue.bat "HKEY_CURRENT_USER\SOFTWARE\LETZTECHANCE.ORG\LC2Navigator2024\plugins\%plugin%" "user"
echo /OS:
call %cd%\resources\cmd\getregvalue.bat "HKEY_CURRENT_USER\SOFTWARE\LETZTECHANCE.ORG\LC2Navigator2024\plugins\%plugin%" "os"
echo /Bit
echo /Database User:
call %cd%\resources\cmd\getregvalue.bat "HKEY_CURRENT_USER\SOFTWARE\LETZTECHANCE.ORG\LC2Navigator2024\plugins\%plugin%" "server"
echo /Instance:
call %cd%\resources\cmd\getregvalue.bat "HKEY_CURRENT_USER\SOFTWARE\LETZTECHANCE.ORG\LC2Navigator2024\plugins\%plugin%" "instance"
echo /Port:
call %cd%\resources\cmd\getregvalue.bat "HKEY_CURRENT_USER\SOFTWARE\LETZTECHANCE.ORG\LC2Navigator2024\plugins\%plugin%" "port"
@echo off
REM echo ^<br^>Registered Plugin:
call %cd%\resources\cmd\getregvalue.bat "hkey_current_user\software\letztechance.org\LC2Navigator2024\plugins\%plugin%" "plugin"
REM @echo off
REM echo ^<strong^>
REM call %cd%\resources\cmd\getregvalue.bat "hkey_current_user\software\letztechance.org\LC2Navigator2024\plugins\%plugin%" "version"
REM @echo off
REM echo ^</strong^>