@echo off
SET "LT=^<"
SET "RT=^>"
set css=%2
@REM echo %LT%h1%RT% %outFile% %LT%/h1%RT%
echo %LT%ul class="listul"%RT%
for /f "usebackq tokens=1-5 delims=;" %%a in ("%outFile%") do (	
    echo %LT%li%RT%
	echo %LT%input
	echo type="button" value="%%a" onclick="if(getConfirmation('Start %%c now?')){execCMD('start %%c','pluginresult')};" class="btn btn-info %css%" 
	echo /%RT%%LT%%%dbr/%RT%%%d%LT%br/%RT%
	echo %LT%/li%RT%
)