@echo off
call %~dp0config.bat
@echo off
SET TITLE=%1
SET HREF=%2
SET HREFTARGET=%3
REM echo %LT%a href="%HREF%" target="%HREFTARGET%"%RT%%TITLE%%LT%/a%RT%
REM getOpenDialog('#importGUI_cnt', '.\\assets\\html\\dialog\\install.html', 'Check Installation and Configuration', { top: 100, left: 100, minWidth: 250, margin: 0, minHeight: 150, width: 400, height: 400 });
echo %LT%a onclick="getOpenDialog('%HREFTARGET%', '%HREF%', '%HREF%', { left: 10, minWidth: 250, margin: 0, minHeight: 150, width: 400, height: 400 });"%RT%%TITLE%%LT%/a%RT%