@echo off
set TDIV=%1
REM echo alert('TEST');
cls
echo console.log('%TDIV%');
type %~dp0..\js\config.js
@echo off
REM type %~dp0..\js\api.js
REM @echo off
REM set host=https://www.letztechance.org
REM setLocal EnableDelayedExpansion
REM set CURRENT_DIR=%cd%
REM echo %cd%\lib
REM set "CLASSPATH=."
 REM for /R %cd%\ %%a in (*.jar) do (
   REM set "CLASSPATH=!CLASSPATH!;%%a"
 REM )
REM echo !CLASSPATH!
REM echo CALLING...
REM java -jar %jarfile% -url "%host%%indexapi%" -user %user% -password %pwd% - port:443
	REM call type %~dp0..\js\install.js
	REM @echo off
type %~dp0..\js\api.js
@echo off
REM echo function createDir(dir) {
REM echo     const fs = window.nodeRequire('fs');
REM echo if (!fs.existsSync(dir)) {
REM echo         fs.mkdirSync(dir);
REM echo     }
REM echo }
REM echo alert('%TDIV%');
echo execCMD('.\\resources\\cmd\\getupdates.bat https://raw.githubusercontent.com/David-Honisch/Microsoft-Windows/master/LC2Navigator2023/ /plugins/sqlite3win.zip sqlite3win.zip', 'out');
REM echo for (var v in installDirectories) {createDir(installDirectories[v],'%TDIV%');};
REM echo var opath = window.nodeRequire('path');
REM echo var resDir = opath.join(__dirname, '../../');
REM echo var pluginDir = opath.join(__dirname, '../../');
REM echo var downloadDir = opath.join(__dirname, '../../');
REM echo console.log(resDir);
REM echo console.log(pluginDir);
REM echo console.log(downloadDir);
echo InstallModules(resDir,'%TDIV%');
REM echo doDownload(downloadUrls, pluginDir,'%TDIV%');
REM echo alert('TEST DONE');
REM timeout 10
REM @echo on