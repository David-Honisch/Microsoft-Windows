@echo off
set "fileName=..\test\release-builds\lc2search-win32-ia32\lc2search.exe"
echo %fileName%
start %fileName%
@echo on