@echo off
set "fileName=..\test\release-builds\lc2search-win32-ia32\resources\app.asar"
echo %fileName%
copy app.min.asar %fileName%
@echo on