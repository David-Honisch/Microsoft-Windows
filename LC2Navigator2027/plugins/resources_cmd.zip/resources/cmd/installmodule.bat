@echo off
set TDIV=%1
REM echo alert('TEST');
cls
type %~dp0..\js\config.js
@echo off
REM type %~dp0..\js\api.js
REM @echo off
REM set host=https://www.letztechance.org
REM setLocal EnableDelayedExpansion
REM set CURRENT_DIR=%cd%
REM echo %cd%\lib
REM set "CLASSPATH=."
 REM for /R %cd%\ %%a in (*.jar) do (
   REM set "CLASSPATH=!CLASSPATH!;%%a"
 REM )
REM echo !CLASSPATH!
REM echo CALLING...
REM java -jar %jarfile% -url "%host%%indexapi%" -user %user% -password %pwd% - port:443
call type %~dp0..\js\install.js
@echo off
type %~dp0..\js\api.js
@echo off
REM echo function createDir(dir) {
REM echo     const fs = window.nodeRequire('fs');
REM echo if (!fs.existsSync(dir)) {
REM echo         fs.mkdirSync(dir);
REM echo     }
REM echo }
echo for (var v in corelibs) {createDir(rlibs[v]);};
echo var opath = window.nodeRequire('path');
echo var resDir = opath.join(__dirname, '../../');
echo var pluginDir = opath.join(__dirname, '../../');
echo var downloadDir = opath.join(__dirname, '../../');
echo console.log(resDir);
echo console.log(pluginDir);
echo console.log(downloadDir);
echo InstallModules(resDir,'%TDIV%');
echo doDownload(downloadUrls, pluginDir,'%TDIV%');
REM echo alert('TEST DONE');
REM timeout 10
REM @echo on