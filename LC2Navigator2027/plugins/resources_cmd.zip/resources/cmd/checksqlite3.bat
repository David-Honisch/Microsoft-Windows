@echo off
cls
call "%cd%\resources\cmd\config.bat"
@echo off
call "%cd%\resources\cmd\getupdates.bat" /plugins/sqlite3win.zip sqlite3win.zip
@echo off
