@echo off 
set str=%1
REM echo %str%
set str=%str:\=\\% 
echo %str%
call %~dp0 dequote.bat %str%
REM SET string=%1
REM SET modified=%string:\=\\%
REM ECHO %string%
REM ECHO %modified%