@echo off
SETLOCAL
call %cd%\resources\cmd\config.bat h5 UPDATECONFIG
@echo off
REM set SQLFILE=%1
cls
set "BR=%LT%hr%RT%"
set LINE==================================
REM set SQLFILE=%1
set IMPORTFILE=%1
set table=%2
set btable=%2_bin
set "resdir=%cd%\resources\"
REM set "sexec=%resdir%app\sqlite\sqlite3.exe"
REM set "sexec=%cd%\sqlite3.exe"
REM set "dbfile=%cd%\release-builds\lc2search-win32-ia32\resources\lc.db"
REM set "dbfile=%cd%\lc.db"
echo Creating table %table%
SET "QUERY=select * from %table% limit 1000000;"
SET "QUERY2=INSERT INTO %table% (name) values ('Test');"
set "RPATH=https://raw.githubusercontent.com/David-Honisch/Microsoft-Windows/master/LC2Navigator2019/"
call %cd%\resources\cmd\htmlelem.bat h1 IMPORT
@echo off

REM echo %LT%div class='container-fluid cm-container-white' %RT%

REM @echo off
echo %LT%hr%RT%
REM echo %SQLFILE%
REM echo 
echo IMPORTFILE:%IMPORTFILE%
echo %LT%hr%RT%
echo %LT%hr%RT%
echo READING CSV %table%
echo %LT%hr%RT%
call %sexec% %dbfile% -csv "CREATE TABLE %btable% ("person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,name varchar(255) not null, path varchar(255) not null, description varchar(255) not null, url blob);"
call %sexec% %dbfile% -csv "CREATE TABLE %table% ( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT(255,0) NOT NULL, "first_name" TEXT(255,0) NULL, "description" TEXT(255,0) NULL, "zipcode" TEXT(255,0) NULL, "city" TEXT(255,0) NULL,	 "street" TEXT(255,0) NULL,	 "url" TEXT(255,0) NULL);"
call %sexec% %dbfile% -csv "INSERT INTO systables(name,first_name, description,url)VALUES('%btable%','menu.bat','menu.bat','menu.bat');"
call %sexec% %dbfile% -csv "INSERT INTO systables(name,first_name, description,url)VALUES('%table%','menu.bat','menu.bat','menu.bat');"
REM sqlite3.exe -csv logsql.sqlite "SELECT local_port AS port, COUNT(local_port) AS hitcount FROM connections  WHERE connection_type = 'accept' GROUP BY local_port ORDER BY hitcount DESC;" > output.csv
REM %sexec% %dbfile% -csv test.sqlite "CREATE TABLE test (name varchar(255) not null, blah varchar(255) not null);" .import ./output.csv test
REM echo call %sexec% %dbfile% -csv "DROP TABLE %btable%;"
REM call %sexec% %dbfile% -csv "DROP TABLE %btable%;"

REM timeout 3
echo %LT%hr%RT%%LT%hr%RT%
echo Importing %table%
echo %LT%hr%RT%%LT%hr%RT%
for /f "usebackq tokens=1-4 delims=," %%a in ("%IMPORTFILE%") do (
	  REM %sexec% %dbfile% -csv "INSERT INTO %btable%(name,path, mime,content) VALUES('%%~na','%%~da%%~pa','%%~xa',REPLACE('%%a','\','\\'));"
	  REM @echo off
	  %sexec% %dbfile% -csv "INSERT INTO %table%(first_name,name, description,url) VALUES('%%~na','%%~da%%~pa','%%~xa',REPLACE('%%a','\','\\'));"
	  @echo off
	  %sexec% %dbfile% -csv "INSERT INTO %btable%(name,path, description,url) VALUES('%%~na','%%~da%%~pa%%~na','%%~xa',readfile('%%a'));"
	  @echo off	
)
REM timeout 3
echo %LT%hr%RT%%LT%hr%RT%
echo Importing files done
echo %LT%hr%RT%%LT%hr%RT%

REM echo %LT%hr%RT%%LT%hr%RT%
call %sexec% %dbfile% -csv "select 'COUNT:'|| count(*) from %table%;"
call %sexec% %dbfile% -csv "select 'COUNT:'|| count(*) from %table%;"
REM echo %LT%hr%RT%%LT%hr%RT%
REM call %sexec% %dbfile% -csv "select 'COUNT:'||count(*) from files;"

REM echo %LT%hr%RT%
REM echo call %sexec% %dbfile% -csv "select name from files limit 1000;"
REM echo %LT%hr%RT%
REM call %sexec% %dbfile% -csv "select path||name||mime from files limit 1000;"



REM @echo off
REM echo 
REM echo %LT%p%RT%IMPORTING %cd%\%UPDATEFILE% DONE %LT%/p%RT%
REM echo 
type %resdir%\html\clearbutton.html
REM type %resdir%\html\execbutton.html EXECUTE
REM call %resdir%\cmd\htmlelem.bat h5 IMPORT_DONE
REM @echo off
REM echo 
REM echo 

REM echo %LT%/div%RT%
@echo on