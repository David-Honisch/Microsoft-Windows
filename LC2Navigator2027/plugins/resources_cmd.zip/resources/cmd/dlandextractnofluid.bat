@echo off
cls
call %cd%\resources\cmd\htmlelem.bat h1 DLEXTRACT
@echo off
REM echo %LT%div class='container-fluid cm-container-white' %RT%
call %cd%\resources\cmd\update.config.bat h1 UPDDATECONFIG_DLEXTRACT
@echo off
set RPATH=%1
set UPDATEFILE=%2
set XUPDATEFILE=%3
echo %LT%p%RT% MENU %LT%/p%RT%
call %cd%\resources\cmd\getlnk.bat menu.bat menu.bat appcnt
@echo off
echo %LT%br/%RT%
call %cd%\resources\cmd\getlnk.bat %RPATH%%UPDATEFILE% %RPATH%%UPDATEFILE% appcnt
@echo off
echo %LT%p%RT% EOF MENU %LT%/p%RT%
echo %LINE%
echo %LT%p%RT% DELETING %UPDATEFILE%  %LT%/p%RT%
echo %LINE%
DEL %UPDATEFILE%
echo %LT%p%RT% DOWNLOADING %RPATH%%UPDATEFILE% %LT%/p%RT%
echo %LT%p%RT% AND WRITING TO %cd%\%UPDATEFILE% %LT%/p%RT%
echo %LINE%
if exist "%NODOWNLOAD%" (
	echo %LT%h1%RT%Download NOT accepted%LT%/h1%RT%
) else (
	echo %LT%h1%RT%Download accepted%LT%/h1%RT%
	call %cd%\resources\cmd\dl.bat "%RPATH%%UPDATEFILE%"  true autodownload
	@echo off
)
echo %LT%h1%RT% Extraction in progress... %LT%/h1%RT%
echo FILE:%XUPDATEFILE%
if exist "%NOEXTRACT%" (
	echo %LT%h1%RT%Extraction NOT accepted%LT%/h1%RT%
) else (
    echo %LT%h1%RT%Extraction accepted %LT%/h1%RT%
	echo %LT%h5%RT% call lc2extract "%cd%\%XUPDATEFILE%" %LT%/h5%RT%
	call lc2extract "%cd%\%XUPDATEFILE%"
	@echo off
	REM echo %LT%h1%RT% call extract "%cd%\%XUPDATEFILE%" %LT%/h1%RT%
	REM call extract "%cd%\%XUPDATEFILE%"
	REM @echo off
)
echo %LT%h1%RT%Extraction done.%LT%/h1%RT%
echo %LINE%
@echo on