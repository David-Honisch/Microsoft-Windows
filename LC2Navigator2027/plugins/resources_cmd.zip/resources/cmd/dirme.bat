@echo off
setlocal enabledelayedexpansion
rem Create a temporary HTML file
set "htmlFile=%temp%\Drives.html"
rem Start the HTML file
echo ^<html^> > "%htmlFile%"
echo ^<head^> >> "%htmlFile%"
echo ^<title^>Drive Buttons^</title^> >> "%htmlFile%"
echo ^</head^> >> "%htmlFile%"
echo ^<body^> >> "%htmlFile%"
rem Loop through all drives
for /f "tokens=1" %%i in ('wmic logicaldisk get caption') do (
if "%%i" neq "Caption" (
rem Create a button for each drive
echo ^<button onclick="alert('You clicked on drive %%i!')">Drive %%i^</button>^<br^> >> "%htmlFile%"
)
)
rem End the HTML file
echo ^</body^> >> "%htmlFile%"
echo ^</html^> >> "%htmlFile%"
rem Open the HTML file
start "" "%htmlFile%"
echo HTML file created and opened.
endlocal