echo ^<style^>
echo     .logo {
echo         background: #FFFFFF url(../../../resources/img/logo.png) center;
echo         background-repeat: no-repeat;
echo         background-size: 200px 150px;
echo     }
echo ^</style^>
echo ^<h4^>Main Menu %version%^</h4^>
echo ^<ul id="myTab" class="nav nav-tabs" role="tablist"^>