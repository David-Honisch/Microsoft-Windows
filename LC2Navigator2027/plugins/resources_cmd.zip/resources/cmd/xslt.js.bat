@echo off
type %~dp0..\js\xslt.js
set source=%1
set target=%2
set divid=%3
echo var source = "%source%";
echo var target = "%target%";
echo var divid = "%divid%";
echo var outXmlString = getXsltProcess(source, target);
echo console.log(outXmlString);
type %~dp0..\js\xsltout.js
echo printXSLT(divid, outXmlString);