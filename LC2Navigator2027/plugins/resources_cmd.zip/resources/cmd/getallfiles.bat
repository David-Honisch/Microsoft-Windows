@echo off
SET "LT=^<"
SET "RT=^>"
set outFile=%cd%\resources\data\hdds.csv
echo get all files now^<br^>
echo %LT%ul class="listul"%RT%
for /f "usebackq tokens=1-5 delims=;" %%a in ("%outFile%") do (		
    echo %LT%li%RT%
	REM echo call dir /b /s %%a:\*.* > %cd%\resources\data\%%~an_HDD.csv
	REM call dir /b /s %%a:\*.* > %cd%\resources\data\%%~an_HDD.csv
	echo %LT%input
	echo type="button" value="Drive: %%a" onclick="new HttpRequest().execCMD('type .\\resources\\data\\%%~an_HDD.csv','allfiles');" 
	echo /%RT%%LT%br/%RT%%%d%LT%br/%RT%
	echo %LT%/li%RT%
)
echo %LT%div id="allfiles"%RT%.%LT%/div%RT%
echo ^<br^>get all files done.
timeout 3