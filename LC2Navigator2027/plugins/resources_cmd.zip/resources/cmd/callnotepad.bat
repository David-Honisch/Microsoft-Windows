@echo off
echo call notepad %1
call notepad "%1"
echo call notepad %1 done.
@echo on