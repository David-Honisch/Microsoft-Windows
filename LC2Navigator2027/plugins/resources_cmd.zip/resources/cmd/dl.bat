@echo off
call "%cd%\resources\cmd\config.bat"
@echo off
set XUPDATEFILE=%1
set XTARGETFILE=%2
REM echo %LT%h2%RT% CONFIG LOADED %LT%/h2%RT%
REM echo %LINE%
REM echo %LINE%
REM echo %LINE%
echo %LT%p%RT%DOWNLOADING FILE %LT%a onclick="openBrowser('%RPATH%%XUPDATEFILE%');"%RT%%XUPDATEFILE%%LT%/a%RT%  %LT%/p%RT%
echo %LT%p%RT%TO:%LT%strong%RT%%XTARGETFILE%%LT%/strong%RT% %LT%/p%RT%
REM echo call %cd%\LC2DL.exe "%RPATH%%XUPDATEFILE%" %XTARGETFILE%  true autodownload
call %cd%\LC2DL.exe "%RPATH%%XUPDATEFILE%" %XTARGETFILE%  true autodownload
@echo off
if not ERRORLEVEL 1 (
REM @echo off
echo %LT%h6%RT%Oh, the download or auto extraction may be failed %LT%/h6%RT%
REM exit /b 1
)
if ERRORLEVEL 1 (
REM @echo off
echo %LT%h2%RT%Successfully downloaded and extracted %LT%/h2%RT%
)
REM echo %LINE%
echo %LT%p%RT%DOWNLOAD %LT%strong%RT%%LT%/strong%RT% %LT%strong%RT%DONE%LT%/strong%RT% %LT%/p%RT%
REM echo %LINE%
REM @echo off