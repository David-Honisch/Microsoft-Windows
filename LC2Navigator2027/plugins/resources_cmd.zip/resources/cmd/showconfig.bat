@echo off
cls
call %cd%\resources\cmd\htmlelem.bat h1 SHOW_CONFIG_v.1.0
type %cd%\resources\html\config.html
echo %LINE%
type %cd%\resources\html\clearbutton.html
type %cd%\resources\html\execbutton.html Refresh
@echo on