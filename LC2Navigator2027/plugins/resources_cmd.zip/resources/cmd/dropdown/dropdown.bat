echo    ^<li role="presentation" class="dropdown"^>
echo        ^<a href="#" id="myTabDrop1" class="dropdown-toggle" data-toggle="dropdown" aria-controls="myTabDrop1-contents" aria-expanded="false"^>API ^<span class="caret"^>^</span^>^</a^>
echo        ^<ul class="dropdown-menu" role="menu" aria-labelledby="myTabDrop1" id="myTabDrop1-contents"^>
for /f "usebackq tokens=1-5 delims=;" %%a in ("%~dp0..\dropdown.csv") do (
			call %~dp0items\%%a
)
REM echo            ^<li^>^<a href="#dropdown1" tabindex="-1" role="tab" id="dropdown1-tab" data-toggle="tab" aria-controls="dropdown1"^>@coming soon^</a^>^</li^>
REM echo            ^<li^>^<a href="#dropdown2" tabindex="-1" role="tab" id="dropdown2-tab" data-toggle="tab" aria-controls="dropdown2"^>@update coming soon.^</a^>^</li^>
echo        ^</ul^>
echo    ^</li^>
