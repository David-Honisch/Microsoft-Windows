@echo off
setlocal
call "%~dp0config.bat"
set QUERY=%1
echo Database
call "%sexec%" "%QUERY%" "select name||'<br>' from %QUERY%"
endlocal