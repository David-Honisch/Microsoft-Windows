@echo off
cls
call "%cd%\resources\cmd\config.bat"
@echo off
set QUERY=%1
echo Database
call "%sexec%" "%QUERY%" "select name||'<br>' from %QUERY%"
@echo on