@echo off
set "link=%1"
set "linktitle=%2"
set contentid=%3
SET "LT=^<"
SET "RT=^>"
REM echo %LT%a href="#%link%" onclick="new HttpRequest().execCMD('%link%', '%contentid%')" %RT%
echo %LT%a href="#" onclick="new HttpRequest().execCMD('%link%', '%contentid%')" %RT%
echo %linktitle%
echo %LT%/a%RT%
@echo on