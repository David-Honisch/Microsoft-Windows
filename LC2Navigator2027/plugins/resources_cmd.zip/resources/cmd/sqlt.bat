@echo off
cls
call "%cd%\resources\cmd\config.bat" h1 IMPORT
@echo off
set SQLFILE=%1
echo %LT%h2%RT% INIT SQL IMPORT%LT%/h2%RT%
echo call "%sexec%" "%dbfile%" "%SQLFILE%"
REM call "%sexec%" "%dbfile%" "select person_id,url,name from %table% order by name asc, person_id desc limit 1000"
echo call "%sexec%" "%dbfile%" %SQLFILE%
call "%sexec%" "%dbfile%" %SQLFILE%
@echo off
@echo on