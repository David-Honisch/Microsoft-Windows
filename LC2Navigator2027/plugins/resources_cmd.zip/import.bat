@echo off
menu.bat
@echo on