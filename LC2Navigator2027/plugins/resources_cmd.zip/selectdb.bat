@echo off
cls
call "%cd%\resources\cmd\config.bat"
@echo off
set QUERY=%1
set dbfile=resources\lc.db
REM call "%sexec%" "%dbfile%" "select name||'<br>' from %QUERY%"
call "%sexec%" "%dbfile%" %QUERY%