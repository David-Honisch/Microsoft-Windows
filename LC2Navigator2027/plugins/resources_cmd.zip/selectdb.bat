@echo off
cls
call "%cd%\resources\cmd\config.bat"
@echo off
set QUERY=%1
set "exec=%cd%\resources\app\sqlite\SQLite3.exe"
REM call "%sexec%" "%dbfile%" "select name||'<br>' from %QUERY%"
REM echo call "%sexec%" "%dbfile%" %QUERY%
call "%sexec%" "%dbfile%" %QUERY%
@echo on