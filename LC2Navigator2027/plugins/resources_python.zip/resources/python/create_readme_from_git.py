import requests
import markdown
import sys

def fetch_repo_data(repo_url):
	response = requests.get(repo_url)
	if response.status_code == 200:
		return response.json()
	else:
		raise Exception(f"Failed to fetch repository data: {response.status_code}")

def get_repo_details(repo_data):
	details = {
	"name": repo_data["name"],
	"description": repo_data["description"],
	"url": repo_data["html_url"],
	"stargazers_count": repo_data["stargazers_count"],
	"forks_count": repo_data["forks_count"],
	"open_issues_count": repo_data["open_issues_count"],
	"language": repo_data["language"],
	"license": repo_data.get("license", {}).get("name", "No License"),
	"created_at": repo_data["created_at"],
	"updated_at": repo_data["updated_at"],
	}
	return details
def generate_readme(repo_details):
	md_content = f"""
	# {repo_details['name']}
	{repo_details['description']}
	## Table of Contents
	- [Repository Details](#repository-details)
	- [License](#license)
	- [Contributing](#contributing)
	- [License](#license)
	## Repository Details
	- **URL**: [{repo_details['name']}]({repo_details['url']})
	- **Stars**: {repo_details['stargazers_count']}
	- **Forks**: {repo_details['forks_count']}
	- **Open Issues**: {repo_details['open_issues_count']}
	- **Language**: {repo_details['language']}
	- **License**: {repo_details['license']}
	- **Created At**: {repo_details['created_at']}
	- **Updated At**: {repo_details['updated_at']}
	## License
	This project is licensed under the {repo_details['license']}.
	## Contributing
	Contributions are welcome! Please read our [CONTRIBUTING.md](CONTRIBUTING.md) for details on how to contribute.
	## License
	This project is licensed under the {repo_details['license']}.
	"""
	return markdown.markdown(md_content)

def main():
	if len(sys.argv) != 2:
		print("Usage: python create_readme_from_git.py <github_repo_url>")
		sys.exit(1)
	repo_url = sys.argv[1]
	print("Fetching repository data...")
	repo_data = fetch_repo_data(repo_url)
	print("Fetching repository details...")
	repo_details = get_repo_details(repo_data)
	print("Generating README content...")
	readme_content = generate_readme(repo_details)
	with open("README.md", "w") as readme_file:
		readme_file.write(readme_content)
		print("README.md generated successfully!")

if __name__ == "__main__":
	main()