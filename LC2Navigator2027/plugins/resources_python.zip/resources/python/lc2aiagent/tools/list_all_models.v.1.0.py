import json
from transformers import AutoModelForCausalLM, AutoTokenizer

def export_models_to_json(model_names, filename="models_info.json"):
    models_data = []
    
    for name in model_names:
        print(f"Lade Informationen für: {name}...")
        try:
            # Nur Konfiguration laden, um Ressourcen zu sparen
            model = AutoModelForCausalLM.from_pretrained(name, device_map="cpu", torch_dtype="auto")
            tokenizer = AutoTokenizer.from_pretrained(name)
            
            # Wichtige Metadaten extrahieren
            model_info = {
                "model_id": name,
                "architectures": getattr(model.config, "architectures", "Unbekannt"),
                "model_type": getattr(model.config, "model_type", "Unbekannt"),
                "vocab_size": getattr(model.config, "vocab_size", 0),
                "hidden_size": getattr(model.config, "hidden_size", 0),
                "num_layers": getattr(model.config, "num_hidden_layers", 0),
                "max_seq_length": getattr(model.config, "max_position_embeddings", 0),
                "tokenizer_class": tokenizer.__class__.__name__
            }
            models_data.append(model_info)
            
        except Exception as e:
            print(f"Fehler bei Modell '{name}': {e}")
            models_data.append({"model_id": name, "error": str(e)})

    # Speichern der Liste als JSON
    with open(filename, "w", encoding="utf-8") as f:
        json.dump(models_data, f, indent=4, ensure_ascii=False)
    
    print(f"\nFertig! Die Daten wurden in '{filename}' gespeichert.")

if __name__ == "__main__":
    # Liste der gewünschten Modelle
    target_models = ["gpt2", "facebook/opt-125m", "distilgpt2"]
    
    export_models_to_json(target_models)