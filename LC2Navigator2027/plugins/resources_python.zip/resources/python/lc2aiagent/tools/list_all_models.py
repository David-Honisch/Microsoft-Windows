import json
from huggingface_hub import HfApi
from tqdm import tqdm

def export_all_hf_models(output_file="all_huggingface_models.json"):
    api = HfApi()
    
    print("Rufe Modell-Liste vom Hugging Face Hub ab...")
    # list_models() gibt einen Iterator zurück, um den Speicher zu schonen
    # 'full=False' lädt nur Basis-Metadaten (schneller)
    models_iterator = api.list_models(full=False)
    
    models_list = []
    
    # tqdm zeigt einen Fortschrittsbalken an
    for model in tqdm(models_iterator, desc="Modelle werden erfasst"):
        model_data = {
            "id": model.id,
            "author": model.author,
            "last_modified": str(model.last_modified) if hasattr(model, 'last_modified') else None,
            "tags": model.tags if hasattr(model, 'tags') else [],
            "pipeline_tag": getattr(model, "pipeline_tag", None),
            "private": getattr(model, "private", False),
        }
        models_list.append(model_data)

    print(f"\nSpeichere {len(models_list)} Modelle in {output_file}...")
    with open(output_file, "w", encoding="utf-8") as f:
        json.dump(models_list, f, indent=2, ensure_ascii=False)
    
    print("Export abgeschlossen.")

if __name__ == "__main__":
    export_all_hf_models()