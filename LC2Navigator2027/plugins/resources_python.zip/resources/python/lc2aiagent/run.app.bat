@echo off
REM call py app.py 5000 "openai-community/gpt2"
REM call py app.py 5000 "openai/whisper-large-v3-turbo"
call py app.py 5000 "qwen-coder"