import argparse
import torch
from transformers import AutoModelForCausalLM, AutoTokenizer
# Load pre-trained model and tokenizer
model_name = "gpt2" # You can choose other models like "gpt3" or "bert"
tokenizer = AutoTokenizer.from_pretrained(model_name)
model = AutoModelForCausalLM.from_pretrained(model_name)
# Set the model to evaluation mode
model.eval()
# Function to generate text
def generate_text(prompt, max_length=50, num_return_sequences=1):
    # Tokenize the input prompt
    inputs = tokenizer(prompt, return_tensors="pt", max_length=max_length, truncation=True)
    # Generate text
    with torch.no_grad():
        outputs = model.generate(**inputs, max_length=max_length, num_return_sequences=num_return_sequences)
        # Decode and return the generated text
        generated_texts = [tokenizer.decode(output, skip_special_tokens=True) for output in outputs]
        return generated_texts
# CLI function
def cli():
    parser = argparse.ArgumentParser(description="Text Generation CLI Agent")
    parser.add_argument("prompt", type=str, help="Input prompt for text generation")
    parser.add_argument("--max_length", type=int, default=50, help="Maximum length of generated text")
    parser.add_argument("--num_return_sequences", type=int, default=1, help="Number of generated sequences")
    args = parser.parse_args()
    generated_texts = generate_text(args.prompt, args.max_length, args.num_return_sequences)
    for text in generated_texts:
        print(text)
if __name__ == "__main__":
    cli()