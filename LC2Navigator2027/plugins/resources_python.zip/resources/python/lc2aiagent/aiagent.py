import argparse
import torch
from utils.logger import get_logger, log_prompt
from transformers import AutoModelForCausalLM, AutoTokenizer

# Modell laden
model_name = "gpt2"
tokenizer = AutoTokenizer.from_pretrained(model_name)
model = AutoModelForCausalLM.from_pretrained(model_name)

# GPT-2 hat kein standardmäßiges Pad-Token, daher setzen wir es auf das End-of-String Token
tokenizer.pad_token = tokenizer.eos_token
model.config.pad_token_id = model.config.eos_token_id

model.eval()

def generate_text(prompt, max_length=50, num_return_sequences=1):
    # Tokenize input
    inputs = tokenizer(prompt, return_tensors="pt")
    
    # Generierung mit modernem Standard (do_sample für Vielfalt)
    with torch.no_grad():
        outputs = model.generate(
            **inputs, 
            max_new_tokens=max_length, # Nutze max_new_tokens statt max_length für bessere Kontrolle
            num_return_sequences=num_return_sequences,
            do_sample=True,            # Ermöglicht kreativere Texte
            top_k=50, 
            top_p=0.95,
            pad_token_id=tokenizer.eos_token_id
        )
    
    return [tokenizer.decode(output, skip_special_tokens=True) for output in outputs]

def cli():
    parser = argparse.ArgumentParser(description="Text Generation CLI Agent")
    parser.add_argument("prompt", type=str, help="Input prompt")
    parser.add_argument("model", type=str, help="Input model e.g. openai-community/gpt2")
    parser.add_argument("--max_length", type=int, default=50, help="Länge der generierten Antwort")
    parser.add_argument("--num_return_sequences", type=int, default=1, help="Anzahl der Varianten")
    
    args = parser.parse_args()
    model_name = args.model
    
    generated_texts = generate_text(args.prompt, args.max_length, args.num_return_sequences)
    
    for i, text in enumerate(generated_texts, 1):
        print(f"\n--- Variante {i} ---\n{text}")
        log_prompt(f"\n--- Variante {i} ---\n{text}") # Log the prompt with timestamp

if __name__ == "__main__":
    cli()