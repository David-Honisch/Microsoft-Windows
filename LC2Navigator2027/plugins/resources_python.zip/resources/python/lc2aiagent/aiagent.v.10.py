import torch
from transformers import AutoModelForCausalLM, AutoTokenizer
# Load pre-trained model and tokenizer
model_name = "gpt2" # You can choose other models like "gpt3" or "bert"
tokenizer = AutoTokenizer.from_pretrained(model_name)
model = AutoModelForCausalLM.from_pretrained(model_name)
# Set the model to evaluation mode
model.eval()
# Function to generate text
def generate_text(prompt, max_length=50, num_return_sequences=1):
# Tokenize the input prompt
    inputs = tokenizer(prompt, return_tensors="pt", max_length=max_length, truncation=True)
    # Generate text
    with torch.no_grad():
        outputs = model.generate(**inputs, max_length=max_length, num_return_sequences=num_return_sequences)
        # Decode and return the generated text
        generated_texts = [tokenizer.decode(output, skip_special_tokens=True) for output in outputs]
        return generated_texts
# Example usage
prompt = "Once upon a time"
generated_texts = generate_text(prompt)
for text in generated_texts:
    print(text)