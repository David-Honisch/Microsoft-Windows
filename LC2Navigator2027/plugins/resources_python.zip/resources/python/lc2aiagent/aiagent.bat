REM python aiagent.py %1 "openai-community/gpt2" --max_length 400 --num_return_sequences 20
python aiagent.py %1 "qwen3-coder" --max_length 400 --num_return_sequences 20