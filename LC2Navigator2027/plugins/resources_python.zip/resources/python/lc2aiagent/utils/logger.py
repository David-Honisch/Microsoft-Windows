import logging
import datetime

def get_logger(name):
    logging.basicConfig(level=logging.INFO)
    logger = logging.getLogger(name)
    return logger

def log_prompt(prompt):
    timestamp = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    file_timestamp = datetime.datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
    with open(file_timestamp+"_log.txt", "a") as log_file:
        log_file.write(f"{timestamp} - Prompt: {prompt}\n")