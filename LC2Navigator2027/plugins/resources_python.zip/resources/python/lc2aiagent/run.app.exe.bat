@echo off
REM call app 5001 "openai-community/gpt2"
REM call py app.py 5000 "openai/whisper-large-v3-turbo"
call py app.py 5000 "Jackrong/Qwen3.5-27B-Claude-4.6-Opus-Reasoning-Distilled"