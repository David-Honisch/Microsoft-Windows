from transformers import pipeline
from utils.logger import get_logger
from transformers import AutoModelForCausalLM, AutoTokenizer


logger = get_logger(__name__)
class ModelPredictor:
    def __init__(self):
        # self.model = pipeline('text-generation', model='gpt-2')
        self.model = pipeline('text-generation', model='openai-community/gpt2')
    def predict(self, input_text):
        logger.info(f"Predicting for input: {input_text}")
        # return self.model(input_text,eos_token_id=50256, max_length=20000,max_new_tokens=256)[0]['generated_text']
        return self.model(input_text)[0]['generated_text']
    
    def predict_ext(self, input_text,model):
        logger.info(f"Predicting for input: {input_text}")
        self.model = pipeline('text-generation', model=model)
        return self.model(input_text)[0]['generated_text']
    
    
    # model_name = "gpt2"
    def generate_text(model_name,prompt, max_length=50, num_return_sequences=1):
        logger.info(f"input: {prompt} model:{model_name}")
        tokenizer = AutoTokenizer.from_pretrained(model_name)
        model = AutoModelForCausalLM.from_pretrained(model_name)

        # GPT-2 hat kein standardmäßiges Pad-Token, daher setzen wir es auf das End-of-String Token
        tokenizer.pad_token = tokenizer.eos_token
        model.config.pad_token_id = model.config.eos_token_id

        model.eval()
        # Tokenize input
        inputs = tokenizer(prompt, return_tensors="pt")
        
        # Generierung mit modernem Standard (do_sample für Vielfalt)
        with torch.no_grad():
            outputs = model.generate(
                **inputs, 
                max_new_tokens=max_length, # Nutze max_new_tokens statt max_length für bessere Kontrolle
                num_return_sequences=num_return_sequences,
                do_sample=True,            # Ermöglicht kreativere Texte
                top_k=50, 
                top_p=0.95,
                pad_token_id=tokenizer.eos_token_id
            )
        
        return [tokenizer.decode(output, skip_special_tokens=True) for output in outputs]