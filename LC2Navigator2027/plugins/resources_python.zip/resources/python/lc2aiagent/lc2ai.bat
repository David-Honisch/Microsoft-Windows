@echo off
REM call python "D:\tools\LETZTECHANCE.ORG\LC2Navigator2027\app\lc2aiagent\aiagent.py" %1 "openai-community/gpt2" --max_length 400 --num_return_sequences 20
call python "D:\tools\LETZTECHANCE.ORG\LC2Navigator2027\app\lc2aiagent\aiagent.py" %1 "Jackrong/Qwen3.5-27B-Claude-4.6-Opus-Reasoning-Distilled" --max_length 400 --num_return_sequences 20