# PowerShell script to convert JSON to XML
# Function to convert JSON to XML
function Convert-JsonToXml {
    param (
        [Parameter(Mandatory = $true)]
        [string]$JsonData
    )
    # Convert JSON to XML
    $xml = ([xml]([System.Text.Encoding]::UTF8.GetString([System.Convert]::FromBase64String([System.Convert]::ToBase64String([System.Text.Encoding]::UTF8.GetBytes($JsonData))))))
# Return the XML
return $xml
}
# Example JSON data
$jsonData = '{
"name": "John Doe",
"age": 30,
"isMarried": true,
"address": {
"street": "123 Main St",
"city": "Anytown",
"zip": "12345"
},
"hobbies": ["reading", "traveling", "cooking"]
}'
# Convert JSON to XML
$xmlData = Convert-JsonToXml -JsonData $jsonData
# Output the XML data
$xmlData.Save("output.xml")
# Optionally, display the XML data in the console
$xmlData.OuterXml