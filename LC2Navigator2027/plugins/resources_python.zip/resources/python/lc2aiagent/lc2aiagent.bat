@echo off
REM call py %~dp0app.py 5000 "openai-community/gpt2"
call py %~dp0app.py 5000 "openai/whisper-medium"
REM call py %~dp0app.py 5000 "qwen3-coder"
