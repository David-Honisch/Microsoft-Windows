import os
import subprocess
import re
import sys
from pathlib import Path

def is_installed(pkg):
    try:
        result = subprocess.run(
            ["/usr/bin/which", pkg],
            check=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True
        )
        if result.stdout:
            return True
        return False
    except:
        return False

def install(pkg):
    print(f"Installing {pkg}...")
    # Windows: Use `winget` or `choco` (depending on your system)
    # For this example, we'll use `winget` (recommended)

    # Example for using winget
    # winget install --no-prompt libssl-dev
    # winget install --no-prompt libcrypto-dev
    # winget install --no-prompt openssl-dev
    # winget install --no-prompt libssl1.1
    # winget install --no-prompt libcrypto1.1
    # ...

    print("Packages are now installed.")

if __name__ == "__main__":
    print("Checking OpenSSL development packages...")
    packages = [
        "libssl-dev",
        "libcrypto-dev",
        "openssl-dev",
        "libssl1.1",
        "libcrypto1.1",
        "libssl1.1-dev",
        "libcrypto++-dev",
        "libssl-cert-dev",
        "openssl-1.1",
        "openssl-1.1-dev",
        "libxml2-dev",
        "libxslt1.1",
        "libpython3.10-dev",
        "python3.10-dev"
    ]

    for pkg in packages:
        if not is_installed(pkg):
            print(f"Package {pkg} is not installed. Installing...")
            install(pkg)
            print("Package installed successfully.")

    print("\nOpenSSL development packages are now installed.")
    print("You can now run OpenSSL commands or use Python with OpenSSL support.")
