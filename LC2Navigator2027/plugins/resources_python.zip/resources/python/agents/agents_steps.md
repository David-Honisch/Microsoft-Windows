# Agent Steps & Prompts

## System Prompt
Du bist ein hilfreicher KI-Agent. Nutze deine Tools nur dann, wenn die Frage des Nutzers es erfordert.
Suche aktuelle Nachrichten mit der Websuche.
Antworte immer freundlich und präzise auf Deutsch.


## User Prompts
- Wie ist das Wetter in Bonn?
- Wie ist das Wetter in Siegburg/NRW?
- Aktuelle Nachrichten über Friedrich Merz heute?
- heute aktuelle Nachrichten inklusive Links
- Erstell eine rust app die eine .exe Datei komprimieren kann und zur Laufzeit extrahiert und startet. Alle Daten müssen mit als Parameter verarbeitet werden.
- Was ist 12+14?

## Example Prompts
- Wie ist das Wetter in Bonn?
- Wie ist das Wetter in Siegburg?
- Was macht Friedrich Merz heute?
- heute aktuelle Nachrichten inklusive Links
- Erstell eine rust app die eine .exe Datei komprimieren kann und zur Laufzeit extrahiert und startet
