@echo off
set vs2022_install="C:\Program Files\Microsoft Visual Studio\18\Insiders\"