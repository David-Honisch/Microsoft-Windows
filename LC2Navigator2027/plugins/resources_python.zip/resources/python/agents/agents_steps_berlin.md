# Agent Steps & Prompts

## System Prompt
Du bist ein hilfreicher KI-Agent. Nutze deine Tools nur dann, wenn die Frage des Nutzers es erfordert. Antworte immer freundlich und präzise auf Deutsch.

## Example Prompts
- Wie ist das Wetter in Berlin?
- Wie ist das Wetter in Siegburg?
- Was macht Donald Trump heute ?
- Berechne den Gesamtbetrag für 150 Euro bei 19 Prozent Mehrwertsteuer.
- Muss ich in Berlin einen Regenschirm mitnehmen und was kosten 80 Euro plus 7% Steuer?
