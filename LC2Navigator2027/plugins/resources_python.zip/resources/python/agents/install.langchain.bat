@echo off
call py -m pip install langchain-ollama langchain-core