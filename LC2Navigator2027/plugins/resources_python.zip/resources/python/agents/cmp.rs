use std::fs::File;
use std::io::{BufReader, BufWriter};
use std::path::Path;

use zip::ZipArchive;
use zip::ZipEntry;

fn komprimiere_datei(input_path: &str, output_path: &str) {
    let file = File::open(input_path).unwrap();
    let reader = BufReader::new(file);
    let mut writer = BufWriter::new(File::create(output_path).unwrap());

    let mut zip = ZipArchive::new(writer);

    for i in 0..zip.len() {
        let entry = zip.by_index(i).unwrap();
        writer.write_all(&entry.name().bytes()).unwrap();
    }
}

fn extrahiere_datei(input_path: &str, output_path: &str) {
    let file = File::open(input_path).unwrap();
    let reader = BufReader::new(file);

    let mut zip = ZipArchive::new(reader);

    for i in 0..zip.len() {
        let entry = zip.by_index(i).unwrap();
        let output_file = File::create(entry.name().to_str().unwrap()).unwrap();
        output_file.write_all(&entry.read().unwrap()).unwrap();
    }
}

fn main() {
    let input_path = "input.txt";
    let output_path = "output.zip";

    komprimiere_datei(input_path, output_path);

    let input_path = "output.zip";
    let output_path = "output.txt";

    extrahiere_datei(input_path, output_path);
}