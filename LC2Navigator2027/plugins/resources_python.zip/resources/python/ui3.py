import tkinter as tk
from tkinter import *
from tkinter import ttk

def grad_nach_kelvin():
    # print(eingabefeld_wert.get())
    grad = int(eingabefeld_wert.get())
    kelvin = grad + 273
    textausgabe = tk.Label(root, text=kelvin, bg="yellow")
    textausgabe.pack()

def aktionSF():
    label3 = tk.Label(root, text="Aktion durchgeführt", bg="yellow")
    label3.pack()


root = tk.Tk()

# frm = tk.Frame(root, padding=10)
# frm.grid()
# tk.Label(frm, text="Hello World!").grid(column=0, row=0)
# tk.Button(frm, text="Quit", command=root.destroy).grid(column=1, row=0)

eingabefeld_wert=tk.StringVar()
eingabefeld=tk.Entry(root, textvariable=eingabefeld_wert)
eingabefeld.pack()
# Textausgabe erzeugen
label1 = tk.Label(root, text="Link16 UI Launcher")
label1.pack()

schaltf1 = tk.Button(root, text="Execute", command=aktionSF)
schaltf1.pack()

calcKelvinBtn = tk.Button(root, text="Calc", command=grad_nach_kelvin)
calcKelvinBtn.pack()

quitBtn = tk.Button(root, text="Calc", command=grad_nach_kelvin)
quitBtn.pack()

quitBtn = tk.Button(root, text="Exit", command=root.destroy)
quitBtn.pack()


root.mainloop()