import struct
print(struct.calcsize("P") * 8) # Sollte 64 ausgeben