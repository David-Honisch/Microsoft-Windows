import os
import shutil
import argparse
def archive_directory(source_dir, archive_name):
    # Create a zip archive of the source directory
    shutil.make_archive(archive_name, 'zip', source_dir)
    print(f"Directory '{source_dir}' archived as '{archive_name}.zip'.")
def replace_string_in_files(directory, old_string, new_string):
    # Walk through all files in the directory
    for root, _, files in os.walk(directory):
        for file in files:
            file_path = os.path.join(root, file)
            # Read the content of the file
            with open(file_path, 'r', encoding='utf-8') as f:
                content = f.read()
                # Replace the old string with the new string
                new_content = content.replace(old_string, new_string)
                # Write the modified content back to the file
                with open(file_path, 'w', encoding='utf-8') as f:
                    f.write(new_content)
                    print(f"Replaced '{old_string}' with '{new_string}' in file: {file_path}")
def main():
    parser = argparse.ArgumentParser(description="Archive a directory and optionally replace a string in all files.")
    parser.add_argument('source_dir', type=str, help="Path to the directory to archive.")
    parser.add_argument('--archive_name', type=str, help="Name of the archive file (without extension).", default='archive')
    parser.add_argument('--replace', action='store_true', help="Replace a string in all files.")
    parser.add_argument('--old_string', type=str, help="The string to replace.")
    parser.add_argument('--new_string', type=str, help="The new string to replace with.")
    args = parser.parse_args()
    if args.replace:
        if not args.old_string or not args.new_string:
            parser.error("Both --old_string and --new_string must be provided when --replace is used.")
            replace_string_in_files(args.source_dir, args.old_string, args.new_string)
        else:
            archive_directory(args.source_dir, args.archive_name)
        
if __name__ == "__main__":
    main()