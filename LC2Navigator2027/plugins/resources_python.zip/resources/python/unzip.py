#!/usr/bin/python3

import os, os.path, re,sys, zipfile, json

def get_files_to_zip():
	#Exclude git stuff, build scripts etc.
	exclude = [
		r'\.(.ignore|sh|pem|zip|iso)$', #file endings
		r'(\\|/)\.', #hidden files
		r'package\.json|icon\.html', #file names
		r'(\\|/)(promo|unittest|build)(\\|/)' #folders
	]

	zippable_files = []
	for root, folders, files in os.walk('.'):
		print(root)
		for f in files:
			file = os.path.join(root,f)
			if not any(re.search(p, file) for p in exclude):
				zippable_files.append(file)
	return zippable_files

def replace_in_file(file_path, search_pattern, replacement):
    with open(file_path, 'r', encoding='utf-8', errors='replace') as f:
        content = f.read()
    new_content = content.replace(search_pattern, replacement)
    with open(file_path, 'w', encoding='utf-8') as f:
        f.write(new_content)

def unzip_file(zip_path, target_dir):
    """
    Extracts a zip file to the specified target directory.
    """
    print(f"Extracting '{zip_path}' to '{target_dir}'")
    if not os.path.exists(target_dir):
        os.makedirs(target_dir)
    with zipfile.ZipFile(zip_path, 'r') as zip_ref:
        zip_ref.extractall(target_dir)
    print(f"Extracted '{zip_path}' to '{target_dir}'")
    
def create_addon(files, browser):
	output_folder = 'build'
	if not os.path.isdir(output_folder):
		os.mkdir(output_folder)

	if browser == 'firefox':
		ext = 'xpi'
	else:
		ext = 'zip'

	output_file = os.path.join(output_folder, f'lc2ttsredirector-{browser}.{ext}')
	zf = zipfile.ZipFile(output_file, 'w', zipfile.ZIP_STORED)
	cert = 'extension-certificate.pem'

	print('')
	print(f'**** Creating addon for ${browser} ****')
	
	if browser == 'opera' and not os.path.exists(cert):
		print('Extension certificate does not exist, cannot create .nex file for Opera')
		return

	for f in files:
		print('Adding', f)
		if f.endswith('manifest.json'):
			manifest = json.load(open(f))
			if browser != 'firefox':
				del manifest['applications'] #Firefox specific, and causes warnings in other browsers...


			if browser == 'firefox':
				del manifest['background']['persistent'] #Firefox chokes on this, is always persistent anyway

			if browser == 'opera':
				manifest['options_ui']['page'] = 'redirector.html' #Opera opens options in new tab, where the popup would look really ugly
				manifest['options_ui']['chrome_style'] = False

			zf.writestr(f[2:], json.dumps(manifest, indent=2)) 
		else:
			zf.write(f[2:])

	zf.close()

	if browser == 'opera':
		#Create .nex
		os.system('./nex-build.sh %s %s %s' % (output_file, output_file.replace('.zip', '.nex'), cert))

def create_zip(files, browser):
	output_folder = 'build'
	ext = 'zip'
	if not os.path.isdir(output_folder):
		os.mkdir(output_folder)	

	output_file = os.path.join(output_folder, f'{browser}.{ext}')
	zf = zipfile.ZipFile(output_file, 'w', zipfile.ZIP_STORED)
	cert = 'extension-certificate.pem'

	print('')
	print(f'**** Creating addon for ${browser} ****')
	
	# if browser == 'opera' and not os.path.exists(cert):
	# 	print('Extension certificate does not exist, cannot create .nex file for Opera')
	# 	return

	for f in files:
		print('Adding', f)
		#replace default pattern
		search_pattern = 'lc2ttsdefault'
		replacement = browser
		replace_in_file(f, search_pattern, replacement)
		zf.write(f[2:])
	zf.close()


if __name__ == '__main__':
	#Make sure we can run this from anywhere
	folder = os.path.dirname(os.path.realpath(__file__))
	unzip_file(os.path.join(folder,'backup','src.zip'), os.path.join(folder,'src'))
	# os.chdir(os.path.join(folder))

	# files = get_files_to_zip()
	
	# print('******* REDIRECTOR BUILD SCRIPT *******')
	# print('')
	# if len(sys.argv) < 2:
	# 	print(f"Usage: {sys.argv[0]} <browser>")
	# 	sys.exit(1)
	# browser = sys.argv[1]
	# print('args:{}', sys.argv)
	# # if len(sys.argv) > 1:
    # # print('args:{}', sys.argv)
	
	# create_zip(files, browser)
	# create_addon(files, 'chrome')
	# create_addon(files, 'edge')
	# create_addon(files, 'opera')
	# create_addon(files, 'firefox')

