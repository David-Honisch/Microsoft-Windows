select '<hr/><h2>Import LC2ShortCutCLI processes</h2>';
select '<p>drop plugin tables</p>';
drop table IF EXISTS LC2ShortCutCLI;
drop table IF EXISTS LC2ShortCutCLI_main;
drop table IF EXISTS LC2ShortCutCLI_install;
drop table IF EXISTS LC2ShortCutCLI_help;
drop table IF EXISTS LC2ShortCutCLI_data;
drop table IF EXISTS LC2ShortCutCLI_info;
drop table IF EXISTS LC2ShortCutCLI_work;
drop table IF EXISTS LC2ShortCutCLI_procdata;
drop table IF EXISTS LC2ShortCutCLItemp;
drop table IF EXISTS LC2ShortCutCLI_datatemp;
drop table IF EXISTS LC2ShortCutCLI_worktemp;
drop table IF EXISTS LC2ShortCutCLI_proc;
drop table IF EXISTS LC2ShortCutCLI_tests;
drop table IF EXISTS LC2ShortCutCLI_proctemp;
---------------------------------------------------------------
select '<span>Creating tables</span>';
---------------------------------------------------------------
CREATE TABLE LC2ShortCutCLI( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,  "url" TEXT NULL);
CREATE TABLE LC2ShortCutCLI_main( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE LC2ShortCutCLI_install( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE LC2ShortCutCLI_help( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE LC2ShortCutCLI_data( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE LC2ShortCutCLI_info( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE LC2ShortCutCLI_work( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
--CREATE TABLE LC2ShortCutCLI_proc( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE LC2ShortCutCLI_proc( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
---------------------------------------------------------------
CREATE TABLE LC2ShortCutCLI_tests( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE LC2ShortCutCLI_procdata( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
---------------------------------------------------------------
CREATE TABLE IF NOT EXISTS LC2ShortCutCLItemp (
"name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "url" TEXT NULL
);
CREATE TABLE IF NOT EXISTS LC2ShortCutCLI_proctemp( "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "url" TEXT NULL);
---------------------------------------------------------------
-- import menu
select '<span>start import to plugin tables</span>';
---------------------------------------------------------------
.separator ";"
--.import .\\resources\\plugins\\LC2ShortCutCLI\\import\\import.csv LC2ShortCutCLItemp
-- INSERT INTO LC2ShortCutCLI(first_name,name,zipcode, city, description) select first_name,name,zipcode, city, description  from LC2ShortCutCLItemp;
.import .\\resources\\plugins\\LC2ShortCutCLI\\import\\import.csv LC2ShortCutCLI
.import .\\resources\\plugins\\LC2ShortCutCLI\\import\\main.csv LC2ShortCutCLI_main
.import .\\resources\\plugins\\LC2ShortCutCLI\\import\\install.csv LC2ShortCutCLI_install
.import .\\resources\\plugins\\LC2ShortCutCLI\\import\\help.csv LC2ShortCutCLI_help
.import .\\resources\\plugins\\LC2ShortCutCLI\\import\\info.csv LC2ShortCutCLI_info
.import .\\resources\\plugins\\LC2ShortCutCLI\\import\\data.csv LC2ShortCutCLI_data
.import .\\resources\\plugins\\LC2ShortCutCLI\\import\\work.csv LC2ShortCutCLI_work
.import .\\resources\\plugins\\LC2ShortCutCLI\\import\\proc.csv LC2ShortCutCLI_proc
.import .\\resources\\plugins\\LC2ShortCutCLI\\import\\tests.csv LC2ShortCutCLI_tests
---------------------------------------------------------------
-- import procs
-- select '<span>importing processes</span>';
-------------------------------------------------------------
-- .separator ","
-- .import '.\\resources\\plugins\\LC2ShortCutCLI\\import\\proc.csv' LC2ShortCutCLI_proctemp
-- .separator ";"
-- INSERT INTO LC2ShortCutCLI_proc(first_name,name,zipcode, description,url) select first_name,name,zipcode, description,url  from LC2ShortCutCLI_proctemp;
-- select 'LC2ShortCutCLI_work count:';
-- select count(*) from LC2ShortCutCLI_proc;
-- eof insert work data
-- eof insert work data
---------------------------------------------------------------
-- done
select '<span>import done</span>';
---------------------------------------------------------------
select 'LC2ShortCutCLI count:';
select count(*) from LC2ShortCutCLI;
select '<p>start data import to plugin tables</p>';
-- delete from LC2ShortCutCLI_datatemp;
--
select '<p>LC2ShortCutCLI count:';
select count(*) from LC2ShortCutCLI;
select 'LC2ShortCutCLI_data count:';
select count(*) from LC2ShortCutCLI_data;
select 'LC2ShortCutCLI_info count:';
select count(*) from LC2ShortCutCLI_info;
select 'LC2ShortCutCLI_help count:';
select count(*) from LC2ShortCutCLI_help;
select 'LC2ShortCutCLI_procdata count:';
select count(*) from LC2ShortCutCLI_procdata;
select 'LC2ShortCutCLI_work count:';
select count(*) from LC2ShortCutCLI_work;
select 'LC2ShortCutCLI_proc count:';
select count(*) from LC2ShortCutCLI_proc;
select 'LC2ShortCutCLI_proctemp count:';
select count(*) from LC2ShortCutCLI_proctemp;

drop table IF EXISTS LC2ShortCutCLItemp;
-- drop table IF EXISTS LC2ShortCutCLI_proctemp;
-- select '<p>Import done</p>';
select '<h4>Import LC2ShortCutCLI processes done.</h4>';
.exit