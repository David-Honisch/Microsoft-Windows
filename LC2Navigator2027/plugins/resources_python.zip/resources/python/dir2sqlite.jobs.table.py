import csv
import sqlite3
import os

# Configuration
CSV_FILE = 'filenames.csv'
DB_NAME = 'jobs.db'
TABLE_NAME = 'jobs'

# Initialize SQLite database
conn = sqlite3.connect(DB_NAME)
cursor = conn.cursor()

# Create table if not exists
cursor.execute('''
    CREATE TABLE IF NOT EXISTS jobs (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        title TEXT NOT NULL,
        company TEXT NOT NULL,
        location TEXT NOT NULL,
        job_type TEXT NOT NULL,
        category TEXT NOT NULL,
        description TEXT NOT NULL,
        requirements TEXT,
        benefits TEXT,
        salary TEXT,
        posted_date TEXT NOT NULL,
        deadline TEXT,
        contact_email TEXT NOT NULL,
        contact_phone TEXT,
        website TEXT,
        featured INTEGER NOT NULL DEFAULT 0,
        external_id TEXT,
        last_synced TEXT,
        shell_command TEXT,
        download_files TEXT
    )
''')

# Read CSV and insert into database
with open(CSV_FILE, 'r') as file:
    csv_reader = csv.DictReader(file)
    for row in csv_reader:
        filename = row['filename']

        # Fill all fields with the filename or default values
        title = filename
        company = filename
        location = filename
        job_type = filename
        category = filename
        description = filename
        requirements = filename
        benefits = filename
        salary = filename
        posted_date = filename
        deadline = filename
        contact_email = filename
        contact_phone = filename
        website = filename
        featured = 0
        external_id = filename
        last_synced = filename
        shell_command = filename
        download_files = filename

        # Insert into database
        cursor.execute('''
            INSERT INTO jobs (
                title, company, location, job_type, category, description,
                requirements, benefits, salary, posted_date, deadline,
                contact_email, contact_phone, website, featured,
                external_id, last_synced, shell_command, download_files
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ''', (
            title, company, location, job_type, category, description,
            requirements, benefits, salary, posted_date, deadline,
            contact's email, contact_phone, website, featured,
            external_id, last_synced, shell_command, download_files
        ))

conn.commit()
conn.close()

print("✅ Done. Inserted all files into the database.")
