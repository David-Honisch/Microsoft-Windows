@echo off
REM call start python ui.py
call show_release.bat
python ui.py