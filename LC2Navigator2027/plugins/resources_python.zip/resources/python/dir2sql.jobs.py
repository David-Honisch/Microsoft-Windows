import csv
import sys

# SQL table schema
TABLE_NAME = 'jobs'

# SQL schema (used to build the INSERT statement)
COLUMNS = [
    'id', 'title', 'company', 'location', 'job_type', 'category', 'description',
    'requirements', 'benefits', 'salary', 'posted_date', 'deadline',
    'contact_email', 'contact_phone', 'website', 'featured', 'external_id',
    'last_synced', 'shell_command', 'download_files'
]

# SQL INSERT template
INSERT_SQL = f"""
INSERT INTO {TABLE_NAME} ({', '.join(COLUMNS)}) VALUES ({', '.join(['?'] * len(COLUMNS))});
"""

def main():
    if len(sys.argv) != 3:
        print("Usage: python generate_sql.py <CSV_FILE> <SQL_FILE>")
        sys.exit(1)

    CSV_FILE = sys.argv[1]
    SQL_FILE = sys.argv[2]

    # Validate CSV file exists
    if not os.path.exists(CSV_FILE):
        print(f"Error: CSV file '{CSV_FILE}' not found.")
        sys.exit(1)

    # Open SQL file for writing
    with open(SQL_FILE, 'w', newline='') as sql_file:
        csv_reader = csv.DictReader(open(CSV_FILE, 'r'))
        for row in csv_reader:
            filename = row['filename']

            # Fill all fields with the filename (or use default if needed)
            values = [
                filename, filename, filename, filename, filename, filename, filename,
                filename, filename, filename, filename, filename, filename,
                filename, filename, 0, filename, filename, filename, filename
            ]

            # Format the SQL statement
            sql = INSERT_SQL.format(', '.join(['?'] * len(COLUMNS)))
            sql = sql.format(*values)

            # Write to SQL file
            sql_file.write(sql + '\n')

    print(f"✅ SQL INSERT statements generated and saved to: {SQL_FILE}")

if __name__ == "__main__":
    main()
