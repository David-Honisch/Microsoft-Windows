<?xml version="1.0" encoding="UTF-8"?>
<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform">
    <xsl:variable name="color" select='"red"' />
    <xsl:template match="/">
        <root>
            <xsl:template match="/">
                <html>
                    <meta charset="UTF-8"/>
                    <title>LetzteChance.Org Plugin</title>
                    <link rel="stylesheet" href="../../assets/js/carousel/css/main.css"/>

                    <script src="../../assets/js/carousel/jquery.reflection.js"></script>
                    <script src="../../assets/js/carousel/jquery.cloud9carousel.js"></script>
                    <script src="../../assets/js/carousel/main.js"></script>
                    <body>

                        <div class="panel panel-default ">
                            <div class="panel-heading ">
                                <xsl:value-of select="root/title" />
                            </div>
                            <div class="panel-body demo-btn " style="min-height: 252px; ">
                                <!-- <h2>
                  <xsl:value-of select="root/title" />
                </h2> -->
                                <!-- <center> -->
                                <table border="1" style="width:85%;">
                                    <tr bgcolor="#9acd32">
                                        <th>Title</th>
                                        <th>Updated</th>
                                        <th>Url</th>
                                    </tr>
                                    <xsl:for-each select="root/urlslist/urls">
                                        <tr>
                                            <td>
                                                <xsl:value-of select="title" />
                                            </td>
                                            <td>
                                                <xsl:value-of select="year" />
                                            </td>
                                            <td>

                                                <xsl:element name="a">

                                                    <xsl:value-of select="url" />
                                                    <!-- <xsl:attribute
                                                    name="href">javascript:openBrowser('<xsl:value-of
                                                    select="url" />');</xsl:attribute> -->
                                                    <xsl:attribute
                                                        name="href">
                                                        <xsl:value-of select="urltarget" />
                                                    </xsl:attribute>
                                                </xsl:element>


                                            </td>
                                        </tr>
                                    </xsl:for-each>
                                </table>
                            </div>
                        </div>

                        <div id="pregister"></div>
                        <div id="showcase" class="noselect">
                        </div>
                        <p id="item-title"></p>
                        <div class="carnav noselect">
                            <button class="left"> ← </button>
                            <button class="right"> → </button>
                        </div>

                        <div id="LC2Carouselout"></div>
                        <div id="pform"></div>
                        <div id="pnav"></div>
                        <div id="pnavmenu"></div>

                        <div id="playout"></div>
                        <div id="pout"></div>
                        <div id="pout_progress"></div>
                        <div id="p__out"></div>
                        <div id="p__out_progress"></div>
                        <div id="pschema"></div>


                        <!-- </center> -->
                    </body>
                    <xsl:element name="script">
                        <xsl:attribute name="src">
                            <xsl:value-of select="/root/url_config" />
                        </xsl:attribute>
                    </xsl:element>
                    <xsl:element name="script">
                        <xsl:attribute name="src">
                            <xsl:value-of select="/root/url_main" />
                        </xsl:attribute>
                    </xsl:element>
                    <!-- <script src="../../resources/plugins/LC2CRC32/index.js" type="text/javascript"></script> -->
                </html>
            </xsl:template>


        </root>
    </xsl:template>
</xsl:stylesheet>