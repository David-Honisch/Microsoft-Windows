<?xml version="1.0" encoding="UTF-8"?>
<xsl:stylesheet version="1.0"
    xmlns:xsl="http://www.w3.org/1999/XSL/Transform">
    <!-- Define the output method -->
    <xsl:output method="xml" indent="yes" />
    <!-- Define the template for the root element -->
    <xsl:template match="/">
        <root>
            <xsl:apply-templates select="root/items/item[position() mod 10 = 1]" />
        </root>
    </xsl:template>
    <!-- Define the template for each page -->
    <xsl:template match="item[position() mod 10 = 1]">
        <page>
            <xsl:variable name="page-number" select="position() div 10 + 1" />
            <xsl:attribute name="number"><xsl:value-of select="$page-number" /></xsl:attribute>
            <xsl:copy-of select="." />
            <xsl:copy-of select="following-sibling::item[position() < 10]" />
        </page>
    </xsl:template>
</xsl:stylesheet>