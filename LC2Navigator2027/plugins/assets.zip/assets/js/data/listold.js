// $.urlParam = function(name) {
//         var results = new RegExp('[\?&]' + name + '=([^&#]*)').exec(window.location.href);
//         if (results == null) {
//             return null;
//         }
//         return decodeURI(results[1]) || 0;
//     }
//     //angular
const model = window.nodeRequire(path.join(__dirname, 'app', 'model.js'));
var app = angular.module('app', ['ui.bootstrap']);


function MyController($scope, $http, $filter) {
    const path = window.nodeRequire('path');
    // default values for pagination and filtering
    $scope.pageSize = 5;
    $scope.maxSize = 5;
    $scope.start = 0;
    $scope.end = 0;
    $scope.currentPage = 0;
    $scope.numOfPages = 0;
    $scope.filteredItems = [];
    $scope.startItems = [];
    $scope.pagedItems = [];
    $scope.data = null;
    $scope.query = { browser: "" };

    // get the data
    // $http.get('assets/js/data/data.json')
    //     .success(function(data) {
    //         // set the data
    //         $scope.data = data.Data;
    //     });
    // const model = window.nodeRequire(path.join(__dirname, 'app', 'model.js'));
    // model.initDb('' + webRoot, //app.getPath('userData'),
    //     // Load a DOM stub here. See renderer.js for the fully composed DOM.
    //     //mainWindow.loadURL(`file:${__dirname}/app/html/index.html`)
    //     console.log('Init Database')
    // );
    var q = '';
    var res = model.GetQuery(path.join(__dirname, 'lc.db'), 'select * from ' + $.urlParam('db'));
    // console.log(JSON.stringify(res));
    var list = {
        "Data": []
    };

    for (var v in res) {
        // console.log(JSON.stringify(v));
        var t = {
            "id": res[v]['person_id'],
            "name": res[v]['name'],
            "first_name": res[v]['first_name'],
            "last_name": res[v]['last_name'],
            "zipcode": res[v]['zipcode'],
            "url": res[v]['url'],
            // "platform": {
            //     "inner": res[v]['name'],
            //     "details": [
            //         "4",
            //         "X"
            //     ]
            // }
        };
        // console.log(JSON.stringify(t));
        list['Data'].push(t);
    }
    // console.log(JSON.stringify(list.Data));
    $scope.data = list.Data;


    // when the data is altered, filter the items and set the page
    $scope.$watch('data', function(data, old) {
        $scope.filteredItems = $filter('filter')(data, $scope.query);
        if (old === null) setPage();
    });

    // when the query value changes, refilter the data
    $scope.$watch('query|json', function() {
        $scope.filteredItems = $filter('filter')($scope.data, $scope.query);
    });

    // set the pagination for the filtered items
    function setPage() {
        $scope.start = ($scope.currentPage - 1) * $scope.pageSize + ($scope.filteredItems === undefined && $scope.filteredItems.length ? 1 : 0);
        $scope.startItems = $filter('startFrom')($scope.filteredItems, $scope.start - 1);
    }

    // when the current page is changed by the pagination control, update the list of items
    $scope.$watch('currentPage', function(page) {
        setPage();
    });

    // when the filtered items are set, recalculate the number of pages
    $scope.$watch('filteredItems', function(items, old) {
        $scope.currentPage = 1;
        if (items !== undefined && items.length !== undefined)
            $scope.numOfPages = Math.ceil(items.length / $scope.pageSize);
    });

    // when the page start is changed, update the list of paged items
    $scope.$watch('startItems', function(items) {
        $scope.pagedItems = $filter('limitTo')(items, $scope.pageSize);
        $scope.end = ($scope.currentPage - 1) * $scope.pageSize + $scope.pagedItems.length;
    });



}

// angular directive to change default behavior from processing input change immediately to on blur or enter
app.directive('ngModelBlur', function() {
    return {
        restrict: 'A',
        require: 'ngModel',
        link: function(scope, elm, attr, ngModelCtrl) {
            if (attr.type === 'radio' || attr.type === 'checkbox') { return; }

            elm.unbind('input').unbind('keydown').unbind('change');
            elm.bind('blur keydown', function(e) {
                if (e.type === 'keydown' && e.which !== 13) { return; }

                scope.$apply(function() {
                    ngModelCtrl.$setViewValue(elm.val());
                });
            });
        }
    };
});

// angular filter to take array items starting from provided index
app.filter('startFrom', function() {
    return function(input, start) {
        if (angular.isArray(input)) {
            var st = parseInt(start, 10);
            if (isNaN(st)) st = 0;
            return input.slice(st);
        }
        return input;
    };
});

function readFile(t, id) {
    var childProcess = window.nodeRequire("child_process");
    // This line initiates
    var script_process = childProcess.spawn(t, [], { env: process.env });
    // Echoes any command output 
    script_process.stdout.on('data', function(data) {
        console.log('stdout: ' + data);
        document.getElementById(id).innerHTML = data;

    });
    // Error output
    script_process.stderr.on('data', function(data) {
        document.getElementById(id).innerHTML = 'stderr: ' + data;
        console.log('stderr: ' + data);

    });
    // Process exit
    script_process.on('close', function(code) {
        console.log('child process exited with code ' + code);
    });
}