To create an npm function that checks if a directory exists and creates it if it doesn't, you can use the `fs` module provided by Node.js. Here's an example of how you can do this:
1. Create a new npm package if you haven't already:
```sh
mkdir check-and-create-dir
cd check-and-create-dir
npm init -y
```
2. Create a file named `index.js` and add the following code:
```javascript
const fs = require('fs');
const path = require('path');
/**
* Checks if a directory exists and creates it if it doesn't.
* @param {string} dirPath - The path of the directory to check and create.
* @returns {Promise} - A promise that resolves when the directory is created or already exists.
*/
async function checkAndCreateDir(dirPath) {
return new Promise((resolve, reject) => {
fs.access(dirPath, fs.constants.F_OK, (err) => {
if (err) {
// Directory does not exist, create it
fs.mkdir(dirPath, { recursive: true }, (err) => {
if (err) {
reject(err);
} else {
resolve();
}
});
} else {
// Directory already exists
resolve();
}
});
});
}
module.exports = checkAndCreateDir;
```
3. Add a script to your `package.json` to run a test:
```json
{
"name": "check-and-create-dir",
"version": "1.0.0",
"description": "A utility to check and create directories",
"main": "index.js",
"scripts": {
"test": "node test.js"
},
"dependencies": {}
}
```
4. Create a `test.js` file to test the function:
```javascript
const checkAndCreateDir = require('./index');
const dirPath = './testDir';
checkAndCreateDir(dirPath)
.then(() => {
console.log('Directory created or already exists:', dirPath);
})
.catch((err) => {
console.error('Error creating directory:', err);
});
```
5. Run the test:
```sh
npm run test
```
This will check if the `testDir` directory exists and create it if it doesn't. If the directory already exists, it will simply log a message indicating that the directory already exists.
The `fs.access` method is used to check if the directory exists, and `fs.mkdir` is used to create the directory. The `recursive` option in `fs.mkdir` ensures that any parent directories are also created if they don't exist.