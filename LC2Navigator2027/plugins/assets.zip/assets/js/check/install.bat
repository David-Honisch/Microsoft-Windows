@echo off
call %~dp0..\resources\cmd\config
@REM set IMPORTFILE=%~dp0..\resources\data\_install.csv
@REM echo %LT%div class='container-fluid cm-container-white' %RT%
echo %LT%h1%RT%INSTALL%LT%/h1%RT%
@REM echo %LT%h3%RT%ARGS: %1%2 %LT%/h3%RT%
@REM echo %LT%/div%RT%

REM echo console.log('TEST.');
REM echo running since
REM dir /b *.*
REM for /f "usebackq tokens=1-4 delims=," %%a in ("%IMPORTFILE%") do (
	REM echo console.log("%%a");
REM )
REM echo console.log('TEST done.');