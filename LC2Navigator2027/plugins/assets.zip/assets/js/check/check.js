console.log('CHECK FILES div:' + divOUT);
// filePath = "update\\check.bat";
do_checkFiles('../../install.json',divOUT)
console.log('CHECK FILES DONE.');