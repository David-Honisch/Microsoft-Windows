class NODEAPI_TEST {
    static run() { console.log(this.name + ' running...') }
}
class NODEAPI {
    static run() { console.log(this.name + ' running...') };
    static test() { console.log(this.name + ' test running...') };
    static getAppConfig(appConfigFileName) {
        const fs = require('fs');
        let rawdata = fs.readFileSync(appConfigFileName);
        let appConfig = JSON.parse(rawdata);
        // console.log(appConfig);
        return appConfig;
    };
    //
    static getContainerInstances(o, backend, db, run) {
        var isAppAlreadyInUse = false;
        var isDBAlreadyInUse = false;
        var msg = 'Are you sure to start the container ?';
        const fs = require('fs');
        const { dialog } = require('electron');
        var ChildProcessWithoutNullStreams = require('child_process');
        var child = ChildProcessWithoutNullStreams;
        console.log("\ncontainer backend port:" + backend + "\ndb port" + db);

        NODEAPI.isPortInUse(db).then((isDBAlreadyInUse) => {
            console.log("PORT OUT:" + JSON.stringify(isDBAlreadyInUse) + "\n");
            if (isDBAlreadyInUse == true) {
                console.log("Container DBMS PORT " + db + " IS NOT USED.\n");
                let response = dialog.showMessageBoxSync(o, {
                    type: 'question',
                    buttons: ['Yes', 'No'],
                    title: 'Confirm',
                    message: 'Are you sure to start the database ?'
                });
                if (response == 0) {
                    console.log("y");
                    //NODEAPI.printExecCMD(".\\resources\\plugins\\lc2container\\run.bat");
                    NODEAPI.printExecCMD(run);
                }
                else {
                    console.log("n");
                }

            } else {
                console.log("Container DBMS PORT " + db + " IS USED.\n");
            }
            NODEAPI.isPortInUse(backend).then((isAppInUse) => {
                console.log("PORT OUT:" + JSON.stringify(isAppInUse) + "\n");
                if (isAppInUse == true) {
                    console.log("Container Backend PORT " + backend + " IS NOT USED.\n");
                } else {
                    console.log("Container Backend PORT " + backend + " IS USED.\n");
                }
                console.log("Container backed port " + backend + " check done.\n");

            });
            console.log("Container backed port " + db + " check done.\n");

        });
    };
    static getServerInstances(o, params, jarPath) {
        console.log("getServerInstances Params:" + JSON.stringify(params) + "\n");
        var isAppAlreadyInUse = false;
        const fs = require('fs');
        const { dialog } = require('electron');
        var ChildProcessWithoutNullStreams = require('child_process');
        var child = ChildProcessWithoutNullStreams;
        console.log("\nCheck if backend exists:\n" + jarPath);
        if (fs.existsSync(jarPath)) {
            console.log("\nbackend exists. Loading backend now...\n" + jarPath);
            let response = dialog.showMessageBoxSync(o, {
                type: 'question',
                buttons: ['Yes', 'No'],
                title: 'Confirm',
                message: 'Are you sure to start the backend ?'
            });

            if (response == 0) {
                console.log(jarPath + " found. Checking dbms (mysql) instance:\n");
                NODEAPI.isPortInUse(8085).then((isAppInUse) => {
                    console.log("BACKEND PORT:" + JSON.stringify(isAppInUse));
                    if (isAppInUse == true) {
                        console.log("PORT 8085 IS NOT USED.\nChecking now dbms port listening:");
                    } else {
                        console.log("PORT 8085 IS USED.");
                        isAppAlreadyInUse = true;
                        let responseInner = dialog.showMessageBoxSync(o, {
                            type: 'question',
                            buttons: ['Yes'],
                            title: 'Confirm',
                            message: 'Already connection to 8085 established and listening. Next free port:\n' + isAppInUse + '.\nPlease install mysql or start the docker/podman pod and try again ?'
                        });
                        if (responseInner == 0) {
                            console.log("backend application is listenng. Backend NOT started.\n");
                        }
                    }
                });
                NODEAPI.isPortInUse(3306).then((isMySQLBusy) => {
                    if (isMySQLBusy == false) {
                        console.log("PORT 3306 IS OPEN and NOT USED.\n");
                        let res = dialog.showMessageBoxSync(this, {
                            type: 'question',
                            buttons: ['Yes'],
                            title: 'Confirm',
                            message: 'NO DBMS (MySQL, Oracle etc.) is NOT running ?'
                        });

                        if (res == 0) {
                            console.log("Backend found but instance already started. not extra session started.\n");
                        }
                    } else {
                        console.log("DBMS PORT 3306 SUCCESSFULLY ESTABLISHED.\n");
                        if (isAppAlreadyInUse == false) {
                            console.log("Backend found. Starting backend instance.\n" + params[0] + "" + JSON.stringify([params[1], jarPath, params[2]]) + ":\n");
                            //child = require('child_process').spawn('java', ['-jar', jarPath, '']);
                            child = require('child_process').spawn(params[0], [params[1], jarPath, params[2]]);
                        }
                        else {
                            console.log("Backend found. Nothing todo.\n");
                            // child = require('child_process').spawn('java', ['-jar', jarPath, '']);
                        }
                    }
                });


            }
            else {
                console.log("1");
            }
        }
        else {
            console.log("\nLoading:\n" + jarPath + " FAILED. File does not exists.\nRepair and try again");
        }
    };
    //
    static printExecCMD(f) {
        const {
            exec
        } = require('child_process');
        exec('' + f, (err, stdout, stderr) => {
            if (err) {
                console.error(err);
                return;
            }
            console.log('' + stdout);
        });
    }
    //ports
    static async isPortInUse(p) {
        return await this.isPortOpen(p);
    };
    static async showDBPortCheck(p) {
        let port = await getNextOpenPort(p);
        // console.log("Next free port:" + port);
        return port;
    };

    static async isPortOpen(port) {
        return new Promise((resolve, reject) => {
            var net = require('net');
            let s = net.createServer();
            s.once('error', (err) => {
                s.close();
                if (err["code"] == "EADDRINUSE") {
                    resolve(false);
                } else {
                    resolve(false);
                }
            });
            s.once('listening', () => {
                resolve(true);
                s.close();
            });
            s.listen(port);
        });
    };
    static async getNextOpenPort(startFrom) {
        let openPort = null;
        while (startFrom < 65535 || !!openPort) {
            if (await isPortOpen(startFrom)) {
                openPort = startFrom;
                break;
            }
            startFrom++;
        }
        return openPort;
    };

    static async getFileSize(file) {
        var fs = require("fs"); // Load the filesystem module
        var stats = fs.statSync(file)
        var fileSizeInBytes = stats.size;
        // Convert the file size to megabytes (optional)
        return fileSizeInBytes / (1024 * 1024);
    };

    static get_Cookie(url, name, value) {
        const { session } = require('electron');
        // Query all cookies.
        session.defaultSession.cookies.get({})
            .then((cookies) => {
                console.log(cookies)
            }).catch((error) => {
                console.log(error)
            })

        // Query all cookies associated with a specific url.
        session.defaultSession.cookies.get({ url: url })
            .then((cookies) => {
                console.log(cookies)
            }).catch((error) => {
                console.log(error)
            })


    };
    static set_Cookie(url, name, value) {
        const { session } = require('electron');
        // Query all cookies.
        session.defaultSession.cookies.get({})
            .then((cookies) => {
                console.log(cookies)
            }).catch((error) => {
                console.log(error)
            })

        // Query all cookies associated with a specific url.
        session.defaultSession.cookies.get({ url: url })
            .then((cookies) => {
                console.log(cookies)
            }).catch((error) => {
                console.log(error)
            })

        // Set a cookie with the given cookie data;
        // may overwrite equivalent cookies if they exist.
        const cookie = { url: url, name: name, value: value }
        session.defaultSession.cookies.set(cookie)
            .then(() => {
                // success
            }, (error) => {
                console.error(error)
            })
    };



}
module.exports = { NODEAPI, NODEAPI_TEST };