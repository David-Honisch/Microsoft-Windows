$(document).ready(function () {
    var allowedExt = ["exe", "bin", "iso"];

    console.log("LC2Navigator Check install ready.");
    getXML("resources\\xml\\backend.xml", "resources\\xml\\backend.xslt", "backend", true, false);
    setTimeout(() => {
        var isBackendRunning = document.getElementById("is_BackendRunning");
        var is_BackendStopRunning = document.getElementById("is_BackendStopRunning");
        set_DragOver('backendmaindrop', 'newdb', "backendhtmlout", "backendoutFile", allowedExt);
        console.log("set_DragOver done.");
        execCMD("resources\\cmd\\register.config.bat", "backend_main", true, false);
        execCMD("resources\\cmd\\checkrequirement.bat .\\resources\\cmd\\csv\\check.csv", "backend_installcnt", true, false);
        is_BackendStopRunning.addEventListener("click", function () {
            execCMD("resources\\cmd\\stop_backend.bat", "backend_main", true, false);
            isBackendRunning.value = "The backend is stopped.";
            isBackendRunning.classList.remove('btn-success');
            isBackendRunning.classList.add('btn-default');
            isBackendRunning.setAttribute("onclick", "execCMD('resources\\cmd\\start_backend.bat','import');");
        });
        var pB2 = isPortOpen(8085);
        pB2.then(function (isDBInUse) {
            if (isDBInUse == true) {
                isBackendRunning.value = "The backend is running on port:8085.";
                isBackendRunning.classList.remove('btn-default');
                isBackendRunning.classList.add('btn-success');
                isBackendRunning.setAttribute("onclick", "execCMD('" + appConfig.cmd + " " + appConfig.params + " " + appConfig.server.jar + "','import');");
            }
            else {
                isBackendRunning.value = "The backend is NOT running on port:8085.";
                isBackendRunning.classList.remove('btn-default');
                isBackendRunning.classList.add('btn-warning');

                isBackendRunning.setAttribute("onclick", "execCMD('start http://localhost:8084/?actuator/shutdown','import');");

            }
        })
    }, 3000);

});
