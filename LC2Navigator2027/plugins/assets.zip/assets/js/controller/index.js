var remote = window.nodeRequire('electron').remote;
//arguments = remote.getGlobal('sharedObject').prop1;
//console.log(arguments);
//alert(arguments);
//LC2Navigator 2022
var app = angular.module('app', ['ui.bootstrap']);

// const APPCFG = "application.config.json";
const path = window.nodeRequire('path');
const jQuery = window._PAGE_.jQuery;
const { readFileSync, fs } = window.nodeRequire('fs');
const cfg = window.nodeRequire(path.join(__dirname, '..', '..', 'config.json'));
//const model = window.nodeRequire(path.join(__dirname, '..', 'assets', 'js', 'app', 'model.js'));
const model = window.nodeRequire(path.join(__dirname, '..', '..', 'assets', 'js', 'app', 'model.js'));
const cpath = path.join(__dirname);
const dbPath = path.join(__dirname, '..', 'lc.db'); // remote.getGlobal('sharedObj').dbPath; // remote.getGlobal('sharedObj').dbPath;
const gelectron = window.nodeRequire('electron');
const shell = gelectron.shell;
const browserDetails = {
    userAgent: navigator.userAgent,
    platform: navigator.platform,
    language: navigator.language,
    languages: navigator.languages,
    appVersion: navigator.appVersion,
    appName: navigator.appName,
    appCodeName: navigator.appCodeName,
    product: navigator.product,
    productSub: navigator.productSub,
    vendor: navigator.vendor,
    vendorSub: navigator.vendorSub,
    onLine: navigator.onLine,
    cookieEnabled: navigator.cookieEnabled,
    doNotTrack: navigator.doNotTrack,
    hardwareConcurrency: navigator.hardwareConcurrency,
    maxTouchPoints: navigator.maxTouchPoints,
    msMaxTouchPoints: navigator.msMaxTouchPoints,
    deviceMemory: navigator.deviceMemory
};
// const OPEN_LINK = "https://www.letztechance.org/openlink?";
// -var remote = window.nodeRequire('electron').remote;
// const rootLib = window.nodeRequire('app-root-path');
// const appRoot = path.dirname(('' + rootLib).replace("app.asar", ""));
// console.log('rootLib:' + rootLib);
var dialogProperties = {
    // appendTo: "#dialog",
    show: "puff",
    hide: "explode",
    top: 140,
    resizable: true,
    closeOnEscape: true,
    minWidth: 150,
    minHeight: 150,
    // position: { my: "left top", of: "left top" },
    height: "auto",
    width: "auto"
};

function AppController($scope, $http, $filter) {
    const APPCFG = "application.config.json";
    const path = window.nodeRequire('path');
    // default values for pagination and filtering    
    $scope.title = "LC2Navigator - HOME";
    $scope.allowedExt = ["exe", "bin", "iso"];
    $scope.cfg = [];
    $scope.pageSize = 10;
    $scope.maxSize = 15;
    $scope.start = 0;
    $scope.end = 0;
    $scope.currentPage = 1;
    $scope.numOfPages = 0;
    $scope.filteredItems = [];
    $scope.startItems = [];
    $scope.pagedItems = [];
    $scope.currentTable = getURLParam('table') !== undefined ? getURLParam('table') : "systables";
    $scope.currentDB = getURLParam('db') !== null && getURLParam('db') !== undefined ? getURLParam('db') : dbPath;
    $scope.currentSite = getURLParam('q') !== null && getURLParam('q') !== undefined ? getURLParam('q') : "home";
    $scope.query = getURLParam('query') !== null && getURLParam('query') !== undefined ? getURLParam('query') : "";
    $scope.data = [];
    $scope.dataplugins = [];
    $scope.query = { name: "" };
    $scope.index = [];
    $scope.drives = [];
    $scope.files = [];
    $scope.news = [];
    $scope.security = [];
    $scope.menu = [];
    $scope.log = [];
    $scope.person = [];
    $scope.onlinedownloads = [];
    $scope.onlineplugindownloads = [];
    $scope.alerts = [];

    $scope.regDays = [];

    $scope.downloads = [];
    $scope.otherdownloads = [];

    // console.log(APPCFG);
    $scope.cfg = getAppConfig(APPCFG);
    $scope.menu = $scope.cfg.topmenu;

    var dlPath = $scope.cfg.api.xmlnews;
    var resDir = path.join(__dirname, '../../');
    // console.log("Download to resdir:" + resDir + " done.");
    var currentSite = $scope.currentSite;
    document.title += " - " + $scope.cfg.productname;
    var head = getHeader(cfg.local);
    // console.log(JSON.stringify(head));    
    $('#head').html("" + head);
    $('#ptitle').append("" + $scope.title);

    try {
        console.log("Drives:" + JSON.stringify(drives));
        getListDrives().then(function (drives) {
            drives.pop();
            console.log("Drives:" + JSON.stringify(drives));
            $scope.drives = drives;
        });
    } catch (error) {
        console.error(error);
    }
    //eof head
    getXML("resources\\xml\\index.xml", "resources\\xml\\index.xslt", "appplugins", true, false);
    setTimeout(() => {
        set_DragOver('maindrop', 'newdb', "htmlout", "outFile", $scope.allowedExt);
        console.log("set_DragOver done.");
        execCMD("resources\\cmd\\register.config.bat", "_app", true, false);
        // execCMD("resources\\cmd\\checkrequirement.bat .\\resources\\cmd\\csv\\check.csv", "_app", true, false);
    }, 3000);
    // get_Download_File(dlPath, "app.xml", resDir + "app.xml", resDir, "out_cnt");
    // get_Download_File(dlPath, "app.xslt", resDir + "app.xslt", resDir, "out_cnt");


    // alert($scope.cfg.apiexternal[0].url);
    $http.get($scope.cfg.apiexternal[0].url)
        .success(function (data) {
            $scope.index = data.list;
        });

    $http.get($scope.cfg.apiexternal[1].url)
        .success(function (data) {
            $scope.news = data.row;
        });

    $http.get($scope.cfg.apiexternal[2].url)
        .success(function (data) {
            $scope.security = data.row;
        });

    $http.get($scope.cfg.apiexternal[3].url)
        .success(function (data) {
            $scope.downloads = data.row;
        });
    $http.get($scope.cfg.apiexternal[4].url)
        .success(function (data) {
            $scope.otherdownloads = data.row;
        });
    $http.get($scope.cfg.apiexternal[5].url)
        .success(function (data) {
            $scope.person = data.row;
        });
    console.log("api:" + JSON.stringify($scope.cfg.apiexternal[5].url));
    $http.get($scope.cfg.apiexternal[5].url)
        .success(function (data) {
            $scope.onlineplugindownloads = data.row;
        });
    $http.get($scope.cfg.apiexternal[6].url)
        .success(function (data) {
            $scope.onlinedownloads = data.row;
        });
    console.log("log api:" + $scope.cfg.apiexternal[7].url + "&timestamp=" + new Date().getTime() + "" + "&query=" + encodeURIComponent(JSON.stringify(browserDetails)));
    $http.get($scope.cfg.apiexternal[7].url + "&timestamp=" + new Date().getTime() + "&query=" + encodeURIComponent(JSON.stringify(browserDetails)))
        .success(function (data) {
            // console.log("log");
            $scope.log = data;
        });
    $http.get($scope.cfg.apiexternal[11].url)
        .success(function (data) {
            $scope.alerts = data.row;
        });
    $http.get($scope.cfg.apiexternal[12].url)
        .success(function (data) {
            var drives = data.drives;
            $scope.drives = drives;
            try {
                console.log("Drives:" + JSON.stringify(drives));
                getListDrives().then(function (drives) {
                    drives.pop();
                    $scope.drives = drives;
                    console.log("Drives:" + JSON.stringify(drives));
                    // printDirectory(drives[0], 'files', false, false);
                    // printDirectory(drives[0], 'localfiles', false, false);
                });
            } catch (error) {
                console.error(error);
            }
        });
    // alert($scope.cfg.apiexternal[7].url);
    var scDate = (new Date().toISOString() + "").substring(0, 10);
    var surl = ($scope.cfg.apiexternal[8].url).replace("cdate=2026-01-01", "cdate=" + scDate);
    console.log("regDays URL:" + surl);
    $http.get(surl)
        .success(function (data) {
            $scope.regDays = data;

        });
    // console.log("LISTING DRIVES !!!");

    // model.initDb('' + webRoot, //app.getPath('userData'),
    //     // Load a DOM stub here. See renderer.js for the fully composed DOM.
    //     //mainWindow.loadURL(`file:${__dirname}/app/html/index.html`)
    //     console.log('Init Database')
    // );
    $scope.data = getSQLQuery('select * from systables order by person_id asc, name asc', $scope.currentDB);
    $scope.other = getSQLQuery('select * from other order by person_id asc, name asc', $scope.currentDB);
    $scope.dataplugins = getSQLQuery('select * from plugins order by person_id asc, name asc', $scope.currentDB);
    $scope.dropdowns = getSQLQuery('select * from dropdowns order by person_id asc, name asc', $scope.currentDB);
    // console.log(JSON.stringify(remote.getGlobal('sharedObject').get('query')));
    // var query;
    // if (remote !== undefined && remote.getGlobal !== undefined && remote.getGlobal('sharedObject') !== undefined) {
    //     query = remote.getGlobal('sharedObject').query;
    //     console.log('query fond:'+query);
    // }

    var query = getSQLQuery('select first_name from params order by person_id asc, name asc', $scope.currentDB);
    query = JSON.parse(JSON.stringify(query));
    query = query["0"]["first_name"];
    // console.log('Parameter:' + JSON.stringify(query));
    $scope.loadedplugin = getSQLQuery('select * from application where first_name like \'%' + query + '%\' or name like \'%' + query + '%\' order by person_id asc, name asc limit 1', $scope.currentDB);
    const pluginUrl = $scope.loadedplugin?.[0]?.url;
    if (pluginUrl && pluginUrl !== undefined && pluginUrl.trim() !== '') {
        // 2. Sichere und performante Ausführung statt eval()
        try {
            const executePlugin = new Function(pluginUrl);
            executePlugin();
        } catch (error) {
            console.error('Fehler beim Ausführen des Plugins:', error);
        }
    } else {
        console.log('No plugin found.');
    }
    // console.log("Site:" + currentSite);
    switch (currentSite) {
        case "search":
            console.log("Site:" + currentSite);
            console.log("DATA:" + JSON.stringify($scope.data));
            // getXML("search.xml", "search.xslt", "out_cnt", true, false);
            getXML("resources\\xml\\search.xml", "resources\\xml\\search.xslt", "out", true, false);
            $scope.query = getURLParam('query') !== null && getURLParam('query') !== undefined ? getURLParam('query') : "";
            console.log("Search:" + JSON.stringify($scope.query));
            searchPage(query);

            // $scope.data = getSQLQuery('select * from systables order by person_id asc, name asc', $scope.currentDB);
            break;

        default:
            console.log("default Site:" + currentSite);
            document.getElementById('appplugins').innerHTML += '<input type="button" value="Load news" onclick="getXML(\'resources\\xml\\app.xml\', \'resources\\xml\\app.xslt\',\'out_cnt\');"></input>';
            getXML("resources\\xml\\app.xml", "resources\\xml\\app.xslt", "appplugins", true, false);

            document.getElementById('out').innerHTML += '<input type="button" value="Load menu" onclick="getXML(\'resources\\xml\\menu.xml\', \'resources\\xml\\menu.xslt\',\'out\');"></input>';
            // let _cookie = document.cookie;
            var url = "https://www.letztechance.org";
            var _cookie = document.cookie; // get_Cookie(url, "isLoggedInAndShown", "true");
            try {

                if ($scope.cfg.isIntroLoaded == true) {
                    getExtFile('https://www.letztechance.org/LC2Intro.v.4.0/', 'intro', 'top=500,left=200,width=640,height=960,frame=true,nodeIntegration=no');
                    // getExtFile('http://localhost/LC2Intro.v.4.0/index.html', 'intro', 'top=500,left=200,width=640,height=960,frame=true,nodeIntegration=no');
                    console.log('Intro loading done.');
                }

                if ($scope.cfg.isClockLoaded == true && $scope.cfg.isClockLoadedRequest == true) {
                    if (getConfirmation('Show LC2Fluid now?')) { getExtFile('https://www.letztechance.org/tools/lc2fluid/', 'fluid-clock', 'top=10,left=10,width=320,height=320,frame=true,nodeIntegration=no') };
                    console.log('clock request loading done.');
                }
                else {
                    if ($scope.cfg.isClockLoaded == true) {
                        getExtFile('https://www.letztechance.org/tools/lc2fluid/', 'fluid-clock', 'top=10,right=0,width=320,height=320,frame=false,nodeIntegration=no');
                        console.log('clock loading done.');
                    } else {
                        console.log('clock not loading done.');
                    }

                }



                if ($scope.cfg.isServerLoaded == true) {
                    // getOpenDialog('#out', '.\\assets\\html\\dialog\\backend.html', 'Backend', { top: 90, left: 90, minWidth: 250, margin: 0, minHeight: 150, width: 300, height: 300 });
                    getOpenDialog('#importGUI_cnt', '.\\assets\\html\\dialog\\install.html', 'Check Installation and Configuration', { top: 100, left: 100, minWidth: 250, margin: 0, minHeight: 150, width: 400, height: 400 });
                    //getExtFile('http://localhost:8085', 'backend', 'top=500,left=100,width=640,height=480,frame=true,nodeIntegration=yes');
                    // getload_File('file:///./assets/html/dialog/server.html',"resizable=true,toolbar=false,status=true,menubar=false,frame=true,nodeIntegration=true,top=10, left=200,innerWidth=300, width=300,innerHeight=400, height=400");
                    // getExtFile('file:///./assets/html/dialog/server.html', 'serverlauncher', 'top=50,left=50,width=340,height=260,frame=true,nodeIntegration=yes');
                    // getExtFile('http://localhost:8084', 'serverlauncher', 'top=50,left=50,width=340,height=460,frame=true,nodeIntegration=yes');
                    // getOpenDialog('#_app', 'http://localhost:8084', 'Check Installation and Configuration', { top: 100, left: 100, minWidth: 250, margin: 0, minHeight: 150, width: 300, height: 600 });
                }
                //openBrowser('https://www.letztechance.org/LC2Intro.v.4.0/index.html');

                // console.log("cookie:" + JSON.stringify(_cookie) + " !!!");
                // if (_cookie === undefined || _cookie.value == "false") {
                //     console.log("Cookie NOT found.");
                // }
                // else {
                //     console.log("Cookie found.");
                // }
                // document.cookie = "isLoggedInAndShown=true; expires=Thu, 01 Jan 2026 00:00:00 UTC; path=/;";
                // document.cookie = "isLoggedInAndShown=true;";
                // set_Cookie("https://www.letztechance.org", "isLoggedInAndShown", "true");
                // found = set_Cookie("https://www.letztechance.org");
                // console.log("FOUND:" + JSON.stringify(_cookie) + " !!!");
                //getload_File('file:///./resources/plugins/LC2Intro/v.1.3/index.html',"resizable=true,toolbar=false,status=true,menubar=false,frame=true,nodeIntegration=true,top=10, left=200,innerWidth=700, width=700,innerHeight=960, height=960");
            } catch (error) {
                console.error(error);
                console.error(error.stack);
            }
            break;
    }

    console.log("Checking if is online or not:");
    const updateOnlineStatus = () => {
        console.log(navigator.onLine ? 'online' : 'offline');
        $('.cm-footer').find('.pull-left').html(("Anonymous, not logged in and " + (navigator.onLine ? 'online' : 'offline')) + "");
    }
    window.addEventListener('online', updateOnlineStatus);
    window.addEventListener('offline', updateOnlineStatus);
    updateOnlineStatus();


    setTimeout(() => {
        $('#out_cal').load('../../assets/html/calendar.html');
        setTimeout(() => {
            init_Scheduler();
        }, 5000);
    }, 1000);



    // when the data is altered, filter the items and set the page
    $scope.$watch('data', function (data, old) {
        $scope.filteredItems = $filter('filter')(data, $scope.query);
        if (old === null) setPage();
    });

    // when the query value changes, refilter the data
    $scope.$watch('query|json', function () {
        $scope.filteredItems = $filter('filter')($scope.data, $scope.query);
    });


    // when the current page is changed by the pagination control, update the list of items
    $scope.$watch('currentPage', function (page) {
        console.log('currentPage');
        setPage();
    });

    // when the filtered items are set, recalculate the number of pages
    $scope.$watch('filteredItems', function (items, old) {
        console.log('filteredItems');
        $scope.currentPage = 1;
        if (items !== undefined && items.length !== undefined)
            $scope.numOfPages = Math.ceil(items.length / $scope.pageSize);
    });

    // when the page start is changed, update the list of paged items
    $scope.$watch('startItems', function (items) {
        console.log('startItems:' + $scope.currentPage);
        $scope.pagedItems = $filter('limitTo')(items, $scope.pageSize);
        $scope.end = ($scope.currentPage - 3) * $scope.pageSize + $scope.pagedItems.length;
    });
    //functions
    // set the pagination for the filtered items
    function setPage() {
        console.log('setPage:' + $scope.currentPage);
        $scope.start = ($scope.currentPage - 1) * $scope.pageSize + ($scope.filteredItems === undefined && $scope.filteredItems.length ? 1 : 0);
        $scope.startItems = $filter('startFrom')($scope.filteredItems, $scope.start + 1);
    }
    //new
    // ==========================================
    // PAGING LOGIK ERGÄNZUNG
    // ==========================================

    // Funktion zur Berechnung und Aktualisierung der angezeigten Elemente
    $scope.updatePagination = function () {
        // Gesamtzahl der Seiten berechnen
        $scope.numOfPages = Math.ceil($scope.filteredItems.length / $scope.pageSize);

        // Grenzen für den aktuellen Datensatz-Ausschnitt berechnen
        $scope.start = ($scope.currentPage - 1) * $scope.pageSize;
        $scope.end = $scope.start + $scope.pageSize;

        // Daten für die aktuelle Seite zuschneiden
        $scope.pagedItems = $scope.filteredItems.slice($scope.start, $scope.end);
    };

    // Überwacht Änderungen an den Daten oder der Seitenauswahl
    // $scope.$watchGroup(['currentPage', 'pageSize', 'filteredItems'], function () {
    //     $scope.updatePagination();
    // });

    // Beispiel-Initialisierung: Falls gefilterte Items initial leer sind, 
    // müssen sie mit den Grunddaten (z.B. aus einer API) verknüpft werden:
    $scope.$watch('data', function (newData) {
        if (newData && newData.length > 0) {
            $scope.filteredItems = newData;
            $scope.updatePagination();
        }
    }, true);
    //eof new

    function searchPage(query) {
        $scope.data = [];
        var files = get_DirectoryFiles("resources");
        var insert = { "id": "0", "created": "2025-02-02 03:12:03", "enddate": "2025-02-02 03:12:03", "name": "search", "sname": "search", "first_name": "search", "last_name": "search", "city": null, "street": null, "zipcode": null, "description": "search", "url": "list.html?db=lc&table=systables', 'out')" };
        $scope.data.push(insert);
        for (var v in files) {
            var f = files[v];
            var f2 = f.replace(".db", "");
            if (f.includes(".db")) {
                insert = { "id": v, "created": "2025-02-02 03:12:03", "enddate": "2025-02-02 03:12:03", "name": "" + f2 + "", "sname": "" + f2 + "", "first_name": "" + f + "", "last_name": "" + f2 + "", "city": null, "street": null, "zipcode": null, "description": "" + f + "", "url": "list.html?action=search&db=" + f + "&table=" + f2 + "', 'out')" };
                // console.log("Insert:"+JSON.stringify(insert));
                $scope.data.push(insert);
                try {
                    console.log("Insert:" + $scope.data.length);
                    var tdata = getSQLQuery('select * from ' + f2 + ' where name like \'%' + query + '%\'  order by person_id asc, name asc limit 100', "resources\\" + f);
                    for (var vv in tdata) {
                        try {
                            insert = { "id": v, "created": "2025-02-02 03:12:03", "enddate": "2025-02-02 03:12:03", "name": "" + tdata[vv]["name"] + "", "sname": "" + tdata[vv]["name"] + "", "first_name": "" + tdata[vv]["name"] + "", "last_name": "" + tdata[vv]["name"] + "", "city": null, "street": null, "zipcode": null, "description": "" + tdata[vv]["description"] + "", "url": "read.html?" + tdata[vv]["url"] + "', 'out')" };
                            $scope.data.push(insert);
                        } catch (error) {
                            console.error(error);
                        }

                    }
                } catch (error) {
                    console.error(error);
                }
            }

        }
    }

    function getAppConfig(appConfigFileName) {
        const fs = window.nodeRequire('fs');
        let rawdata = fs.readFileSync(appConfigFileName);
        let appConfig = JSON.parse(rawdata);
        // console.log(appConfig);
        return appConfig;
    }

    function init_Scheduler() {
        // window.addEventListener("DOMContentLoaded", function () {
        try {
            console.log('scheduler running...');
            scheduler.plugins({
                recurring: true,
                minical: true
            });

            scheduler.config.multi_day = true;
            scheduler.config.event_duration = 35;
            scheduler.config.occurrence_timestamp_in_utc = true;
            scheduler.config.include_end_by = true;
            scheduler.config.repeat_precise = true;
            scheduler.config.repeat_date = "%d-%m-%Y";
            scheduler.attachEvent("onclick", function (event) {
                console.log(JSON.stringify(this._events[event]["url"]));
                openBrowser("https://www.letztechance.org/" + this._events[event]["url"]);
            });
            console.log('scheduler attach event(s)...');
            scheduler.attachEvent("onLightbox", function () {
                var lightbox_form = scheduler.getLightbox(); // this will generate lightbox form
                var inputs = lightbox_form.getElementsByTagName('input');
                var date_of_end = null;
                console.log('checking inputs.');
                for (var i = 0; i < inputs.length; i++) {
                    if (inputs[i].name == "date_of_end") {
                        date_of_end = inputs[i];
                        break;
                    }
                }
                console.log('date_of_end:' + date_of_end);

                var repeat_end_date_format = scheduler.date.date_to_str(scheduler.config.repeat_date);
                var show_minical = function () {
                    if (scheduler.isCalendarVisible())
                        scheduler.destroyCalendar();
                    else {
                        scheduler.renderCalendar({
                            position: date_of_end,
                            date: scheduler.getState().date,
                            navigation: true,
                            handler: function (date, calendar) {
                                date_of_end.value = repeat_end_date_format(date);
                                console.log('Inserting recurring end date:' + date_of_end.value);
                                // getSQLQuery('UPDATE `OTHER` (NAME, FIRST_NAME, URL  ) VALUES ( "Menu v.1.0", "Menu v.1.0","test");', dbPath);
                                getSQLQuery('INSERT INTO other("enddate","name","first_name","last_name","description","zipcode","city","street","url") VALUES (\'' + date_of_end.value + '\',\'' + inputs[0].value + '\',\'' + inputs[0].value + '\',\'' + inputs[0].value + '\',\'' + inputs[0].value + '\',\'' + inputs[0].value + '\',\'' + inputs[0].value + '\',\'' + inputs[0].value + '\',\'' + inputs[0].value + '\',\'' + inputs[0].value + '\');', dbPath);
                                scheduler.destroyCalendar();
                            }
                        });
                    }
                };
                date_of_end.onclick = show_minical;
                console.log('Inserting recurring end date:' + date_of_end.value);
                getSQLQuery('INSERT INTO other("enddate","name","first_name","last_name","description","zipcode","city","street","url") VALUES (\'' + date_of_end.value + ' 01:01:01\',\'' + inputs[0].value + '\',\'' + inputs[0].value + '\'\'' + inputs[0].value + '\',\'' + inputs[0].value + '\',\'' + inputs[0].value + '\',\'' + inputs[0].value + '\',\'' + inputs[0].value + '\',\'' + inputs[0].value + '\',\'' + inputs[0].value + '\');', dbPath);
                console.log('scheduler done.');
            });

            scheduler.config.lightbox.sections = [
                { name: "description", height: 50, map_to: "text", type: "textarea", focus: true },
                { name: "recurring", type: "recurring", map_to: "rec_type", button: "recurring" },
                { name: "time", height: 72, type: "calendar_time", map_to: "auto" }
            ];
            scheduler.init('lc2scheduler', new Date(), "day");
            var result = '{ "data": [';
            result += '{ "id": "10000", "start_date": "2000-01-10 00:00:00", "end_date": "2030-12-31 00:00:00", "text": "Welcome to LC", "details": "LetzteChance.Org Siegburg, DE", "allDays": "true"},';
            result += concatTableToJSON($scope.data, 0);
            result += concatTableToJSON($scope.loadedplugin, 15);
            result += concatTableToJSON($scope.other, 41);
            var count = 0;
            var regDays = $scope.regDays;
            console.log('count:' + count);
            // console.log("JSON:"+JSON.stringify(regDays));
            for (var s in regDays) {
                try {
                    // console.log("Value:"+JSON.stringify(regDays));
                    var ID;
                    var name = "N/A";
                    var title = "N/A";
                    try {
                        ID = +(regDays[s]["id"]);
                        title = regDays[s]["title"];
                        name = encode_utf8(decode_utf8((title !== undefined) ? (title).replace(/"/g, '&quot;') : (ID).replace(/[^\w\s]/gi, '') + "-NA"));
                    } catch (error) {
                        // console.error("ERROR:" + error + " title:" + title);
                        try {
                            name = encodeURI(title);
                        } catch (error) {
                            console.error("ERROR:" + error + " title:" + title);
                        }
                    }
                    var desc = name;
                    try {
                        desc = regDays[s]["url"].replace(/"/g, '&quot;');
                    } catch (error) {
                        console.error(error);
                    }
                    var created = ("" + regDays[s]["start"]).substring(0, 13) + ":00:01";
                    var enddate = ("" + regDays[s]["end"]).substring(0, 11) + "23:59:59";
                    var line = '{ "id": "' + ID + '", "start_date": "' + created + '", "end_date": "' + enddate + '", "text": "' + name + '", "details": "' + name + '-' + desc + '", "url": "' + desc + '"},';
                    // console.log(line);
                    result += line;
                    count++;
                    // console.log('count:' + count + " created:" + created + " enddate:" + enddate);
                    if (count == 10000) break;
                } catch (error) {
                    console.error(error);
                }
            }
            result += '{ "id": "10000001", "start_date": "2021-01-10 23:00:00", "end_date": "2300-01-16 23:00:00", "text": "Welcome to LC\\n(c)by David Honisch", "details": "LetzteChance.Org Siegburg, DE"}';
            result += "]  }";
            console.log('final count:' + count);
            //write to fs
            var eventsFile = "../../assets/data/events.json";
            var eventsOutFile = "./assets/data/events.json";
            write_file(eventsOutFile, result);
            scheduler.load(eventsFile, function () {
                // scheduler.showLightbox(10000001);
            });
        } catch (error) {
            console.error(error);
        }


        // });

    }

    function concatTableToJSON(table, add) {
        var result = "";
        for (var s in table) {
            var ID = +(table[s]["id"]) + add;
            var name = table[s]["name"];
            var desc = table[s]["description"];
            var created = ("" + table[s]["created"]).substring(0, 13) + ":00:00";
            var enddate = ("" + table[s]["enddate"]).substring(0, 13) + ":30:00";
            //console.log(""+ID+"-"+name + "=" + created + "=" + enddate);
            result += '{ "id": "' + ID + '", "start_date": "' + created + '", "end_date": "' + enddate + '", "text": "' + name + '", "details": "' + name + " Descripion:" + desc + '"},';

        }
        return result;

    }

}

// angular directive to change default behavior from processing input change immediately to on blur or enter
app.directive('ngModelBlur', function () {
    return {
        restrict: 'A',
        require: 'ngModel',
        link: function (scope, elm, attr, ngModelCtrl) {
            if (attr.type === 'radio' || attr.type === 'checkbox') { return; }

            elm.unbind('input').unbind('keydown').unbind('change');
            elm.bind('blur keydown', function (e) {
                if (e.type === 'keydown' && e.which !== 13) { return; }

                scope.$apply(function () {
                    ngModelCtrl.$setViewValue(elm.val());
                });
            });
        }
    };
});

// angular filter to take array items starting from provided index
app.filter('startFrom', function () {
    return function (input, start) {
        if (angular.isArray(input)) {
            var st = parseInt(start, 10);
            if (isNaN(st)) st = 0;
            return input.slice(st);
        }
        return input;
    };
});