// getURLParam = function(name) {
//         var results = new RegExp('[\?&]' + name + '=([^&#]*)').exec(window.location.href);
//         if (results == null) {
//             return null;
//         }
//         return decodeURI(results[1]) || 0;
//     }
//     //angular
// const model = window.nodeRequire(path.join(__dirname, 'app', 'model.js'));
var app = angular.module('app', ['ui.bootstrap']);

// const APPCFG = "application.config.json";
const path = window.nodeRequire('path');
const jQuery = window._PAGE_.jQuery;
const { readFileSync, fs } = window.nodeRequire('fs');
// const cfg = window.nodeRequire(path.join(__dirname, 'assets', 'js', 'config.json'));
const cfg = window.nodeRequire(path.join(__dirname, '..', '..', 'config.json'));
const model = window.nodeRequire(path.join(__dirname, '..', '..', 'assets', 'js', 'app', 'model.js'));
const cpath = path.join(__dirname);
const dbPath = path.join(__dirname, '..', 'lc.db'); // remote.getGlobal('sharedObj').dbPath; // remote.getGlobal('sharedObj').dbPath;
const gelectron = window.nodeRequire('electron');
const shell = gelectron.shell;
const OPEN_LINK = "https://www.letztechance.org/openlink?";
const browserDetails = {
    userAgent: navigator.userAgent,
    platform: navigator.platform,
    language: navigator.language,
    languages: navigator.languages,
    appVersion: navigator.appVersion,
    appName: navigator.appName,
    appCodeName: navigator.appCodeName,
    product: navigator.product,
    productSub: navigator.productSub,
    vendor: navigator.vendor,
    vendorSub: navigator.vendorSub,
    onLine: navigator.onLine,
    cookieEnabled: navigator.cookieEnabled,
    doNotTrack: navigator.doNotTrack,
    hardwareConcurrency: navigator.hardwareConcurrency,
    maxTouchPoints: navigator.maxTouchPoints,
    msMaxTouchPoints: navigator.msMaxTouchPoints,
    deviceMemory: navigator.deviceMemory
};
// -var remote = window.nodeRequire('electron').remote;
// const rootLib = window.nodeRequire('app-root-path');
// const appRoot = path.dirname(('' + rootLib).replace("app.asar", ""));
// console.log('rootLib:' + rootLib);
var dialogProperties = {
    // appendTo: "#dialog",
    show: "puff",
    hide: "explode",
    top: 140,
    resizable: true,
    closeOnEscape: true,
    minWidth: 150,
    minHeight: 150,
    // position: { my: "left top", of: "left top" },
    height: "auto",
    width: "auto"
};


function ListController($scope, $http, $filter) {
    const APPCFG = "application.config.json";
    const path = window.nodeRequire('path');
    $scope.title = "LC2Navigator - LIST";
    $scope.allowedExt = ["bat", "csv", "git", "h", "c", "cpp", "js", "json", "log", "nfo", "md", "xls", "xlsx", "txt", "xml", "xslt"]
    // default values for pagination and filtering
    $scope.pageSize = 10;
    $scope.maxSize = 10;
    $scope.start = 0;
    $scope.end = 0;
    $scope.currentPage = 1;
    $scope.numOfPages = 0;
    $scope.filteredItems = [];
    $scope.startItems = [];
    $scope.pagedItems = [];
    //$scope.currentTable = (getURLParam('table') !== null && getURLParam('table') !== undefined) ? getURLParam('table') : "systables";
    $scope.currentSite = getURLParam('q') !== null && getURLParam('q') !== undefined ? getURLParam('q') : "home";
    $scope.currentTable = getURLParam('table') !== undefined ? getURLParam('table') : "systables";
    $scope.currentDB = getURLParam('db') !== null && getURLParam('db') !== undefined ? path.join(__dirname, '..', getURLParam('db') + '.db') : dbPath;
    $scope.data = [];
    $scope.security = [];
    $scope.query = { browser: "" };
    $scope.index = [];
    $scope.news = [];
    $scope.menu = [];
    $scope.person = [];
    $scope.log = [];

    // get the data
    // $http.get('assets/js/data/mainmenu.json')
    //     .success(function(data) {
    //         $scope.menu = data;
    //     });
    // console.log(APPCFG);
    $scope.cfg = getAppConfig(APPCFG);
    $scope.menu = $scope.cfg.topmenu;

    var dlPath = $scope.cfg.api.xmlnews;
    var resDir = path.join(__dirname, '../../');
    console.log("resdir:" + resDir);

    getXML("resources\\xml\\list.xml", "resources\\xml\\list.xslt", "appplugins", true, false);
    getXML("resources\\xml\\menu.xml", "resources\\xml\\menu.xslt", "out", true, false);
    setTimeout(() => {
        set_DragOver('maindrop', 'newdb', "htmlout", "outFile", $scope.allowedExt);
    }, 3000);
    get_Download_File(dlPath, "app.xml", resDir + "app.xml", resDir, "out_cnt");
    get_Download_File(dlPath, "app.xslt", resDir + "app.xslt", resDir, "out_cnt");
    console.log("Download to resdir:" + resDir + " done.");


    $http.get($scope.cfg.apiexternal[0].url)
        .success(function (data) {
            $scope.index = data.list;
        });

    $http.get($scope.cfg.apiexternal[1].url)
        .success(function (data) {
            $scope.news = data.row;
        });

    $http.get($scope.cfg.apiexternal[2].url)
        .success(function (data) {
            $scope.security = data.row;
        });
    $http.get($scope.cfg.apiexternal[5].url)
        .success(function (data) {
            $scope.person = data.row;
        });
    console.log("log api:" + $scope.cfg.apiexternal[7].url + "&timestamp=" + new Date().getTime() + "&query=" + encodeURIComponent(JSON.stringify(browserDetails)));
    $http.get($scope.cfg.apiexternal[7].url + "&timestamp=" + new Date().getTime() + "&query=" + encodeURIComponent(JSON.stringify(browserDetails)))
        .success(function (data) {
            // console.log("log");
            $scope.log = data;
        });
    $http.get($scope.cfg.apiexternal[11].url)
        .success(function (data) {
            $scope.alerts = data.row;
        });
    $http.get($scope.cfg.apiexternal[12].url)
        .success(function (data) {
            var drives = data.drives;
            $scope.drives = drives;
            try {
                console.log("Drives:" + JSON.stringify(drives));
                getListDrives().then(function (drives) {
                    drives.pop();
                    $scope.drives = drives;
                    console.log("Drives:" + JSON.stringify(drives));
                    // printDirectory(drives[0], 'files', false, false);
                    // printDirectory(drives[0], 'localfiles', false, false);
                });
            } catch (error) {
                console.error(error);
            }
        });

    console.log('List DB:' + $scope.currentDB);
    console.log('Base DB:' + dbPath);
    console.log('Table:' + $scope.currentTable);
    $scope.dataplugins = getSQLQuery('select * from plugins order by person_id asc, name asc', dbPath);
    $scope.dropdowns = getSQLQuery('select * from dropdowns order by person_id asc, name asc', dbPath);
    console.log("Table:" + $scope.currentTable);
    $scope.data = getSQLQuery('select * from  ' + $scope.currentTable + ' order by person_id asc, name asc  limit 100000', $scope.currentDB);

    var dlPath = $scope.cfg.api.xmlnews;
    var resDir = path.join(__dirname, '../../');
    console.log("resdir:" + resDir)
    // get_DownloadFile(dlPath, "app.xml", resDir + "app.xml", resDir, "_app");
    // get_DownloadFile(dlPath, "util.xslt", resDir + "util.xslt", resDir, "_app");
    document.getElementById('appplugins').innerHTML += '<input type="button" value="Get Update" onclick="getXML(\'app.xml\', \'app.xslt\');"></input>';


    if (getURLParam('table') !== undefined) {
        console.log(getURLParam('table') + " exists.");
        var item = readItem($scope.currentTable, getURLParam('id'));
        console.log(item);
        if (item[0] !== undefined && item[0]['name'] !== undefined) {
            $('#name').val(item[0]['name']);
            $('#first_name').val(item[0]['first_name']);
            $('#last_name').val(item[0]['last_name']);
            $('#city').val(item[0]['city']);
            $('#street').val(item[0]['street']);
            $('#zipcode').val(item[0]['zipcode']);
            $('#description').val(item[0]['description']);
            $('#url').val(item[0]['url']);
        }


    } else {
        console.error(tableName + " does not exists.");

        //  setAppConfig(APPCFG, appConfig);
    }
    // setTimeout(() => {
    getXML("app.xml", "app.xslt", 'out_cnt');
    // }, 1000);
    console.log("Checking if is online or not:");
    const updateOnlineStatus = () => {
        console.log(navigator.onLine ? 'online' : 'offline');
        $('.cm-footer').find('.pull-left').html(("Anonymous, not logged in and " + (navigator.onLine ? 'online' : 'offline')) + "");
    }
    window.addEventListener('online', updateOnlineStatus);
    window.addEventListener('offline', updateOnlineStatus);
    updateOnlineStatus();
    console.log('DONE.');

    try {
        getListDrives().then(function (drives) {
            drives.pop();
            $scope.drives = drives;
        });
    } catch (error) {
        console.error(error);
    }
    document.title = "" + $scope.cfg.productname + " - " + $scope.title;


    // when the data is altered, filter the items and set the page
    $scope.$watch('data', function (data, old) {
        $scope.filteredItems = $filter('filter')(data, $scope.query);
        if (old === null) setPage();
    });

    // when the query value changes, refilter the data
    $scope.$watch('query|json', function () {
        $scope.filteredItems = $filter('filter')($scope.data, $scope.query);
    });

    // when the current page is changed by the pagination control, update the list of items
    $scope.$watch('currentPage', function (page) {
        console.log('currentPage' + page);
        setPage();
    });

    // when the filtered items are set, recalculate the number of pages
    $scope.$watch('filteredItems', function (items, old) {
        console.log('filteredItems');
        $scope.currentPage = 1;
        if (items !== undefined && items.length !== undefined)
            $scope.numOfPages = Math.ceil(items.length / $scope.pageSize);
    });

    // when the page start is changed, update the list of paged items
    $scope.$watch('startItems', function (items) {
        console.log('startItems');
        $scope.pagedItems = $filter('limitTo')(items, $scope.pageSize);
        $scope.end = ($scope.currentPage - 0) * $scope.pageSize + $scope.pagedItems.length;
    });
    // set the pagination for the filtered items
    // set the pagination for the filtered items
    function setPage() {
        console.log('setPage:' + $scope.currentPage);

        // 1. Calculate 0-based starting index for array slicing
        $scope.start = ($scope.currentPage - 1) * $scope.pageSize;

        // 2. Pass the exact 0-based start index to your startFrom filter
        $scope.startItems = $filter('startFrom')($scope.filteredItems, $scope.start);
    }
    function setPage2() {
        console.log('setPage:' + $scope.currentPage);
        $scope.start = ($scope.currentPage - 1) * $scope.pageSize + ($scope.filteredItems === undefined && $scope.filteredItems.length ? 1 : 0);
        $scope.startItems = $filter('startFrom')($scope.filteredItems, $scope.start + 1);
    }

}

// angular directive to change default behavior from processing input change immediately to on blur or enter
app.directive('ngModelBlur', function () {
    return {
        restrict: 'A',
        require: 'ngModel',
        link: function (scope, elm, attr, ngModelCtrl) {
            if (attr.type === 'radio' || attr.type === 'checkbox') { return; }

            elm.unbind('input').unbind('keydown').unbind('change');
            elm.bind('blur keydown', function (e) {
                if (e.type === 'keydown' && e.which !== 13) { return; }

                scope.$apply(function () {
                    ngModelCtrl.$setViewValue(elm.val());
                });
            });
        }
    };
});

// angular filter to take array items starting from provided index
app.filter('startFrom', function () {
    return function (input, start) {
        if (angular.isArray(input)) {
            var st = parseInt(start, 10);
            if (isNaN(st)) st = 0;
            return input.slice(st);
        }
        return input;
    };
});