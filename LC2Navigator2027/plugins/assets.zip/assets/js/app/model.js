'use strict'

const path = require('path');
const fs = require('fs');
// const SQL = require('sql.js');
const SQL = require(path.join(__dirname, '..','..','..','assets','js','app', 'sql.js'));
const view = require(path.join(__dirname, 'homeview.js'));

/*
 * SQL.js returns a compact object listing the columns separately from the
 * values or rows of data. This function joins the column names and values into
 * a single objects and collects these together by row id. { 0: {first_name:
 * "x", name: "xx", person_id: 1}, 1: {first_name: "xxx", name: "xxx",
 * person_id: 2}, } This format makes updating the markup easy when the DOM
 * input id attribute is the same as the column name. See view.showPeople() for
 * an example.
 */
let _rowsFromSqlDataObject = function (object) {
    let data = {}
    let i = 0
    let j = 0
    for (let valueArray of object.values) {
        data[i] = {}
        j = 0
        for (let column of object.columns) {
            Object.assign(data[i], {
                [column]: valueArray[j]
            })
            j++
        }
        i++
    }
    return data
}

/*
 * Return a string of placeholders for use in a prepared statement.
 */
let _placeHoldersString = function (length) {
    let places = ''
    for (let i = 1; i <= length; i++) {
        places += '?, '
    }
    return /(.*),/.exec(places)[1]
}

SQL.dbOpen = function (databaseFileName) {
    // alert(databaseFileName);
    try {
        return new SQL.Database(fs.readFileSync("" + databaseFileName))
    } catch (error) {
        console.error("Can't open database " + databaseFileName + " file.", error.message);
        // throw error;
        return null;
    }
}

SQL.dbClose = function (databaseHandle, databaseFileName) {
    try {
        let data = databaseHandle.export();
        let buffer = Buffer.alloc(data.length, data);
        fs.writeFileSync(databaseFileName, buffer);
        databaseHandle.close();
        return true;
    } catch (error) {
        console.log("Can't close database file.", error);
        return null;
    }
};

/*
 * A function to create a new SQLite3 database from schema.sql.
 * 
 * This function is called from main.js during initialization and that's why
 * it's passed appPath. The rest of the model operates from renderer and uses
 * window.model.db.
 */
module.exports.initDb = function (dbPath, callback) {
    console.log("Init Path:" + dbPath);
    // let dbPath = path.join(appPath, 'lc.db');
    let createDb = function (dbPath) {
        // Create a database.
        let db = new SQL.Database();
        var schema = path.join(__dirname, 'db', 'schema.sql');
        console.log("Init Schema:" + schema + " Path" + dbPath)
        let filequery = fs.readFileSync(schema, 'utf8')
        let result = db.exec(filequery);

        let query = 'SELECT count(*) as `count` FROM `sqlite_master`';
        let row = db.exec(query);
        console.log('DB MASTER COUNT:'+JSON.stringify(row));
        //query = '.separator ";.import .\resources\plugins\\sqlite3win\import\application.csv application';
        query = 'SELECT count(*) as `count` FROM `application`';
        row = db.exec(query);
        console.log('DB Applications COUNT:'+JSON.stringify(row));
        query = 'SELECT count(*) as `count` FROM `plugins`';
        row = db.exec(query);
        console.log('DB Plugins COUNT:'+JSON.stringify(row));

        if (Object.keys(result).length === 0 &&
            typeof result.constructor === 'function' &&
            SQL.dbClose(db, dbPath)) {
            console.log('Created a new database:' + dbPath + '.');
        } else {
            console.log('model.initDb.createDb failed.')
        }
    }
    let db = SQL.dbOpen(dbPath)
    if (db === null) {
        /* The file doesn't exist so create a new database. */
        createDb(dbPath)
    } else {
        /*
         * The file is a valid sqlite3 database. This simple query will demonstrate
         * whether it's in good health or not.
         */
        let query = 'SELECT count(*) as `count` FROM `sqlite_master`'
        let row = db.exec(query)
        let tableCount = parseInt(row[0].values)
        if (tableCount === 0) {
            console.log('The file is an empty SQLite3 database.')
            createDb(dbPath)
        } else {
            console.log('The database has', tableCount, 'tables.')
        }
        if (typeof callback === 'function') {
            callback()
        }
    }
}

/*
 * Populates the People List.
 */
module.exports.getQuery = function (_dbPath, ctab, query, id) {
    // let db = SQL.dbOpen(window.model.db)
    let db = SQL.dbOpen(_dbPath);
    if (db !== null) {
        try {
            console.log('SQL:' + query);
            let row = db.exec(query)
            if (row !== undefined && row.length > 0) {
                row = _rowsFromSqlDataObject(row[0])
                view.showPeople(_dbPath, row, ctab, id)
            }
        } catch (error) {
            console.log('model.getQuery', error.message)
        } finally {
            //SQL.dbClose(db, window.model.db)
            SQL.dbClose(db, _dbPath);
        }
    }
}
module.exports.GetQuery = function (_db, query) {
    let row;
    console.log('DB:' + _db +" q:"+query)
    let db = SQL.dbOpen(_db)
    if (db !== null) {
        try {
            console.log(query);
            row = db.exec(query)
            if (row !== undefined && row.length > 0) {
                row = _rowsFromSqlDataObject(row[0]);
            }
        } catch (error) {
            console.error('model.GetQuery', error.message);
            console.warn('Query', query);
            console.error('model.GetQuery', error.stack);
        } finally {
            SQL.dbClose(db, _db);
        }
    }
    return row;
}

/*
 * Fetch a person's data from the database.
 */
module.exports.getPerson = function (pid, query) {
    let db = SQL.dbOpen(window.model.db)
    if (db !== null) {
        // let query = 'SELECT * FROM `people` WHERE `person_id` IS ?'
        let statement = db.prepare(query, [pid])
        try {
            if (statement.step()) {
                let values = [statement.get()]
                let columns = statement.getColumnNames()
                return _rowsFromSqlDataObject({ values: values, columns: columns })
            } else {
                console.log('model.getQuery', 'No data found for person_id =', pid + " Query:" + query)
            }
        } catch (error) {
            console.log('model.getQuery', error.message)
        } finally {
            SQL.dbClose(db, window.model.db)
        }
    }
}

/*
 * Delete a person's data from the database.
 */
module.exports.deletePerson = function (_dbPath, table, pid, callback) {
    let db = SQL.dbOpen(_dbPath)
    if (db !== null) {
        // var ctable = $('#currentapp').val();
        let query = 'DELETE FROM `' + table + '` WHERE `person_id` IS ?';
        console.log('Query:' + query);
        let statement = db.prepare(query)
        try {
            if (statement.run([pid])) {
                if (typeof callback === 'function') {
                    callback()
                }
            } else {
                console.log('model.deletePerson', 'No data found for person_id =', pid)
            }
        } catch (error) {
            console.log('model.deletePerson', error.message)
        } finally {
            SQL.dbClose(db, _dbPath)
        }
    }
}

/*
 * Insert or update a person's data in the database.
 */
module.exports.saveFormData = function (_dbPath, tableName, keyValue, callback) {
    if (keyValue.columns.length > 0) {
        // let db = SQL.dbOpen(window.model.db)
        let db = SQL.dbOpen(_dbPath)
        if (db !== null) {
            let query = 'INSERT OR REPLACE INTO `' + tableName
            query += '` (`' + keyValue.columns.join('`, `') + '`)'
            query += ' VALUES (' + _placeHoldersString(keyValue.values.length) + ')';
            console.log('Query:' + query);
            let statement = db.prepare(query)
            try {
                if (statement.run(keyValue.values)) {
                    $('#' + keyValue.columns.join(', #'))
                        .addClass('form-control-success')
                        .animate({ class: 'form-control-success' }, 1500, function () {
                            if (typeof callback === 'function') {
                                callback()
                            }
                        })
                } else {
                    console.log('model.saveFormData', 'Query failed for', keyValue.values)
                }
            } catch (error) {
                console.log('model.saveFormData', error.message)
            } finally {
                SQL.dbClose(db, _dbPath)
            }
        }
    } else {
        console.log('model.saveFormData', 'Query is empty')
    }
}
module.exports.saveData = function (_dbPath, tableName, columns, values, callback) {
    if (columns.length > 0) {
        // let db = SQL.dbOpen(window.model.db)
        let db = SQL.dbOpen(_dbPath)
        if (db !== null) {
            let query = 'INSERT OR REPLACE INTO `' + tableName
            query += '` (`' + columns.join('`, `') + '`)'
            query += ' VALUES (' + _placeHoldersString(values.length) + ')';
            console.log('Query:' + query);
            let statement = db.prepare(query)
            try {
                if (statement.run(values)) {
                    $('#' + columns.join(', #'))
                        .addClass('form-control-success')
                        .animate({ class: 'form-control-success' }, 1500, function () {
                            if (typeof callback === 'function') {
                                callback()
                            }
                        })
                } else {
                    console.log('model.saveFormData', 'Query failed for', values)
                }
            } catch (error) {
                console.log('model.saveFormData', error.message)
            } finally {
                SQL.dbClose(db, _dbPath)
            }
        }
    } else {
        console.log('model.saveFormData', 'Query is empty')
    }
}
module.exports.saveQuery = function (_dbPath, query) {
    let db = SQL.dbOpen(_dbPath)
    if (db !== null) {
        let statement = db.prepare(query)
        try {
            if (statement.run()) {
                // $('#' + keyValue.columns.join(', #'))
                //     .addClass('form-control-success')
                //     .animate({ class: 'form-control-success' }, 1500, function() {
                //         if (typeof callback === 'function') {
                //             callback()
                //         }
                //     })
                console.log('model.saveFormData', 'Query failed for', query);
                if (typeof callback === 'function') {
                    callback()
                }
            } else {
                console.error('model.saveFormData', 'Query failed for', query)
            }
        } catch (error) {
            console.log('model.saveFormData', error.message)
        } finally {
            SQL.dbClose(db, _dbPath)
        }
    }

}

module.exports.saveSQLFile = function (_dbPath, file) {
    let db = SQL.dbOpen(_dbPath)
    if (db !== null) {
        let query = fs.readFileSync(file);
        let statement = db.prepare(query);
        try {
            if (statement.run()) {
                // $('#' + keyValue.columns.join(', #'))
                //     .addClass('form-control-success')
                //     .animate({ class: 'form-control-success' }, 1500, function() {
                //         if (typeof callback === 'function') {
                //             callback()
                //         }
                //     })
                console.log('model.saveFormData', 'Query failed for', query);
                if (typeof callback === 'function') {
                    callback()
                }
            } else {
                console.error('model.saveFormData', 'Query failed for', query)
            }
        } catch (error) {
            console.log('model.saveFormData', error.message)
        } finally {
            SQL.dbClose(db, _dbPath)
        }
    }

}