@echo off
cls
call %~dp0config.bat
@echo off
echo %LT%h4%RT% Maven Building:%title% %version% %LT%/h4%RT%
REM echo call%~dp0..\apache-maven\bin\mvn -f %~dp0pom.xml install
REM call %~dp0..\apache-maven\bin\mvn clean install
call %~dp0..\apache-maven\bin\mvn -f "%~dp0pom.xml" package>%temp%%plugin%-build.log
echo %LT%h4%RT% Maven Building:%title% %version% done. %LT%/h4%RT%
type %temp%%plugin%-build.log
timeout 0 > NUL 
@echo on 