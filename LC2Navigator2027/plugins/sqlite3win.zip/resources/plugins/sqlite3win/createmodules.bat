@echo off
cls
echo CREATING MODULES.XML
set IMPORTFILE=directories.csv
set mods=modules.xml
dir /AD /b>%IMPORTFILE%
type nul> %mods%
echo ^<modules^> >> %mods%
for /f "usebackq tokens=1-4 delims=," %%a in ("%IMPORTFILE%") do (
	echo ^<module^>%%a^</module^> >> %mods%
)
echo ^</modules^> >> %mods%
timeout 3