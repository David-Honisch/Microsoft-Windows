<xsl:stylesheet version="2.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform">

    <xsl:output indent="yes"></xsl:output>

    <xsl:template name="get-prefered">
        <xsl:param name="field-name"/> 

        <xsl:variable name="vCondition" select="name"/>
        <xsl:variable name="x" select="sources/source[@type='C']/$field-name"/>
        <xsl:value-of select="$x"></xsl:value-of>
    </xsl:template>

    <xsl:template match="/">
        <xsl:call-template name="get-prefered">
            <xsl:with-param name="field-name">name</xsl:with-param>
        </xsl:call-template>
        </xsl:template>
</xsl:stylesheet>