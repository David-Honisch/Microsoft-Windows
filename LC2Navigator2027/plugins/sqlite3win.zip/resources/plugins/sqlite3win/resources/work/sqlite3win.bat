@echo off
call %~dp0..\..\config.bat
REM echo ^<h1^>%plugin%^<h1^>
REM call tasklist /FO CSV /FI "STATUS eq running" /NH> %~dp0..\..\import\%plugin%work.csv
REM @echo off
REM echo ^<h4^>import processes into database...^<h4^>
REM call  "%sexec%" "%dbfile%" ".read .\\resources\\plugins\\%plugin%\\schema.sql"
REM @echo off
REM @echo off
REM call  "%sexec%" "%dbfile%" "select person_id, name, url,description,zipcode,city, street from %plugin% order by person_id asc" > %importFile%
REM @echo off
REM call  "%sexec%" "%dbfile%" "select person_id, name, url,description,zipcode,city, street from %plugintable% order by person_id asc" > %workFile%
REM @echo off
REM -------------------------------------------
REM echo %LT%input type="button" value="reload" class="btn btn-info" onclick="execPluginCMD('out','%plugin%');;"/%RT%
REM echo %LT%input type="button" value="install requirements" class="btn btn-warning" onclick="getOpenDialog('#dialog','.\\resources\\plugins\\%plugin%\\install.html','Install',{ minWidth: 250,  minHeight: 150, width: 400});"/%RT%
REM -------------------------------------------
echo ^<fieldset^>
echo ^<div id="inputKeyFile" class="btn btn-default"^>Drop a file^</div^>
echo ^<br^>
echo ^<input type="text" name="inputFile" id="inputFile" value="test.csv" /^>
echo ^<button type="button" class="btn btn-default" onclick="if(getConfirmation('Start task '+document.getElementById('inputFile').value+' now?')){execCMD('.\\resources\\plugins\\%plugin%\\video.bat '+document.getElementById('inputFile').value, '%plugin%result')};"^>Start^</button^>
echo ^<button type="button" class="btn btn-default" onclick="execCMD('.\\resources\\plugins\\%plugin%\\launch.bat '+document.getElementById('inputFile').value, '%plugin%');"^>Start^</button^>
echo ^</fieldset^>
echo ^<fieldset^>
REM echo  ^<legend^>Result:^</legend^>
REM echo ^<input type="text" id="inputKey2" value=".\\resources\\%plugin%.csv"/^>^<br^>
REM echo %importFile%
REM echo ^<div id="inputKeyFile" class="btn btn-default"^>Drop a file^</div^>
echo ^<br^>
REM echo ^<input type="text" name="inputFile" id="inputFile" value="test.csv" /^>
REM echo ^<button type="button" class="btn btn-default" onclick="execCMD('.\\resources\\plugins\\%plugin%\\launch.bat '+document.getElementById('inputFile').value, '%plugin%');"^>Start^</button^>
echo ^<hr^>

echo ^<select id="inputKey"^>
for /f "usebackq tokens=1-5 delims=|" %%a in ("%selectFile%") do (
	echo ^<option value="%%b" ^>%%b^</option^>
)
echo ^</select^>
echo ^<button type="button" class="btn btn-default" onclick="getExtFile(document.getElementById('inputKey').value);"^>Start^</button^>
echo ^<button type="button" class="btn btn-default" onclick="openBrowser(document.getElementById('inputKey').value);"^>Start Browser^</button^>
echo ^<div id="%plugin%result"^>^</div^>
echo ^</fieldset^>