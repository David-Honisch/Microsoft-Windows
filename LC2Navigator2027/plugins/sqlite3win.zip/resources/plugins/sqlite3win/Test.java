public class Test{

    public static final Class<Test> CLASS = Test.class;
    public static void main(String[] args) {

        System.out.println("Java "+CLASS.getName()+" is running...");
    }
}