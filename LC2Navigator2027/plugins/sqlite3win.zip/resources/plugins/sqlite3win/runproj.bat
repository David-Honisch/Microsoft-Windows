@echo off
REM call-java-class.bat path-to-lib-dir com.foo.bar.Main -help
REM java -cp ".;mysql-connector-j-8.0.33.jar" -jar lcdelivery\target\LC2UIBackend-0.0.1-SNAPSHOT.jar
::
:: %1 directory where all jars are located
:: %2 main class
:: %* program parameters
::
:: JAVA_OPTS ... parameter before main class
::
REM set libdir=%1
set libdir=sqlite3windelivery\target\libs\
REM set libdir=.\
REM shift
REM set main=%1
set main=sqlite3windelivery\target\LC2UIBackend-0.0.1-SNAPSHOT.jar
REM shift

set JARS=
set CLASSPATH=
set JAVA_OPTS=-jar
set APPEND=%~dp0cpappend.bat
REM echo deleting %libdir%*.jar
REM del %libdir%*.jar
echo %APPEND%
REM pause

pushd %libdir%
for %%i in (*.jar) do call %APPEND% %libdir%\%%i
REM for %%i in (%libdir%*.jar) do call %APPEND% %%i
set CLASSPATH=.%JARS%
popd

:: debug
echo %CLASSPATH%
echo %JAVA_HOME%\bin\java %main% %1 %2 %3 %4 %5 %6 %7 %8 %9
%JAVA_HOME%\bin\java %JAVA_OPTS% %main% %1 %2 %3 %4 %5 %6 %7 %8 %9