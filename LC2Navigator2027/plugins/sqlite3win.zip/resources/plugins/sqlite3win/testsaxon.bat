@echo off
SET "LT=^<"
SET "RT=^>"
cls
call %~dp0config.bat
@echo off
set "outFile=%1"
set "defaultFile=%~dp0csv\default.csv"
java -jar libs\Saxon-HE-12.0.jar pathToCSV=/tmp/a.csv -xsl:csvtoxml.xslt -it:main -o:output.xml