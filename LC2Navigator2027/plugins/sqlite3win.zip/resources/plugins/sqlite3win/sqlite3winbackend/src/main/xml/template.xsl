<?xml version="1.0" encoding="UTF-8"?>
<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform">
    <xsl:output encoding="iso-8859-1" />
    <xsl:template match="/">
        <html>
            <body>
                <xsl:apply-templates/>              (1)
            </body>
        </html>
    </xsl:template>
    <xsl:template match="Autor">
        <br/>
        <h4>
            <xsl:apply-templates/>
        </h4>
    </xsl:template>
    <xsl:template match="Vorname">
        <xsl:apply-templates/>
        <xsl:text> </xsl:text>                      (2)
    </xsl:template>
    <xsl:template match="Nachname">
        <xsl:apply-templates/>
    </xsl:template>
    <xsl:template match="Titel">
        <h2>
            <xsl:apply-templates/>
        </h2>
    </xsl:template>
    <xsl:template match="Strophe">
        <p>
            <xsl:apply-templates/>
        </p>
    </xsl:template>
    <xsl:template match="Vers">
        <xsl:apply-templates/>
        <br/>
    </xsl:template>
</xsl:stylesheet>