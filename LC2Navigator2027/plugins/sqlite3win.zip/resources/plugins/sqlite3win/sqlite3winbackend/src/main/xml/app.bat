@echo off
call app.exe test1 test2 test3