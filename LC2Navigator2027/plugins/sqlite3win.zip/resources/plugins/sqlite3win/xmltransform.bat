@echo off
cls
set "jarloader=%~dp0../LC2JXMLTransform/org.letztechance.domain.xml.Lib-0.0.1-SNAPSHOT-shaded.jar"
REM call java -jar %jarloader% %~dp0original.xml %~dp0overwiew.xslt %~dp0_transformed.xml.log
REM call java -jar %jarloader% "%1" "%2" "resources\plugins\LC2JXMLTransform\resources\transform.xml"
call java -jar %jarloader% "%1" "%2" "%3"
REM echo ^<hr~^>done
REM echo %1
timeout 3
@echo on