<?xml version="1.0" encoding="UTF-8"?>
<xsl:stylesheet version="1.0"	xmlns:xsl="http://www.w3.org/1999/XSL/Transform">
<xsl:variable name="color" select='"red"' />
	<xsl:template match="/">
<root>
  <xsl:template match="/">
    <html>
      <body>
        <h2>URLS</h2>
        <table border="1">
          <tr bgcolor="#9acd32">
            <th>Title</th>
            <th>Url</th>
          </tr>
          <xsl:for-each select="urlslist/urls">
            <tr>
              <td>
                <xsl:value-of select="title" />
              </td>
              <td>
			  
                <xsl:element name="a">
    <!-- <xsl:attribute name="href">javascript:openBrowser('{$url}');</xsl:attribute> -->
	<xsl:attribute name="href">javascript:openBrowser('{$url}');</xsl:attribute>
	<!-- <xsl:attribute name="onclick">alert('{$url}');</xsl:attribute> -->
    <xsl:value-of select="url"/>
</xsl:element>

                
              </td>
            </tr>
          </xsl:for-each>
        </table>
      </body>
    </html>
  </xsl:template>
  
   <xsl:template match="/">
   <xsl:for-each select="urlslist/urls">
   <input onclick="{@onclick}openBrowser();" type="button">
      <xsl:copy-of select="@*[not(name()='onclick')]"/>
   </input>
   </xsl:for-each>
 </xsl:template>
 <xsl:template match="text()"/>
  
</root>
</xsl:template>
</xsl:stylesheet>   