<?xml version="1.0" encoding="UTF-8"?>
<xsl:stylesheet version="1.0" xmlns="http://www.w3.org/1999/xhtml"
	xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns:html="http://www.w3.org/1999/xhtml">
	<xsl:output method="xml" indent="no" encoding="UTF-8"
		omit-xml-declaration="yes" />
 
	<xsl:param name="currentPage" />
	<xsl:template match="/">
		<xsl:variable name="recordsPerPage" select="5" />
		<xsl:variable name="pageNumber">
			<xsl:choose>
				<!-- first page -->
				<xsl:when test="$currentPage &lt;= 0 or $currentPage = '' or $currentPage = 'NaN'">0</xsl:when>
				<!-- what was passed in -->
				<xsl:otherwise>
					<xsl:value-of select="$currentPage" />
				</xsl:otherwise>
			</xsl:choose>
		</xsl:variable>
		<xsl:variable name="numberOfRecords" select="count(/group/item)" />
 
		<!-- The fun starts here -->
 
		<xsl:call-template name="pagination">
			<xsl:with-param name="pageNumber" select="$pageNumber" />
			<xsl:with-param name="recordsPerPage" select="$recordsPerPage" />
			<xsl:with-param name="numberOfRecords" select="$numberOfRecords" />
		</xsl:call-template>
 
		<ul class="listing self-clear">
			<xsl:for-each select="//item">
				<xsl:if
					test="position() &gt; $recordsPerPage * number($pageNumber) and position() &lt;= number($recordsPerPage * number($pageNumber) + $recordsPerPage )">
					<li>
						<xsl:attribute name="class">
							<xsl:if test="data[@alias='image'] = ''">
                                                        no-img
                                                </xsl:if>
                                                <xsl:if test="position() = $recordsPerPage * (number($pageNumber) + 1)">last</xsl:if></xsl:attribute>
						<h3>
							<a href="?p={position()}">
								<xsl:value-of select="text()" />
							</a>
						</h3>
					</li>
				</xsl:if>
			</xsl:for-each>
		</ul>
 
		<xsl:call-template name="pagination">
			<xsl:with-param name="pageNumber" select="$pageNumber" />
			<xsl:with-param name="recordsPerPage" select="$recordsPerPage" />
			<xsl:with-param name="numberOfRecords" select="$numberOfRecords" />
		</xsl:call-template>
 
	</xsl:template>
 
	<xsl:template name="pagination">
		<xsl:param name="pageNumber" />
		<xsl:param name="recordsPerPage" />
		<xsl:param name="numberOfRecords" />
 
		<div class="pagination">
			<div class="wrapper">
 
				<xsl:if
					test="(($pageNumber +1 ) * $recordsPerPage) &lt; ($numberOfRecords)">
					<a href="?page={$pageNumber +1}" class="next">Next</a>
				</xsl:if>
 
				<xsl:if test="$pageNumber &gt; 0">
					<a href="?page={$pageNumber -1}" class="prev">Prev</a>
				</xsl:if>
 
				<span class="page-nos">
					Page
					<xsl:call-template name="for.loop">
						<xsl:with-param name="i">
							1
						</xsl:with-param>
						<xsl:with-param name="page" select="$pageNumber +1"></xsl:with-param>
						<xsl:with-param name="count"
							select="ceiling(count(//item)div $recordsPerPage)"></xsl:with-param>
					</xsl:call-template>
				</span>
 
			</div>
		</div>
	</xsl:template>
 
	<xsl:template name="for.loop">
		<xsl:param name="i" />
		<xsl:param name="count" />
		<xsl:param name="page" />
		<xsl:if test="$i &lt;= $count">
			<span>
				<xsl:if test="$page != $i">
					<a href="?page={$currentPage}">
						<xsl:value-of select="$i" />
					</a>
				</xsl:if>
				<xsl:if test="$page = $i">
					<xsl:value-of select="$i" />
				</xsl:if>
			</span>
		</xsl:if>
 
		<xsl:if test="$i &lt;= $count">
			<xsl:call-template name="for.loop">
				<xsl:with-param name="i">
					<xsl:value-of select="$i + 1" />
				</xsl:with-param>
				<xsl:with-param name="count">
					<xsl:value-of select="$count" />
				</xsl:with-param>
 
				<xsl:with-param name="page">
					<xsl:value-of select="$page" />
				</xsl:with-param>
			</xsl:call-template>
		</xsl:if>
	</xsl:template>
</xsl:stylesheet>