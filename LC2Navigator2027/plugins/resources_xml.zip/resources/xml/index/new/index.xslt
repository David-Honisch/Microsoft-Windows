<?xml version="1.0" encoding="UTF-8"?>
<xsl:stylesheet version="1.0"
  xmlns:xsl="http://www.w3.org/1999/XSL/Transform">
  <xsl:variable name="color" select='"red"' />
  <xsl:template match="/">
    <root>
      <xsl:template match="/">
        <html>
          <body>
            <h1>
              <xsl:copy-of select="root/title/node()|@*" />
            </h1>
            <h4>
              <xsl:copy-of select="root/subtitle/node()|@*" />
            </h4>
            <hr></hr>
            <ul id="myTab" class="nav nav-tabs" role="tablist">
              <li role="presentation" class="active">
                <a href="#LC2NavMainMenu" id="LC2NavMainMenu-tab" role="tab" data-toggle="tab"
                  aria-expanded="true" aria-controls="LC2NavMainMenu">Menu</a>
              </li>
              <li role="presentation" class="">
                <a href="#LC2NavMainMenu_main" id="LC2NavMainMenu_main-tab" role="tab"
                  data-toggle="tab"
                  aria-expanded="false" aria-controls="LC2NavMainMenu_main">Main</a>
              </li>

              <li role="presentation" class="">
                <a href="#LC2NavMainMenu_newplugin" id="LC2NavMainMenu_newplugin-tab" role="tab"
                  data-toggle="tab"
                  aria-expanded="false" aria-controls="LC2NavMainMenu_newplugin">New Plugin</a>
              </li>

              <li role="presentation" class="">
                <a href="#LC2NavMainMenu_ki" id="LC2NavMainMenu_ki-tab" role="tab"
                  data-toggle="tab"
                  aria-expanded="false" aria-controls="LC2NavMainMenu_ki">KI</a>
              </li>

              <li role="presentation" class="">
                <a href="#LC2NavMainMenu_network" id="LC2NavMainMenu_network-tab" role="tab"
                  data-toggle="tab"
                  aria-expanded="false" aria-controls="LC2NavMainMenu_network">Network</a>
              </li>
              <li role="presentation" class="">
                <a href="#LC2NavMainMenu_database" id="LC2NavMainMenu_database-tab" role="tab"
                  data-toggle="tab"
                  aria-expanded="false" aria-controls="LC2NavMainMenu_database">Database</a>
              </li>
              <li role="presentation">
                <a href="#LC2NavMainMenu_install" id="LC2NavMainMenu_install-tab" role="tab"
                  data-toggle="tab" aria-expanded="false" aria-controls="LC2NavMainMenu_install">
    Install</a>
              </li>

              <li role="presentation">
                <a href="#LC2NavMainMenu_registry" id="LC2NavMainMenu_registry-tab" role="tab"
                  data-toggle="tab" aria-expanded="false" aria-controls="LC2NavMainMenu_registry">
    Registry</a>
              </li>

              <li role="presentation">
                <a href="#LC2NavMainMenu_help" id="LC2NavMainMenu_help-tab" role="tab"
                  data-toggle="tab"
                  aria-expanded="false" aria-controls="LC2NavMainMenu_help">Help</a>
              </li>
              <li role="presentation" class="dropdown">
                <a href="#" id="myTabDrop1" class="dropdown-toggle" data-toggle="dropdown"
                  aria-controls="myTabDrop1-contents" aria-expanded="false">API <span class="caret"></span></a>
                <ul class="dropdown-menu" role="menu" aria-labelledby="myTabDrop1"
                  id="myTabDrop1-contents">
                  <li ng-repeat="item in dropdowns">
                    <a href="#>dropHelp" tabindex="-1" role="tab" id="dropdown1-tab"
                      data-toggle="tab" aria-controls="dropHelp"
                      onclick="alert('Updates coming soon....')">Help</a>
                  </li>
                </ul>
              </li>
            </ul>
            <div id="myTabContent" class="tab-content">
              <div role="tab-panel" class="tab-pane fade active in" id="LC2NavMainMenu"
                aria-labelledby="LC2NavMainMenu-tab">
                <div class="panel panel-default">
                  <div>
                    <div class="panel-body demo-btn" style="min-height: 252px;">
                      <xsl:copy-of select="root/tabs/menu" />
                      <fieldset>
                        <legend>Menu:</legend>
                        <ul class="listul">
                          <xsl:for-each select="root/menulist/urls">
                            <li>
                              <xsl:element name="input">
                                <xsl:attribute name="type">button</xsl:attribute>
                            <xsl:attribute
                                  name="class">btn <xsl:value-of select="btn" /></xsl:attribute>
                            <xsl:attribute
                                  name="onclick"><xsl:value-of select="urltarget" /></xsl:attribute>
                            <xsl:attribute
                                  name="value"><xsl:value-of select="title" /></xsl:attribute>
                              </xsl:element>
                            </li>
                          </xsl:for-each>
                        </ul>
                      </fieldset>
                      <xsl:copy-of select="root/tabs/menu_body" />


                    </div>
                  </div>
                </div>
              </div>
              <div role="tabpanel" class="tab-pane fade" id="LC2NavMainMenu_main"
                aria-labelledby="LC2NavMainMenu_main-tab">
                <div class="panel panel-default">
                  <div panel-heading="Commands">
                    <div class="panel-body demo-btn" style="min-height: 252px;">
                      <fieldset>
                        <ul class="listul">
                          <xsl:for-each select="root/defaultlist/urls">
                            <li>
                              <xsl:element name="a">
                                <xsl:attribute name="onclick"><xsl:value-of select="urltarget" /></xsl:attribute>                          
                          <xsl:value-of
                                  select="title" />
                              </xsl:element>
                            </li>
                          </xsl:for-each>
                        </ul>
                        <xsl:copy-of select="root/tabs/main_body" />
                      </fieldset>


                    </div>
                  </div>
                </div>
              </div>

              <div role="tabpanel" class="tab-pane fade" id="LC2NavMainMenu_newplugin"
                aria-labelledby="LC2NavMainMenu_newplugin-tab">
                <div class="panel panel-default">
                  <div panel-heading="KI">
                    <div class="panel-body demo-btn" style="min-height: 252px;">
                      <xsl:copy-of select="root/tabs/newplugin" />
                      <fieldset>
                        <ul class="listul">
                          <xsl:for-each select="root/defaultlist/urls">
                            <li>
                              <xsl:element name="a">
                                <xsl:attribute name="onclick"><xsl:value-of select="urltarget" /></xsl:attribute>                          
                          <xsl:value-of
                                  select="title" />
                              </xsl:element>
                            </li>
                          </xsl:for-each>
                        </ul>

                        <xsl:copy-of select="root/tabs/newplugin_body" />
                      </fieldset>

                    </div>
                  </div>
                </div>
              </div>

              <div role="tabpanel" class="tab-pane fade" id="LC2NavMainMenu_ki"
                aria-labelledby="LC2NavMainMenu_ki-tab">
                <div class="panel panel-default">
                  <div panel-heading="KI">
                    <div class="panel-body demo-btn" style="min-height: 252px;">
                      <xsl:copy-of select="root/tabs/ki" />
                      <fieldset>
                        <ul class="listul">
                          <xsl:for-each select="root/defaultlist/urls">
                            <li>
                              <xsl:element name="a">
                                <xsl:attribute name="onclick"><xsl:value-of select="urltarget" /></xsl:attribute>                          
                          <xsl:value-of
                                  select="title" />
                              </xsl:element>
                            </li>
                          </xsl:for-each>
                        </ul>

                        <xsl:copy-of select="root/tabs/ki_body" />
                      </fieldset>

                    </div>
                  </div>
                </div>
              </div>

              <div role="tabpanel" class="tab-pane fade" id="LC2NavMainMenu_network"
                aria-labelledby="LC2NavMainMenu_network-tab">
                <div class="panel panel-default">
                  <div panel-heading="Network">
                    <div class="panel-body demo-btn" style="min-height: 252px;">
                      <xsl:copy-of select="root/tabs/network" />
                      <fieldset>
                        <ul class="listul">
                          <xsl:for-each select="root/defaultlist/urls">
                            <li>
                              <xsl:element name="a">
                                <xsl:attribute name="onclick"><xsl:value-of select="urltarget" /></xsl:attribute>                          
                          <xsl:value-of
                                  select="title" />
                              </xsl:element>
                            </li>
                          </xsl:for-each>
                        </ul>

                        <xsl:copy-of select="root/tabs/network_body" />
                      </fieldset>

                    </div>
                  </div>
                </div>
              </div>

              <div role="tabpanel" class="tab-pane fade" id="LC2NavMainMenu_database"
                aria-labelledby="LC2NavMainMenu_database-tab">
                <div class="panel panel-default">
                  <div panel-heading="Database">
                    <div class="panel-body demo-btn" style="min-height: 252px;">
                      <xsl:copy-of select="root/tabs/database" />
                      <fieldset>
                        <ul class="listul">
                          <xsl:for-each select="root/defaultlist/urls">
                            <li>
                              <xsl:element name="a">
                                <xsl:attribute name="onclick"><xsl:value-of select="urltarget" /></xsl:attribute>                          
                          <xsl:value-of
                                  select="title" />
                              </xsl:element>
                            </li>
                          </xsl:for-each>
                        </ul>
                        <xsl:copy-of select="root/tabs/database_body" />

                      </fieldset>


                    </div>
                  </div>
                </div>
              </div>


              <div role="tabpanel" class="tab-pane fade" id="LC2NavMainMenu_install"
                aria-labelledby="LC2NavMainMenu_install-tab">
                <div class="panel panel-default">
                  <div panel-heading="Install">
                    <div class="panel-body demo-btn" style="min-height: 252px;">
                      <fieldset>
                        <ul class="listul">
                          <xsl:for-each select="root/defaultlist/urls">
                            <li>
                              <xsl:element name="a">
                                <xsl:attribute name="onclick"><xsl:value-of select="urltarget" /></xsl:attribute>                          
                          <xsl:value-of
                                  select="title" />
                              </xsl:element>
                            </li>
                          </xsl:for-each>
                        </ul>

                        <xsl:element name="button">
                          <xsl:attribute name="class">btn btn-default</xsl:attribute>                          
                          <xsl:attribute
                            name="onclick">
                            <xsl:value-of select="/root/checkreq" />
                          </xsl:attribute>
                          <xsl:value-of
                            select="/root/checkreqtext" />
                        </xsl:element>
                      </fieldset>

                    </div>
                  </div>
                </div>
              </div>

              <div role="tabpanel" class="tab-pane fade" id="LC2NavMainMenu_registry"
                aria-labelledby="LC2NavMainMenu_registry-tab">
                <div class="panel panel-default">
                  <div panel-heading="Registry">
                    <div class="panel-body demo-btn" style="min-height: 252px;">
                      <fieldset>
                        <ul class="listul">
                          <xsl:for-each select="root/defaultlist/urls">
                            <li>
                              <xsl:element name="a">
                                <xsl:attribute name="onclick"><xsl:value-of select="urltarget" /></xsl:attribute>                          
                          <xsl:value-of
                                  select="title" />
                              </xsl:element>
                            </li>
                          </xsl:for-each>
                        </ul>
                        <xsl:copy-of select="/root/registrycnt" />

                      </fieldset>

                    </div>
                  </div>
                </div>
              </div>

              <div role="tabpanel" class="tab-pane fade" id="LC2NavMainMenu_help"
                aria-labelledby="LC2NavMainMenu_help-tab">
                <div class="panel panel-default">
                  <div panel-heading="Help">
                    <div class="panel-body demo-btn" style="min-height: 252px;">

                      <fieldset>
                        <ul class="listul">
                          <xsl:for-each select="root/defaultlist/urls">
                            <li>
                              <xsl:element name="a">
                                <xsl:attribute name="onclick"><xsl:value-of select="urltarget" /></xsl:attribute>                          
                          <xsl:value-of
                                  select="title" />
                              </xsl:element>
                            </li>
                          </xsl:for-each>
                        </ul>
                      </fieldset>


                    </div>
                  </div>
                </div>
              </div>
            </div>

            <div id="menuout" class="">
            </div>


          </body>
        </html>
      </xsl:template>


    </root>
  </xsl:template>
</xsl:stylesheet>   