<?xml version="1.0" encoding="UTF-8"?>
<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform">
<xsl:output method="html" indent="yes"/>
<!-- Define the parameters for pagination -->
<xsl:param name="currentPage" select="1"/>
<xsl:param name="pageSize" select="10"/>
<!-- Main template to apply the transformation -->
<xsl:template match="/">
<html>
<head>
<title>Paginated XML</title>
</head>
<body>
<h1>Paginated XML</h1>
<div>
<!-- Display the current page number -->
<p>Page: <xsl:value-of select="$currentPage"/></p>
</div>
<div>
<!-- Apply the template to the items on the current page -->
<xsl:apply-templates select="root/item[position() >= (($currentPage - 1) * $pageSize) + 1 and position() <= $currentPage * $pageSize]"/>
</div>
<div>
<!-- Navigation links -->
<a href="?currentPage=1&pageSize=10">First</a>
<a href="?currentPage={($currentPage - 1)}&pageSize=10">Previous</a>
<a href="?currentPage={($currentPage + 1)}&pageSize=10">Next</a>
<a href="?currentPage={last()}&pageSize=10">Last</a>
</div>
</body>
</html>
</xsl:template>
<!-- Template to apply to each item -->
<xsl:template match="item">
<div>
<h2><xsl:value-of select="title"/></h2>
<p><xsl:value-of select="description"/></p>
</div>
</xsl:template>
</xsl:stylesheet>