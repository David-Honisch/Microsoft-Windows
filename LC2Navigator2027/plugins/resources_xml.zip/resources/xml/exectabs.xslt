<?xml version="1.0" encoding="UTF-8"?>
<xsl:stylesheet version="1.0"
    xmlns:xsl="http://www.w3.org/1999/XSL/Transform">
    <xsl:variable name="color" select='"red"' />
    <xsl:template match="/">
        <root>
            <xsl:template match="/">
                <html>
                    <body>
                        <h1> x<xsl:copy-of select="document/title/node()|@*" />
                        </h1>
                        <h4>
                            <xsl:copy-of select="document/subtitle/node()|@*" />
                        </h4>
                        <ul id="myTab" class="nav nav-tabs" role="tablist">
                            <!-- <li role="presentation" class="active">
                                <a href="#lc2pyms_main" id="lc2pyms_main-tab" role="tab"
                                    data-toggle="tab"
                                    aria-expanded="true" aria-controls="lc2pyms_main">lc2pyms Menu</a>
                            </li> -->
                            <xsl:for-each select="document/category/url">
                                <xsl:element name="li">
                                    <xsl:attribute name="role">presentation</xsl:attribute>
                                     <xsl:attribute
                                        name="class">
                                        <!-- <xsl:choose>
                                            <xsl:when test="position()=1">active</xsl:when>
                                            <xsl:otherwise></xsl:otherwise>
                                        </xsl:choose> -->
                                        <xsl:value-of select="active" />
                                    </xsl:attribute>
                                     <xsl:element
                                        name="a">
                                        <xsl:attribute name="href">
                                            <xsl:value-of select="concat('#', id)" />
                                        </xsl:attribute>
                                        <xsl:attribute
                                            name="id">
                                            <xsl:value-of select="concat(id, '-tab')" />
                                        </xsl:attribute>
                                        <xsl:attribute
                                            name="role">tab</xsl:attribute>
                                        <xsl:attribute
                                            name="data-toggle">tab</xsl:attribute>
                                        <xsl:attribute
                                            name="aria-expanded">false</xsl:attribute>
                                        <xsl:attribute
                                            name="aria-controls">
                                            <xsl:value-of select="concat('', id)" />
                                        </xsl:attribute>
                                        <xsl:value-of
                                            select="title" />
                                    </xsl:element>
                                </xsl:element>

                            </xsl:for-each>


                            <li role="presentation" class="dropdown">
                                <a href="#" id="myTabDrop1" class="dropdown-toggle"
                                    data-toggle="dropdown"
                                    aria-controls="myTabDrop1-contents" aria-expanded="false">API <span
                                        class="caret"></span></a>
                                <ul class="dropdown-menu" role="menu" aria-labelledby="myTabDrop1"
                                    id="myTabDrop1-contents">
                                    <li ng-repeat="item in dropdowns">
                                        <a href="#>dropHelp" tabindex="-1" role="tab"
                                            id="dropdown1-tab"
                                            data-toggle="tab" aria-controls="dropHelp"
                                            onclick="alert('Updates coming soon....')">Help</a>
                                    </li>
                                </ul>
                            </li>
                        </ul>
                        <div id="myTabContent" class="tab-content">

                            <xsl:for-each select="document/category/url">
                                <xsl:element name="div">
                                    <xsl:attribute name="role">tabpanel</xsl:attribute>
                                    <xsl:attribute
                                        name="class">tab-pane fade <xsl:choose>
                                            <xsl:when test="position()=1">in active</xsl:when>
                                            <xsl:otherwise></xsl:otherwise>
                                        </xsl:choose>
                                    </xsl:attribute>
                                    <xsl:attribute
                                        name="id">
                                        <xsl:value-of select="concat('', id)" />
                                    </xsl:attribute>
                                    <xsl:attribute
                                        name="aria-labelledby">
                                        <xsl:value-of select="concat('', id, '-tab')" />
                                    </xsl:attribute>
                                    <div
                                        class="panel panel-default">
                                        <xsl:element name="div">
                                            <xsl:attribute name="panel-heading"><xsl:value-of
                                                    select="id" /></xsl:attribute>
                                            
                                            <xsl:attribute
                                                name="id"><xsl:value-of
                                                    select="id" /></xsl:attribute>
                                            <ul class="listul">
                                                <xsl:for-each select="urls/url">
                                                    <li>
                                                        <xsl:element name="a">
                                                        <xsl:attribute name="onclick"><xsl:value-of
                                                                select="urltarget" /></xsl:attribute>
                                                        <xsl:value-of
                                                            select="title" />
                                                    </li>
                                                </xsl:for-each>
                                            </ul>
                                        </xsl:element>
                                    </div>

                                </xsl:element>
                            </xsl:for-each>
                            <!-- old -->
                            <div role="tabpanel" class="tab-pane fade" id="lc2pyms_main"
                                aria-labelledby="lc2pyms_main-tab">
                                <div class="panel panel-default">

                                    <div panel-heading="Help">
                                        <div class="panel-body demo-btn" style="min-height: 252px;">

                                            <fieldset>
                                                <ul class="listul">
                                                    <xsl:for-each select="root/defaultlist/urls">
                                                        <li>
                                                            <xsl:element name="a">
                                                                <xsl:attribute name="onclick"><xsl:value-of
                                                                        select="urltarget" /></xsl:attribute>                          
                     <xsl:value-of
                                                                    select="title" />
                                                            </xsl:element>
                                                        </li>
                                                    </xsl:for-each>
                                                </ul>
                                            </fieldset>


                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div id="menuout" class="">
                        </div>


                    </body>
                </html>
            </xsl:template>


        </root>
    </xsl:template>
</xsl:stylesheet>