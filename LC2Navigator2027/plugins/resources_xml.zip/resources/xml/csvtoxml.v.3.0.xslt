<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
    exclude-result-prefixes="xsl">
    <xsl:output method="xml" encoding="utf-8" />

    <xsl:variable name="newline" select="'#xa;'" />
    <xsl:variable name="comma" select="','" />

    <xsl:template match="/">
        <data>
            <xsl:apply-templates/>
        </data>
    </xsl:template>

    <xsl:template match="text()">
        <originalCSV>
            <xsl:value-of select="." />
        </originalCSV>
        <xsl:call-template name="write-line" />
    </xsl:template>

    <xsl:template name="write-line">
        <xsl:param name="text" select="." />
        <xsl:variable name="this-row" select="substring-before( concat( $text, $newline ), $newline )" />
        <xsl:variable name="remaining-rows" select="substring-after( $text, $newline )" />
        <xsl:if test="string-length($this-row) &gt; 1">
            <row>
                <xsl:call-template name="write-item">
                    <xsl:with-param name="line" select="$this-row" />
                </xsl:call-template>
            </row>
        </xsl:if>
        <xsl:if test="string-length( $remaining-rows ) &gt; 0">
            <xsl:call-template name="write-line">
                <xsl:with-param name="text" select="$remaining-rows" />
            </xsl:call-template>
        </xsl:if>
    </xsl:template>

    <xsl:template name="write-item">
        <xsl:param name="line"/>
        <xsl:variable name="this-item" select="substring-before( concat( $line, $comma ), $comma)" />
        <xsl:variable name="remaining-items" select="substring-after( $line, $comma )" />
        <item>
            <xsl:value-of select="$this-item" />
        </item>
        <xsl:if test="string-length( $remaining-items ) &gt; 0">
            <xsl:call-template name="write-item">
                <xsl:with-param name="line" select="$remaining-items" />
            </xsl:call-template>
        </xsl:if>
    </xsl:template>

</xsl:stylesheet>