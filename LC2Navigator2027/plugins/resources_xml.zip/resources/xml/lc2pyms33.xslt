<?xml version="1.0" encoding="UTF-8"?>
<xsl:stylesheet xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns:xs="http://www.w3.org/2001/XMLSchema" exclude-result-prefixes="xs" version="1.0">
  <xsl:variable name="lowercase" select="'abcdefghijklmnopqrstuvwxyz'" />
  <xsl:variable name="uppercase" select="'ABCDEFGHIJKLMNOPQRSTUVWXYZ'" />
  <xsl:param name="first">1</xsl:param>
  <xsl:param name="size">10</xsl:param>

  <xsl:template match="Root">
    <div>
      <xsl:call-template name="navigation"/>
      <xsl:apply-templates select="Product[position() >= $first and position() &lt; $first + $size]"/>
      <xsl:call-template name="navigation"/>
    </div>
  </xsl:template>

  <xsl:template match="Product">
    <!-- do product stuff here -->
    <xsl:if test="Story/ServiceName != '' and Story/Desc_Destinations != '' and Story/Product_Rating != ''">
      <div id="TeaserBase" style="background-color: #000000; color:#ffffff; width:960px; font: 81%/1.4 Arial,Verdana,sans-serif;">
        <div id="teaser_content" style="padding:10px;">
          <div id="teaser_image" style="float:left; padding:10px 5px 10px 10px">
            <xsl:element name="img">
              <xsl:attribute name="border">0</xsl:attribute>
              <xsl:attribute name="src">
                <xsl:value-of select="Image_1/@href"/>
              </xsl:attribute>
              <xsl:attribute name="width">430</xsl:attribute>
              <xsl:attribute name="height">325</xsl:attribute>
              <xsl:attribute name="alt">
                <xsl:value-of select="Story/ServiceName"/>
              </xsl:attribute>
            </xsl:element>
          </div>
          <div id="teaser_right" style="float:left; padding:10px 5px 0 10px">
            <div style="font-size:18px; font-weight:bold; max-width:480px">
              <xsl:value-of select="translate(Story/ServiceName, $lowercase, $uppercase)"/>
            </div>
            <div>
              <xsl:choose>
                <xsl:when test="Story/Product_Rating = 1">
                  <img src="Star.png" alt="1" title="1" ></img>
                </xsl:when>
                <xsl:when test="Story/Product_Rating = 2">
                  <img src="Star2.png" alt="2" title="2" ></img>
                </xsl:when>
                <xsl:when test="Story/Product_Rating = 3">
                  <img src="Star3.png" alt="3" title="3" ></img>
                </xsl:when>
                <xsl:when test="Story/Product_Rating = 4">
                  <img src="Star4.png" alt="4" title="4" ></img>
                </xsl:when>
                <xsl:when test="Story/Product_Rating = 5">
                  <img src="Star5.png" alt="5" title="5" ></img>
                </xsl:when>
              </xsl:choose>
              <span style="font-size:15px; font-weight:bold">
                <xsl:value-of select="translate(Story/Desc_Destinations, $lowercase, $uppercase)"></xsl:value-of>
              </span>
            </div>
            <div id="teaser_text" style="float:left; width:290px; max-height:290px; height:290px">
              <div style="width:280px; height:280px; overflow:hidden">
                <span style="font-size:12px;">
                  <xsl:value-of select="Story/Desc_Snapshot"/>
                </span>
              </div>
            </div>
            <div id="teaser_extra" style="float:left; padding-left:10px; width:180px; height:290px;">
              <div style="font-weight:bold">Hotel Facilities</div>
              <div style="max-height:70px; overflow:hidden">
                <xsl:value-of select="Story/Desc_Hotel_Facilities"/>
              </div>
              <div style="font-weight:bold; margin-top:5px;">Guest Rooms</div>
              <div style="max-height:70px; overflow:hidden">
                <xsl:value-of select="Story/Desc_Guest_Rooms"/>
              </div>
              <div style="font-weight:bold; margin-top:5px; font-size:14px">
                From
                <xsl:value-of select="Story/Price" /> per person per night
              </div>
              <div style="font-size:smaller">
                <xsl:value-of select="Story/Desc_Price_description"/>
              </div>
              <table style="padding-top:10px;">
                <tr>
                  <td>
                    <img src="btw_btn_email_enquiry.gif" />
                  </td>
                  <td>
                    <img src="btw_btn_find_branch.gif" />
                  </td>
                </tr>
              </table>
            </div>
          </div>
          <div style="clear:both"></div>
        </div>
      </div>
    </xsl:if>
  </xsl:template>

  <xsl:template name="navigation">
    <div>
      <a href="#">
        <xsl:attribute name="onclick">
          <xsl:text>showPage(</xsl:text>
          <xsl:value-of select="$first - $size"/>
          <xsl:text>,</xsl:text>
          <xsl:value-of select="$size"/>
          <xsl:text>);</xsl:text>
        </xsl:attribute>
        <xsl:text>previous</xsl:text>
      </a>
      <xsl:text>   </xsl:text>
      <a href="#">
        <xsl:attribute name="onclick">
          <xsl:text>showPage(</xsl:text>
          <xsl:value-of select="$first + $size"/>
          <xsl:text>,</xsl:text>
          <xsl:value-of select="$size"/>
          <xsl:text>);</xsl:text>
        </xsl:attribute>
        <xsl:text>next</xsl:text>
      </a>
      <xsl:text>   Page </xsl:text>
      <xsl:value-of select="floor($first div $size + 1)"/>
    </div>
  </xsl:template>

</xsl:stylesheet>