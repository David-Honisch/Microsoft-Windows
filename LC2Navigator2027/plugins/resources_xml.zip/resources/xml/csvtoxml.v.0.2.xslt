<xsl:transform xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
  version="2.0">

<xsl:template name="main">
  <xsl:variable name="input2" select="unparsed-text('test.csv')"/>
  <xsl:variable name="input" select="/"/>
  <CSVData>
  <xsl:variable name="rows" select="tokenize($input, '\r?\n')"/>
    <Heading>
    <xsl:for-each select="tokenize($rows[1], ',')">
      <xsl:element name="h{position()}">
         <xsl:value-of select="."/>
      </xsl:element>
    </xsl:for-each>
    </Heading>
    <Dataset>
      <xsl:for-each select="remove($rows, 1)">
        <data>
          <xsl:for-each select="tokenize(., ',')">
            <xsl:element name="h{position()}">
              <xsl:value-of select="."/>
            </xsl:element>
          </xsl:for-each>
        </data>
      </xsl:for-each>
    </Dataset>
  </CSVData>
</xsl:template>

</xsl:transform>
