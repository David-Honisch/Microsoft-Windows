<?xml version="1.0" encoding="utf-8"?>
<xsl:stylesheet
	xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
	xmlns:csv="http://www.example.org/xslt/csv"
	xmlns:xs="http://www.w3.org/2001/XMLSchema"
	xmlns:fn="http://www.w3.org/2005/xpath-functions"
	exclude-result-prefixes="csv xs fn"
	version="2.0">

	<xsl:param required="no" name="comma" as="xs:string" select="','" />
	<xsl:param required="no" name="quote" as="xs:string">"</xsl:param>
	<xsl:param required="no" name="pipe" as="xs:string" select="'|'" />
	<xsl:param required="no" name="new-line" as="xs:string" select="'&#10;'" />

	<xsl:function name="csv:csv" as="xs:string?">
		<xsl:param name="value" as="xs:anyAtomicType" />
    <xsl:value-of
			select="fn:normalize-space(fn:concat($quote, 
      fn:replace(csv:string($value), $quote, 
      fn:concat($quote, $quote)), $quote))" />
	</xsl:function>

	<xsl:function name="csv:display-values" as="xs:string?">
		<xsl:param name="values" as="xs:anyAtomicType*" />
    
    <xsl:value-of
			select="csv:display-values($values, $pipe)" />
	</xsl:function>

	<xsl:function name="csv:display-values" as="xs:string?">
		<xsl:param name="values" as="xs:anyAtomicType*" />
    <xsl:param name="separator"
			as="xs:string?" />
    
    <xsl:value-of select="fn:string-join(csv:string($values), $separator)" />
	</xsl:function>

	<xsl:function name="csv:string" as="xs:string*">
		<xsl:param name="values" as="xs:anyAtomicType*" />
    <xsl:for-each select="$values">
			<xsl:value-of select="fn:string(.)" />
		</xsl:for-each>
	</xsl:function>

</xsl:stylesheet>