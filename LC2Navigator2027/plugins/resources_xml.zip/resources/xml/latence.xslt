<?xml version="1.0" encoding="UTF-8"?>
<xsl:stylesheet version="1.0"
	xmlns:xsl="http://www.w3.org/1999/XSL/Transform">
	<!-- <xsl:strip-space elements="*"/> -->
	<xsl:variable name="color" select='"red"' />
	<xsl:template match="/">
		<root>\n\r
		<h1>XSLT</h1>
			<xsl:variable name="vID"	select="/map/entry[0]/string" />
			<vId><xsl:value-of select="$vID" /></vId>
			<xsl:variable name="vTitle"	select="/map/entry[1]/string" />
			<vTitle><xsl:value-of select="$vTitle" /></vTitle>
			
			<xsl:variable name="vTitle2"	select="/map/entry[2]/string" />
			<vTitle2><xsl:value-of select="$vTitle2" /></vTitle2>
			
			<xsl:variable name="vBody"	select="/map/entry/list[1]/string[1]" />
			<des><xsl:value-of select="$vBody" /></des>
			
			<c>
				<xsl:for-each select="/map/entry/list">
					-<xsl:variable name="name"	select="string" />#
					\n\r<des><xsl:value-of select="$name/string" /></des>
				</xsl:for-each>
			</c>\n\r
			
			<!-- <xsl:for-each select="*/list"> -->
			<xsl:for-each select="/map/entry/string">
				<childs>
					
					
					<xsl:variable name="vBody"	select="/map/entry/list[1]/string[1]" />
			<des><xsl:value-of select="$vBody" /></des>

					<xsl:for-each select="/map/entry/list/string">
					<xsl:value-of select="generate-id(.)" />
						<id>
							<xsl:value-of select="string/text()" />
						</id>
						<description>


						</description>
						<xsl:value-of select="date" />
						<!-- <xsl:for-each select="*/*/string"> -->
						<xsl:for-each select="/map/entry/list/string">
							<t>
								<xsl:value-of select="generate-id(.)" />
								<xsl:value-of select="text()" />
								<xsl:value-of select="." />
								<xsl:value-of select="../name" />
								<xsl:value-of select="../date" />
								<xsl:value-of select="@itemID" />
								<xsl:value-of select="text()" />
							</t>
						</xsl:for-each>
					</xsl:for-each>
				</childs>
			</xsl:for-each>




		</root>
	</xsl:template>

</xsl:stylesheet>