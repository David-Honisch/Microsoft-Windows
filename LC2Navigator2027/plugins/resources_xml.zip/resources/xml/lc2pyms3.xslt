<?xml version="1.0" encoding="UTF-8"?>
<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform">
    <xsl:output method="xml" indent="yes" encoding="UTF-8"/>

    <!-- Parameter -->
    <xsl:param name="page" select="1"/>
    <xsl:param name="pageSize" select="10"/>

    <!-- Ultra-sichere Berechnung der Grenzen -->
    <!-- Wir erzwingen die numerische Auswertung durch number() -->
    <xsl:variable name="vPage" select="number($page)"/>
    <xsl:variable name="vSize" select="number($pageSize)"/>
    
    <!-- Berechnung: (page - 1) * pageSize + 1 -->
    <xsl:variable name="startPos" select="($vPage - 1) * $vSize + 1"/>
    <!-- Berechnung: page * pageSize -->
    <xsl:variable name="endPos" select="$vPage * $vSize"/>

    <xsl:template match="/">
        <root>
            <!-- Diagnose-Ausgabe (kann später gelöscht werden) -->
            <debug>
                <pageVal><xsl:value-of select="$vPage"/></pageVal>
                <start><xsl:value-of select="$startPos"/></start>
                <end><xsl:value-of select="$endPos"/></end>
            </debug>

            <items>
                <!-- Wir verwenden position() direkt gegen die berechneten Variablen -->
                <xsl:apply-templates select="//item[not(position() &lt; $startPos) and not(position() &gt; $endPos)]"/>
            </items>
        </root>
    </xsl:template>

    <xsl:template match="item">
        <xsl:copy-of select="."/>
    </xsl:template>
</xsl:stylesheet>