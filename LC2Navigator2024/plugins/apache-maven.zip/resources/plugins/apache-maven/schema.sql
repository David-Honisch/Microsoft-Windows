-- select '<h2>Import processes</h2>';
drop table IF EXISTS apache_maven;
drop table IF EXISTS apache_maven_data;
drop table IF EXISTS apache_maven_procdata;
-- drop table IF EXISTS apache_maventemp;
-- drop table IF EXISTS apache_maven_datatemp;
CREATE TABLE apache_maven( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE apache_maven_data( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
-- CREATE TABLE apache_maven_procdata( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
-- CREATE TABLE IF NOT EXISTS apache_maventemp (
-- "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL
-- );
-- create table IF NOT EXISTS apache_maven_datatemp ( name varchar(255));
-- CREATE TABLE IF NOT EXISTS apache_maven_datatemp (
-- "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL
-- );
-- import menu
-- select '<p>Import processes</p>';
.separator ";"
.import .\\resources\\plugins\\apache-maven\\import\\import.csv apache_maven
-- .import .\\resources\\plugins\\apache_maven\\import\\import.csv apache_maventemp
-- INSERT INTO apache_maven(first_name,name,zipcode, city, description) select first_name,name,zipcode, city, description  from apache_maventemp;
--.separator ';'
-- .separator ";"
--.import '.\\resources\\plugins\\apache_maven\\import\\menu.csv' apache_maven_datatemp
/* .import '.\\resources\\plugins\\apache_maven\\import\\menu.csv' apache_maven_datatemp */
-- INSERT INTO apache_maven_data(first_name,name,zipcode, city, description) select first_name,name,zipcode, city, description  from apache_maven_datatemp;
.import '.\\resources\\plugins\\apache-maven\\import\\menu.csv' apache_maven_data
-- delete from apache_maven_datatemp;
--
-- .separator ","
-- .import '.\\resources\\plugins\\apache_maven\\import\\apache_mavenwork.csv' apache_maven_datatemp
-- INSERT INTO apache_maven_procdata(first_name,name,zipcode, city, description) select first_name,name,zipcode, city, description  from apache_maven_datatemp;

select '<p>apache_maven count:';
select count(*) from apache_maven;
select 'apache_maven_data count:';
select count(*) from apache_maven_data;
select 'apache_maven_procdata count:';
select count(*) from apache_maven_procdata;
.separator ";"
drop table IF EXISTS apache_maventemp;
-- select '<p>Import done</p>';
.exit