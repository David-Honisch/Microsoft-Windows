// @flow
export default function equalNames(a: string, b: string) {
  return a.toUpperCase() === b.toUpperCase()
}
