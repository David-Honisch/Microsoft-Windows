-- select '<h2>Import processes</h2>';
drop table IF EXISTS LC2ShortCutCLI;
drop table IF EXISTS LC2ShortCutCLI_data;
drop table IF EXISTS LC2ShortCutCLI_procdata;
-- drop table IF EXISTS LC2ShortCutCLItemp;
-- drop table IF EXISTS LC2ShortCutCLI_datatemp;
CREATE TABLE LC2ShortCutCLI( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE LC2ShortCutCLI_data( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
-- CREATE TABLE LC2ShortCutCLI_procdata( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
-- CREATE TABLE IF NOT EXISTS LC2ShortCutCLItemp (
-- "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL
-- );
-- create table IF NOT EXISTS LC2ShortCutCLI_datatemp ( name varchar(255));
-- CREATE TABLE IF NOT EXISTS LC2ShortCutCLI_datatemp (
-- "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL
-- );
-- import menu
-- select '<p>Import processes</p>';
.separator ";"
.import .\\resources\\plugins\\LC2ShortCutCLI\\import\\import.csv LC2ShortCutCLI
.import '.\\resources\\plugins\\LC2ShortCutCLI\\import\\menu.csv' LC2ShortCutCLI_data
-- delete from LC2ShortCutCLI_datatemp;
--
-- .separator ","
-- .import '.\\resources\\plugins\\LC2ShortCutCLI\\import\\LC2ShortCutCLIwork.csv' LC2ShortCutCLI_datatemp
-- INSERT INTO LC2ShortCutCLI_procdata(first_name,name,zipcode, city, description) select first_name,name,zipcode, city, description  from LC2ShortCutCLI_datatemp;

select '<p>LC2ShortCutCLI count:';
select count(*) from LC2ShortCutCLI;
select 'LC2ShortCutCLI_data count:';
select count(*) from LC2ShortCutCLI_data;
select 'LC2ShortCutCLI_procdata count:';
select count(*) from LC2ShortCutCLI_procdata;
.separator ";"
drop table IF EXISTS LC2ShortCutCLItemp;
-- select '<p>Import done</p>';
.exit