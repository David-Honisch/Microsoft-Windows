-- select '<h2>Import processes</h2>';
drop table IF EXISTS LC2ShortCutCLI;
drop table IF EXISTS LC2ShortCutCLI_main;
drop table IF EXISTS LC2ShortCutCLI_install;
drop table IF EXISTS LC2ShortCutCLI_help;
drop table IF EXISTS LC2ShortCutCLI_work;
drop table IF EXISTS LC2ShortCutCLI_procdata;
drop table IF EXISTS LC2ShortCutCLItemp;
drop table IF EXISTS LC2ShortCutCLI_worktemp;
CREATE TABLE LC2ShortCutCLI( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE LC2ShortCutCLI_main( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE LC2ShortCutCLI_install( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE LC2ShortCutCLI_help( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE LC2ShortCutCLI_work( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE LC2ShortCutCLI_procdata( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE IF NOT EXISTS LC2ShortCutCLItemp (
"name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL
);
-- create table IF NOT EXISTS LC2ShortCutCLI_worktemp ( name varchar(255));
CREATE TABLE IF NOT EXISTS LC2ShortCutCLI_worktemp (
"name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL
);
-- import menu
-- select '<p>Import processes</p>';
.separator ";"
-- .import .\\resources\\plugins\\LC2ShortCutCLI\\import\\import.csv LC2ShortCutCLItemp
-- INSERT INTO LC2ShortCutCLI(first_name,name,zipcode, city, description) select first_name,name,zipcode, city, description  from LC2ShortCutCLItemp;
.import .\\resources\\plugins\\LC2ShortCutCLI\\import\\import.csv LC2ShortCutCLI
.import .\\resources\\plugins\\LC2ShortCutCLI\\import\\main.csv LC2ShortCutCLI_main
.import .\\resources\\plugins\\LC2ShortCutCLI\\import\\install.csv LC2ShortCutCLI_install
.import .\\resources\\plugins\\LC2ShortCutCLI\\import\\help.csv LC2ShortCutCLI_help

--
-- eof insert work data
select 'LC2ShortCutCLI count:';
select count(*) from LC2ShortCutCLI;
--.separator ';'
.separator ","
--.import '.\\resources\\plugins\\LC2ShortCutCLI\\import\\menu.csv' LC2ShortCutCLI_worktemp
-- .import '.\\resources\\plugins\\LC2ShortCutCLI\\import\\menu.csv' LC2ShortCutCLI_worktemp
-- INSERT INTO LC2ShortCutCLI_work(first_name,name,zipcode, city, description) select first_name,name,zipcode, city, description  from LC2ShortCutCLI_worktemp;
-- .import '.\\resources\\plugins\\LC2ShortCutCLI\\import\\menu.csv' LC2ShortCutCLI_work
.import .\\resources\\plugins\\LC2ShortCutCLI\\import\\work.csv LC2ShortCutCLI_worktemp
INSERT INTO LC2ShortCutCLI_work(first_name,name,zipcode, city, description) select first_name,name,zipcode, city, description  from LC2ShortCutCLI_worktemp;

delete from LC2ShortCutCLI_worktemp;
--
-- .separator ","
-- .import '.\\resources\\plugins\\LC2ShortCutCLI\\import\\LC2ShortCutCLIwork.csv' LC2ShortCutCLI_worktemp
-- INSERT INTO LC2ShortCutCLI_procdata(first_name,name,zipcode, city, description) select first_name,name,zipcode, city, description  from LC2ShortCutCLI_worktemp;
--
select '<p>LC2ShortCutCLI count:';
select count(*) from LC2ShortCutCLI;
select '<p>LC2ShortCutCLI_main count:';
select count(*) from LC2ShortCutCLI_main;
select '<p>LC2ShortCutCLI_install count:';
select count(*) from LC2ShortCutCLI_install;
select '<p>LC2ShortCutCLI_help count:';
select count(*) from LC2ShortCutCLI_help;
select '<p>LC2ShortCutCLI_work count:';
select count(*) from LC2ShortCutCLI_work;
select 'LC2ShortCutCLI_procdata count:';
select count(*) from LC2ShortCutCLI_procdata;
.separator ";"
drop table IF EXISTS LC2ShortCutCLItemp;
-- select '<p>Import done</p>';
.exit