function getPluginArguments() {
    var arguments = null;
    try {
        arguments = getSQLQuery('select name from params order by person_id asc, name asc', dbPath);
        //var query = getExtractArg(arguments,'--query=');        
        //$('#showcase').load('..\\..\\..\\resources\\plugins\\' + pluginName + '\\menu.html');
        console.log(arguments);
        return arguments;
    } catch (e) {
        alert(e.stack);
    }
}
function pluginINIT(pluginName) {
    var result = "";
    try {
        var arg = getPluginArguments();
        console.log(arg);
        
        execCMD("call tasklist /FO CSV /FI \"STATUS eq running\" /NH> .\\resources\\plugins\\" + pluginName + "\\import\\data.csv", "pnavmenu");
        execCMD("call  resources\\app\\sqlite\\SQLite3.exe \"resources\\" + pluginName + ".db\" \".read .\\\\resources\\\\plugins\\\\" + pluginName + "\\\\schema.sql\"", "pschema");
        // execCMD("call  resources\\app\\sqlite\\SQLite3.exe \"resources\\" + pluginName + ".db\" \".read .\\\\resources\\\\plugins\\\\" + pluginName + "\\\\schemaimport.sql\"", "pnavmenu");
        execCMD("call resources\\cmd\\register_plugin.bat "+pluginName, "pregister");
        
        if(getConfirmation('Install requirements of ' + pluginName + ' now?')){getOpenDialog('#dialog','.\\resources\\plugins\\' + pluginName + '\\install.html','Install',{ minWidth: 250,  minHeight: 150, width: 400})};
        
        getXML(".\\resources\\plugins\\" + pluginName +"\\xml\\app.xml", ".\\resources\\plugins\\" + pluginName + "\\xml\\app.xslt","pnav");
        setTimeout(() => {
            // getXML(".\\resources\\plugins\\" + pluginName +"\\xml\\app.xml", ".\\resources\\plugins\\" + pluginName + "\\xml\\app.xslt","pnav");            
            execPluginCMDList(pluginName,'#'+pluginName+'');
            execPluginCMDTableList(pluginName, pluginName+"_main",'#'+pluginName+'_main');
            execPluginCMDTableList(pluginName, pluginName+"_install",'#'+pluginName+'_install');
            execPluginCMDTableList(pluginName, pluginName+"_help",'#'+pluginName+'_help');
            console.log("reading requirements:");
            execCMD("resources\\cmd\\checkrequirement.bat .\\resources\\plugins\\" + pluginName + "\\csv\\check.csv", ""+pluginName+"_install");            
            console.log("reading requirements done.");
            execCMD("call  resources\\app\\sqlite\\SQLite3.exe  \"resources\\" + pluginName + ".db\" \"select * from " + pluginName + "_work\">\"resources\\plugins\\" + pluginName + "\\csv\\" + pluginName + "_data.csv\"", "pout");
            execCMD("call  \"resources\\plugins\\" + pluginName + "\\resources\\work\\" + pluginName + ".bat\"", "pform");
        }, 3000);        
    } catch (e) {
        alert(e.stack);
    }
}