function pluginINIT(pluginName) {
    try {
        // var arguments = getSQLQuery('select name from params order by person_id asc, name asc', dbPath);
        // var query = getExtractArg(arguments,'--query=');        
        $('#showcase').load('..\\..\\resources\\plugins\\' + pluginName + '\\menu.html');
        console.log(arguments);
        // $('#playout').load('..\\..\\resources\\plugins\\' + pluginName + '\\launch.html');
        execCMD('.\\resources\\plugins\\' + pluginName + '\\index.bat', 'pnavmenu');
    } catch (e) {
        alert(e.stack);
    }
}