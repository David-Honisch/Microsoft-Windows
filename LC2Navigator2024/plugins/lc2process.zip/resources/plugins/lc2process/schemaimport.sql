select '<h2>Import current process data</h2>';
-- drop table IF EXISTS lc2process;
-- drop table IF EXISTS lc2process_data;
drop table IF EXISTS lc2process_work;
drop table IF EXISTS lc2process_worktemp;
-- CREATE TABLE lc2process( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
-- CREATE TABLE lc2process_data( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE lc2process_work( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE IF NOT EXISTS lc2process_worktemp (
"name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL
);
-- import menu
-- select '<p>Import processes</p>';

-- delete from lc2process_datatemp;
--
.separator ","
.import '.\\resources\\plugins\\lc2process\\import\\data.csv' lc2process_worktemp
INSERT INTO lc2process_work(first_name,name,zipcode, city, description) select first_name,name,zipcode, city, description  from lc2process_worktemp;
--
select 'lc2process_work count:';
select count(*) from lc2process_work;
.separator ";"
drop table IF EXISTS lc2process_worktemp;
-- select '<p>Import done</p>';
.exit