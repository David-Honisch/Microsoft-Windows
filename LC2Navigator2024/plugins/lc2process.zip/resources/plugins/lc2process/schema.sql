select '<h2>Import lc2process processes</h2>';
-- select '<p>drop plugin tables</p>';
drop table IF EXISTS lc2process;
drop table IF EXISTS lc2process_main;
drop table IF EXISTS lc2process_install;
drop table IF EXISTS lc2process_help;
drop table IF EXISTS lc2process_data;
drop table IF EXISTS lc2process_work;
drop table IF EXISTS lc2process_procdata;
drop table IF EXISTS lc2processtemp;
drop table IF EXISTS lc2process_datatemp;
drop table IF EXISTS lc2process_worktemp;

-- select '<p>create plugin tables</p>';
CREATE TABLE lc2process( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,  "url" TEXT NULL);
CREATE TABLE lc2process_main( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE lc2process_install( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE lc2process_help( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE lc2process_data( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE lc2process_work( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);

CREATE TABLE lc2process_procdata( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE IF NOT EXISTS lc2processtemp (
"name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "url" TEXT NULL
);
-- create table IF NOT EXISTS lc2process_datatemp ( name varchar(255));
-- CREATE TABLE IF NOT EXISTS lc2process_datatemp (
-- "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL
-- );
CREATE TABLE IF NOT EXISTS lc2process_datatemp( "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL, "url" TEXT NULL);
-- CREATE TABLE IF NOT EXISTS lc2process_worktemp (
-- "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL
-- );
--CREATE TABLE IF NOT EXISTS lc2process_worktemp( "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,"add1" TEXT NULL,"add2" TEXT NULL,"add3" TEXT NULL,  "url" TEXT NULL);
CREATE TABLE IF NOT EXISTS lc2process_worktemp( "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "url" TEXT NULL);
-- import menu
-- select '<p>Import processes</p>';
-- select '<p>start import to plugin tables</p>';
.separator ";"
--.import .\\resources\\plugins\\lc2process\\import\\import.csv lc2processtemp
-- INSERT INTO lc2process(first_name,name,zipcode, city, description) select first_name,name,zipcode, city, description  from lc2processtemp;
.import .\\resources\\plugins\\lc2process\\import\\import.csv lc2process
.import .\\resources\\plugins\\lc2process\\import\\main.csv lc2process_main
.import .\\resources\\plugins\\lc2process\\import\\install.csv lc2process_install
.import .\\resources\\plugins\\lc2process\\import\\help.csv lc2process_help
.import .\\resources\\plugins\\lc2process\\import\\data.csv lc2process_data
--.import .\\resources\\plugins\\lc2process\\import\\data.csv lc2process_work
--
.separator ","
.import '.\\resources\\plugins\\lc2process\\import\\work.csv' lc2process_worktemp
INSERT INTO lc2process_data(first_name,name,zipcode, description,url) select first_name,name,zipcode, description,url from lc2process_worktemp;
INSERT INTO lc2process_work(first_name,name,zipcode, description,url) select first_name,name,zipcode, description,url  from lc2process_worktemp;
-- eof insert work data
select 'lc2process_work count:';
select count(*) from lc2process_work;
-- eof insert work data
select 'lc2process count:';
select count(*) from lc2process;
select '<p>start data import to plugin tables</p>';
.separator ";"
--.import '.\\resources\\plugins\\lc2process\\import\\menu.csv' lc2process_datatemp
-- .import '.\\resources\\plugins\\lc2process\\import\\menu.csv' lc2process_datatemp
-- INSERT INTO lc2process_data(first_name,name,zipcode, city, description) select first_name,name,zipcode, city, description  from lc2process_datatemp;
-- .import '.\\resources\\plugins\\lc2process\\import\\menu.csv' lc2process_data
-- delete from lc2process_datatemp;
--
-- select '<p>start work data import to plugin tables</p>';
-- .separator ","
-- .import '.\\resources\\plugins\\lc2process\\import\\data.csv' lc2process_worktemp
-- INSERT INTO lc2process_work(first_name,name,zipcode, city, description) select first_name,name,zipcode, city, description  from lc2process_worktemp;
--
select 'lc2process_work count:';
select count(*) from lc2process_work;
-- .separator ","
-- .import '.\\resources\\plugins\\lc2process\\import\\lc2processwork.csv' lc2process_datatemp
-- INSERT INTO lc2process_procdata(first_name,name,zipcode, city, description) select first_name,name,zipcode, city, description  from lc2process_datatemp;
--
select '<p>lc2process count:';
select count(*) from lc2process;
select 'lc2process_data count:';
select count(*) from lc2process_data;
select 'lc2process_procdata count:';
select count(*) from lc2process_procdata;
.separator ";"
drop table IF EXISTS lc2processtemp;
-- select '<p>Import done</p>';
.exit