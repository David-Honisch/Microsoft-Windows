-- select '<h2>Import processes</h2>';
drop table IF EXISTS lc2process;
drop table IF EXISTS lc2process_main;
drop table IF EXISTS lc2process_install;
drop table IF EXISTS lc2process_help;
drop table IF EXISTS lc2process_work;
drop table IF EXISTS lc2process_procdata;
drop table IF EXISTS lc2processtemp;
drop table IF EXISTS lc2process_worktemp;
CREATE TABLE lc2process( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE lc2process_main( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE lc2process_install( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE lc2process_help( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE lc2process_work( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE lc2process_procdata( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE IF NOT EXISTS lc2processtemp (
"name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL
);
-- create table IF NOT EXISTS lc2process_worktemp ( name varchar(255));
CREATE TABLE IF NOT EXISTS lc2process_worktemp (
"name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL
);
-- import menu
-- select '<p>Import processes</p>';
.separator ";"
-- .import .\\resources\\plugins\\lc2process\\import\\import.csv lc2processtemp
-- INSERT INTO lc2process(first_name,name,zipcode, city, description) select first_name,name,zipcode, city, description  from lc2processtemp;
.import .\\resources\\plugins\\lc2process\\import\\import.csv lc2process
.import .\\resources\\plugins\\lc2process\\import\\main.csv lc2process_main
.import .\\resources\\plugins\\lc2process\\import\\install.csv lc2process_install
.import .\\resources\\plugins\\lc2process\\import\\help.csv lc2process_help

--
-- eof insert work data
select 'lc2process count:';
select count(*) from lc2process;
--.separator ';'
.separator ","
--.import '.\\resources\\plugins\\lc2process\\import\\menu.csv' lc2process_worktemp
-- .import '.\\resources\\plugins\\lc2process\\import\\menu.csv' lc2process_worktemp
-- INSERT INTO lc2process_work(first_name,name,zipcode, city, description) select first_name,name,zipcode, city, description  from lc2process_worktemp;
-- .import '.\\resources\\plugins\\lc2process\\import\\menu.csv' lc2process_work
.import .\\resources\\plugins\\lc2process\\import\\work.csv lc2process_worktemp
INSERT INTO lc2process_work(first_name,name,zipcode, city, description) select first_name,name,zipcode, city, description  from lc2process_worktemp;

delete from lc2process_worktemp;
--
-- .separator ","
-- .import '.\\resources\\plugins\\lc2process\\import\\lc2processwork.csv' lc2process_worktemp
-- INSERT INTO lc2process_procdata(first_name,name,zipcode, city, description) select first_name,name,zipcode, city, description  from lc2process_worktemp;
--
select '<p>lc2process count:';
select count(*) from lc2process;
select '<p>lc2process_main count:';
select count(*) from lc2process_main;
select '<p>lc2process_install count:';
select count(*) from lc2process_install;
select '<p>lc2process_help count:';
select count(*) from lc2process_help;
select '<p>lc2process_work count:';
select count(*) from lc2process_work;
select 'lc2process_procdata count:';
select count(*) from lc2process_procdata;
.separator ";"
drop table IF EXISTS lc2processtemp;
-- select '<p>Import done</p>';
.exit