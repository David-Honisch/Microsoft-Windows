-- select '<h2>Import processes</h2>';
drop table IF EXISTS apache_ant;
drop table IF EXISTS apache_ant_main;
drop table IF EXISTS apache_ant_install;
drop table IF EXISTS apache_ant_help;
drop table IF EXISTS apache_ant_data;
drop table IF EXISTS apache_ant_work;
drop table IF EXISTS apache_ant_procdata;
drop table IF EXISTS apache_anttemp;
drop table IF EXISTS apache_ant_datatemp;
CREATE TABLE apache_ant( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE apache_ant_main( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE apache_ant_install( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE apache_ant_help( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE apache_ant_data( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE apache_ant_work( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE apache_ant_procdata( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE IF NOT EXISTS apache_anttemp (
"name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL
);
-- create table IF NOT EXISTS apache_ant_datatemp ( name varchar(255));
CREATE TABLE IF NOT EXISTS apache_ant_datatemp (
"name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL
);
-- import menu
-- select '<p>Import processes</p>';
.separator ";"
-- .import .\\resources\\plugins\\apache_ant\\import\\import.csv apache_anttemp
-- INSERT INTO apache_ant(first_name,name,zipcode, city, description) select first_name,name,zipcode, city, description  from apache_anttemp;
.import .\\resources\\plugins\\apache-ant\\import\\import.csv apache_ant
.import .\\resources\\plugins\\apache-ant\\import\\main.csv apache_ant_main
.import .\\resources\\plugins\\apache-ant\\import\\install.csv apache_ant_install
.import .\\resources\\plugins\\apache-ant\\import\\help.csv apache_ant_help
.import .\\resources\\plugins\\apache-ant\\import\\data.csv apache_ant_work
--
-- eof insert work data
select 'apache_ant count:';
select count(*) from apache_ant;
--.separator ';'
-- .separator ";"
--.import '.\\resources\\plugins\\apache_ant\\import\\menu.csv' apache_ant_datatemp
-- .import '.\\resources\\plugins\\apache_ant\\import\\menu.csv' apache_ant_datatemp
-- INSERT INTO apache_ant_data(first_name,name,zipcode, city, description) select first_name,name,zipcode, city, description  from apache_ant_datatemp;
-- .import '.\\resources\\plugins\\apache-ant\\import\\menu.csv' apache_ant_data
-- delete from apache_ant_datatemp;
--
-- .separator ","
-- .import '.\\resources\\plugins\\apache-ant\\import\\data.csv' apache_ant_worktemp
-- INSERT INTO apache_ant_work(first_name,name,zipcode, city, description) select first_name,name,zipcode, city, description  from apache_ant_worktemp;
--
select 'apache_ant_work count:';
select count(*) from apache_ant_work;
-- .separator ","
-- .import '.\\resources\\plugins\\apache_ant\\import\\apache_antwork.csv' apache_ant_datatemp
-- INSERT INTO apache_ant_procdata(first_name,name,zipcode, city, description) select first_name,name,zipcode, city, description  from apache_ant_datatemp;
--
select '<p>apache_ant count:';
select count(*) from apache_ant;
select 'apache_ant_data count:';
select count(*) from apache_ant_data;
select 'apache_ant_procdata count:';
select count(*) from apache_ant_procdata;
.separator ";"
drop table IF EXISTS apache_anttemp;
-- select '<p>Import done</p>';
.exit