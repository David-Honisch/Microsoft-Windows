function getArg(arguments, pattern) {
    var argparts = (arguments + "").split(',');
    var i = 0;
    var query = "";
    for (var s in argparts) {
        var v = argparts[s];
        if (v.startsWith(pattern + "=")) {
            query = v.replace(pattern + "=", '');
            break;
        }
        i++;
    }
    return query;
}

function pluginINIT(pluginName) {
    try {
        var arguments = getSQLQuery('select name from params order by person_id asc, name asc', dbPath);
        var query = getExtractArg(arguments,'--query=');        
        $('#showcase').load('..\\..\\..\\resources\\plugins\\' + pluginName + '\\menu.html');
        execCMD('.\\resources\\plugins\\' + pluginName + '\\index.bat', 'pnavmenu');
        
        //$('#showcase').load('..\\..\\resources\\plugins\\' + pluginName + '\\menu.html');
        console.log(query);
        setTimeout(() => {
            $("#inputKey").val(query);
            document.getElementById("inputKey").value = query;            
        }, 4000);

    } catch (e) {
        console.error(e.stack);
    }
}