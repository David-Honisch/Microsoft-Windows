select '<h2>Import LC2JSVideoPlayer processes</h2>';
-- select '<p>drop plugin tables</p>';
drop table IF EXISTS LC2JSVideoPlayer;
drop table IF EXISTS LC2JSVideoPlayer_main;
drop table IF EXISTS LC2JSVideoPlayer_install;
drop table IF EXISTS LC2JSVideoPlayer_help;
drop table IF EXISTS LC2JSVideoPlayer_data;
drop table IF EXISTS LC2JSVideoPlayer_work;
drop table IF EXISTS LC2JSVideoPlayer_procdata;
drop table IF EXISTS LC2JSVideoPlayertemp;
drop table IF EXISTS LC2JSVideoPlayer_datatemp;
drop table IF EXISTS LC2JSVideoPlayer_worktemp;

-- select '<p>create plugin tables</p>';
CREATE TABLE LC2JSVideoPlayer( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,  "url" TEXT NULL);
CREATE TABLE LC2JSVideoPlayer_main( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE LC2JSVideoPlayer_install( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE LC2JSVideoPlayer_help( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE LC2JSVideoPlayer_data( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE LC2JSVideoPlayer_work( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);

CREATE TABLE LC2JSVideoPlayer_procdata( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE IF NOT EXISTS LC2JSVideoPlayertemp (
"name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "url" TEXT NULL
);
-- create table IF NOT EXISTS LC2JSVideoPlayer_datatemp ( name varchar(255));
-- CREATE TABLE IF NOT EXISTS LC2JSVideoPlayer_datatemp (
-- "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL
-- );
CREATE TABLE IF NOT EXISTS LC2JSVideoPlayer_datatemp( "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL, "url" TEXT NULL);
-- CREATE TABLE IF NOT EXISTS LC2JSVideoPlayer_worktemp (
-- "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL
-- );
--CREATE TABLE IF NOT EXISTS LC2JSVideoPlayer_worktemp( "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,"add1" TEXT NULL,"add2" TEXT NULL,"add3" TEXT NULL,  "url" TEXT NULL);
CREATE TABLE IF NOT EXISTS LC2JSVideoPlayer_worktemp( "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "url" TEXT NULL);
-- import menu
-- select '<p>Import processes</p>';
-- select '<p>start import to plugin tables</p>';
.separator ";"
--.import .\\resources\\plugins\\LC2JSVideoPlayer\\import\\import.csv LC2JSVideoPlayertemp
-- INSERT INTO LC2JSVideoPlayer(first_name,name,zipcode, city, description) select first_name,name,zipcode, city, description  from LC2JSVideoPlayertemp;
.import .\\resources\\plugins\\LC2JSVideoPlayer\\import\\import.csv LC2JSVideoPlayer
.import .\\resources\\plugins\\LC2JSVideoPlayer\\import\\main.csv LC2JSVideoPlayer_main
.import .\\resources\\plugins\\LC2JSVideoPlayer\\import\\install.csv LC2JSVideoPlayer_install
.import .\\resources\\plugins\\LC2JSVideoPlayer\\import\\help.csv LC2JSVideoPlayer_help
.import .\\resources\\plugins\\LC2JSVideoPlayer\\import\\data.csv LC2JSVideoPlayer_data
.import .\\resources\\plugins\\LC2JSVideoPlayer\\import\\work.csv LC2JSVideoPlayer_work
--
-- .separator ","
-- .import '.\\resources\\plugins\\LC2JSVideoPlayer\\import\\work.csv' LC2JSVideoPlayer_worktemp
-- INSERT INTO LC2JSVideoPlayer_data(first_name,name,zipcode, description,url) select first_name,name,zipcode, description,url from LC2JSVideoPlayer_worktemp;
-- INSERT INTO LC2JSVideoPlayer_work(first_name,name,zipcode, description,url) select first_name,name,zipcode, description,url  from LC2JSVideoPlayer_worktemp;
-- eof insert work data
select 'LC2JSVideoPlayer_work count:';
select count(*) from LC2JSVideoPlayer_work;
-- eof insert work data
select 'LC2JSVideoPlayer count:';
select count(*) from LC2JSVideoPlayer;
select '<p>start data import to plugin tables</p>';
.separator ";"
--.import '.\\resources\\plugins\\LC2JSVideoPlayer\\import\\menu.csv' LC2JSVideoPlayer_datatemp
-- .import '.\\resources\\plugins\\LC2JSVideoPlayer\\import\\menu.csv' LC2JSVideoPlayer_datatemp
-- INSERT INTO LC2JSVideoPlayer_data(first_name,name,zipcode, city, description) select first_name,name,zipcode, city, description  from LC2JSVideoPlayer_datatemp;
-- .import '.\\resources\\plugins\\LC2JSVideoPlayer\\import\\menu.csv' LC2JSVideoPlayer_data
-- delete from LC2JSVideoPlayer_datatemp;
--
-- select '<p>start work data import to plugin tables</p>';
-- .separator ","
-- .import '.\\resources\\plugins\\LC2JSVideoPlayer\\import\\data.csv' LC2JSVideoPlayer_worktemp
-- INSERT INTO LC2JSVideoPlayer_work(first_name,name,zipcode, city, description) select first_name,name,zipcode, city, description  from LC2JSVideoPlayer_worktemp;
--
select 'LC2JSVideoPlayer_work count:';
select count(*) from LC2JSVideoPlayer_work;
-- .separator ","
-- .import '.\\resources\\plugins\\LC2JSVideoPlayer\\import\\LC2JSVideoPlayerwork.csv' LC2JSVideoPlayer_datatemp
-- INSERT INTO LC2JSVideoPlayer_procdata(first_name,name,zipcode, city, description) select first_name,name,zipcode, city, description  from LC2JSVideoPlayer_datatemp;
--
select '<p>LC2JSVideoPlayer count:';
select count(*) from LC2JSVideoPlayer;
select 'LC2JSVideoPlayer_data count:';
select count(*) from LC2JSVideoPlayer_data;
select 'LC2JSVideoPlayer_procdata count:';
select count(*) from LC2JSVideoPlayer_procdata;
.separator ";"
drop table IF EXISTS LC2JSVideoPlayertemp;
-- select '<p>Import done</p>';
.exit