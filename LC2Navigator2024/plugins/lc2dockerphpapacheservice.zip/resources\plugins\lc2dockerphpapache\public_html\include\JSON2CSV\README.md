JSON2CSV
========
A simple PHP script to convert JSON data to CSV

Command Line Usage
========
The script can also take command line arguments! 

php json2csv.php --file=/path/to/source/file.json --dest=/path/to/destination/file.csv

OR You can have it dump the CSV file relative to the PHP script
php json2csv.php --file=/path/to/source/file.json