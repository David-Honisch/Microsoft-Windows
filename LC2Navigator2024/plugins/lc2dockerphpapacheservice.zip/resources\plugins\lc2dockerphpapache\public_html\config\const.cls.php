<?php
/**
 * Die Datei global.inc beinhaltet globale Einstellungen und FunktionalitÃ¤ten,
 * wie z.B. das Ermitteln der Navigation, dem An- und Abmelden von benutzern usw.
 *
 * LC2CMS v.1.0
 * @author David Honisch
 */
define('__ROOT__', dirname(dirname(__FILE__)));
// $url = preg_replace ( '@/((\&)?PHPSESSID=[a-zA-Z0-9]+(\&)?)/i@', "",$REQUEST [q]);
// don�t allow direct querying this file...
if (strpos("const.cls.php", $_SERVER['PHP_SELF'])) {
    Header("Location:/index.php");
    die();
}
global $LANG;
$LANG = $LANG = isset($_REQUEST["l"]) ? $_REQUEST["l"] : "de_DE";
$env["TokenPREFIX"] = "LC2Token-RSA-c25343sZ4A4C22511sTB33531112";
$env["isInstalled"] = "true"; // Please change to true after installation !!
                               // Save Remote IP
$env["redirectTimeOut"] = 30;
$env["ip"] = $_SERVER['REMOTE_ADDR'];
$env["isHttps"] = (! empty($_SERVER['HTTPS']));
$matches = array();
if (substr_count($_SERVER['HTTP_HOST'], '.') == 1) {
    // domain.tld
    preg_match('/^(?P<d>.+)\.(?P<tld>.+?)$/', $_SERVER['HTTP_HOST'], $matches);
} else {
    // www.domain.tld, sub1.sub2.domain.tld, ...
    preg_match('/^(?P<sd>.+)\.(?P<d>.+?)\.(?P<tld>.+?)$/', $_SERVER['HTTP_HOST'], $matches);
}
$env["subdomain"] = (isset($matches['sd'])) ? $matches['sd'] : '';
$env["domain"] = isset($matches['d']) ? $matches['d'] : "";
$env["tld"] = isset($matches['tld']) ? $matches['tld'] : "";
// ------------------------------------------------------------------------------
$env["queryString"] = strstr($_SERVER['REQUEST_URI'], '?'); // $queryString enth�lt jetzt "?arg1=foo&arg2=bar" oder (bool)false falls keine Parameter definiert wurden
$env["queryString"] = ($env["queryString"] === false) ? '' : substr($env["queryString"], 1);
// Parameter als Array
$env["parameters"] = array();
parse_str(($env["queryString"] !== false) ? $env["queryString"] : '', $env["parameters"]); // $parameters enth�lt jetzt array("arg1" => "foo", "arg2" => "bar")
$env["path"] = ($env["queryString"] !== '') ? substr($_SERVER['REQUEST_URI'], 0, - strlen($env["queryString"]) - 1) : $_SERVER['REQUEST_URI'];
// alles ab dem letzten Slash/Schr�gstrich (oder (bool)false, falls kein Schr�gstrich gefunden wurde)
$env["file"] = strrchr($env["path"], '/');
// falls kein Schr�gstrich gefunden wurde, wird alles als Dateiname angesehen,
// sonst: falls nach dem letzten Schr�gstrich nichts mehr folgte bleibt die Datei leer, sonst alles ab dem letzten Schr�gstrich
$env["file"] = ($env["file"] === false) ? $env["path"] : (($env["file"] === '/') ? '' : substr($env["file"], 1));
$env["pathNoFile"] = ($env["file"] === '') ? $env["path"] : substr($env["path"], 0, - strlen($env["file"]));
// WebService Database
// set default request
if (empty($env["req"]["q"])) {
    $env["req"]["q"] = "home";
}
$doc["head"] = "";
$doc["foot"] = "";
$doc["includeFile"] = "";
$doc["isShortHead"] = false;
$env["httpServerPort"] = 80;
// require_once("./include/autoloader/Autoloader.cls.php");
$env["hptitle"] = "LETZTECHANCE.ORG";
$env["FileNotFound"] = "<h1>404 - File not found</h1>";
// ------------------------------------------------------------------------------
// logos
// ------------------------------------------------------------------------------
$doc["logos"] = array(
    "1" => array(
        "name" => "1",
        "logo" => "./img/t.jpg "
    ),
    "2" => array(
        "name" => "2",
        "logo" => "./img/t.jpg"
    )
);
// ------------------------------------------------------------------------------
// logos
// ------------------------------------------------------------------------------

// $LANG = "";

// overwrite local environment
error_reporting(E_ALL);
// ------------------------------------------------------------------------------
// ------------------------------------------------------------------------------
$env["hptitle"] = "LETZTECHANCE.ORG";
$env["webmastermail"] = "webmaster@letztechance.org";
// ------------------------------------------------------------------------------
// add db environment to array
// ------------------------------------------------------------------------------
$env["dbuser"] = "root";
$env["dbpassword"] = "rootpassword";
$env["defaultdb"] = "dbtest";
$env["cntdb"] = "dbtest-forum";
$env["cntdb"] = "dbtest";
$env["dbhost"] = "mysql";
// ------------------------------------------------------------------------------
// set web environment
$env["httpServer"] = "https://www.letztechance.org";
// ------------------------------------------------------------------------------
// ------------------------------------------------------------------------------
$env["httpServer"] = "http://localhost";
$env["httpsServer"] = "https://www.letztechance.org";
// $env["hpprefix"] = "/newcontent/";
$env["hpprefix"] = "/";
$env["password"] = "";
// ------------------------------------------------------------------------------
// $env["dbtype"] = "oracle";
// $env["dbtype"] = "sqlite";
// ------------------------------------------------------------------------------
$env["dbtype"] = "mysqli";
$env["dbfile"] = "lc.db";
$env["dbport"] = 1521;
// ------------------------------------------------------------------------------
$isDown = false; // switch maintenance
                 // ------------------------------------------------------------------------------
                 // EOF DB
                 // set webservice vars
$env["WebService"] = $env["httpServer"] . ":" . $env["httpServerPort"] . $env["hpprefix"] . "webservices/server.php";
$env["WebServicePlugins"] = $env["httpServer"] . ":" . $env["httpServerPort"] . $env["hpprefix"] . "ws/server.php";
$isDown = false;
// don�t show errors if production environment is set !!!!!
if ($_SERVER["SERVER_NAME"] == "www.letztechance.org") {
//     error_reporting(0);
}
// ------------------------------------------------------------------------------
// overwrite local environment
// ------------------------------------------------------------------------------
if ($_SERVER["SERVER_NAME"] != "www.letztechance.org" && $_SERVER["SERVER_NAME"] != "letztechance.org") {
    if (preg_match("/cms/", $_SERVER['REQUEST_URI']) || preg_match("/wiki/", $_SERVER['REQUEST_URI'])) {
        $env["hptitle"] = "LC2ADODB.v.1.0 ";
        $env["defaultdb"] = "dbtest";
        $env["cntdb"] = "dbtest";
        $env["dbuser"] = "root";
        $env["dbpassword"] = "rootpassword";
        $env["dbhost"] = "mysql";
        $env["hpprefix"] = "/cms/";
        $env["plugins"] = "/plugins/";
        $env["httpServer"] = "http://localhost";
        $env["httpsServer"] = "https://localhost";
        $env["dbtype"] = "mysqli";
        $env["httpServerPort"] = 80;
        $env["dbfile"] = "lc2.db";
        $env["dbport"] = 1521;
        // $env ["WebService"] = $env ["httpServer"] . "" . $env ["hpprefix"] . "webservices/server.php";
        $env["WebService"] = $env["httpServer"] . ":" . $env["httpServerPort"] . $env["hpprefix"] . "webservices/server.php";
        $env["WebServicePlugins"] = $env["httpServer"] . ":" . $env["httpServerPort"] . $env["hpprefix"] . "ws/server.php";
        error_reporting(E_ALL);
    }
    if ($_SERVER["SERVER_NAME"] == "192.168.2.101") {
        $env["dbuser"] = "root";
        $env["dbpassword"] = "admin";
    }
}
// echo "Debug!!";
$env["copyright"] = "(c) Copyright 1998 by " . $env["hptitle"];
// ------------------------------------------------------------------------------
// Oracle switch f�r XE
if (strpos("oracle", $env["dbtype"])) {
    $env["dbhost"] .= "/XE";
}
// ------------------------------------------------------------------------------
// EOF Oracle switch f�r XE
// EOF database environment
// set head foot meta tag template relative path
// ------------------------------------------------------------------------------
$env["skin"] = "standard";
$env["htmlhead"] = "skin/" . $env["skin"] . "/header.tpl.php";
$env["htmlfoot"] = "skin/" . $env["skin"] . "/footer.tpl.php";
$env["nolefthtmlhead"] = "skin/" . $env["skin"] . "/noleftheader.tpl.php";
$env["htmlmenu"] = "skin/" . $env["skin"] . "/menu.tpl.php";
$env["htmlnav"] = "skin/" . $env["skin"] . "/leftnav.tpl.php";
$env["showlocation"] = "skin/" . $env["skin"] . "/geolocateip.tpl.php";
$doc["page"] = "start";
$auth["auth"] = "false";
$env["numofentries"] = 15;
$env["shortnumofentries"] = 10;
// referer - test hackz
$env["referrer"] = getenv("HTTP_REFERER");
// $last_request = $_SESSION["last_request"];
$SCRIPT_URI = $_SERVER["SCRIPT_NAME"];
// get post, get, script_uri
$this_request = array(
    $_POST,
    $_GET,
    $SCRIPT_URI
);
// ------------------------------------------------------------------------------
$env["ip"] = $_SERVER['REMOTE_ADDR'];
// ------------------------------------------------------------------------------
// set timezone
date_default_timezone_set('Europe/Paris');
// set login time to save logintime with session
$login_date_id = date("l dS of F Y h:i:s A") . microtime();
// set date
$env["date"] = date("Y-m-d H:i:s");
setlocale(LC_ALL, 'de_DE@euro', 'de_DE', 'deu_deu', 'de_DE.utf8');
// ------------------------------------------------------------------------------
// ------------------------------------------------------------------------------
// media binaries
$env["audioPrefix"] = "/audio/mediendb";
$env["videoPrefix"] = "/video/mediendb";
$env["imgPrefix"] = "/images/mediendb";
$env["email"] = array();
$env["email"]["kontakt"] = "david@honisch.org";
$env["email"]["pressetermin"] = "david@honisch.org";
// ------------------------------------------------------------------------------
// define globals !!
// if(ereg(".*\/$", $_SERVER["DOCUMENT_ROOT"])){
if (preg_match("/\//", "" . $_SERVER["SCRIPT_NAME"])) {
    define("DOCROOT", $_SERVER["DOCUMENT_ROOT"] . "" . $env["hpprefix"]);
} else {
    define("DOCROOT", $_SERVER["DOCUMENT_ROOT"] . $env["hpprefix"]);
}
define("CDIR", "" . $env["hpprefix"]);
// ------------------------------------------------------------------------------
$env["plugins"] = $_SERVER["DOCUMENT_ROOT"] . "plugins/";
// ------------------------------------------------------------------------------
$env["serverPort"] = $_SERVER["SERVER_PORT"];
// noscript tag
$env["script"] = basename($_SERVER["SCRIPT_NAME"]);
$env["noscript"] = "<div style=\"text-align:center;\"><h1 class=\"alert\">Javascript not activated</h1><p class=\"salert\">Important navigation elements are not visible.</p></div>";
$env["dir"] = dirname($_SERVER["SCRIPT_NAME"]);
$env["self"] = $_SERVER["SCRIPT_NAME"];
$env["docroot"] = DOCROOT;
$env["docrootUrl"] = CDIR;
$env["include"] = DOCROOT . "include/";
$env["includeUrl"] = CDIR . "include/";
$env["skin"] = DOCROOT . "templates/".$env["skin"]."/";
$env["WS"] = DOCROOT . "webservices/";
$env["WSUrl"] = CDIR . "webservices/include/";
$env["includeWS"] = DOCROOT . "webservices/include/";
$env["includeWSUrl"] = CDIR . "webservices/include/";
// merge request
$env["req"] = array_merge($_POST, $_GET, $_FILES);
$env["params_str"] = $_SERVER["QUERY_STRING"];
$env["params_array"] = $_REQUEST;
$env["user"] = array();
$env["userIsLoggedIn"] = false;
$env["remote_host"] = $_SERVER['REMOTE_ADDR'];

$env["host_url"] = $_SERVER['REMOTE_ADDR'];
$env["linkroot"] = $env["httpServer"] . ":" . $env["serverPort"];
$env["fullroot"] = $env["httpServer"] . ":" . $env["serverPort"] . $env["hpprefix"];
$env["root"] = $_SERVER["DOCUMENT_ROOT"];
$env["log"] = $env["docroot"] . "/log/";
// ------------------------------------------------------------------------------
// set language vars !!!!!!!!!!!!!
// ------------------------------------------------------------------------------
// Here is the HTML Head index
$doc["head"] = "";
// Here is the HTML Body index
$doc["body"] = "";
// Here is the HTML Footer index
$doc["foot"] = "";
// ------------------------------------------------------------------------------

// ------------------------------------------------------------------------------
// include corporate designed HTML Elements
// ------------------------------------------------------------------------------
// Kalender
$env["linkedDays"] = array();
// $date = mktime();
$date = time();
$doc["date"] = $date;
if (! empty($env["req"]["date"])) {
    $date = intval($env["req"]["date"]);
} else if (! empty($env["req"]["chdate"])) {
    $date = intval($env["req"]["chdate"]);
}
$env["firstDayInMonth"] = mktime(0, 0, 0, strftime("%m", $date), 1, strftime("%Y", $date));
$env["lastDayInMonth"] = mktime(23, 59, 59, strftime("%m", $date), date("t", $date), strftime("%Y", $date));
// ------------------------------------------------------------------------------
if (file_exists($env["include"] . "parse/read_functions.cls.php")) {
    require_once ($env["include"] . "parse/read_functions.cls.php");
} else {
    echo "404 - Read Parse Function File not found.";
    die();
}
// //------------------------------------------------------------------------------
$doc["CSSclass"] = "core.css";
if (isset($_REQUEST["CSSclass"])) {
    if (file_exists("./css/" . $_REQUEST["CSSclass"])) {
        $doc["CSSclass"] = $_REQUEST["CSSclass"];
    }
}
// echo "Debug!!!";
// ------------------------------------------------------------------------------
// ------------------------------------------------------------------------------
// Utils
// ------------------------------------------------------------------------------
if (file_exists($env["include"] . "util/util.cls.php")) {
    require_once ($env["include"] . "util/util.cls.php");
} else {
    println($env["FileNotFound"]);
    println("Utitily Page not found.");
    die();
}
// echo "Debug:".$env["docroot"];
// ------------------------------------------------------------------------------
// escape request data
$env["req"] = Util::escapeRequestData($env["req"]);
// ------------------------------------------------------------------------------
// Read URI String
// ------------------------------------------------------------------------------
$uri = $_SERVER['REQUEST_URI'];
$env["uri"]["uri"] = explode("?", $uri);
// ------------------------------------------------------------------------------
// ------------------------------------------------------------------------------
// Language
// ------------------------------------------------------------------------------
if (file_exists($env["include"] . "lang/lang.cls.php")) {
    require_once ($env["include"] . "lang/lang.cls.php");
    $LANG = isset($_REQUEST["l"]) ? $_REQUEST["l"] : "de_DE";
    // $URI = preg_replace ( '@/((\&)?PHPSESSID=[a-zA-Z0-9]+(\&)?)/i@', "", $_SERVER ['REQUEST_URI'] );
    if (strpos($_SERVER['REQUEST_URI'], 'l=de_DE') !== false) {
        $LANG = 'de_DE';
    }
    if (strpos($_SERVER['REQUEST_URI'], 'l=en_US') !== false) {
        $LANG = 'en_US';
    }
    if (empty($LANG)) {
        $LANG = 'de_DE';
    }
    
    $LANG = setLanguage(isset($LANG) ? $LANG : "de_DE");
} else {
    println($env["FileNotFound"]);
    println("Language Page not found.");
    die();
}
$doc["lang"] = $LANG;
// echo "Debug!:".$env["docroot"];
// echo "Debug:".$doc["lang"];
// ------------------------------------------------------------------------------
// set language vars !!!!!!!!!!!!!
// ------------------------------------------------------------------------------
$language = $language["adress"] = msg("adress");
$env["lang"] = $language;
// ------------------------------------------------------------------------------
// IO
// ------------------------------------------------------------------------------
if (file_exists($env["include"] . "io/io.cls.php")) {
    require_once ($env["include"] . "io/io.cls.php");
} else {
    echo $env["FileNotFound"];
    echo "IO Failure or page not found.";
    die();
}

// ------------------------------------------------------------------------------
// Xml2Array
// ------------------------------------------------------------------------------
if (file_exists($env["include"] . "xml/xml2array.cls.php")) {
    require_once ($env["include"] . "xml/xml2array.cls.php");
} else {
    echo $env["FileNotFound"];
    echo "XMLArray Page not found.";
    die();
}
//
$env["env"]["date"]["time"] = date_default_timezone_set("Europe/Berlin");
//
$conn = new mysqli($env["dbhost"],  $env["dbuser"], $env["dbpassword"]);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 
// ------------------------------------------------------------------------------
function Debug($pVar)
{
    println("<h1>Debug:</h1>" . $pVar);
}

function DebugArray($pVar)
{
    println("<h1>Debug:</h1>");
    print_r($pVar);
}

function println($pVar)
{
    echo $pVar;
}
function getReqQuery($query = "query" )
{
    if (!empty($env["req"][$query]))
    {
        $query = $env["req"][$query];
    }    
    $ref = isset($_SERVER['HTTP_REFERER'])?$_SERVER['HTTP_REFERER']:null;
    $pattern = "?". $query."=";    
    $t = strstr($ref, 'query=');
    $t = substr($t,6, strpos($t,'&')-6);    
    return preg_replace ( '@/((\&)?PHPSESSID=[a-zA-Z0-9]+(\&)?)/i@', "", $t );
}
?>