<?PHP
# This file is part of Web-XML

# Web-XML is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.

# Web-XML is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.

# You should have received a copy of the GNU General Public License
# along with Web-XML; if not, write to the Free Software
# Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA

# This work is Copyright (C)2006 by Ryan Kelley
# Individual portions may be copyright by individual contributors, and
# are included in this collective work with permission of the copyright
# owners.

function kill()
{
print("
        <html>
        <head>
                <title>XML</title>
        </head>
        <body>
                <div align=\"center\">
                Sorry but that was an invalid request\n
                </div>
        </body>
        </html>

");
}
function convert($fp,$key)
{
	$tested=0;
	$key = stripslashes($key);
	$out = array();
	$p=0;
	for($z=0;$key[$z]!=NULL;$z++)
	{
		if($key[$z]=='<')
		{
			$temp=NULL;
			for($i=$z;$i<$z+20;$i++)
				$temp .=$key[$i];
			//print("$temp <br>");
			$two = substr($temp,0,2);
			$fou = substr($temp,0,4);
			$fiv = substr($temp,0,5);
			$six = substr($temp,0,6);
			$sev = substr($temp,0,7);
			$eig = substr($temp,0,8);
			$nin = substr($temp,0,9);
			$ten = substr($temp,0,10);
			$elv = substr($temp,0,11);
			$twl = substr($temp,0,12);
			$thi = substr($temp,0,13);
			$fte = substr($temp,0,14);
			
			if($six==="<link>"||$sev==="</link>"||$six==="<item>"||$sev==="</item>"||$nin==="<pubDate>"||$ten==="</pubDate>"||$thi==="<description>"||$fte==="</description>"||$nin==="<channel>"||$ten==="</channel>"||$two==="<?"||$sev==="<title>"||$eig==="</title>"||$fou==="<rss"||$fiv==="<?xml"||$elv==="<copyright>"||$twl==="</copyright>"||$ten==="<language>"||$elv==="</language>"||$fiv==="</rss")
			{
				$tested=1;
				print($key[$z]);
				fwrite($fp,$key[$z]);
				
			}
			else
			{
				$tested=0;
				print('&#60;');
				fwrite($fp,'&#60;');
			}
		}
		else if($key[$z]==">")
		{
			if($tested==1)
			{
				print($key[$z]);
				fwrite($fp,$key[$z]);
			}
			else
			{
				print('&#62;');
				fwrite($fp,'&#62;');
			}
		}
		else if($key[$z]=="&")
		{
			print('&amp;');
			fwrite($fp,'&amp;');
		}
		else
		{
			print($key[$z]);
			fwrite($fp,$key[$z]);
		}
		
		
	}

}

function pull($id)
{
	if($id==1)
		return "./news.xml";
}
//writes to a file
function write($file, $data)
{
	$fp = fopen($file,"w");

	if(!$fp)
		die("Error: Cannot open file to write");
	convert($fp,$data);
	fclose($fp);
	
}
//reads in from a file handle
function read($file)
{
	$fp = fopen($file,"r");//open the file with read access
	
	while(!feof($fp))//go thought the file till the end is reached
		$buf .= fread($fp,filesize($file));//store each line into buf
	
	fclose($fp);//close the file
	
	return $buf;//return the file buffer
}
?>
