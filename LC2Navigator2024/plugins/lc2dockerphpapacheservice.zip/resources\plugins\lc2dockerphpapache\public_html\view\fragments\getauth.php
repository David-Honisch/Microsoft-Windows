<?PHP
require('../../include/curl/curl.cls.php');
$login = 'login';
$password = 'password';
$url = "http://localhost/index.php";
$oMain = new CURLHelper();

$oMain->getCURL("admin", "rootpassword", "http://localhost/auth.php");
$oMain->getCURL("admin", "rootpassword", "http://localhost/include/upload/showdb.php");

$oMain->getCURL("postman", "password", "https://postman-echo.com/basic-auth");
$oMain->getCURL("postman", "password2", "https://postman-echo.com/basic-auth");
