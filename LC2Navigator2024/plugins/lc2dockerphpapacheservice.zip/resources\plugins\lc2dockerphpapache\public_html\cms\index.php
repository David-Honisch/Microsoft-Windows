<h1>Welcome to LC2MySQL Database</h1>
<h4>Attempting MySQL connection fromx php...</h4>
<a href="/index.php" target="_parent">Home</a>
<a href="/adminer-4.7.0.php" target="_blank">Admin</a>
<a href="/showdb.php" target="_blank">showdb.php</a>
<hr>
<form action="upload.php" method="post" enctype="multipart/form-data">
  Select image to upload:
  <input type="file" name="fileToUpload" id="fileToUpload">
  <input type="submit" value="Upload Image" name="submit">
</form>
<hr>
