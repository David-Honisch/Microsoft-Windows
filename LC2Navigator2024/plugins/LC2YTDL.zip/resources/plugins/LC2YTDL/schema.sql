select '<h2>Import LC2YTDL processes</h2>';
-- select '<p>drop plugin tables</p>';
drop table IF EXISTS LC2YTDL;
drop table IF EXISTS LC2YTDL_main;
drop table IF EXISTS LC2YTDL_install;
drop table IF EXISTS LC2YTDL_help;
drop table IF EXISTS LC2YTDL_data;
drop table IF EXISTS LC2YTDL_work;
drop table IF EXISTS LC2YTDL_procdata;
drop table IF EXISTS LC2YTDLtemp;
drop table IF EXISTS LC2YTDL_datatemp;
drop table IF EXISTS LC2YTDL_worktemp;

-- select '<p>create plugin tables</p>';
CREATE TABLE LC2YTDL( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,  "url" TEXT NULL);
CREATE TABLE LC2YTDL_main( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE LC2YTDL_install( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE LC2YTDL_help( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE LC2YTDL_data( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE LC2YTDL_work( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);

CREATE TABLE LC2YTDL_procdata( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE IF NOT EXISTS LC2YTDLtemp (
"name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "url" TEXT NULL
);
-- create table IF NOT EXISTS LC2YTDL_datatemp ( name varchar(255));
-- CREATE TABLE IF NOT EXISTS LC2YTDL_datatemp (
-- "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL
-- );
CREATE TABLE IF NOT EXISTS LC2YTDL_datatemp( "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL, "url" TEXT NULL);
-- CREATE TABLE IF NOT EXISTS LC2YTDL_worktemp (
-- "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL
-- );
--CREATE TABLE IF NOT EXISTS LC2YTDL_worktemp( "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,"add1" TEXT NULL,"add2" TEXT NULL,"add3" TEXT NULL,  "url" TEXT NULL);
CREATE TABLE IF NOT EXISTS LC2YTDL_worktemp( "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "url" TEXT NULL);
-- import menu
-- select '<p>Import processes</p>';
-- select '<p>start import to plugin tables</p>';
.separator ";"
--.import .\\resources\\plugins\\LC2YTDL\\import\\import.csv LC2YTDLtemp
-- INSERT INTO LC2YTDL(first_name,name,zipcode, city, description) select first_name,name,zipcode, city, description  from LC2YTDLtemp;
.import .\\resources\\plugins\\LC2YTDL\\import\\import.csv LC2YTDL
.import .\\resources\\plugins\\LC2YTDL\\import\\main.csv LC2YTDL_main
.import .\\resources\\plugins\\LC2YTDL\\import\\install.csv LC2YTDL_install
.import .\\resources\\plugins\\LC2YTDL\\import\\help.csv LC2YTDL_help
.import .\\resources\\plugins\\LC2YTDL\\import\\data.csv LC2YTDL_data
.import .\\resources\\plugins\\LC2YTDL\\import\\data.csv LC2YTDL_work
--
--.separator ","
--.import '.\\resources\\plugins\\LC2YTDL\\import\\work.csv' LC2YTDL_worktemp
--INSERT INTO LC2YTDL_data(first_name,name,zipcode, description,url) select first_name,name,zipcode, description,url from LC2YTDL_worktemp;
--INSERT INTO LC2YTDL_work(first_name,name,zipcode, description,url) select first_name,name,zipcode, description,url  from LC2YTDL_worktemp;
-- eof insert work data
select 'LC2YTDL_work count:';
select count(*) from LC2YTDL_work;
-- eof insert work data
select 'LC2YTDL count:';
select count(*) from LC2YTDL;
select '<p>start data import to plugin tables</p>';
.separator ";"
--.import '.\\resources\\plugins\\LC2YTDL\\import\\menu.csv' LC2YTDL_datatemp
-- .import '.\\resources\\plugins\\LC2YTDL\\import\\menu.csv' LC2YTDL_datatemp
-- INSERT INTO LC2YTDL_data(first_name,name,zipcode, city, description) select first_name,name,zipcode, city, description  from LC2YTDL_datatemp;
-- .import '.\\resources\\plugins\\LC2YTDL\\import\\menu.csv' LC2YTDL_data
-- delete from LC2YTDL_datatemp;
--
-- select '<p>start work data import to plugin tables</p>';
-- .separator ","
-- .import '.\\resources\\plugins\\LC2YTDL\\import\\data.csv' LC2YTDL_worktemp
-- INSERT INTO LC2YTDL_work(first_name,name,zipcode, city, description) select first_name,name,zipcode, city, description  from LC2YTDL_worktemp;
--
select 'LC2YTDL_work count:';
select count(*) from LC2YTDL_work;
-- .separator ","
-- .import '.\\resources\\plugins\\LC2YTDL\\import\\LC2YTDLwork.csv' LC2YTDL_datatemp
-- INSERT INTO LC2YTDL_procdata(first_name,name,zipcode, city, description) select first_name,name,zipcode, city, description  from LC2YTDL_datatemp;
--
select '<p>LC2YTDL count:';
select count(*) from LC2YTDL;
select 'LC2YTDL_data count:';
select count(*) from LC2YTDL_data;
select 'LC2YTDL_procdata count:';
select count(*) from LC2YTDL_procdata;
.separator ";"
drop table IF EXISTS LC2YTDLtemp;
-- select '<p>Import done</p>';
.exit