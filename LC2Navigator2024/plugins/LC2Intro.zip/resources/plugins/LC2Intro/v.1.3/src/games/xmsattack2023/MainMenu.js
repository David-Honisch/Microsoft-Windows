class MainMenu extends Phaser.Scene
{
    constructor ()
    {
        super('MainMenu');
    }

    create ()
    {
        this.sound.play('music', { loop: true, delay: 2 });

        this.add.shader('snow', 512, 384, 1024, 768);
        let logo = this.add.image(1700, 384, 'title');
        //  Intro snowball fight
        LC2.showSnowFX(this,'sprites', 'snowball1','throw');


        this.tweens.add({
            targets: logo,
            x: 512,
            ease: 'back.out',
            delay: 1800,
            duration: 600,
            onStart: () => {
                this.sound.play('throw');
            }
        });

        this.input.keyboard.once('keydown-SPACE', () => {

            this.scene.start('MainGame');

        }, this);

        this.input.once('pointerdown', () => {

            this.scene.start('MainGame');

        });
    }
}
