class Preloader extends Phaser.Scene {
    constructor() {
        var sceneConfig = {
            type: Phaser.AUTO,
            parent: 'content',
            key: 'Preloader',
            isAutoRedirected: true,
            isActiveDOM: false,
            pixelArt: true,
            width: 640,
            height: 960,
            dom: {
                createContainer: true
            },
            input: {
                gamepad: true
            },

            scale: {
                mode: Phaser.Scale.FIT,
                parent: 'content',
                autoCenter: Phaser.Scale.CENTER_BOTH,
                width: 640,
                height: 960,
                arcade: {
                    gravity: { y: 0.0 },
                    // fps: 60,
                    debug: false
                }
            },
            physics: {
                default: 'arcade',
                arcade: {
                    gravity: { y: 3.9 },
                    fps: 60,
                    debug: false
                }
            },
            scene: {
                preload: "preload",
                create: "create",
                update: "update",
                extend: {
                    checkBulletVsEnemy: "checkBulletVsEnemy",
                    launchEnemy: "launchEnemy",
                    hitShip: "hitShip",
                    hitEnemy: "hitEnemy"
                }
            }
        };
        super(sceneConfig);
    }
    preload() {
        // this.add.sprite(0, 0, 'background').setOrigin(0, 0);
        var logoPic = this.add.sprite(LC2.world.centerX, LC2.world.centerY - 100, 'logo');
        logoPic.setOrigin(0.5, 0.5);
        var loadingBg = this.add.sprite(LC2.world.centerX, LC2.world.centerY + 100, 'loading-background');
        loadingBg.setOrigin(0.5, 0.5);
        var progress = this.add.graphics();
        this.load.on('progress', function (value) {
            progress.clear();
            progress.fillStyle(0x00f211, 1);
            progress.fillRect(loadingBg.x - (loadingBg.width * 0.5) + 20, loadingBg.y - (loadingBg.height * 0.5) + 10, 540 * value, 25);
        });

        var resources = {
            'image': [
                ['title', 'assets/img/lclogo.png']
            ],
            'spritesheet': [
                ['button-start', 'assets/img/button-start.png', { frameWidth: 180, frameHeight: 180 }],
                ['button-settings', 'assets/img/button-settings.png', { frameWidth: 80, frameHeight: 80 }],
                ['loader', 'assets/img/loader.png', { frameWidth: 45, frameHeight: 45 }]
            ]
        };
        for (var method in resources) {
            resources[method].forEach(function (args) {
                var loader = this.load[method];
                loader && loader.apply(this.load, args);
            }, this);
        };
    }
    create() {
        LC2.fadeOutScene('MainMenu', this);
    }
}