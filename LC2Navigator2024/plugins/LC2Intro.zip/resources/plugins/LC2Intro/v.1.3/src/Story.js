class Story extends Phaser.Scene {
    isActiveDOM = appConfig.isActiveDOM;
    constructor() {
        var sceneConfig = {
            type: Phaser.AUTO,
            parent: 'content',
            key: 'Story',
            isAutoRedirected: false,
            isActiveDOM: true,
            pixelArt: true,
            dom: {
                createContainer: true
            },
            input: {
                gamepad: true
            },

            scale: {
                mode: Phaser.Scale.FIT,
                parent: 'content',
                autoCenter: Phaser.Scale.CENTER_BOTH,
                width: 1900,
                height: 1080
            },
            physics: {
                default: 'arcade',
                arcade: {
                    gravity: { y: 0.0 },
                    fps: 60,
                    debug: false
                }
            },
            scene: {
                init: "init",
                preload: "preload",
                create: "create",
                update: "update",
                extend: {
                    checkBulletVsEnemy: "checkBulletVsEnemy",
                    launchEnemy: "launchEnemy",
                    hitShip: "hitShip",
                    hitEnemy: "hitEnemy"
                }
            }
        };
        super(sceneConfig);
    }
    preload() {
        this.q = LC2.getUrlVars();
        if (this.isActiveDOM) {
            this.load.htmlTexture('storyhtmltex', '/LC2Intro.v.4.0/assets/html/story.php?action=tex&query=story&s=gl', 640, 960);
            this.load.html('storyHTML', '/LC2Intro.v.4.0/assets/html/story.php?action=menu&s=gl&q=' + this.q);
        }
    }
    create() {
        var shader = create_Shader(this, 640, 480, 'BufferShader1', 'BufferShader2', 'BufferShader3', fragmentShader4, fragmentShader3, fragmentShader3_1);
        shader.setAlpha(0.9);
        this.bg = this.add.tileSprite(0, 0, 0, 0, "bg").setOrigin(0).setScale(1).setSize(1920, 1080).setAlpha(0.9).setScrollFactor(0);
        // var bgg = this.add.image(0, 0, '__WHITE').setOrigin(0).setScale(1).setSize(1920, 1080).setAlpha(0.7);        
        //bgg.setDisplaySize(640, 960);
        LC2.addGradient(this.bg, 800, 960, 32, 0xffffff, 0x0000ff);
        this.light = this.lights.addLight(0, 0, 200).setScrollFactor(0.0);
        this.lights.enable().setAmbientColor(0x555555);
        this.lights.addLight(0, 100, 100).setColor(0xff0000).setIntensity(3.0);
        this.lights.addLight(0, 200, 100).setColor(0x00ff00).setIntensity(3.0);
        this.lights.addLight(0, 300, 100).setColor(0x0000ff).setIntensity(3.0);
        this.lights.addLight(0, 400, 100).setColor(0xffff00).setIntensity(3.0);

        this.lights.addLight(0, 900, 100).setColor(0xffff00).setIntensity(3.0);

        this.lights.addLight(0, 100, 800).setColor(0x0000ff).setIntensity(3.0);
        this.lights.addLight(0, 300, 800).setColor(0x0000ff).setIntensity(5.0);
        this.lights.addLight(0, 400, 800).setColor(0xff00ff).setIntensity(5.0);
        this.lights.addLight(0, 900, 800).setColor(0x0000ff).setIntensity(5.0);

        this.lights.addLight(0, 100, 600).setColor(0xff0000).setIntensity(4.0);
        this.lights.addLight(0, 200, 600).setColor(0x00ff00).setIntensity(3.0);
        this.lights.addLight(0, 300, 600).setColor(0x0000ff).setIntensity(3.0);
        this.lights.addLight(0, 400, 600).setColor(0xffff00).setIntensity(3.0);
        this.lights.addLight(0, 800, 600).setColor(0xffff00).setIntensity(3.0);
        this.lights.addLight(0, 900, 600).setColor(0xffff00).setIntensity(3.0);


        this.offsets = [0.1, 0.3, 0.5, 0.7];

        LC2.addLights(this, this.bg);
        // var particles = this.add.particles('flares');
        // var emitter = particles.createEmitter(this.cache.json.get('emitter'));
        // emitter.setAlpha(0.5);
        this.bgf = this.add.tileSprite(0, 0, 0, 0, "bgf").setOrigin(0).setScale(1).setSize(1920, 1080).setAlpha(0.9).setScrollFactor(0);
        this.bgas = this.add.tileSprite(0, 0, 0, 0, "bgas").setOrigin(0).setScale(1).setSize(1920, 1080).setAlpha(0.9).setScrollFactor(0);
        const clouds = this.add.tileSprite(400, 300, 800, 600, 'seaclouds');
        this.tweens.add({
            targets: clouds,
            tilePositionX: 800,
            duration: 9000,
            ease: 'linear',
            repeat: -1,
        });
        const fish1 = this.add.image(0, 700, 'fish01');
        const fish2 = this.add.image(800, 700, 'fish02');
        const waves = this.add.tileSprite(400, 800, 800, 960, 'waves');
        waves.setAlpha(0.5);
        LC2.getTweenFlip(this, clouds, waves, fish1, fish2);
        this.tweens.add({
            targets: waves,
            tilePositionY: 100,
            duration: 2000,
            ease: 'sine.inout',
            yoyo: true,
            repeat: -1,
            onUpdate: () => {
                waves.tilePositionX += 4
            }
        });
        var raster = createAlphaRasterY(this, 900, getGameHeight(this) - 30, getGameWidth(this), 1, 8, 4500, 1000, false, 0.8);

        // this.dynamiccontent = appConfig["data"]["storyscroller"]["text"].join(' ').toUpperCase();
        const scrollersconfig = {
            image: "171",
            width: 16,
            height: 18,
            chars: 'ABCDEFGHIJKLMNOPQRSTUVWXYZ| 0123456789*#!@:.,\\?-+=^$£()\'',
            charsPerRow: 19,
            spacing: { x: 0, y: 1 }
        };
        LC2.getScrollerTextGroup(this, "LETZTECHANCE IS BACK IN THE HOUSE", "171", scrollersconfig, 2, 640, 18, 850);


        // var sun = this.add.image(300, 300, 'sun').setScale(0.1);
        // LC2.getTween(this, sun,'Quad.easeInOut','Cubic.easeInOut', 10000,3.0,3.0,0, false);
        var sun = this.add.image(300, 300, 'space', 'sun2').setScale(0.1);
        LC2.getTween(this, sun, 'Quad.easeInOut', 'Cubic.easeInOut', 10000, 2.0, 2.0, -1, true);

        if (this.isActiveDOM) {
            var htmlTex = this.add.image(3, 10, 'storyhtmltex').setOrigin(0).setAlpha(0.5);
            var html = LC2.addHTMLObject(this, 'storyHTML', 20, 960, 800, -300, 200).setAlpha(0.9);
            var h1 = { title: 'LETZTECHANCE', style: 'chrome120', x: 400, y: 100 };
            var h2 = { title: 'The Story', style: 'dreams', x: 400, y: 18 };
            var h3 = { title: 'David Honisch', style: 'chrome36', x: 410, y: 160 };
            var tw = { y: 200, duration: 3000, loop: -1, ease: 'Sine.easeInOut', yoyo: true };
            getDOMTween(this, h1, h2, h3, tw);
            var style = {
                // 'background-color': 'lime',
                'width': '220px',
                'height': '50px',
                'font': '12px Arial',
                'font-weight': 'bold'
            };
            var element = this.add.dom(100, 950, 'div', style, '<h1>Done by David Honisch</h1>');
        }
        // var storyFont = { font: '24px ' + LC2.text['FONT'], fill: '#ffde00', stroke: '#000', strokeThickness: 7, align: 'center' };
        // LC2.addFontTextCentered(this, LC2.text['screen-story-howto'],storyFont);

        // createElf(this);
        this.buttonSettings = new Button(20, 20, 'button-settings', this.clickSettings, this);
        this.buttonSettings.setOrigin(0, 0);

        var buttonContinue = new Button(LC2.world.width - 20, LC2.world.height - 20, 'button-continue', this.clickContinue, this);
        buttonContinue.setOrigin(1, 1);

        buttonContinue.x = LC2.world.width + buttonContinue.width + 20;
        this.tweens.add({ targets: buttonContinue, x: LC2.world.width - 20, duration: 500, ease: 'Back' });

        this.keyEnter = this.input.keyboard.addKey(Phaser.Input.Keyboard.KeyCodes.ENTER);
        this.keyEnter.on('down', function (key, event) { this.clickContinue(); }, this);

        this.cameras.main.fadeIn(250, 0, 0, 0);
    }
    clickSettings() {

        LC2.Sfx.play('click');
        if (this.loadImage) {
            this.loadImage.destroy();
        }
        LC2.fadeOutScene('Settings', this);
        var animationFrames = this.anims.generateFrameNumbers('loader');
        animationFrames.pop();
        this.waitingForSettings = true;
        this.buttonSettings.setAlpha(0.1);
        var loadAnimation = this.anims.create({
            key: 'loading',
            frames: animationFrames,
            frameRate: 12,
            repeat: -1
        });
        this.loadImage = this.add.sprite(30, 30, 'loader').setOrigin(0, 0).setScale(1.25);
        this.loadImage.play('loading');
    }

    clickContinue() {
        LC2.Sfx.play('click');
        LC2.fadeOutScene('Game', this);
    }
    update(time, delta) {
        // this.bg.tilePositionY += +1;
        this.bgf.tilePositionY += +0.4;
        this.bgas.tilePositionX += +0.3;

        // if (this.dynamiccontent !== undefined) {
        //     LC2.updateHVScroller(this, this.dynamiccontent, this.dynamiccontent);
        // }
        if (this.scrollers !== undefined) {
            LC2.updateScrollerTextGroup(this, this.scrollers, delta);
        }
    }
};