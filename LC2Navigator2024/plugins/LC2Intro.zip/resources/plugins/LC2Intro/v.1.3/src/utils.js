var LC2 = {};

LC2.Sfx = {
    manage: function (type, mode, game, button, label) {
        switch (mode) {
            case 'init':
                {
                    LC2.Storage.initUnset('LC2-' + type, true);
                    LC2.Sfx.status = LC2.Sfx.status || [];
                    LC2.Sfx.status[type] = LC2.Storage.get('LC2-' + type);
                    if (type == 'sound') {
                        LC2.Sfx.sounds = [];
                        LC2.Sfx.sounds['click'] = game.sound.add('sound-click');
                        LC2.Sfx.sounds['points'] = game.sound.add('sound-points');
                        LC2.Sfx.sounds['shoot'] = game.sound.add('sound-shoot');
                        LC2.Sfx.sounds['explodedbl'] = game.sound.add('sound-explodedbl');
                    } else { // music
                        if (!LC2.Sfx.music || !LC2.Sfx.music.isPlaying) {
                            LC2.Sfx.music = game.sound.add('music-theme');
                            LC2.Sfx.music.volume = 0.5;
                        }
                    }
                    break;
                }
            case 'on':
                {
                    LC2.Sfx.status[type] = true;
                    break;
                }
            case 'off':
                {
                    LC2.Sfx.status[type] = false;
                    break;
                }
            case 'switch':
                {
                    LC2.Sfx.status[type] = !LC2.Sfx.status[type];
                    break;
                }
            default:
                { }
        }
        LC2.Sfx.update(type, button, label);

        if (type == 'music' && LC2.Sfx.music) {
            if (LC2.Sfx.status['music']) {
                if (!LC2.Sfx.music.isPlaying) {
                    LC2.Sfx.music.play({ loop: true });
                }
            } else {
                LC2.Sfx.music.stop();
            }
        }

        LC2.Storage.set('LC2-' + type, LC2.Sfx.status[type]);
    },
    play: function (audio) {
        if (audio == 'music') {
            if (LC2.Sfx.status['music'] && LC2.Sfx.music && !LC2.Sfx.music.isPlaying) {
                LC2.Sfx.music.play({ loop: true });
            }
        } else { // sound
            if (LC2.Sfx.status['sound'] && LC2.Sfx.sounds && LC2.Sfx.sounds[audio]) {
                LC2.Sfx.sounds[audio].play();
            }
        }
    },
    update: function (type, button, label) {
        if (button) {
            if (LC2.Sfx.status[type]) {
                button.setTexture('button-' + type + '-on');
            } else {
                button.setTexture('button-' + type + '-off');
            }
        }
        if (label) {
            if (LC2.Sfx.status[type]) {
                label.setText(LC2.Lang.text[LC2.Lang.current][type + '-on']);
            } else {
                label.setText(LC2.Lang.text[LC2.Lang.current][type + '-off']);
            }
        }
    }
};
LC2.getUrlVars = function () {
    var url;
    var found = window.location.href.indexOf('?q=');
    if (found !== undefined && found > 0) {
        url = window.location.href.substr(found + 3, window.location.href.length);
    }
    else {
        url = "";// ConfigModel.Product.url;
    }
    return url.replace("https://www.youtube.com/watch?v=", "/ytidplayer.html?v=");
}
LC2.addToDOM = function (game, elem, title, x, y) {
    return game.add.dom(x, y, elem, null, title);
}
LC2.createRetroFont = function (game, text, x, y) {
    var dynamic = LC2.intRetroFont(game, dynamic, text, x, y);
    dynamic = LC2.scrollRetroFont(game, dynamic, x, y);
    return dynamic;
}
LC2.easeInOutTween = function (game, asset, ease, duration, repeat, isYoyo) {
    game.tweens.add({
        targets: asset,
        duration: duration,
        scaleY: + 0.1,
        scaleX: + 0.1,
        ease: ease,//'Cubic.easeInOut',
        repeat: repeat,
        yoyo: isYoyo
    });
}
LC2.getTween = function(game, data, ease1, ease2, duration, x, y, RepeatNumber, isYoyo) {
    game.tweens.add({
        targets: data,
        duration: duration,
        scaleX: x,
        scaleY: y,
        ease: ease1,//'Quad.easeInOut',
        repeat: RepeatNumber,
        yoyo: isYoyo
    });

    game.tweens.add({
        targets: data,
        duration: duration,
        scaleY: y,
        scaleY: y,
        ease: ease2,//'Cubic.easeInOut',
        repeat: RepeatNumber,
        yoyo: isYoyo
    });

}
LC2.setCursorControls = function(game, ship, cursorKeys) {
    //var cursorKeys = game.input.keyboard.createCursorKeys();
    if (cursorKeys !== undefined) {
        //left
        if (cursorKeys.left.isDown) {
            if (ship !== undefined) {
                ship.x += -1.0;
                ship.rotation += -0.1;
            }
        }
        //right
        if (cursorKeys.right.isDown) {
            if (ship !== undefined) {
                ship.x += +1.0;
                ship.rotation += 0.1;
            }
        }
        //up
        if (cursorKeys.up.isDown) {
            if (ship !== undefined) {
                ship.y += -1.0;
            }

        }
        if (cursorKeys.down.isDown) {
            if (ship !== undefined) {
                ship.y += 1.0;
            }
        }
    }
}
LC2.setFireControls = function(game, ship, bullets) {    
    var spaceBar = game.input.keyboard.addKey(Phaser.Input.Keyboard.KeyCodes.SPACE);
    if (spaceBar.isDown) {
        console.log('spacebar');
        // this.fireBullet(time);
        bullets.fireBullet(ship.x, ship.y);
    }

}
LC2.intRetroFont = function (game, dynamic, text, x, y) {
    var rConfig = {
        image: 'knighthawks',
        width: 31,
        height: 25,
        chars: Phaser.GameObjects.RetroFont.TEXT_SET6,
        charsPerRow: 10,
        'offset.x': 1,
        'offset.y': 1,
        'spacing.x': 1,
        'spacing.y': 1,
        lineSpacing: 1,
        spacing: { x: 1, y: 1 }
    };
    //game.cache.bitmapFont.add('knighthawks', Phaser.GameObjects.RetroFont.Parse(game, rConfig));

    //dynamic = game.add.dynamicBitmapText(x, y, 'knighthawks', text);
    //dynamic.setScale(2);
    return dynamic;
}
LC2.scrollRetroFont = function (game, dynamic, x, y) {
    game.tweens.add({
        targets: dynamic,
        duration: 2000,
        y: 75 * 4,
        ease: 'Sine.easeInOut',
        repeat: -1,
        yoyo: true,
    });
    return dynamic;

}
LC2.getDOMTweenDelayed = function (game, dh1, dh2, dh3, tw, delay) {
    var h1 = game.add.dom(dh1.x, dh1.y, 'h1', null, dh1.title);
    h1.setClassName(dh1.style);

    var h3 = game.add.dom(dh3.x, dh3.y, 'h3', null, dh3.title);
    h3.setClassName(dh3.style);

    var h2 = game.add.dom(dh2.x, dh2.y, 'h2', null, dh2.title);
    h2.setClassName(dh2.style);
    h2.setAngle(-15);

    game.tweens.add({
        targets: [h1, h2, h3],
        y: tw.y,
        duration: tw.duration,
        ease: 'Sine.easeInOut',
        loop: tw.loop,
        yoyo: true
    });
    var addEvent = function (event) {
        // console.log("Event:" + event);
        switch (event) {
            case 'onComplete':
                console.log("onComplete");
                h1.destroy();
                h2.destroy();
                h3.destroy();
                break;
            case 'onStart':
                console.log("onStart");
                break;
            case 'onRepeat':
                console.log("onRepeat");
                break;

            default:
                break;
        }
    };
    var tween = game.tweens.add({
        targets: [h1, h2, h3],
        delay: 10000,
        props: {
            x: {
                value: 600,
                delay: 1000
            }
        },
        ease: 'Power1',
        duration: 3000,
        yoyo: true,
        paused: false,
        repeat: 3,
        onActive: function () { addEvent('onActive') },
        onStart: function () { addEvent('onStart') },
        onLoop: function () { addEvent('onLoop') },
        onYoyo: function () { addEvent('onYoyo') },
        onRepeat: function () { addEvent('onRepeat') },
        onComplete: function () { addEvent('onComplete') }
    });
}
LC2.fadeOutIn = function (passedCallback, context) {
    context.cameras.main.fadeOut(250);
    context.time.addEvent({
        delay: 250,
        callback: function () {
            context.cameras.main.fadeIn(250);
            passedCallback(context);
        },
        callbackScope: context
    });
}
LC2.fadeOutScene = function (sceneName, context) {
    context.cameras.main.fadeOut(250);
    context.time.addEvent({
        delay: 250,
        callback: function () {
            context.scene.start(sceneName);
        },
        callbackScope: context
    });
};
LC2.createEmitter = function (game,  ship) {
    var xparticles = game.add.particles('explosion');

    /*
    xparticles.createEmitter({
        frame: [ 'smoke-puff', 'cloud', 'smoke-puff' ],
        angle: { min: 240, max: 300 },
        speed: { min: 200, max: 300 },
        quantity: 6,
        lifespan: 2000,
        alpha: { start: 1, end: 0 },
        scale: { start: 1.5, end: 0.5 },
        on: false
    });
    */

    xparticles.createEmitter({
        frame: 'red',
        angle: { min: 0, max: 360, steps: 32 },
        lifespan: 1000,
        speed: 400,
        quantity: 32,
        scale: { start: 0.3, end: 0 },
        on: false
    });

    xparticles.createEmitter({
        frame: 'muzzleflash2',
        lifespan: 200,
        scale: { start: 2, end: 0 },
        rotate: { start: 0, end: 180 },
        on: false
    });

    var particles = game.add.particles('space');

    var emitter = particles.createEmitter({
        frame: 'blue',
        speed: 200,
        lifespan: {
            onEmit: function (particle, key, t, value)
            {
                return Phaser.Math.Percent(ship.body.speed, 0, 400) * 2000;
            }
        },
        alpha: {
            onEmit: function (particle, key, t, value)
            {
                return Phaser.Math.Percent(ship.body.speed, 0, 400);
            }
        },
        angle: {
            onEmit: function (particle, key, t, value)
            {
                // var v = Phaser.Math.Between(-10, 10);
                var v = 0;
                return (ship.angle - 180) + v;
            }
        },
        scale: { start: 0.6, end: 0 },
        blendMode: 'ADD'
    });

    emitter.startFollow(ship);
    return xparticles;
};

class Button extends Phaser.GameObjects.Image {
    constructor(x, y, texture, callback, scene, noframes) {
        super(scene, x, y, texture, 0);
        this.setInteractive({ useHandCursor: true });

        this.on('pointerup', function () {
            if (!noframes) {
                this.setFrame(1);
            }
        }, this);

        this.on('pointerdown', function () {
            if (!noframes) {
                this.setFrame(2);
            }
            callback.call(scene);
        }, this);

        this.on('pointerover', function () {
            if (!noframes) {
                this.setFrame(1);
            }
        }, this);

        this.on('pointerout', function () {
            if (!noframes) {
                this.setFrame(0);
            }
        }, this);

        scene.add.existing(this);
    }
};

LC2.Storage = {
    availability: function () {
        if (!(!(typeof (window.localStorage) === 'undefined'))) {
            console.log('localStorage not available');
            return null;
        }
    },
    get: function (key) {
        this.availability();
        try {
            return JSON.parse(localStorage.getItem(key));
        } catch (e) {
            return window.localStorage.getItem(key);
        }
    },
    set: function (key, value) {
        this.availability();
        try {
            window.localStorage.setItem(key, JSON.stringify(value));
        } catch (e) {
            if (e == QUOTA_EXCEEDED_ERR) {
                console.log('localStorage quota exceeded');
            }
        }
    },
    initUnset: function (key, value) {
        if (this.get(key) === null) {
            this.set(key, value);
        }
    },
    getFloat: function (key) {
        return parseFloat(this.get(key));
    },
    setHighscore: function (key, value) {
        if (value > this.getFloat(key)) {
            this.set(key, value);
        }
    },
    remove: function (key) {
        this.availability();
        window.localStorage.removeItem(key);
    },
    clear: function () {
        this.availability();
        window.localStorage.clear();
    }
};

LC2.Lang = {
    current: 'de',
    options: ['de','en', 'pl'],
    parseQueryString: function (query) {
        var vars = query.split('&');
        var query_string = {};
        for (var i = 0; i < vars.length; i++) {
            var pair = vars[i].split('=');
            if (typeof query_string[pair[0]] === 'undefined') {
                query_string[pair[0]] = decodeURIComponent(pair[1]);
            } else if (typeof query_string[pair[0]] === 'string') {
                var arr = [query_string[pair[0]], decodeURIComponent(pair[1])];
                query_string[pair[0]] = arr;
            } else {
                query_string[pair[0]].push(decodeURIComponent(pair[1]));
            }
        }
        return query_string;
    },
    updateLanguage: function (lang) {
        var query = window.location.search.substring(1);
        var qs = LC2.Lang.parseQueryString(query);
        if (qs && qs['lang']) {
            console.log('LANG: ' + qs['lang']);
            LC2.Lang.current = qs['lang'];
        } else {
            if (lang) {
                LC2.Lang.current = lang;
            } else {
                LC2.Lang.current = navigator.language;
            }
        }
        if (LC2.Lang.options.indexOf(LC2.Lang.current) == -1) {
            LC2.Lang.current = 'en';
        }
    },
    text: {
        'de': {
            'FONT': 'Berlin',
            'settings': 'Konfiguration',
            'sound-on': 'Sound: AN',
            'sound-off': 'Sound: AUS',
            'music-on': 'Music: AN',
            'music-off': 'Music: AUS',
            'keyboard-info': 'Press K for keyboard shortcuts',
            'credits': 'CREDITS',
            'madeby': 'LC2HTMLLoader v.1.0 made by',
            'team': 'THE TEAM',
            'coding': 'coding',
            'design': 'design',
            'testing': 'testing',
            'musicby': 'Music by',
            'key-title': 'TASTATUR SHORTCUTS',
            'key-settings-title': 'Settings',
            'key-settings-onoff': 'S - show/hide settings',
            'key-audio': 'A - turn sound on/off',
            'key-music': 'M - turn music on/off',
            'key-credits': 'C - show/hide credits',
            'key-shortcuts': 'K - show/hide keyboard shortcuts',
            'key-menu': 'Main menu',
            'key-start': 'Enter - start game',
            'key-continue': 'Enter - continue',
            'key-gameplay': 'Gameplay',
            'key-button': 'Enter - use the Fire to kill everything button',
            'key-pause': 'P - turn pause screen on/off',
            'key-pause-title': 'Pause screen',
            'key-back': 'B - back to main menu',
            'key-return': 'P - return to the game',
            'key-gameover': 'Game over screen',
            'key-try': 'T - try again',
            'gameplay-score': 'Score: ',
            'gameplay-timeleft': 'Time left: ',
            'gameplay-paused': 'PAUSE',
            'gameplay-gameover': 'GAME OVER',
            'menu-highscore': 'Highscore: ',
            'screen-story-howto': 'Story\n\n Use cursors\nor click mouse button\nto destory\nas many things\nas possible.'
        },
        'en': {
            'FONT': 'Berlin',
            'settings': 'SETTINGS',
            'sound-on': 'Sound: ON',
            'sound-off': 'Sound: OFF',
            'music-on': 'Music: ON',
            'music-off': 'Music: OFF',
            'keyboard-info': 'Press K for keyboard shortcuts',
            'credits': 'CREDITS',
            'madeby': 'LC2HTMLLoader v.1.0 made by',
            'team': 'THE TEAM',
            'coding': 'coding',
            'design': 'design',
            'testing': 'testing',
            'musicby': 'Music by',
            'key-title': 'KEYBOARD SHORTCUTS',
            'key-settings-title': 'Settings',
            'key-settings-onoff': 'S - show/hide settings',
            'key-audio': 'A - turn sound on/off',
            'key-music': 'M - turn music on/off',
            'key-credits': 'C - show/hide credits',
            'key-shortcuts': 'K - show/hide keyboard shortcuts',
            'key-menu': 'Main menu',
            'key-start': 'Enter - start game',
            'key-continue': 'Enter - continue',
            'key-gameplay': 'Gameplay',
            'key-button': 'Enter - use the Fire to kill everything button',
            'key-pause': 'P - turn pause screen on/off',
            'key-pause-title': 'Pause screen',
            'key-back': 'B - back to main menu',
            'key-return': 'P - return to the game',
            'key-gameover': 'Game over screen',
            'key-try': 'T - try again',
            'gameplay-score': 'Score: ',
            'gameplay-timeleft': 'Time left: ',
            'gameplay-paused': 'PAUSED',
            'gameplay-gameover': 'GAME OVER',
            'menu-highscore': 'Highscore: ',
            'screen-story-howto': 'Story\n\n Click mouse button\nto destory\nas many bricks\nas possible.'
        },
        'pl': {
            'FONT': 'Arial',
            'settings': 'USTAWIENIA',
            'sound-on': 'David Honisch',
            'sound-off': 'David Honisch',
            'music-on': 'David Honisch',
            'music-off': 'David Honisch',
            'keyboard-info': 'Press K',
            'credits': 'AUTORZY',
            'madeby': 'David Honisch - Open Code',
            'team': 'Bey0nd3r',
            'coding': 'David',
            'design': 'Bey0nd3r',
            'testing': 'Bey0nd3r',
            'musicby': 'Bey0nd3r',
            'key-title': 'Bey0nd3r',
            'key-settings-title': 'Bey0nd3r',
            'key-settings-onoff': 'S - settings',
            'key-audio': 'A - Audio',
            'key-music': 'M - włącz/wyłącz muzykę',
            'key-credits': 'C - pokaż/ukryj autorów',
            'key-shortcuts': 'K - pokaż/ukryj skróty klawiszowe',
            'key-menu': 'Menu główne',
            'key-start': 'Enter - zacznij grę',
            'key-continue': 'Enter - kontynuuj',
            'key-gameplay': 'Rozgrywka',
            'key-button': 'Enter - use the Fire to kill everything button',
            'key-pause': 'P - Pause',
            'key-pause-title': 'Pause',
            'key-back': 'B - powrót do menu głównego',
            'key-return': 'P - powrót do gry',
            'key-gameover': 'Ekran końca gry',
            'key-try': 'T - spróbuj ponownie',
            'gameplay-score': 'Wynik: ',
            'gameplay-timeleft': 'Pozostały czas: ',
            'gameplay-paused': 'PAUZA',
            'gameplay-gameover': 'KONIEC GRY',
            'menu-highscore': 'Rekord: ',
            'screen-story-howto': 'Ekran fabuły / jak grać'
        }
    }
};

// Usage tracking - remember to replace with your own!
// var head = document.getElementsByTagName('head')[0];
// var script = document.createElement('script');
// script.type = 'text/javascript';
// script.onload = function() {
//     window.dataLayer = window.dataLayer || [];

//     function gtag() { dataLayer.push(arguments); }
//     gtag('js', new Date());
//     gtag('config', 'UA-30485283-26');
// }
// script.src = 'https://www.googletagmanager.com/gtag/js?id=UA-30485283-26';
// head.appendChild(script);