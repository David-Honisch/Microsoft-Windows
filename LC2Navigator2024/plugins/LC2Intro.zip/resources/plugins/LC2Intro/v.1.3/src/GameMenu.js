class GameMenu extends Phaser.Scene {
    sceneConfig;
    //
    q;
    bullets;
    textQuery;
    redirectscene = "Redirect";
    progressCount = 0;
    redirectRepeatcount = 100;
    cursorKeys;// = this.input.keyboard.createCursorKeys();// = Phaser.Types.Input.Keyboard.CursorKeys;
    dataText = {
        'name': "Golden Labyrinth",
        'level': 0,
        'gold': 0,
        'userName': 'guest'
    };
    blitter;
    frame;
    scrfirst = 0;
    text_num = -1;
    counter = -1;
    letters;
    structure;

    callback = null;

    iteration = null;
    skip = false;
    posy;

    storyscroller;
    scrollers;
    dynamicscroller;
    dynamiccontent;



    spriteBounds;
    group;
    group2;
    map;
    layer;
    hsv;
    isActiveDOM = appConfig.isActiveDOM;

    asteroids;
    // ship_collisiongroup;
    asteroids_collisiongroup;

    constructor() {
        var sceneConfig = {
            type: Phaser.AUTO,
            parent: 'content',
            key: 'GameMenu',
            isAutoRedirected: false,
            isActiveDOM: true,
            pixelArt: true,
            width: 640,
            height: 960,
            pipeline: { LazersPostFX },
            dom: {
                createContainer: true
            },
            input: {
                gamepad: true
            },

            scale: {
                mode: Phaser.Scale.FIT,
                parent: 'content',
                autoCenter: Phaser.Scale.CENTER_BOTH,
                width: 1900,
                height: 1080
            },
            physics: {
                default: 'arcade',
                arcade: {
                    gravity: { y: 0.0 },
                    fps: 60,
                    debug: false
                }
            },
            scene: {
                init: "init",
                preload: "preload",
                create: "create",
                update: "update",
                extend: {
                    checkBulletVsEnemy: "checkBulletVsEnemy",
                    launchEnemy: "launchEnemy",
                    hitShip: "hitShip",
                    hitEnemy: "hitEnemy"
                }
            }
        };
        super(sceneConfig);
        this.sceneConfig = sceneConfig;
        this.bgFilesLoaded = false;
    }
    isRedirect(s) {
        if (s.includes('http') || s.includes('.html')) {
            return true;
        }
        else {
            return false;
        }
    }
    preload() {
        this.q = LC2.getUrlVars();
        var isChrome = LC2.isBrowserCompatible();
        if (isChrome){
            this.isActiveDOM = false;
            console.log("isActiveDOM:"+(this.isActiveDOM?"true":"false"));
        }
        else{            
            console.log("isActiveDOM:"+(this.isActiveDOM?"true":"false"));
        }
        // alert(this.isActiveDOM?"true":"false");
        this.load.spritesheet('ball', 'assets/img/balls.png', { frameWidth: 17, frameHeight: 17 })
        this.load.bitmapFont('ice', 'assets/fonts/bitmap/iceicebaby.png', 'assets/fonts/bitmap/iceicebaby.xml');
        this.load.atlas('assets', 'assets/atlas/tweenparts.png', 'assets/atlas/tweenparts.json');
        if (this.isActiveDOM) {
            console.log("isActiveDOM preload");
            this.load.htmlTexture('homeHTML', 'assets/html/home.php?q=' + this.q, 640, 960);
            //this.load.html('titleHTML', 'assets/html/title.html');
            this.load.html('titleHTML', '/LC2Intro.v.4.0/assets/html/title.php?q=' + this.q);
            //this.load.html('nameform', 'assets/html/form.html');
            this.load.html('loginForm', '/LC2Intro.v.4.0/assets/html/loginform.php?q=' + this.q);
            this.load.html('loggedinForm', '/LC2Intro.v.4.0/assets/html/loggedinForm.php?q=' + this.q);
            this.load.html('gamesHTML', '/cms/games.html' + this.q);
            
            console.log("isActiveDOM preload done.");
        }

        this.load.tilemapCSV('introcsv', 'assets/tilemaps/csv/intro.csv');

        this.load.atlas('knight', 'assets/animations/knight.png', 'assets/animations/knight.json');
        this.load.image('bobfont', 'assets/img/twist/bob-font.png');
        this.load.atlas('bobs', 'assets/img/twist/bobs.png', 'assets/img/twist/bobs.json');

        // this.load.image('tileset2', 'assets/tilemaps/tiles/tileorder.png');
        // this.load.tilemapTiledJSON('map2', 'assets/tilemaps/maps/tileorder.json');
        this.load.image('tiles', ['assets/tilemaps/tiles/drawtiles1.png', 'assets/tilemaps/tiles/drawtiles1_n.png']);
        this.load.tilemapCSV('homemap', 'assets/tilemaps/csv/levels/home.csv');

        // this.load.atlas('elves', 'assets/img/elves-craft-pixel.png', 'assets/img/elves-craft-pixel.json');

    }
    create() {
       
        const timeline = this.add.timeline();
        timeline.play();
        // this.physics.startSystem(Phaser.Physics.P2JS);
        // this.physics.p2.setImpactEvents(true);
        this.level = 0;
        this.q = LC2.getUrlVars();
        this.tilesetutils = new Tilesetutils();
        this.mainCamera = new Camera();
        this.cursorKeys = this.input.keyboard.createCursorKeys();
        var fontHighscore = { font: '24px ' + LC2.text['FONT'], fill: '#ffde00', stroke: '#000', strokeThickness: 5 };
        this.cameras.main.setBounds(0, 0, 640 * 2, 960 * 2);
        this.physics.world.setBounds(0, 0, 640 * 2, 960 * 2);



        // var shader = create_Shader(this, 640, 960, 'BufferShader1', 'BufferShader2', 'BufferShader3', fragmentShader4, fragmentShader3, fragmentShader3_1);
        // shader.setAlpha(0.9);
        // this.bg = this.add.tileSprite(0, 0, 0, 0, "bg").setOrigin(0).setScale(1).setSize(1920, 1080).setAlpha(0.9).setScrollFactor(0);
        // var shader = create_Shader(this, 640, 480, 'BufferShader1', 'BufferShader2', 'BufferShader3', fragmentShader4, fragmentShader3, fragmentShader3_1);
        // shader.setAlpha(0.9);        
        this.bg = this.add.tileSprite(0, 0, 0, 0, "bg").setOrigin(0).setScale(1).setSize(1920, 1080).setAlpha(0.9).setScrollFactor(0);
        this.bg.setPipeline('Light2D');
        // this.bg = this.add.tileSprite(0, 0, 0, 0, "bg").setOrigin(0).setScale(1).setSize(1920, 1080).setAlpha(0.9).setScrollFactor(0);
        // var bgg = this.add.image(0, 0, '__WHITE').setOrigin(0).setScale(1).setSize(1920, 1080).setAlpha(0.5);        
        // bgg.setDisplaySize(640, 960);
        LC2.addGradient(this.bg, 800, 960, 32, 0xffffff, 0x0000ff);
        // this.bgf = this.add.tileSprite(0, 0, 0, 0, "bgf").setOrigin(0).setScale(1).setSize(1920, 1080).setAlpha(0.9).setScrollFactor(0);
        // this.bgf.setAlpha(0,0,1,1);
        // this.bgas = this.add.tileSprite(0, 0, 0, 0, "bgas").setOrigin(0).setScale(1).setSize(1920, 1080).setAlpha(0.9).setScrollFactor(0);

        this.light = this.lights.addLight(0, 0, 200).setScrollFactor(0.0);
        this.lights.enable().setAmbientColor(0x555555);
        this.lights.addLight(0, 100, 100).setColor(0xff0000).setIntensity(3.0);
        this.lights.addLight(0, 200, 100).setColor(0x00ff00).setIntensity(3.0);
        this.lights.addLight(0, 300, 100).setColor(0x0000ff).setIntensity(3.0);
        this.lights.addLight(0, 400, 100).setColor(0xffff00).setIntensity(3.0);

        this.lights.addLight(0, 900, 100).setColor(0xffff00).setIntensity(3.0);

        this.lights.addLight(0, 100, 800).setColor(0x0000ff).setIntensity(3.0);
        this.lights.addLight(0, 300, 800).setColor(0x0000ff).setIntensity(5.0);
        this.lights.addLight(0, 400, 800).setColor(0xff00ff).setIntensity(5.0);
        this.lights.addLight(0, 900, 800).setColor(0x0000ff).setIntensity(5.0);

        this.lights.addLight(0, 100, 600).setColor(0xff0000).setIntensity(4.0);
        this.lights.addLight(0, 200, 600).setColor(0x00ff00).setIntensity(3.0);
        this.lights.addLight(0, 300, 600).setColor(0x0000ff).setIntensity(3.0);
        this.lights.addLight(0, 400, 600).setColor(0xffff00).setIntensity(3.0);
        this.lights.addLight(0, 800, 600).setColor(0xffff00).setIntensity(3.0);
        this.lights.addLight(0, 900, 600).setColor(0xffff00).setIntensity(3.0);
        this.offsets = [0.1, 0.3, 0.5, 0.7, 2.0, 3.0, 2.0, 1.0, 0.5];

        // const clouds = this.add.tileSprite(400, 300, 800, 600, 'seaclouds');
        // this.tweens.add({
        //     targets: clouds,
        //     tilePositionX: 800,
        //     duration: 9000,
        //     ease: 'linear',
        //     repeat: -1,
        // });
        // const fish1 = this.add.image(0, 700, 'fish01');
        // const fish2 = this.add.image(800, 700, 'fish02');
        // const waves = this.add.tileSprite(400, 800, 800, 960, 'waves');
        // waves.setAlpha(0.5);
        // LC2.getTweenFlip(this, clouds, waves, fish1, fish2);
        // this.tweens.add({
        //     targets: waves,
        //     tilePositionY: 100,
        //     duration: 2000,
        //     ease: 'sine.inout',
        //     yoyo: true,
        //     repeat: -1,
        //     onUpdate: () => {
        //         waves.tilePositionX += 4
        //     }
        // });

        // this.cameras.main.scrollX = 120;
        // this.cameras.main.scrollY = 80;
        // this.cameras.main.zoom = 2;
        const map = this.make.tilemap({ key: 'homemap', tileWidth: 32, tileHeight: 32 });
        const tileset = map.addTilesetImage('tiles', null, 32, 32, 1, 2);
        this.layer = map.createLayer(0, tileset, 0, 0).setPipeline('Light2D');




        LC2.addLights(this, this.bg);
        LC2.addLights(this, this.layer);
        //LC2.createLayer(this);
        // this.bg = this.add.sprite(0, 0, 'background').setOrigin(0, 0).setAlpha(1.0);
        var raster = createAlphaRasterY(this, 900, getGameHeight(this) - 30, getGameWidth(this), 1, 4, 4500, 1000, false, 0.7);
        raster.setAlpha(0.5);
        // this.showreleaseChunks(this);
        // var particles = this.add.particles('flares');
        // var emitter = particles.createEmitter(this.cache.json.get('emitter'));
        // emitter.setAlpha(0.5);
        // this.mainCamera.setCameraPipeline(this);
        // this.mainCamera.setCameraShake(this);
        // var planet = this.add.image(200, 200, 'purple-planet').setOrigin(0).setScale(0.2);
        // LC2.getTween(this, planet, 'Quad.easeInOut', 'Cubic.easeInOut', 4000, 0.4, 0.4, -1, true);
        var sun = this.add.image(300, 300, 'space', 'sun2').setScale(0.1);
        LC2.getTween(this, sun, 'Quad.easeInOut', 'Cubic.easeInOut', 10000, 2.0, 2.0, -1, true);

        if (this.isActiveDOM) {
            console.log("isActiveDOM running...");
            var _that = this;
            try {
                var htmlTex = this.add.image(3, 10, 'homeHTML').setOrigin(0).setAlpha(0.5);
                var html = LC2.addHTMLObject(this, 'loginForm', 200, 1200, 800, 550, 150).setAlpha(0.5);
                //var games = LC2.addHTMLObject(this, 'gamesHTML', 200, 1200, 800, 600, 350).setAlpha(0.5);
                // var container = LC2.addContainer(this, [html],10,-10,120,80);
                // container.on('drag', (pointer, dragX, dragY) => container.setPosition(dragX, dragY));
                // html.addListener('click');
                // html.on('click', function (event) {
                //     if (event.target.name === 'loginButton') {
                //         // LC2.loginClickEvent(this, loginForm, 'loggedinForm', 200, 1200);
                //         const inputUsername = html.getChildByName('username');
                //         const inputPassword = html.getChildByName('password');
                //         console.log('username:' + inputUsername.value);
                //         if (inputUsername.value !== '' && inputPassword.value !== '') {
                //             //  Turn off the click events
                //             html.removeListener('click');
                //             //  Tween the login form out
                //             this.scene.tweens.add({ targets: html.rotate3d, x: 1, w: 90, duration: 3000, ease: 'Power3' });
                //             this.scene.tweens.add({
                //                 targets: html, scaleX: 2, scaleY: 2, y: 700, duration: 3000, ease: 'Power3',
                //                 onComplete: function () {
                //                     html.setVisible(false);
                //                     // var loggedinForm = _that.add.dom(150, 400).createFromCache('loggedinForm');//LC2.addHTMLObject(_that, img, x, y, 800, 600);
                //                     var loggedinForm = LC2.addHTMLObject(_that, 'loggedinForm', 200, 1200, 800, 550, 150);
                //                     loggedinForm.setAlpha(0.5);
                //                 }
                //             });


                //             //  Populate the text with whatever they typed in as the username!
                //             // text.setText(`Welcome ${inputUsername.value}`);
                //         }
                //         else {
                //             //  Flash the prompt
                //             game.scene.tweens.add({ targets: element, alpha: 0.1, duration: 200, ease: 'Power3', yoyo: true });
                //         }

                //     }

                // });

                // var titleHTML = LC2.createHTMLDIV(this, 'titleHTML');
                // titleHTML.setOrigin(0).setAlpha(0.5);
                var h1 = { title: 'LETZTECHANCE', style: 'chrome120', x: 400, y: 600 };
                var h2 = { title: 'Game Menu', style: 'dreams', x: 400, y: 618 };
                var h3 = { title: 'David Honisch', style: 'chrome36', x: 410, y: 660 };
                var tw = { y: 200, duration: 3000, loop: -1, ease: 'Sine.easeInOut', yoyo: true };
                getDOMTween(this, h1, h2, h3, tw);
                var style = {
                    // 'background-color': 'lime',
                    'width': '220px',
                    'height': '50px',
                    'font': '12px Arial',
                    'font-weight': 'bold'
                };
                var element = this.add.dom(10, 960, 'div', style, 'Done by David Honisch');
            } catch (error) {
                console.error(error);
            }

        }

        // this.letters = LC2.scanFont(this,this.letters);
        // this.blitter = this.add.blitter(0, 0, 'bobs');
        // this.frame = this.textures.getFrame('bobs', 'bob2');

        //scroller
        const scrollersconfig = {
            image: "171",
            width: 16,
            height: 18,
            chars: 'ABCDEFGHIJKLMNOPQRSTUVWXYZ| 0123456789*#!@:.,\\?-+=^$£()\'',
            charsPerRow: 19,
            spacing: { x: 0, y: 1 }
        };
        LC2.getScrollerTextGroup(this, "LETZTECHANCE IS BACK IN THE HOUSE", "171", scrollersconfig, 2, 640, 18, 850);
        this.storyscroller = this.add.dynamicBitmapText(16, 600, 'desyrel', appConfig["data"]["storyscroller"]["text"], 24);
        this.storyscroller.setSize(1024, 300);
        this.dynamiccontent = appConfig["data"]["storyscroller"]["text"].join(' ').toUpperCase();
        var config = {
            image: 'knighthawks',
            width: 32,
            height: 25,
            chars: Phaser.GameObjects.RetroFont.TEXT_SET2,
            charsPerRow: 10
        };
        LC2.getHVScroller(this, 'knighthawks', appConfig["data"]["storyscroller"]["text"], 5)
        //
        //const phaserLogoImg1 = this.add.image(this.scale.width / 2, this.scale.height / 2 - 50, 'logo');
        // const logoPic = this.add.image(this.scale.width / 2, 250, 'logo');
        // logoPic.setInteractive();
        // logoPic.on('pointerdown', () => {
        //     this.clickLogo();
        //     // timeline.add({
        //     //     in: 1000,
        //     //     once: true,
        //     //     run: () => {
        //     //         this.clickLogo();
        //     //         // const x = Phaser.Math.Between(100, 700);
        //     //         // const y = Phaser.Math.Between(100, 500);
        //     //         // this.add.sprite(x, y, 'timeline', 'pumpkin')
        //     //     }
        //     // })
        // });
        // LC2.addDisplacement(this,logoPic,400,400,800);
        // logoPic.on('pointerover', () => { logoPic.setTint(0x44ff44); });
        // logoPic.on('pointerout', () => { logoPic.setTint(0xffff44); logoPic.clearTint(); });
        // LC2.createEmitterFX(this,'star3',200, 200);
        // LC2.setVisibleFX(this, 800, 960);
        // LC2.addLights(this, logoPic);



        // LC2.addShadowTween(this, phaserLogoImg1,1.05, 3000,5,2000, 4000);
        // var buttonLogo = new Button(800, 270, 'logo', this.clickLogo, this, 'static');
        // buttonLogo.setInteractive();
        // buttonLogo.setOrigin(0, 1.0);
        // buttonLogo.x = -buttonLogo.width - 20;
        // buttonLogo.on('pointerover', () => { buttonLogo.setTint(0x44ff44); });
        // buttonLogo.on('pointerout', () => { buttonLogo.setTint(0xffff44); buttonLogo.clearTint(); });
        // this.tweens.add({ targets: buttonLogo, x: 20, duration: 500, ease: 'Back' });

        // this.ship = this.add.image(Math.round(300), Math.round(600),'goldrunner');//.setDepth(2);
        this.ship = this.physics.add.image(Math.round(300), Math.round(500), 'space', 'goldrunner').setDepth(1).setInteractive().setCircle(45);
        this.ship.setCollideWorldBounds(true);
        this.ship.health = 100;
        this.ship.rotation = 0.0;
        this.ship.setDamping(true);
        this.ship.setDrag(0.95);
        this.ship.setMaxVelocity(400);
        this.ship.rotation = 4.7;
        this.ship.setImmovable();
        //LC2.addNewEmitter(this, this.ship);
        // LC2.addNewEmitterScene(this, 'flares', 400,400);
        this.input.on('pointerdown', pointer => {
            LC2.addNewEmitterClick(this, 'flares', pointer.x, pointer.y);
        });
        LC2.addGlowEmitter(this, this.ship, 0xffffff, 32, 2);
        // LC2.addLights(this, this.ship);
        // LC2.addGeometicEmitter(this,'flares',400,300);
        // LC2.addGradientText(this);
        // LC2.wipePic(this, 'logo',400,400,800);
        // this .ship.body.setRectangle(50, 50);
        // this.ship.body.kinematic = true;
        // this.ship.body.setCollisionGroup(ship_collisiongroup);
        // this.ship.body.collides([asteroids_collisiongroup]);

        // LC2.setData(this,this.dataText, 650, 'LC');
        LC2.camerafadeIn(this, 3000);

        //this.physics.add.collider(this.ship, this.group);


        // var wizball = this.physics.add.staticImage(0, 0, 'wizball').setCircle(45);

        var balls = this.physics.add.group({
            defaultKey: 'ball',
            bounceX: 1,
            bounceY: 1
        });
        this.tilesetutils.createColliderObject(this, this.ship, balls);
        // LC2.easeInOutTween(this, this.ship, 'Cubic.easeInOut', 2000, 0.2, 0.2, 1000, -1, true);
        // LC2.easeInOutTween(this, this.ship,   'Cubic.easeInOut', 2010,+0.2,+0.2,2000, -1, true);
        const tintedText = this.add.dynamicBitmapText(5, 10, 'ice', 'LETZTECHANCE.ORG', 64);
        tintedText.setDisplayCallback(this.textCallback);
        LC2.addNewEmitter(this, tintedText);

        // const card = this.add.image(400, 300, 'ball').setInteractive().setScale(10);
        // LC2.addNewEmitter(this, card);

        const tintedSubText = this.add.dynamicBitmapText(10, 900, 'ice', 'by David Honisch', 64);
        tintedSubText.setDisplayCallback(this.textCallback);



        LC2.Storage.initUnset('LC2-highscore', 0);
        var highscore = LC2.Storage.get('LC2-highscore');
        LC2.Storage.initUnset('LC2-Lives', 3);
        var lives = LC2.Storage.get('LC2-Lives');

        this.waitingForSettings = false;

        //var title = this.add.sprite(LC2.world.centerX, LC2.world.centerY - 50, 'title');

        // var buttonLogo = new Button(800, 270, 'logo', this.clickLogo, this, 'static');
        // buttonLogo.setInteractive();
        // buttonLogo.setOrigin(0, 1.0);
        // buttonLogo.x = -buttonLogo.width - 20;
        // buttonLogo.on('pointerover', () => { buttonLogo.setTint(0x44ff44); });
        // buttonLogo.on('pointerout', () => { buttonLogo.setTint(0xffff44); buttonLogo.clearTint(); });
        // this.tweens.add({ targets: buttonLogo, x: 20, duration: 500, ease: 'Back' });


        var title = this.add.sprite(LC2.world.centerX, 100, 'title');
        title.setOrigin(0.5);
        this.tweens.add({ targets: title, angle: title.angle - 2, duration: 1000, ease: 'Sine.easeInOut' });
        this.tweens.add({ targets: title, angle: title.angle + 4, duration: 2000, ease: 'Sine.easeInOut', yoyo: 1, loop: -1, delay: 1000 });
        LC2.getGradientText(this, "PROUD TO PRESENT", 50, 25, 600, '#111111', '#ffffff', '#aaaaaa', '#111111');



        // var buttonEnclave = new Button(20, LC2.world.height - 40, 'logo', this.clickEnclave, this, 'static');
        // this.bullets = this.physics.add.group({
        // 	classType: Bullet,
        // 	maxSize: 30,
        // 	runChildUpdate: true
        // });

        this.input.keyboard.on('keydown', this.handleKey, this);
        var isRedirecting = false;
        // this.textQuery = this.add.text(LC2.world.centerX - 200, LC2.world.centerY - 150, this.q, fontHighscore);
        // this.textQuery.setOrigin(0, 0);

        // if (this.isRedirect(this.q)) {
        //     isRedirecting = true;
        //     this.textQuery.setText('Redirecting:\n' + this.q + '.');

        //     console.log('RUNNING REDIRECTION...');
        //     // this.redirectscene = redirect[0]['scene'];
        //     // textList = [
        //     // 	redirect[0]['scene'],
        //     // 	this.qs
        //     // ];
        //     this.textQuery.setText('Redirecting now to:\n' + this.q + '.');
        //     this.timedEvent = this.time.addEvent({ delay: 100, callback: this.onEvent, callbackScope: this, repeat: this.redirectRepeatcount });
        //     this.timedRedirectEvent = this.time.addEvent({ delay: 10000, callback: this.onRedirectEvent, callbackScope: this, repeat: 0 });
        // }
        // this.dynamic = LC2.createRetroFont(this, "Welcome to LETZTECHANCE.ORG - LC...", 100, 400);
        //var model = new ConfigModel();
        // var menu = getMainMenu(this, new ConfigModel().model().mainMenu, 'menu', 0, 200, 0, 0, 280, 350, false, true);
        //var menu = getMainMenu(this, [LC2ConfigModel.mainMenu[0]], 'menu', 10, 100, 0, 20, 250, 350, false, true, 1, 0, 1, 0);

        var gamemenu = getMainMenu(this, LC2ConfigModel.gameMenu, 'menu', 10, 80, 0, 20, 350, 350, false, true, 1, 0, 1, 0);


        //
        // createElf(this);

        this.buttonSettings = new Button(40, 80, 'button-settings', this.clickSettings, this);
        //this.buttonSettings.setOrigin(40, 40);
        this.buttonSettings.on('pointerover', () => { this.buttonSettings.setTint(0x44ff44); });
        this.buttonSettings.on('pointerout', () => { this.buttonSettings.setTint(0xffff44); this.buttonSettings.clearTint(); });
        this.buttonSettings.y = -this.buttonSettings.height + 20;
        this.tweens.add({ targets: this.buttonSettings, y: 40, x:40, duration: 500, ease: 'Back' });


        this.buttonStart = new Button(LC2.world.width - 20, LC2.world.height - 20, 'button-start', this.clickStart, this);
        this.buttonStart.setOrigin(1, 1);


        var textHighscore = this.add.text(LC2.world.width - 30, 10, LC2.text['menu-highscore'] + highscore, fontHighscore);
        textHighscore.setOrigin(1, 0);
        var textHighscore = this.add.text(LC2.world.width - 30, 30, LC2.text['menu-lives'] + lives, fontHighscore);
        textHighscore.setOrigin(1, 0);



        this.buttonStart.x = LC2.world.width + this.buttonStart.width + 20;
        this.tweens.add({ targets: this.buttonStart, x: LC2.world.width - 20, duration: 500, ease: 'Back' });
        this.buttonStart.setInteractive();
        this.buttonStart.on('pointerover', () => { this.buttonStart.setTint(0x44ff44); });
        this.buttonStart.on('pointerout', () => { this.buttonStart.setTint(0xffff44); this.buttonStart.clearTint(); });




        
        textHighscore.y = -textHighscore.height - 30;
        this.tweens.add({ targets: textHighscore, y: 40, duration: 500, delay: 100, ease: 'Back' });

        this.cameras.main.fadeIn(250);

        if (!this.bgFilesLoaded) {
            this.time.addEvent({
                delay: 500,
                callback: function () {
                    this.startPreloadInTheBackground();
                },
                callbackScope: this
            }, this);
        }
        // if (this.q !== undefined && this.q.length >= 3) {
        //     isRedirecting = true;
        //     this.textQuery = this.add.text(LC2.world.centerX - 200, LC2.world.centerY - 50, this.q, fontHighscore);
        //     this.textQuery.setOrigin(0, 0);
        //     this.tweens.add({ targets: this.textQuery, angle: this.textQuery.angle - 2, duration: 1000, ease: 'Sine.easeInOut' });
        //     this.tweens.add({ targets: this.textQuery, angle: this.textQuery.angle + 4, duration: 2000, ease: 'Sine.easeInOut', yoyo: 1, loop: -1, delay: 1000 });
        //     this.textQuery.setText('Redirecting:\n' + this.q + '.');
        //     console.log('RUNNING REDIRECTION...');
        //     // this.redirectscene = redirect[0]['scene'];
        //     this.textQuery.setText('Redirecting now to:\n' + this.q + '.');
        //     this.timedEvent = this.time.addEvent({ delay: 100, callback: this.onEvent, callbackScope: this, repeat: this.redirectRepeatcount });
        //     this.timedRedirectEvent = this.time.addEvent({ delay: 10000, callback: this.onRedirectEvent, callbackScope: this, repeat: 0 });
        // }

        // this.isStartFollow = true;
        // if (this.isStartFollow) {
        // 	this.cameras.main.startFollow(this.ship);
        // 		this.cameras.main.followOffset.set(-20, 0);
        // }


    }

    handleKey(e) {
        switch (e.code) {
            case 'KeyS':
                {
                    this.clickSettings();
                    break;
                }
            case 'Enter':
                {
                    this.clickStart();
                    break;
                }
            default:
                { }
        }
    }
    showreleaseChunks(game) {
        var graphics = game.add.graphics();
        //graphics.fillStyle(0x000044);
        //graphics.fillRect(0, 140, 800, 460);
        game.physics.world.setBounds(0, 0, 960, 600);
        game.spriteBounds = Phaser.Geom.Rectangle.Inflate(Phaser.Geom.Rectangle.Clone(game.physics.world.bounds), -10, -200);
        game.spriteBounds.y -= 100;

        game.group = game.physics.add.group();
        game.group.runChildUpdate = false;

        //  Create 10,000 bodies at a rate of 100 bodies per 500ms
        game.time.addEvent({ delay: 500, callback: this.releaseChunks, callbackScope: game, repeat: (1000 / 100) - 1 });

        // cursors = game.input.keyboard.createCursorKeys();
        // player = game.physics.add.image(400, 100, 'crate');
        // player.setImmovable();
        // player.setCollideWorldBounds(true);

        // game.physics.add.collider(player, group);

        // text = game.add.text(10, 10, 'Total: 0', { font: '16px Courier', fill: '#ffffff' });
    }
    releaseChunks() {
        for (var i = 0; i < 20; i++) {
            var pos = Phaser.Geom.Rectangle.Random(this.spriteBounds);
            var block = this.group.create(pos.x, pos.y, 'rain');
            block.setBounce(1);
            block.setCollideWorldBounds(true);
            block.setVelocity(Phaser.Math.Between(-20, 20), Phaser.Math.Between(90, -20));
            block.setMaxVelocity(30);
            block.setBlendMode(1);
        }

        // text.setText('Total: ' + group.getLength());
    }
    clickLogo() {
        LC2.Sfx.play('click');
        window.top.location.href = 'https://www.letztechance.org/';
    }
    clickSettings() {
        // if (this.bgFilesLoaded) {
            LC2.Sfx.play('click');
            if (this.loadImage) {
                this.loadImage.destroy();
            }
            LC2.fadeOutScene('Settings', this);
        // } else {
        //     var animationFrames = this.anims.generateFrameNumbers('loader');
        //     animationFrames.pop();
        //     this.waitingForSettings = true;
        //     this.buttonSettings.setAlpha(0.1);
        //     var loadAnimation = this.anims.create({
        //         key: 'loading',
        //         frames: animationFrames,
        //         frameRate: 12,
        //         repeat: -1
        //     });
        //     this.loadImage = this.add.sprite(30, 30, 'loader').setOrigin(0, 0).setScale(1.25);
        //     this.loadImage.play('loading');
        // }
    }
    clickStart() {
        if (this.bgFilesLoaded) {
            LC2.Sfx.play('click');
            if (this.loadImage) {
                this.loadImage.destroy();
            }
            LC2.fadeOutScene('Story', this);
        } else {
            var animationFrames = this.anims.generateFrameNumbers('loader');
            animationFrames.pop();
            this.waitingForStart = true;
            this.buttonStart.setAlpha(0.1);
            var loadAnimation = this.anims.create({
                key: 'loading',
                frames: animationFrames,
                frameRate: 12,
                repeat: -1
            });
            this.loadImage = this.add.sprite(LC2.world.width - 85, LC2.world.height - 85, 'loader').setOrigin(1, 1).setScale(1.25);
            this.loadImage.play('loading');
        }
    }
    textCallback(data) {
        var i = 20;
        var hsv = Phaser.Display.Color.HSVColorWheel();
        data.tint.topLeft = hsv[Math.floor(i)].color;
        data.tint.topRight = hsv[359 - Math.floor(i)].color;
        data.tint.bottomLeft = hsv[359 - Math.floor(i)].color;
        data.tint.bottomRight = hsv[Math.floor(i)].color;
        i += 0.05;
        if (i >= hsv.length) {
            i = 0;
        }

        return data;
    }
    startPreloadInTheBackground() {
        console.log('[LC2] Starting background loading...');
        this.load.image('assets/img/clickme');
        this.load.once('filecomplete', this.addFiles, this);
        this.load.start();
    }
    addFiles() {
        var resources = {
            'image': [
                ['clickme', 'assets/img/clickme.png'],
                ['goldrunner', 'assets/img/gr.png'],
                ['overlay', 'assets/img/overlay.png'],
                ['button-beer', 'assets/img/button-beer.png'],
                ['banner-beer', 'assets/img/banner-beer.png'],
                ['particle', 'assets/img/particle.png']
            ],
            'spritesheet': [
                ['invader', 'assets/img/invader1.png', { frameWidth: 32, frameHeight: 32 }],
                ['boom', 'assets/img/explosion.png', { frameWidth: 64, frameHeight: 64, endFrame: 23 }],

                ['button-continue', 'assets/img/button-continue.png', { frameWidth: 180, frameHeight: 180 }],
                ['button-mainmenu', 'assets/img/button-mainmenu.png', { frameWidth: 180, frameHeight: 180 }],
                ['button-restart', 'assets/img/button-tryagain.png', { frameWidth: 180, frameHeight: 180 }],
                ['button-achievements', 'assets/img/button-achievements.png', { frameWidth: 110, frameHeight: 110 }],
                ['button-pause', 'assets/img/button-pause.png', { frameWidth: 80, frameHeight: 80 }],
                ['button-credits', 'assets/img/button-credits.png', { frameWidth: 80, frameHeight: 80 }],

                ['button-fullscreen-on', 'assets/img/button-fullscreen-on.png', { frameWidth: 80, frameHeight: 80 }],
                ['button-fullscreen-off', 'assets/img/button-fullscreen-off.png', { frameWidth: 80, frameHeight: 80 }],

                ['button-sound-on', 'assets/img/button-sound-on.png', { frameWidth: 80, frameHeight: 80 }],
                ['button-sound-off', 'assets/img/button-sound-off.png', { frameWidth: 80, frameHeight: 80 }],
                ['button-music-on', 'assets/img/button-music-on.png', { frameWidth: 80, frameHeight: 80 }],
                ['button-music-off', 'assets/img/button-music-off.png', { frameWidth: 80, frameHeight: 80 }],
                ['button-back', 'assets/img/button-back.png', { frameWidth: 70, frameHeight: 70 }]
            ],
            'audio': [
                ['sound-click', ['assets/sfx/audio-button.m4a', 'assets/sfx/audio-button.mp3', 'assets/sfx/audio-button.ogg']],
                ['sound-points', ['assets/sfx/points.mp3']],
                ['sound-shoot', ['assets/sfx/shoot.mp3']],
                ['sound-explodedbl', ['assets/sfx/explodedbl.mp3']],
                // ['music-theme', ['assets/sfx/music-bitsnbites-liver.m4a', 'assets/sfx/music-bitsnbites-liver.mp3', 'assets/sfx/music-bitsnbites-liver.ogg']]
                ['music-theme', ['assets/sfx/title.mp3']]
            ]
        };
        for (var method in resources) {
            resources[method].forEach(function (args) {
                var loader = this.load[method];
                loader && loader.apply(this.load, args);
            }, this);
        };
        this.load.on('complete', function () {
            console.log('[LC2] All files loaded in the background.');
            this.bgFilesLoaded = true;
            LC2.Sfx.manage('music', 'init', this);
            LC2.Sfx.manage('sound', 'init', this);
            if (this.waitingForSettings) {
                this.clickSettings();
            }
            if (this.waitingForStart) {
                this.clickStart();
            }
        }, this);
    }


    //events
    onEvent() {

        this.textQuery.setText('Redirect to:\n' + this.q + '\nin ' + this.progressCount + '/' + this.redirectRepeatcount + '%.');
        this.progressCount++;
    }
    onRedirectEvent() {
        this.textQuery.setText('Redirect\nrunning now to:\n' + this.q + '.');
        this.time.addEvent({ delay: 30, callback: this.onRedirectScene, callbackScope: this, repeat: 1000 });
    }
    onRedirectScene() {
        // this.bmptext.setText('Redirecting now to:\n' + this.qs + '.\nBye and have fun.');
        this.textQuery.setText('Redirecting scene\nor\nurl running now to:\n' + this.q + '.');
        this.time.addEvent({ delay: 3000, callback: this.onRedirectSceneFinally, callbackScope: this, repeat: 0 });
    }
    onRedirectSceneFinally() {
        if (this.music !== undefined) this.music.stop();
        if (this.sidPlayer !== undefined) this.sidPlayer.stop();
        // this.bmptext.setText('Bye and have fun.');
        this.textQuery.setText('Bye and have fun.\nRedirecting now to:\n' + this.q + '.');
        this.scene.start(this.redirectscene);
    }
    fireBullet(time) {
        if (this.bullets !== undefined) {
            var bullet = this.bullets.get();
            if (bullet) {
                bullet.fire(this.ship);
                this.lastFired = time + 100;
            }
        }
    }
    //111
    fire() {

        var asteroid = asteroids.getFirstExists(false);

        if (asteroid) {
            asteroid.exists = true;
            asteroid.reset(game.world.randomX, 0);
            asteroid.body.velocity.y = game.rnd.integerInRange(200, 500);
        }

    }
    contactHandler(body, shape1, shape2, equation) {


        //get the velocity of asteroid at point of contact
        var v = body.velocity.y;

        //and the asteroid's mass
        var m = body.mass;

        //calculate momentum
        var momentum = m * v;

        //momentum affects ship damage (reduced by factor of 10)
        ship.damage(momentum * 0.1);

        var report = "Momentum of impact: " + momentum + "\n";
        report += (ship.alive ? "Ship health: " + parseInt(ship.health) + "%" : "SHIP DESTROYED") + "\n";
        report += "-\n" + output.text;
        output.text = report;


    }

    collisionHandler(body1, body2, shape1, shape2) {

        //asteroids are destroyed on collision
        body1.sprite.kill();

        if (!ship.alive)
            ship.destroy();

    }
    //eof    
    update(time, delta) {
        LC2.addLightsUpdate(this);
        // if (LC2.checkOverlap(this.ship, this.exit)) {
        // 	// console.log("overlapping...");
        // 	if (this.isExitReached == false) {
        // 		this.load.tilemapCSV('levelcsv', 'assets/tilemaps/csv/level' + (this.level + 1) + '.csv');
        // 		LC2.getCameraFadeOutComplete(this, () => this.scene.start("Game"));
        // 		LC2.getCameraFadeOut(this, {});
        // 	}
        // 	this.isExitReached = true;
        // }
        // else {
        // 	// console.log("not overlapping...");

        // }
        if (this.dynamicscroller !== undefined) {
            LC2.updateHVScroller(this, this.dynamicscroller, this.dynamiccontent);
        }
        if (this.scrollers !== undefined) {
            LC2.updateScrollerTextGroup(this, this.scrollers, delta);
        }
        LC2.updateOldScroller(this, this.storyscroller, delta);
        // LC2.twistedTextUpdate(this, this.letters,this.structure, this.posy,this.blitter,  this.counter, this.text_num, this.scrfirst, appConfig["data"]["scroller"]["data"]["text"]);
        this.physics.world.wrap(this.ship, 32);
        if (this.bgf !== undefined) {
            this.bgf.tilePositionY += +1;
        }
        if (this.bgas !== undefined) {
            this.bgas.tilePositionX += +0.1;
        }

        // this.physics.world.wrap(this.ship, 32);
        //retrofont
        if (this.dynamicscroller != null && this.dynamicscroller != undefined) {
            this.dynamicscroller.scrollX += 0.15 * delta;
            if (this.dynamicscroller.scrollX > 3000) {
                this.dynamicscroller.scrollX = 0;
            }
        }
        if (this.controls !== undefined) {
            this.controls.update(delta);
        }
        // LC2.setCursorControls(this, this.ship, this.cursorKeys);
        if (this.input.keyboard.checkDown(this.cursorKeys.left, 100)) {
            const tile = this.layer.getTileAtWorldXY(this.ship.x - 32, this.ship.y, true);

            if (tile.index === 2) {
                //  Blocked, we can't move
            }
            else {
                this.ship.x -= 32;
                this.ship.angle = 180;
            }
        }
        else if (this.input.keyboard.checkDown(this.cursorKeys.right, 100)) {
            const tile = this.layer.getTileAtWorldXY(this.ship.x + 32, this.ship.y, true);

            if (tile.index === 2) {
                //  Blocked, we can't move
            }
            else {
                this.ship.x += 32;
                this.ship.angle = 0;
            }
        }
        else if (this.input.keyboard.checkDown(this.cursorKeys.up, 100)) {
            const tile = this.layer.getTileAtWorldXY(this.ship.x, this.ship.y - 32, true);
            if (tile.index === 2) {
                //  Blocked, we can't move
            }
            else {
                this.ship.y -= 32;
                this.ship.angle = -90;
            }
        }
        else if (this.input.keyboard.checkDown(this.cursorKeys.down, 100)) {
            const tile = this.layer.getTileAtWorldXY(this.ship.x, this.ship.y + 32, true);
            if (tile.index === 2) {
                //  Blocked, we can't move
            }
            else {
                this.ship.y += 32;
                this.ship.angle = 90;
            }
        }

        this.light.x = this.ship.x;
        this.light.y = this.ship.y;


        this.lights.lights.forEach(function (currLight, index) {
            if (this.light !== currLight) {
                currLight.x = 400 + Math.sin(this.offsets[index]) * 200;
                this.offsets[index] += 0.02;
            }
        }, this);
    }

}