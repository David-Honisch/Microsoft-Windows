class Game extends Phaser.Scene {
    isExitReached = false;
    isActiveDOM = false;
    level = {
        maxLevel: appConfig.maxlevel,
        isLastLevel: appConfig.isLastLevel,
        level: appConfig.startlevel
    }
    playerConfig = {
        maxTime: appConfig.maxtime,
        lives: appConfig.shiplives,
        hits: appConfig.shiphits,
        rate: appConfig.shiprate
    }
    light;
    cursorKeys;
    ship;
    enemies;
    invaders;
    invaderships;
    bullets;

    lastFired = 0;
    fire;
    xparticles;
    xparticlesboom;
    xparticlesasteroid;
    spaceOuter;
    spaceInner;
    screenGameoverScore;




    constructor() {
        var sceneConfig = {
            type: Phaser.AUTO,
            parent: 'content',
            key: 'Game',
            isAutoRedirected: false,
            isActiveDOM: appConfig.isActiveDOM,
            pixelArt: true,
            pipeline: { LazersPostFX },
            dom: {
                createContainer: true
            },
            input: {
                gamepad: true
            },

            scale: {
                mode: Phaser.Scale.FIT,
                parent: 'content',
                autoCenter: Phaser.Scale.CENTER_BOTH,
                width: 1900,
                height: 1080
            },
            physics: {
                default: 'arcade',
                arcade: {
                    gravity: { y: 0.0 },
                    fps: 60,
                    debug: false
                }
            },
            scene: {
                init: "init",
                preload: "preload",
                create: "create",
                update: "update",
                extend: {
                    checkBulletVsEnemy: "checkBulletVsEnemy",
                    launchEnemy: "launchEnemy",
                    hitShip: "hitShip",
                    hitEnemy: "hitEnemy"
                }
            }
        };
        super(sceneConfig);
    }
    init(props) {
        this.isExitReached = false;
        const { level = 0 } = props;
        console.log("Init Level:" + level);
        this.level.level = level;
        console.log("Inited Level:" + this.level.level);
        LC2.dataText.level = level;
        //this.level.level = level;		
        // this.create();
        this.load.reset;
        this.preload();
        this.load.start();
        console.log("Init Level:" + this.level.level + " done.");
    }
    preload() {
        console.log("Level:" + this.level.level + " preloading...");
        if (this.isActiveDOM) {
            console.log("isActiveDOM preload");
            this.load.htmlTexture('gameHTML', 'assets/html/game.php', 640, 960);
            this.load.html('nameForm', '/LC2Intro.v.4.0/assets/html/loginform.html');
            console.log("isActiveDOM preload done.");
        }
        this.load.tilemapCSV('levelstart', 'assets/tilemaps/csv/levelstart.csv');

        // this.load.tilemapCSV('level'+this.level.level, 'assets/tilemaps/csv/level'+this.level.level+'.csv');
        this.load.tilemapCSV('level1', 'assets/tilemaps/csv/level0.csv');
        this.load.tilemapCSV('level1', 'assets/tilemaps/csv/level1.csv');
        this.load.tilemapCSV('level2', 'assets/tilemaps/csv/level2.csv');
        this.load.tilemapCSV('level3', 'assets/tilemaps/csv/level3.csv');
        this.load.tilemapCSV('level4', 'assets/tilemaps/csv/level4.csv');
        this.load.tilemapCSV('level5', 'assets/tilemaps/csv/level5.csv');
        this.load.tilemapCSV('level6', 'assets/tilemaps/csv/level6.csv');
        this.load.tilemapCSV('level7', 'assets/tilemaps/csv/level7.csv');
        this.load.tilemapCSV('level8', 'assets/tilemaps/csv/level8.csv');
        this.load.tilemapCSV('level9', 'assets/tilemaps/csv/level9.csv');

        this.load.tilemapCSV('bglevel0', 'assets/tilemaps/csv/bglevel0.csv');
        this.load.tilemapCSV('bglevel1', 'assets/tilemaps/csv/bglevel1.csv');
        this.load.tilemapCSV('bglevel2', 'assets/tilemaps/csv/bglevel2.csv');
        this.load.tilemapCSV('bglevel3', 'assets/tilemaps/csv/bglevel3.csv');
        this.load.tilemapCSV('bglevel4', 'assets/tilemaps/csv/bglevel4.csv');
        this.load.tilemapCSV('bglevel5', 'assets/tilemaps/csv/bglevel5.csv');
        this.load.tilemapCSV('bglevel6', 'assets/tilemaps/csv/bglevel6.csv');
        this.load.tilemapCSV('bglevel7', 'assets/tilemaps/csv/bglevel7.csv');
        this.load.tilemapCSV('bglevel8', 'assets/tilemaps/csv/bglevel8.csv');
        this.load.tilemapCSV('bglevel9', 'assets/tilemaps/csv/bglevel9.csv');

        this.load.tilemapCSV('maplevel' + this.level.level, 'assets/tilemaps/csv/levels/level' + this.level.level + '.csv');

        this.load.atlas('flares', 'assets/img/flares.png', 'assets/img/flares.json');
    }
    create() {
        console.log("Level:" + this.level.level + " creating...");

        this.light = this.lights.addLight(0, 0, 300).setScrollFactor(0.0);
        this.lights.enable().setAmbientColor(0x555555);
        this.lights.addLight(0, 100, 100).setColor(0xff0000).setIntensity(3.0);
        this.lights.addLight(0, 200, 100).setColor(0x00ff00).setIntensity(3.0);
        this.lights.addLight(0, 300, 100).setColor(0x0000ff).setIntensity(3.0);
        this.lights.addLight(0, 400, 100).setColor(0xffff00).setIntensity(3.0);
        this.lights.addLight(0, 600, 100).setColor(0xffff00).setIntensity(3.0);
        this.lights.addLight(0, 600, 900).setColor(0x0000ff).setIntensity(3.0);
        this.lights.addLight(0, 600, 800).setColor(0xffff00).setIntensity(3.0);
        this.offsets = [0.1, 0.3, 0.5, 0.7];

        this.cameras.main.setBounds(0, 0, 1920 * 2, 1080 * 2);
        this.physics.world.setBounds(0, 0, 1920 * 2, 1080 * 2);
        this.tilesetutils = new Tilesetutils();
        this.spaceOuter = new Phaser.Geom.Rectangle(-200, -200, 640, 960);
        this.spaceInner = new Phaser.Geom.Rectangle(0, 0, 800, 600);
        this.cursorKeys = this.input.keyboard.createCursorKeys();



        this.textures.addSpriteSheetFromAtlas('mine-sheet', { atlas: 'space', frame: 'mine', frameWidth: 64 });
        this.anims.create({ key: 'mine-anim', frames: this.anims.generateFrameNumbers('mine-sheet', { start: 0, end: 15 }), frameRate: 20, repeat: -1 });

        this.textures.addSpriteSheetFromAtlas('invader-sheet', { atlas: 'space', frame: 'asteroid', frameWidth: 96 });
        this.anims.create({ key: 'invader-anim', frames: this.anims.generateFrameNumbers('invader-sheet', { start: 0, end: 24 }), frameRate: 20, repeat: -1 });

        this.textures.addSpriteSheetFromAtlas('asteroid-sheet', { atlas: 'space', frame: 'asteroid2', frameWidth: 96 });
        this.anims.create({ key: 'asteroid-anim', frames: this.anims.generateFrameNumbers('asteroid-sheet', { start: 0, end: 24 }), frameRate: 20, repeat: -1 });

        this.textures.addSpriteSheetFromAtlas('invaderships-sheet', { atlas: 'space', frame: 'asteroid3', frameWidth: 96 });
        this.anims.create({ key: 'invaderships-anim', frames: this.anims.generateFrameNumbers('invaderships-sheet', { start: 0, end: 24 }), frameRate: 20, repeat: -1 });

        var shader = createShader(this, 640, 480);
        shader.setAlpha(0.5);
        // this.add.sprite(0, 0, 'bg').setOrigin(0, 0).setAlpha(0.9);
        //this.bg = this.add.tileSprite(0, 0, 0, 0, "bg").setOrigin(0).setScale(1).setSize(640, 960).setAlpha(0.9);
        this.bg = this.add.tileSprite(0, 0, 0, 0, "bg").setOrigin(0).setScale(1).setSize(1920, 1080).setAlpha(0.9).setScrollFactor(0);
        this.bgf = this.add.tileSprite(0, 0, 0, 0, "bgf").setOrigin(0).setScale(1).setSize(1920, 1080).setAlpha(0.9).setScrollFactor(0);
        this.bgas = this.add.tileSprite(0, 0, 0, 0, "bgas").setOrigin(0).setScale(1).setSize(1920, 1080).setAlpha(0.9).setScrollFactor(0);

        const clouds = this.add.tileSprite(400, 300, 800, 600, 'seaclouds');
        this.tweens.add({
            targets: clouds,
            tilePositionX: 800,
            duration: 9000,
            ease: 'linear',
            repeat: -1,
        });
        const fish1 = this.add.image(0, 700, 'fish01');
        const fish2 = this.add.image(800, 700, 'fish02');
        const waves = this.add.tileSprite(400, 800, 800, 960, 'waves');
        waves.setAlpha(0.5);
        LC2.getTweenFlip(this, clouds, waves, fish1, fish2);
        this.tweens.add({
            targets: waves,
            tilePositionY: 100,
            duration: 2000,
            ease: 'sine.inout',
            yoyo: true,
            repeat: -1,
            onUpdate: () => {
                waves.tilePositionX += 4
            }
        });

        LC2.createFireEmitter(this, 10, 900);
        // createElf(this);
        
        var bprop = { key: 'levelstart', tileWidth: 64, tileHeight: 64 };
        var bmap = this.tilesetutils.makeCSVTileMap(this, bprop);
        var blayer = this.tilesetutils.makeCSVLayer(this, bmap, 'desert', 0, 0, 64, 64);
        LC2.addLights(this, blayer);
        //this.layer = this.tilesetutils.createLayer(this);
        // var prop = { key: 'level' + this.level.level, tileWidth: 16, tileHeight: 16 };
        // var bmap2 = this.tilesetutils.makeCSVTileMap(this, prop);
        // var blayer2 = this.tilesetutils.makeCSVLayer(this, bmap2, 'tilesmap', 0, 0, 54, 83);
        // var planet = this.add.image(200, 200, 'purple-planet').setOrigin(0).setScale(0.2);
        // LC2.getTween(this, planet,'Quad.easeInOut','Cubic.easeInOut', 4000,0.5,0.5,-1, true);
        var sun = this.add.image(300, 300, 'sun').setScale(0.1);
        LC2.getTween(this, sun, 'Quad.easeInOut', 'Cubic.easeInOut', 10000, 3.0, 3.0, -1, true);

        LC2.addGolem(this, 'golem1', 'golem2', 'icestar',400,300,400,230);

        const map = this.make.tilemap({ key: 'maplevel' + this.level.level, tileWidth: 32, tileHeight: 32 });
        const tileset = map.addTilesetImage('tiles', null, 32, 32, 1, 2);
        this.layer = map.createLayer(0, tileset, 0, 0).setPipeline('Light2D');
        //LC2.addLights(this, this.layer);

        if (this.isActiveDOM) {
            console.log("isActiveDOM running...");
            try {
                // var html = this.add.image(3, 500, 'gameHTML').setOrigin(0).setAlpha(0.5);
                // html.on('click', function (event) {
                //     html.setAlpha(1.0);
                // });
                // html.on('pointerdown', pointer => {
                //     // console.log("pointerdown");
                //     html.setAlpha(1.0);
                // });
                // html.on('pointerover', pointer => {
                //     // console.log("pointerover");
                //     html.setAlpha(1.0);
                // });
                // html.on('pointerout', pointer => {
                //     // console.log("pointerout");
                //     html.setAlpha(0.5);
                // });
                // LC2.addHTMLObject(this, 'nameForm', 200, 1200, 800, 600);
                // var titleHTML = LC2.createHTMLDIV(this, 'titleHTML');
                // titleHTML.setOrigin(0).setAlpha(0.5);
                var h1 = { title: 'LETZTECHANCE', style: 'chrome120', x: 300, y: 100 };
                var h2 = { title: 'Golden Labyrinth', style: 'dreams', x: 370, y: 18 };
                var h3 = { title: 'David Honisch', style: 'chrome36', x: 110, y: 160 };
                var tw = { y: 200, duration: 3000, loop: -1, ease: 'Sine.easeInOut', yoyo: true };
                getDOMTween(this, h1, h2, h3, tw);
                var style = {
                    // 'background-color': 'lime',
                    'width': '220px',
                    'height': '50px',
                    'font': '12px Arial',
                    'font-weight': 'bold'
                };
                var element = this.add.dom(600, 940, 'div', style, 'Done by David Honisch');
            } catch (error) {
                console.error(error);
            }

        }



        


        

        this.stateStatus = null;
        this._score = 0;
        this._time = this.playerConfig.maxTime;
        this._gamePaused = false;
        this._runOnce = false;



        this.buttonDummy = new Button(LC2.world.centerX, LC2.world.centerY, 'spaceship', this.addPoints, this, 'static');
        this.buttonDummy.setOrigin(0.5, 0.5);
        this.buttonDummy.setAlpha(0);
        this.buttonDummy.setScale(0.1);
        this.tweens.add({ targets: this.buttonDummy, alpha: 1, duration: 500, ease: 'Linear' });
        this.tweens.add({ targets: this.buttonDummy, scale: 1, duration: 500, ease: 'Back' });
        LC2.getTween(this, this.buttonDummy, 'Quad.easeInOut', 'Cubic.easeInOut', 10000, 2.0, 2.0, -1, true);

        this.initUI();
        this.currentTimer = this.time.addEvent({
            delay: 1000,
            callback: function () {
                this._time--;
                this.textTime.setText(LC2.text['gameplay-timeleft'] + this._time);
                if (!this._time) {
                    this._runOnce = false;
                    this.stateStatus = 'gameover';
                }
            },
            callbackScope: this,
            loop: true
        });

        //this.ship = this.physics.add.image(0, Math.round(height / 2),'goldrunner').setDepth(2);
        //this.ship = this.add.image(100, Math.round(this.height / 2),'goldrunner');//.setDepth(2);
        this.ship = this.physics.add.image(Math.round(300), Math.round(900), 'goldrunner').setDepth(2);//.setDepth(2);
        this.ship.rotation = 0.0;
        this.ship.setCollideWorldBounds(true);

        this.ship.setDamping(true);
        this.ship.setDrag(0.95);
        this.ship.setMaxVelocity(400);
        LC2.addGlowEmitter(this, this.ship, 0xffffff, 32, 2);

        //LC2.addNewEmitter(this, this.ship);
        //LC2.addLights(this, this.ship);
        // this.input.on('pointerdown', pointer => {
        //     LC2.addNewEmitterClick(this, 'flares', pointer.x, pointer.y);            
        // });

        // this.cameras.main.setBounds(0, 0, bmap2.widthInPixels, bmap2.heightInPixels);
        // this.physics.add.collider(this, this.ship, blayer);
        // this.physics.add.collider(this, this.ship, blayer2);

        //this.xparticles = LC2.createEmitter(this, 'explode');
        this.xparticles = LC2.createEmitter(this, 'star3', 0.4, 0, 1000);
        this.xparticlesboom = LC2.createEmitter(this, 'boom', 0.4, 0, 1000);
        this.xparticlesasteroid = LC2.createEmitter(this, 'explode', 1.0, 0, 1000);



        this.input.keyboard.on('keydown', this.handleKey, this);
        this.cameras.main.fadeIn(250);
        this.stateStatus = 'playing';
        this.enemies = this.physics.add.group({
            classType: Enemy,
            maxSize: 10,
            runChildUpdate: true
        });

        this.invaders = this.physics.add.group({
            classType: Invader,
            maxSize: 2,
            runChildUpdate: true
        });

        this.asteroids = this.physics.add.group({
            classType: EnemyAsteroid,
            maxSize: 2,
            runChildUpdate: true
        });

        this.invaderships = this.physics.add.group({
            classType: InvaderShips,
            maxSize: 2,
            runChildUpdate: true
        });

        this.bullets = new Bullets(this);
        // new Invaders().createInvaders(this, this.ship, "invader", "move", "invader", "explode", "boom", 640, 760);

        this.physics.add.overlap(this.bullets, this.enemies, this.hitEnemy, this.checkBulletVsEnemy, this);
        this.physics.add.overlap(this.bullets, this.invaders, this.hitEnemy, this.checkBulletVsEnemy, this);
        this.physics.add.overlap(this.bullets, this.asteroids, this.hitEnemy, this.checkBulletVsEnemy, this);
        this.physics.add.overlap(this.bullets, this.invaderships, this.hitEnemy, this.checkBulletVsEnemy, this);

        for (var i = 0; i < 6; i++) {
            this.launchEnemy();
        }

        this.exit = this.add.image(LC2.Level[this.level.level].exit.x, LC2.Level[this.level.level].exit.y, 'exit').setOrigin(0).setScale(0.5);
        LC2.addGlowEmitter(this, this.exit, 0x00ff00, 32, 2);
        var exitText = this.add.text(LC2.Level[this.level.level].exit.x + 50, LC2.Level[this.level.level].exit.y + 50, LC2.Level[this.level.level].text.exit, { color: '#000000' }).setFontSize(24);


        this.input.on('pointermove', (pointer) => {

            this.ship.x = pointer.x;

        });

        this.input.on('pointerdown', (pointer) => {
            LC2.Sfx.play('shoot');
            this.bullets.fireBullet(this.ship, this.ship.x, this.ship.y);

        });

        this.isStartFollow = true;
        if (this.isStartFollow && this.level > 2) {
            this.cameras.main.startFollow(this.ship);
            this.cameras.main.followOffset.set(-20, 0);
        }
    }
    update(time, delta) {
        LC2.addLightsUpdate(this);
        if (LC2.checkOverlap(this.ship, this.exit)) {
            console.log("overlapping")
            if (this.isExitReached == false) {
                console.log("loaded level" + this.level.level);
                if (this.level.level <= this.level.maxLevel) {
                    //this.level.level = +1;
                    console.log("loading level" + this.level.level + 1);
                    LC2.getCameraFadeOutComplete(this, () => this.scene.restart({ level: +this.level.level + 1 }));
                }
                else {
                    LC2.getCameraFadeOutComplete(this, () => this.scene.start("Game"));
                }
                LC2.getCameraFadeOut(this, {});
                console.log("load new level done.");
            }
            this.isExitReached = true;
        }
        // this.bg.tilePositionY += +1;
        this.bgf.tilePositionY += +0.3;
        this.bgas.tilePositionX += +0.9;
        if (this.stateStatus == 'gameover') {
            this.enemies.remove;
            this.invaders.remove;
            this.asteroids.remove;
        }
        LC2.setCursorControls(this, this.ship, this.layer, this.cursorKeys);
        LC2.setFireControls(this, this.ship, this.bullets);
        switch (this.stateStatus) {
            case 'paused':
                {
                    if (!this._runOnce) {
                        this.statePaused();
                        this._runOnce = true;
                    }
                    break;
                }
            case 'gameover':
                {
                    if (!this._runOnce) {
                        this.stateGameover();
                        this._runOnce = true;
                    }
                    break;
                }
            case 'playing':
                {
                    this.statePlaying();
                }
            default:
                { }
        }


    }
    launchEnemy() {
        if (this.stateStatus == 'gameover')
            return;
        var a = this.invaders.get();
        if (a) {
            a.launch();
        }
        var b = this.enemies.get();
        if (b) {
            b.launch();
        }
        var c = this.asteroids.get();
        if (c) {
            c.launch();
        }
        var d = this.invaderships.get();
        if (d) {
            d.launch();
        }
    }

    checkBulletVsEnemy(bullet, enemy) {
        return (bullet.active && enemy.active);
    }

    hitShip(ship, enemy) {
    }

    hitEnemy(bullet, enemy) {
        var Enemy = JSON.parse(JSON.stringify(enemy));
        if (this.xparticles !== undefined && Enemy.textureKey == "invader-sheet") {
            this.xparticles.emitParticleAt(enemy.x, enemy.y);
        }
        if (this.xparticlesasteroid !== undefined && Enemy.textureKey == "mine-sheet") {
            this.xparticlesasteroid.emitParticleAt(enemy.x, enemy.y);
        }

        this.cameras.main.shake(500, 0.01);
        bullet.kill();
        enemy.kill();
        this.addPoints();
        LC2.Sfx.play('explodedbl');
    }
    fireBullet(time) {
        var bullet = this.bullets.get();
        if (bullet) {
            bullet.fire(this.ship, this.ship.x, this.ship.y);
            LC2.Sfx.play('shoot');
            this.lastFired = time + 100;
        }
    }
    handleKey(e) {
        switch (e.code) {
            case 'Enter':
                {
                    this.addPoints();

                    break;
                }
            case 'KeyP':
                {
                    this.managePause();
                    break;
                }
            case 'KeyB':
                {
                    this.stateBack();
                    break;
                }
            case 'KeyT':
                {
                    this.stateRestart();
                    break;
                }
            case 'Space':
                {
                    this.fireBullet(1);
                    break;
                }
            default:
                { }
        }
    }
    managePause() {
        this._gamePaused = !this._gamePaused;
        this.currentTimer.paused = !this.currentTimer.paused;
        LC2.Sfx.play('click');
        if (this._gamePaused) {
            LC2.fadeOutIn(function (self) {
                self.buttonPause.input.enabled = false;
                self.buttonDummy.input.enabled = false;
                self.stateStatus = 'paused';
                self._runOnce = false;
            }, this);
            this.screenPausedBack.x = -this.screenPausedBack.width - 20;
            this.tweens.add({ targets: this.screenPausedBack, x: 100, duration: 500, delay: 250, ease: 'Back' });
            this.screenPausedContinue.x = LC2.world.width + this.screenPausedContinue.width + 20;
            this.tweens.add({ targets: this.screenPausedContinue, x: LC2.world.width - 100, duration: 500, delay: 250, ease: 'Back' });
        } else {
            LC2.fadeOutIn(function (self) {
                self.buttonPause.input.enabled = true;
                self.buttonDummy.input.enabled = true;
                self._stateStatus = 'playing';
                self._runOnce = false;
            }, this);
            this.screenPausedBack.x = 100;
            this.tweens.add({ targets: this.screenPausedBack, x: -this.screenPausedBack.width - 20, duration: 500, ease: 'Back' });
            this.screenPausedContinue.x = LC2.world.width - 100;
            this.tweens.add({ targets: this.screenPausedContinue, x: LC2.world.width + this.screenPausedContinue.width + 20, duration: 500, ease: 'Back' });
        }
    }
    statePlaying() {
        if (this._time === 0) {
            this._runOnce = false;
            this.stateStatus = 'gameover';
        }
    }
    statePaused() {
        this.screenPausedGroup.toggleVisible();
    }
    stateGameover() {
        this.currentTimer.paused = !this.currentTimer.paused;
        LC2.Storage.setHighscore('EPT-highscore', this._score);
        LC2.fadeOutIn(function (self) {
            self.screenGameoverGroup.toggleVisible();
            self.buttonPause.input.enabled = false;
            self.buttonDummy.input.enabled = false;
            self.screenGameoverScore.setText(LC2.text['gameplay-score'] + self._score);
            self.gameoverScoreTween();
        }, this);
        this.screenGameoverBack.x = -this.screenGameoverBack.width - 20;
        this.tweens.add({ targets: this.screenGameoverBack, x: 100, duration: 500, delay: 250, ease: 'Back' });
        this.screenGameoverRestart.x = LC2.world.width + this.screenGameoverRestart.width + 20;
        this.tweens.add({ targets: this.screenGameoverRestart, x: LC2.world.width - 100, duration: 500, delay: 250, ease: 'Back' });
    }
    initUI() {
        this.buttonPause = new Button(20, 20, 'button-pause', this.managePause, this);
        this.buttonPause.setOrigin(0, 0);

        var fontScore = { font: '38px ' + LC2.text['FONT'], fill: '#ffde00', stroke: '#000', strokeThickness: 5 };
        var fontScoreWhite = { font: '38px ' + LC2.text['FONT'], fill: '#000', stroke: '#ffde00', strokeThickness: 5 };
        this.textScore = this.add.text(LC2.world.width - 30, 45, LC2.text['gameplay-score'] + this._score, fontScore);
        this.textScore.setOrigin(1, 0);

        this.textScore.y = -this.textScore.height - 20;
        this.tweens.add({ targets: this.textScore, y: 45, duration: 500, delay: 100, ease: 'Back' });

        this.textTime = this.add.text(30, LC2.world.height - 30, LC2.text['gameplay-timeleft'] + this._time, fontScore);
        this.textTime.setOrigin(0, 1);

        this.textTime.y = LC2.world.height + this.textTime.height + 30;
        this.tweens.add({ targets: this.textTime, y: LC2.world.height - 30, duration: 500, ease: 'Back' });

        this.buttonPause.y = -this.buttonPause.height - 20;
        this.tweens.add({ targets: this.buttonPause, y: 20, duration: 500, ease: 'Back' });

        var fontTitle = { font: '48px ' + LC2.text['FONT'], fill: '#000', stroke: '#ffde00', strokeThickness: 10 };

        this.screenPausedGroup = this.add.group();
        this.screenPausedBg = this.add.sprite(0, 0, 'overlay');
        this.screenPausedBg.setAlpha(0.95);
        this.screenPausedBg.setOrigin(0, 0);
        this.screenPausedText = this.add.text(LC2.world.centerX, 100, LC2.text['gameplay-paused'], fontTitle);
        this.screenPausedText.setOrigin(0.5, 0);
        this.screenPausedBack = new Button(100, LC2.world.height - 100, 'button-mainmenu', this.stateBack, this);
        this.screenPausedBack.setOrigin(0, 1);
        this.screenPausedContinue = new Button(LC2.world.width - 100, LC2.world.height - 100, 'button-continue', this.managePause, this);
        this.screenPausedContinue.setOrigin(1, 1);
        this.screenPausedGroup.add(this.screenPausedBg);
        this.screenPausedGroup.add(this.screenPausedText);
        this.screenPausedGroup.add(this.screenPausedBack);
        this.screenPausedGroup.add(this.screenPausedContinue);
        this.screenPausedGroup.toggleVisible();

        this.screenGameoverGroup = this.add.group();
        this.screenGameoverBg = this.add.sprite(0, 0, 'overlay');
        this.screenGameoverBg.setAlpha(0.95);
        this.screenGameoverBg.setOrigin(0, 0);
        this.screenGameoverText = this.add.text(LC2.world.centerX, 100, LC2.text['gameplay-gameover'], fontTitle);
        this.screenGameoverText.setOrigin(0.5, 0);
        this.screenGameoverBack = new Button(100, LC2.world.height - 100, 'button-mainmenu', this.stateBack, this);
        this.screenGameoverBack.setOrigin(0, 1);
        this.screenGameoverRestart = new Button(LC2.world.width - 100, LC2.world.height - 100, 'button-restart', this.stateRestart, this);
        this.screenGameoverRestart.setOrigin(1, 1);
        this.screenGameoverScore = this.add.text(LC2.world.centerX, 300, LC2.text['gameplay-score'] + this._score, fontScoreWhite);
        this.screenGameoverScore.setOrigin(0.5, 0.5);
        // this.screenGameoverScore = LC2.getGradientText(this, LC2.text['gameplay-score'] + this._score, 300, LC2.world.centerX, 300, '#00ff00', '#aaffff', '#aaff22', '#ff0000');
        //this.screenGameoverScore.setShadow(8, 8);
        LC2.addBarrel(this, this.screenGameoverScore, LC2.world.centerX, 300);

        this.screenGameoverGroup.add(this.screenGameoverBg);
        this.screenGameoverGroup.add(this.screenGameoverText);
        this.screenGameoverGroup.add(this.screenGameoverBack);
        this.screenGameoverGroup.add(this.screenGameoverRestart);
        this.screenGameoverGroup.add(this.screenGameoverScore);
        // if (this.asteroids !== undefined){
        //     this.asteroids.toggleVisible();
        // }
        //this.invaders.toggleVisible();
        //this.enemies.toggleVisible();
        // this.screenGameoverGroup.add(this.asteroids);
        // this.screenGameoverGroup.add(this.enemies);
        // this.screenGameoverGroup.add(this.invaders);
        this.screenGameoverGroup.toggleVisible();
    }
    addPoints() {
        this._score += 10;
        this.textScore.setText(LC2.text['gameplay-score'] + this._score);

        var randX = Phaser.Math.Between(200, LC2.world.width - 200);
        var randY = Phaser.Math.Between(200, LC2.world.height - 200);
        var pointsAdded = this.add.text(randX, randY, '+10', { font: '48px ' + LC2.text['FONT'], fill: '#ffde00', stroke: '#000', strokeThickness: 10 });
        pointsAdded.setOrigin(0.5, 0.5);
        this.tweens.add({ targets: pointsAdded, alpha: 0, y: randY - 50, duration: 1000, ease: 'Linear' });
        LC2.Sfx.play('points');
        this.cameras.main.shake(100, 0.01, true);
    }
    stateRestart() {
        LC2.Sfx.play('click');
        LC2.fadeOutScene('Game', this);
    }
    stateBack() {
        LC2.Sfx.play('click');
        LC2.fadeOutScene('MainMenu', this);
    }
    gameoverScoreTweenEvent(game) {
        if (game.screenGameoverScore !== undefined) {
            game.screenGameoverScore.setText(LC2.text['gameplay-score'] + Math.floor(this.pointsTween.getValue()));
        }
        else {
            console.error("screenGameoverScore is undefined!!!");
        }

    }
    gameoverScoreTween() {
        this.screenGameoverScore.setText(LC2.text['gameplay-score'] + '0');
        var that = this;
        if (this._score) {
            this.pointsTween = this.tweens.addCounter({
                from: 0,
                to: this._score,
                duration: 2000,
                delay: 250,
                onUpdateScope: this,
                onCompleteScope: this,
                onUpdate: function () {
                    that.gameoverScoreTweenEvent(that);
                },
                onComplete: function () {
                    var htext = LC2.getGradientText(that, "HIGHSCORE", 90, 10, 450, '#00ff00', '#aaffff', '#aaff22', '#ff0000');
                    htext.setShadow(8, 8);
                    LC2.addBarrel(that, htext, 300, 400);
                    //const emitter2 = LC2.createEmitterFX(that, 'star3', 300, 400,200,600,2,300,0.5, 0.0,true,true);
                    // emitter1.frame =  ['red', 'yellow', 'green'];
                    //emitter1.explode(160);
                    const emitter = that.add.particles(300, 400, 'flares', {
                        frame: ['red', 'yellow', 'green'],
                        angle: { start: 40, end: 350, steps: 8 },
                        // active: true,
                        lifespan: 4000,
                        speed: { min: 10, max: 300 },
                        scale: { start: 0.8, end: 0 },
                        gravityY: 150,
                        blendMode: 'ADD',
                        // bounce: 0.6,
                        // bounds: new Phaser.Geom.Rectangle(-100, -200, 1000, 750),
                        // emitting: false,                        
                        //duration: 1000,
                        repeat: -1,
                        onRepeat: () => {
                            particles.explode(2);
                        }
                    });
                    const emitter1 = that.add.particles(300, 300, 'flares', {
                        frame: ['red', 'yellow', 'green'],
                        active: true,
                        lifespan: 40000,
                        speed: { min: 150, max: 250 },
                        scale: { start: 0.8, end: 0 },
                        gravityY: 150,
                        blendMode: 'ADD',
                        emitting: false
                    });
                    emitter1.explode(16);


                }
            });
        }
    }




};