        // import Boot from './Boot.js';
        // import Preloader from './Preloader.js';
        // import MainMenu from './MainMenu.js';
        // import MainGame from './Game.js';

const config = {
    type: Phaser.AUTO,
    width: 1024,
    height: 768,
    backgroundColor: '#3366b2',
    parent: 'content',
    scale: {
        mode: Phaser.Scale.FIT,
        autoCenter: Phaser.Scale.CENTER_BOTH,
        width: 1024,
        height: 768
    },
    dom: {
		createContainer: true
	},
    physics: {
        default: 'arcade',
        arcade: {
            gravity: { y: 0.0 },
            // fps: 60,
            debug: false
        }
    },
    scene: [ Boot, Preloader, MainMenu, MainGame ]    
};

let game = new Phaser.Game(config);
