class Example extends Phaser.Scene
{
    preload ()
    {
        this.load.html('loginForm', '/cms/index.php?q=intro');
        this.load.html('nameForm', '/LC2Intro.v.4.0/assets/html/loginform.html');
        this.load.image('bg', '/LC2Intro.v.4.0/assets/img/bg.png');
    }
    getDomObject (img,x,y)
    {
        return this.add.dom(x, y).createFromCache(img);
    }

    create ()
    {
        const that = this;
        this.add.image(320, 500, 'bg');

        const text = this.add.text(10, 10, 'Please login to play', { color: 'white', fontFamily: 'Arial', fontSize: '32px '});

        const element = this.getDomObject('nameForm',300, 600);// this.add.dom(300, 600).createFromCache('nameForm');

        element.setPerspective(800);

        element.addListener('click');

        element.on('click', function (event)
        {

            if (event.target.name === 'loginButton')
            {
                const inputUsername = this.getChildByName('username');
                const inputPassword = this.getChildByName('password');

                //  Have they entered anything?
                if (inputUsername.value !== '' && inputPassword.value !== '')
                {
                    //  Turn off the click events
                    this.removeListener('click');

                    //  Tween the login form out
                    this.scene.tweens.add({ targets: element.rotate3d, x: 1, w: 90, duration: 3000, ease: 'Power3' });

                    this.scene.tweens.add({
                        targets: element, scaleX: 2, scaleY: 2, y: 700, duration: 3000, ease: 'Power3',
                        onComplete: function ()
                        {
                            element.setVisible(false);
                        }
                    });

                    //  Populate the text with whatever they typed in as the username!
                    text.setText(`Welcome ${inputUsername.value}`);
                    const loginElement = that.getDomObject('loginForm',400, 900);// this.add.dom(900, 600).createFromCache('loginForm');
                    loginElement.setPerspective(800);
                    that.tweens.add({
                        targets: loginElement,
                        y: 300,
                        duration: 3000,
                        ease: 'Power3'
                    });
                }
                else
                {
                    //  Flash the prompt
                    this.scene.tweens.add({ targets: text, alpha: 0.1, duration: 200, ease: 'Power3', yoyo: true });
                }
            }

        });

        this.tweens.add({
            targets: element,
            y: 300,
            duration: 3000,
            ease: 'Power3'
        });
    }

    
}


const config = {
    type: Phaser.AUTO,
    width: 640,
    height: 960,
    parent: 'phaser-example',
    dom: {
        createContainer: true
    },
    scale: {
        // mode: Phaser.Scale.FIT,
        parent: 'content',
        autoCenter: Phaser.Scale.CENTER_BOTH,
        // width: 640,
        // height: 960,
    },
    scene: Help
};

const game = new Phaser.Game(config);
