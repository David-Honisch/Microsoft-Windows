class Example extends Phaser.Scene
{
    preload ()
    {
    }

    create ()
    {
    }

    update ()
    {
    }
}

const config = {
    type: Phaser.AUTO,
    width: 800,
    height: 600,
    scene: Example
};

const game = new Phaser.Game(config);
