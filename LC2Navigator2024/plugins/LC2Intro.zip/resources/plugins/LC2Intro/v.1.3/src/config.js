var appConfig = {
    "version": 4.1,
    "isApp": true,
    "isActiveDOM": false,
    "apptitle": "LC2Intro",
    "maxlevel": 10,
    "maxtime": 60,
    "startlevel": 0,
    "isLastLevel": false,
    "shiphits": 100,
    "shiplives": 3,
    "shiprate": 1,
    "data": {
        "data": {
            "version": 4.1,
            "isApp": false,
            "isActiveDOM": true,
            "apptitle": "LC2Intro"

        },
        "storyscroller":{
            "text": [
                "WELCOME",
                "TO",
                "",
                "",
                "",
                "",
                "LETZTECHANCE.ORG",
                "",
                "",
                "",
                "",
                "",
                "LC",
                "PROUD TO PRESENT",
                "THE",
                "OFFICIAL",
                "LETZTECHANCE",
                "INTRO 2024",                
                "",
                "",
                "",
                "THANX GOES OUT TO:",
                "",
                "ALL COOL GUYS",
                "",
                "ALL BARTNENDER'S",
                "ALL METALHEADS",
                "FIREBIRD",
                "VIOLATOR",
                "PHYGOZATOR",
                "GWENDOLIN",
                "SAXON",
                "METAlhEAD",
                "BLACKHOLE",
                "TEX",
                "RAZOR 1911",
                "UNION",
                "",
                "",
                "COPYRIGHT",
                "BY",
                "DAVID HONISCH",
                "",
                "BYE"
            ]
        },
        "scroller": {
            "data": {
                "fx": {
                    "fNoop": 0, // No effect
                    "fSin1": 1, // Sine 1
                    "fSin2": 2, // Sine 2
                    "fBce1": 3, // Bounce 1
                    "fBce2": 4, // Bounce 2
                    "fRot1": 5, // Rotate slow
                    "fRot2": 6, // Rotate quick
                    "fCyld": 7, // Cylinder
                    "fTria": 8, // Triangle
                    "fGrow": 9 // Pack/Unpack

                },
                "color": {
                    "olrY": 0, // Yellow
                    "colrB": 1, // Blue
                    "colrP": 2, // Purple
                    "flgDE": 3, // Germany
                    "flgFR": 4, // France
                    "flgBE": 5, // Belgium
                    "flgGB": 6, // Great-Britain
                    "flgSE": 7, // Sweden
                    "flgNL": 8, // Netherlands
                    "flgSC": 9, // Scotland
                    "flgES": 10, // Spain
                    "flgAU": 11, // Australia
                    "flgPT": 12, // Portugal
                    "flgCH": 13, // Switzerland
                    "flgLU": 14 // Luxembourg

                },
                "text": []

            }

        }

    }
}
appConfig["data"]["scroller"]["data"]["text"] = [
    [appConfig.data.scroller.data.fx.fNoop, appConfig.data.scroller.data.color.colrY, 0, 'Welcome to LETZTECHANCE.ORG'],
    [appConfig.data.scroller.data.fx.fSin1, appConfig.data.scroller.data.colorcolrB, 0, 'LC proud to present'],
    [appConfig.data.scroller.data.fx.fSin2, appConfig.data.scroller.data.colorcolrP, 0, 'LC2GoldenLabyrinth'],
    [appConfig.data.scroller.data.fx.fBce1, appConfig.data.scroller.data.colorcolrY, 0, 'powered by Phaser'],
    [appConfig.data.scroller.data.fx.fBce2, appConfig.data.scroller.data.colorcolrB, 0, 'Done by David Honisch'],
    [appConfig.data.scroller.data.fx.fRot1, appConfig.data.scroller.data.colorcolrP, 0, 'https://www.letztechance.org'],
    [appConfig.data.scroller.data.fx.fRot2, appConfig.data.scroller.data.colorcolrY, 0, 'https://www.letztechance.org/vue'],
    [appConfig.data.scroller.data.fx.fCyld, appConfig.data.scroller.data.colorcolrB, 0, 'https://www.letztechance.org/dist'],
    [appConfig.data.scroller.data.fx.fTria, appConfig.data.scroller.data.colorcolrP, 0, 'more'],
    [appConfig.data.scroller.data.fx.fGrow, appConfig.data.scroller.data.colorcolrY, 0, 'coming soon...'],

    [appConfig.data.scroller.data.fx.fSin1, appConfig.data.scroller.data.color.colrB, 0, 'ohhh the new blitter object'],
    [appConfig.data.scroller.data.fx.fRot1, appConfig.data.scroller.data.color.colrY, 0, 'can do some really cool stuff'],
    [appConfig.data.scroller.data.fx.fBce1, appConfig.data.scroller.data.color.colrP, 0, 'don\'t you think so?'],
    [appConfig.data.scroller.data.fx.fCyld, appConfig.data.scroller.data.color.colrY, 0, 'Let\'s do the twist again!'],
    [appConfig.data.scroller.data.fx.fTria, appConfig.data.scroller.data.color.colrB, 0, 'A demo masterminded by Alien.'],
    [appConfig.data.scroller.data.fx.fSin2, appConfig.data.scroller.data.color.colrP, 0, 'Would you like to see some more bobs? Ok:'],
    [appConfig.data.scroller.data.fx.fRot2, appConfig.data.scroller.data.color.colrY, 0, '# ## ### ######'],
    [appConfig.data.scroller.data.fx.fGrow, appConfig.data.scroller.data.color.colrP, 0, 'You just saw 384 masked 3-bitplane bobs per VBL...'],
    [appConfig.data.scroller.data.fx.fRot1, appConfig.data.scroller.data.color.colrY, 0, 'Anyway, let\'s have some greetings now.'],
    [appConfig.data.scroller.data.fx.fTria, appConfig.data.scroller.data.color.colrP, 0, 'First the megagreetings. They go to:'],
    [appConfig.data.scroller.data.fx.fTria, appConfig.data.scroller.data.color.flgDE, 0, 'Delta Force'],
    [appConfig.data.scroller.data.fx.fGrow, appConfig.data.scroller.data.color.flgFR, 0, 'Legacy'],
    [appConfig.data.scroller.data.fx.fGrow, appConfig.data.scroller.data.color.flgFR, 0, 'Overlanders'],
    [appConfig.data.scroller.data.fx.fCyld, appConfig.data.scroller.data.color.flgFR, 0, 'Poltergeist'],
    [appConfig.data.scroller.data.fx.fSin2, appConfig.data.scroller.data.color.flgDE, 0, 'TEX'],
    [appConfig.data.scroller.data.fx.fGrow, appConfig.data.scroller.data.color.flgFR, 1, 'Vegetables.'],
    [appConfig.data.scroller.data.fx.fNoop, appConfig.data.scroller.data.color.colrB, 0, 'Normal greetings go to:'],
    [appConfig.data.scroller.data.fx.fNoop, appConfig.data.scroller.data.color.flgFR, 0, '1984    ABCS 85'],
    [appConfig.data.scroller.data.fx.fTria, appConfig.data.scroller.data.color.flgDE, 0, 'ACF'],
    [appConfig.data.scroller.data.fx.fTria, appConfig.data.scroller.data.color.flgFR, 0, 'Mathias Agopian'],
    [appConfig.data.scroller.data.fx.fRot1, appConfig.data.scroller.data.color.flgFR, 0, 'Alcatraz'],
    [appConfig.data.scroller.data.fx.fSin1, appConfig.data.scroller.data.color.flgDE, 0, 'BMT'],
    [appConfig.data.scroller.data.fx.fSin1, appConfig.data.scroller.data.color.flgFR, 0, 'DNT Crew'],
    [appConfig.data.scroller.data.fx.fGrow, appConfig.data.scroller.data.color.flgBE, 1, 'Dr. Satan'],
    [appConfig.data.scroller.data.fx.fNoop, appConfig.data.scroller.data.color.flgGB, 0, 'Dynamic Duo'],
    [appConfig.data.scroller.data.fx.fCyld, appConfig.data.scroller.data.color.flgSE, 0, 'Electra'],
    [appConfig.data.scroller.data.fx.fTria, appConfig.data.scroller.data.color.flgGB, 0, 'Electronic Images'],
    [appConfig.data.scroller.data.fx.fSin2, appConfig.data.scroller.data.color.flgFR, 0, 'Equinox'],
    [appConfig.data.scroller.data.fx.fGrow, appConfig.data.scroller.data.color.flgNL, 0, 'Eternal'],
    [appConfig.data.scroller.data.fx.fRot2, appConfig.data.scroller.data.color.flgSC, 0, 'Fingerbobs'],
    [appConfig.data.scroller.data.fx.fBce2, appConfig.data.scroller.data.color.flgSE, 0, 'Flexible Front'],
    [appConfig.data.scroller.data.fx.fBce2, appConfig.data.scroller.data.color.flgNL, 0, 'Galtan 6'],
    [appConfig.data.scroller.data.fx.fBce1, appConfig.data.scroller.data.color.flgFR, 0, 'Laurent Z.'],
    [appConfig.data.scroller.data.fx.fBce1, appConfig.data.scroller.data.color.flgBE, 0, 'Lem and Nic'],
    [appConfig.data.scroller.data.fx.fTria, appConfig.data.scroller.data.color.flgFR, 0, 'Mad Vision'],
    [appConfig.data.scroller.data.fx.fGrow, appConfig.data.scroller.data.color.flgFR, 0, 'MCoder'],
    [appConfig.data.scroller.data.fx.fRot2, appConfig.data.scroller.data.color.flgFR, 0, 'Naos'],
    [appConfig.data.scroller.data.fx.fBce2, appConfig.data.scroller.data.color.flgGB, 0, 'Neil of Cor Blimey'],
    [appConfig.data.scroller.data.fx.fCyld, appConfig.data.scroller.data.color.flgDE, 0, 'Newline'],
    [appConfig.data.scroller.data.fx.fCyld, appConfig.data.scroller.data.color.flgFR, 0, 'Next    NGC'],
    [appConfig.data.scroller.data.fx.fBce1, appConfig.data.scroller.data.color.flgSE, 0, 'Omega    Phalanx'],
    [appConfig.data.scroller.data.fx.fBce1, appConfig.data.scroller.data.color.flgFR, 0, 'Prism    Quartex'],
    [appConfig.data.scroller.data.fx.fGrow, appConfig.data.scroller.data.color.flgES, 1, 'Red Devil'],
    [appConfig.data.scroller.data.fx.fNoop, appConfig.data.scroller.data.color.flgDE, 0, 'The Respectables'],
    [appConfig.data.scroller.data.fx.fSin1, appConfig.data.scroller.data.color.flgGB, 0, 'Ripped Off'],
    [appConfig.data.scroller.data.fx.fRot2, appConfig.data.scroller.data.color.flgAU, 0, 'Sewer Software'],
    [appConfig.data.scroller.data.fx.fTria, appConfig.data.scroller.data.color.flgFR, 0, 'Silents'],
    [appConfig.data.scroller.data.fx.fBce1, appConfig.data.scroller.data.color.flgPT, 0, 'Paulo Simoes'],
    [appConfig.data.scroller.data.fx.fCyld, appConfig.data.scroller.data.color.flgCH, 0, 'Spreadpoint'],
    [appConfig.data.scroller.data.fx.fNoop, appConfig.data.scroller.data.color.flgFR, 0, 'ST Magazine'],
    [appConfig.data.scroller.data.fx.fNoop, appConfig.data.scroller.data.color.flgNL, 0, 'ST News'],
    [appConfig.data.scroller.data.fx.fNoop, appConfig.data.scroller.data.color.flgDE, 0, 'Sven Meyer'],
    [appConfig.data.scroller.data.fx.fBce2, appConfig.data.scroller.data.color.flgSE, 0, 'Sync'],
    [appConfig.data.scroller.data.fx.fBce1, appConfig.data.scroller.data.color.flgSE, 0, 'TCB'],
    [appConfig.data.scroller.data.fx.fGrow, appConfig.data.scroller.data.color.flgCH, 0, 'TDA'],
    [appConfig.data.scroller.data.fx.fGrow, appConfig.data.scroller.data.color.flgGB, 0, 'TLB'],
    [appConfig.data.scroller.data.fx.fGrow, appConfig.data.scroller.data.color.flgDE, 0, 'TNT-Crew'],
    [appConfig.data.scroller.data.fx.fSin2, appConfig.data.scroller.data.color.flgDE, 0, 'TOS Magazin'],
    [appConfig.data.scroller.data.fx.fSin2, appConfig.data.scroller.data.color.flgFR, 0, 'Tsunoo Rhilty'],
    [appConfig.data.scroller.data.fx.fRot2, appConfig.data.scroller.data.color.flgDE, 0, 'TVI'],
    [appConfig.data.scroller.data.fx.fGrow, appConfig.data.scroller.data.color.flgLU, 0, 'ULM'],
    [appConfig.data.scroller.data.fx.fGrow, appConfig.data.scroller.data.color.flgFR, 0, 'Undead'],
    [appConfig.data.scroller.data.fx.fCyld, appConfig.data.scroller.data.color.flgGB, 0, 'XXX International'],
    [appConfig.data.scroller.data.fx.fCyld, appConfig.data.scroller.data.color.flgFR, 0, 'Yoda'],
    [appConfig.data.scroller.data.fx.fCyld, appConfig.data.scroller.data.color.flgFR, 0, 'Zarathoustra.'],
    [appConfig.data.scroller.data.fx.fNoop, appConfig.data.scroller.data.color.colrP, 0, 'Alien\'s special greetings are flying over to:'],
    [appConfig.data.scroller.data.fx.fSin2, appConfig.data.scroller.data.color.flgFR, 0, 'Atm    Alain Hurtig    Nicolas Chouckroun'],
    [appConfig.data.scroller.data.fx.fTria, appConfig.data.scroller.data.color.flgDE, 0, 'Flix    Big Alec'],
    [appConfig.data.scroller.data.fx.fSin1, appConfig.data.scroller.data.color.flgGB, 0, 'Manikin'],
    [appConfig.data.scroller.data.fx.fSin1, appConfig.data.scroller.data.color.flgNL, 0, 'Digital Insanity'],
    [appConfig.data.scroller.data.fx.fSin2, appConfig.data.scroller.data.color.flgFR, 0, 'Fury'],
    [appConfig.data.scroller.data.fx.fGrow, appConfig.data.scroller.data.color.flgLU, 0, 'Gunstick'],
    [appConfig.data.scroller.data.fx.fRot2, appConfig.data.scroller.data.color.flgFR, 0, 'Dbug II'],
    [appConfig.data.scroller.data.fx.fTria, appConfig.data.scroller.data.color.flgDE, 0, 'ES    Gogo'],
    [appConfig.data.scroller.data.fx.fGrow, appConfig.data.scroller.data.color.flgSE, 0, 'Tanis'],
    [appConfig.data.scroller.data.fx.fRot1, appConfig.data.scroller.data.color.flgFR, 0, 'Gordon    Thomas Landspurg'],
    [appConfig.data.scroller.data.fx.fBce1, appConfig.data.scroller.data.color.flgGB, 0, 'Kreator    4mat'],
    [appConfig.data.scroller.data.fx.fTria, appConfig.data.scroller.data.color.flgFR, 0, 'Moby    Audio Monster'],
    [appConfig.data.scroller.data.fx.fNoop, appConfig.data.scroller.data.color.colrP, 0, 'Douglas Adams and Rodney Matthews.    Now a little comment about ripping...'],
    [appConfig.data.scroller.data.fx.fSin1, appConfig.data.scroller.data.color.colrY, 0, 'ST Connexion\'s policy is the following:'],
    [appConfig.data.scroller.data.fx.fGrow, appConfig.data.scroller.data.color.colrP, 0, 'All our code is copyrighted and may not be re-used in any program or modified in any way whatsoever.'],
    [appConfig.data.scroller.data.fx.fNoop, appConfig.data.scroller.data.color.colrB, 0, 'It is also illegal to distribute it under any form other than that in which it was released:'],
    [appConfig.data.scroller.data.fx.fSin2, appConfig.data.scroller.data.color.colrP, 0, 'Delta Force\'s Punish Your Machine Demo.'],
    [appConfig.data.scroller.data.fx.fNoop, appConfig.data.scroller.data.color.colrY, 0, 'If you wonder why we have such a strict policy, it is because some commercial lamers helped themselves to parts of our code, as well as inumerable groups.'],
    [appConfig.data.scroller.data.fx.fSin1, appConfig.data.scroller.data.color.colrP, 0, 'Some hints about the 4-bit hardware scroller coming up...    In January 1991, I (Alien) got my 4-bit hardware-scroller to work.'],
    [appConfig.data.scroller.data.fx.fSin2, appConfig.data.scroller.data.color.colrP, 0, 'It allows you to move the whole screen left and right by increments of 4 pixels. The source has been published in my series of articles about overscan in ST Magazine, a French publication.'],
    [appConfig.data.scroller.data.fx.fTria, appConfig.data.scroller.data.color.colrY, 0, 'As this technique is brand-new, it may not work on some Atari ST\'s. If it doesn\'t work on yours, please contact us.'],
    [appConfig.data.scroller.data.fx.fBce2, appConfig.data.scroller.data.color.colrB, 0, 'Time to grab a pen..........    To obtain 4 bit hardware scrolling on an ST, you have to switch to midrez after the passage to hirez used to free the left border, and then wait 0,4,8,12 cycles before switching back to lowrez.'],
    [appConfig.data.scroller.data.fx.fNoop, appConfig.data.scroller.data.color.colrP, 0, 'This affects the way the shifter works, and delays the displaying of the picture by a multiple of 500 nanoseconds, which results in an effective shift in the picture...'],
    [appConfig.data.scroller.data.fx.fSin2, appConfig.data.scroller.data.color.colrY, 0, 'Note the method described here does not work on some STE\'s.   Time is up, so let\'s cut the crap:'],
    [appConfig.data.scroller.data.fx.fRot1, appConfig.data.scroller.data.color.colrB, 0, 'According to Vickers of Legacy sitting next to us, you\'ve been reading this text for over an hour...'],
    [appConfig.data.scroller.data.fx.fCyld, appConfig.data.scroller.data.color.colrP, 0, 'But the original version was over 10 kb long, ensuring 4 hours of pleasant reading!'],
    [appConfig.data.scroller.data.fx.fGrow, appConfig.data.scroller.data.color.colrY, 0, 'See you in the next St Connexion Production, scheduled to be released within the next 2 years!                                 '],
];