<div style="background-image: linear-gradient(0deg, rgb(163, 92, 0), orange 40%, yellow);opacity: 0.9;padding: 4px;margin: 4px;border-radius: 10px;max-width:300px;">

    <p align="center" style="margin: 0; padding: 0; font-size: 24px; color: black"><strong>LC - Help <em>Get help</em></strong></p>    
    <?PHP 
    //$api = "/cms/index.php?q=getLastContent&value1=95&value2=1";
    $api = "/index.php?q=getLastContent&value1=95&value2=1";
    echo "<iframe src=\"".$api."\" width=\"100%\" height=\"480px\" style=\"border: 0; width:100%; height:480px;\"><iframe>";
    ?>    
</div>