<?xml version="1.0" encoding="UTF-8"?>
<tileset name="drawtiles1" tilewidth="32" tileheight="32" spacing="1" margin="1" tilecount="3" columns="3">
 <image source="../tiles/drawtiles1.png" width="102" height="34"/>
</tileset>
