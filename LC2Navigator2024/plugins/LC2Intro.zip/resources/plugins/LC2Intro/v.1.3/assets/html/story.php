
<?php
$url = preg_replace('@/((\&)?PHPSESSID=[a-zA-Z0-9]+(\&)?)/i@', "", isset($_GET["q"]) ? $_GET["q"] : "");
$action = preg_replace('@/((\&)?PHPSESSID=[a-zA-Z0-9]+(\&)?)/i@', "", isset($_GET["action"]) ? $_GET["action"] : "");
switch ($action) {
    case 'menu':
        echo "<div>";
        echo "<br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/>\n";
        echo "</div>";
        echo "<div style=\"background-image: linear-gradient(0deg, rgb(255,255,255), grey 40%, green);opacity: 0.9;padding: 4px;margin: 4px;border-radius: 10px;\">\n";
        echo "\n";
        echo "<p align=\"center\" style=\"margin: 0; padding: 0; font-size: 42px; color: black\"><strong>LC2Intro <em>Story ".$action."</em></strong></p>\n";
        echo "    Willkommen zu <a href=\"index.html\">LetzteChance.Org</a>\n";
        echo "<p>or go to:<a href=\"" . $url . "\">" . $url . "</a></p>\n";
        echo "</div>\n";

        break;
    case 'story':
        echo "<div>";
        echo "<br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/>\n";
        echo "</div>";
        
        echo "<div style=\"background-image: linear-gradient(0deg, rgb(169,25,0), orange 40%, yellow);opacity: 0.9;padding: 4px;margin: 4px;border-radius: 10px;\">\n";
        echo "<h1>Golden Labyrinth</h1>\n";
        echo "</div>\n";

        echo "<div style=\"background-image: linear-gradient(0deg, rgb(255,255,255), grey 40%, green);opacity: 0.9;padding: 4px;margin: 4px;border-radius: 10px;\">\n";                
        echo "<p align=\"center\" style=\"margin: 0; padding: 0; font-size: 42px; color: black\"><strong>The <em>Story</em></strong></p>\n";
        echo "This game collection is still in development...<br/><br/>";
        echo "Shoot with mouse left button or space, move with cursors or mouse...<br/><br/>";
        echo "Please visit this page later.<br/><br/><br/><br/> Thanks.";
        echo "</div>\n";
        echo "<div style=\"background-image: linear-gradient(0deg, rgb(169,25,0), orange 40%, yellow);opacity: 0.9;padding: 4px;margin: 4px;border-radius: 10px;\">\n";
        echo "<p>or go to:<a href=\"" . $url . "\">" . $url . "</a></p>\n";
        echo "</div>\n";

        break;

    default:
        echo "<div>";
        echo "<br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/>\n";
        echo "</div>";
        echo "<div style=\"background-image: linear-gradient(0deg, rgb(163, 92, 0), green 40%, yellow);opacity: 0.9;padding: 4px;margin: 4px;border-radius: 10px;\">\n";
        echo "\n";
        echo "<p align=\"center\" style=\"margin: 0; padding: 0; font-size: 42px; color: black\"><strong>LC2Intro <em>Story ".$action."</em></strong></p>\n";
        echo "Willkommen zu <a href=\"index.html\">LetzteChance.Org</a>\n";
        echo "<p>or go to:<a href=\"" . $url . "\">" . $url . "</a></p>\n";
        echo "<a href=\"index.html\">reload</a>\n";
        echo "<a href=\"/\">LC Home</a>\n";
        echo "</div>\n";
        break;
}


?>