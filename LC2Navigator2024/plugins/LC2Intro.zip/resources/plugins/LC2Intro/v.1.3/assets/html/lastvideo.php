<div style="background-image: linear-gradient(0deg, rgb(163, 92, 0), orange 40%, yellow);opacity: 0.9;padding: 4px;margin: 4px;border-radius: 10px;max-width:300px;">

    <p align="center" style="margin: 0; padding: 0; font-size: 24px; color: black"><strong>LC - Video <em>of the day</em></strong></p>    
    <?PHP 
    $api = "/cms/index.php?q=getLastContent&value1=21&value2=1";
    // echo "<p><a href=\"".preg_replace ( '@/((\&)?PHPSESSID=[a-zA-Z0-9]+(\&)?)/i@', "",$_GET["q"])."\">".preg_replace ( '@/((\&)?PHPSESSID=[a-zA-Z0-9]+(\&)?)/i@', "",$_GET["q"])."</a></p>";
    // $t = file_get_contents("http://localhost/cms/index.php?q=getLastContent&value1=21&value2=1");
    // echo $t;
    echo "<iframe src=\"".$api."\" width=\"100%\" height=\"480px\" style=\"border: 0; width:100%; height:480px;\"><iframe>";
    ?>    
</div>
<!-- <script src="/assets/js/plugins/google/ythtml5.js"></script> -->