<div style="background-image: linear-gradient(0deg, rgb(163, 92, 0), orange 40%, yellow);opacity: 0.9;padding: 4px;margin: 4px;border-radius: 10px;">

    <p align="center" style="margin: 0; padding: 0; font-size: 24px; color: black"><strong>LC2Intro <em>v.4.0</em></strong></p>
    Willkommen zu <a href="index.html">LetzteChance.Org</a><hr/>    
    <p><?PHP echo "<a href=\"".preg_replace ( '@/((\&)?PHPSESSID=[a-zA-Z0-9]+(\&)?)/i@', "",$_GET["q"])."\">".preg_replace ( '@/((\&)?PHPSESSID=[a-zA-Z0-9]+(\&)?)/i@', "",$_GET["q"])."</a>"; ?></p>
    
    
</div>
<div
    style="background-image: linear-gradient(0deg, rgb(163, 92, 0), orange 40%, yellow);opacity: 0.9;padding: 4px;margin: 4px;border-radius: 10px;">
    <input type="text" name="username" id="username" placeholder="Enter your name" style="font-size: 12px"><br />
    <input type="password" name="password" id="password" placeholder="Enter your password" style="font-size: 12px"><br />
    <label for="over18" style="font-size: 12px">Are you over 18?</label> <input type="checkbox" id="over18" name="over18" style="font-size: 12px"><br />
    <input type="button" name="loginButton" id="loginButton" value="Login" style="font-size: 32px">
<div>