<div style="background-image: linear-gradient(0deg, rgb(163, 92, 0), orange 40%, yellow);opacity: 0.9;padding: 4px;margin: 4px;border-radius: 10px;">

    <p align="center" style="margin: 0; padding: 0; font-size: 42px; color: black"><strong>LC2Intro <em>v.4.0</em></strong></p>
    Willkommen zu <a href="index.html">LetzteChance.Org</a>
    <h1><?PHP echo "Redirecting:".preg_replace ( '@/((\&)?PHPSESSID=[a-zA-Z0-9]+(\&)?)/i@', "",$_GET["q"]); ?></h1>
    
</div>
<div>   

    <pre style="padding: 32px; margin: 0">
        LC2Intro.v.4.0
        <a href="index.html">Home</a>
    </pre>
    <a href="index.html">Home</a>


</div>