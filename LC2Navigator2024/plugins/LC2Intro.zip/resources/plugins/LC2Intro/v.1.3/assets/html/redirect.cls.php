
<?php
$url = preg_replace('@/((\&)?PHPSESSID=[a-zA-Z0-9]+(\&)?)/i@', "", isset($_GET["q"]) ? $_GET["q"] : "");
$action = preg_replace('@/((\&)?PHPSESSID=[a-zA-Z0-9]+(\&)?)/i@', "", isset($_GET["action"]) ? $_GET["action"] : "");
switch ($action) {
    case 'tex':
        echo "<div>";
        //echo "<br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/>\n";
        echo "</div>";
        echo "<div style=\"background-image: linear-gradient(0deg, rgb(169,25,0), orange 40%, yellow);opacity: 0.9;padding: 4px;margin: 4px;border-radius: 4px;\">\n";
        echo "<h1>Redirecting to Hyperlink:</h1>\n";
        echo "</div>\n";
        echo "<div style=\"background-image: linear-gradient(0deg, rgb(255,255,255), grey 40%, green);opacity: 0.9;padding: 4px;margin: 4px;border-radius: 4px;\">\n";
        echo "<span>URL:" . $url . "</span>\n";
        echo "</div>\n";

        break;
    case 'redirect':
        echo "<div>";
        //echo "<br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/>\n";
        echo "</div>";
        
        echo "<div style=\"background-image: linear-gradient(0deg, rgb(169,25,0), orange 40%, yellow);opacity: 0.9;padding: 4px;margin: 4px;border-radius: 10px;\">\n";
        echo "<span><a href=\"" . $url . "\">" . $url . "</a></span>\n";
        echo "</div>\n";

        echo "<div style=\"background-image: linear-gradient(0deg, rgb(255,255,255), grey 40%, green);opacity: 0.9;padding: 4px;margin: 4px;border-radius: 10px;\">\n";                
        echo "<p align=\"center\" style=\"margin: 0; padding: 0; font-size: 10px; color: black\">\n";        
        echo "<strong>URL:<em><a href=\"" . $url . "\">" . $url . "</a></em></strong></p>This page is a externally. So please be aware of this.<br/><br/><br/><br/> Thanks.";
        echo "</div>\n";
        echo "<div style=\"background-image: linear-gradient(0deg, rgb(169,25,0), orange 40%, yellow);opacity: 0.9;padding: 4px;margin: 4px;border-radius: 10px;\">\n";
        echo "<p>or go to:<a href=\"" . $url . "\">" . $url . "</a></p>\n";
        echo "</div>\n";

        break;

    default:
        echo "<div>";
        // echo "<br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/>\n";
        echo "</div>";
        echo "<div style=\"background-image: linear-gradient(0deg, rgb(163, 92, 0), green 40%, yellow);opacity: 0.9;padding: 4px;margin: 4px;border-radius: 10px;\">\n";
        echo "\n";
        echo "<p align=\"center\" style=\"margin: 0; padding: 0; font-size: 42px; color: black\"><strong>LC2Intro <em>Story ".$action."</em></strong></p>\n";
        echo "Willkommen zu <a href=\"index.html\">LetzteChance.Org</a>\n";
        echo "<p>Redirecting:" . $url . "</p>\n";
        echo "<a href=\"index.html\">reload</a>\n";
        echo "<a href=\"/\">LC Home</a>\n";
        echo "</div>\n";
        break;
}


?>