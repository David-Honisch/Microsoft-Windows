// alert('TEST2');
function pluginINIT(pluginName) {
    try {
        var arguments = getSQLQuery('select name from params order by person_id asc, name asc', dbPath);
        //var query = getExtractArg(arguments,'--query=');        
        //$('#showcase').load('..\\..\\..\\resources\\plugins\\' + pluginName + '\\menu.html');
		execCMD('.\\resources\\plugins\\' + pluginName + '\\config.bat', 'pnavmenu');
		// alert(pluginName);
        // $('#playout').load('..\\..\\resources\\plugins\\' + pluginName + '\\launch.html');
        execCMD('.\\resources\\plugins\\' + pluginName + '\\index.bat', 'pnavmenu');
    } catch (e) {
        alert(e.stack);
    }
    // var argparts = arguments.split(' ');
    // var i = 0;
    // var query = "";
    // for (var s in argparts)
    // {
    // console.log(s);
    // if (s == "--query"){
    // query = argparts[i+1]
    // }
    // i++;
    // }
    // alert(query);
    // document.getElementById("app_cnt").innerHTML += arguments;
    // document.getElementById("inputKey").value =inputKey
    // alert(arguments);
    // alert(arguments["arg1"]);
    // alert(arguments["--query"]);
	// try {
    // $('#mout').load('..\\..\\resources\\plugins\\' + pluginName + '\\launch.html');
	// execCMD('.\\resources\\plugins\\' + pluginName + '\\index.bat', 'moutnav');
// } catch (e) {
    // alert(e.stack);
// }
}
// pluginLC2CRC32INIT();
// alert(pluginName);