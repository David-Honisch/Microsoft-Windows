function getPluginArguments() {
    var arguments = null;
    try {
        arguments = getSQLQuery('select name from params order by person_id asc, name asc', dbPath);
        //var query = getExtractArg(arguments,'--query=');        
        //$('#showcase').load('..\\..\\..\\resources\\plugins\\' + pluginName + '\\menu.html');
        console.log(arguments);
        return arguments;
    } catch (e) {
        alert(e.stack);
    }
}
function pluginINIT(pluginName) {
    var result = "";
    try {
        var arg = getPluginArguments();
        console.log(arg);
        
        execCMD("resources\\cmd\\register_plugin.bat "+pluginName, "pnavmenu");
        execCMD("call  resources\\app\\sqlite\\SQLite3.exe \"resources\\" + pluginName + ".db\" \".read .\\\\resources\\\\plugins\\\\" + pluginName + "\\\\schema.sql\"", "pnavmenu");
        getXML(".\\resources\\plugins\\" + pluginName +"\\xml\\app.xml", ".\\resources\\plugins\\" + pluginName + "\\xml\\app.xslt","pnav");
        setTimeout(() => {
            // getXML(".\\resources\\plugins\\" + pluginName +"\\xml\\app.xml", ".\\resources\\plugins\\" + pluginName + "\\xml\\app.xslt","pnav");            
            execPluginCMDList(pluginName,'#'+pluginName+'');
            execPluginCMDTableList(pluginName, pluginName+"_main",'#'+pluginName+'_main');
            execPluginCMDTableList(pluginName, pluginName+"_install",'#'+pluginName+'_install');
            execPluginCMDTableList(pluginName, pluginName+"_help",'#'+pluginName+'_help');
        }, 3000);        
    } catch (e) {
        alert(e.stack);
    }
}