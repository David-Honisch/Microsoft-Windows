-- select '<h2>Import processes</h2>';
drop table IF EXISTS LC2CRC32;
drop table IF EXISTS LC2CRC32_data;
drop table IF EXISTS LC2CRC32_procdata;
-- drop table IF EXISTS LC2CRC32temp;
-- drop table IF EXISTS LC2CRC32_datatemp;
CREATE TABLE LC2CRC32( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE LC2CRC32_data( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
-- CREATE TABLE LC2CRC32_procdata( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
-- CREATE TABLE IF NOT EXISTS LC2CRC32temp (
-- "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL
-- );
-- create table IF NOT EXISTS LC2CRC32_datatemp ( name varchar(255));
-- CREATE TABLE IF NOT EXISTS LC2CRC32_datatemp (
-- "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL
-- );
-- import menu
-- select '<p>Import processes</p>';
.separator ";"
.import .\\resources\\plugins\\LC2CRC32\\import\\import.csv LC2CRC32
.import '.\\resources\\plugins\\LC2CRC32\\import\\menu.csv' LC2CRC32_data
-- delete from LC2CRC32_datatemp;
--
-- .separator ","
-- .import '.\\resources\\plugins\\LC2CRC32\\import\\LC2CRC32work.csv' LC2CRC32_datatemp
-- INSERT INTO LC2CRC32_procdata(first_name,name,zipcode, city, description) select first_name,name,zipcode, city, description  from LC2CRC32_datatemp;

select '<p>LC2CRC32 count:';
select count(*) from LC2CRC32;
select 'LC2CRC32_data count:';
select count(*) from LC2CRC32_data;
select 'LC2CRC32_procdata count:';
select count(*) from LC2CRC32_procdata;
.separator ";"
drop table IF EXISTS LC2CRC32temp;
-- select '<p>Import done</p>';
.exit