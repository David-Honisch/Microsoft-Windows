//LC2Navigator 2022
var app = angular.module('app', ['ui.bootstrap']);

function AppController($scope, $http, $filter) {
    const APPCFG = "application.config.json";
    $scope.pageName = "List";
    // const path = window.nodeRequire('path');
    // default values for pagination and filtering
    $scope.pageSize = 10;
    $scope.maxSize = 100;
    $scope.start = 0;
    $scope.end = 0;
    $scope.currentPage = 0;
    $scope.numOfPages = 0;
    $scope.filteredItems = [];
    $scope.startItems = [];
    $scope.pagedItems = [];
    // $scope.currentTable = $.urlParam('db') !== undefined ? $.urlParam('db') : "systables";
    $scope.data = null;
    $scope.query = { name: "" };
    $scope.index = [];
    $scope.news = [];
    $scope.menu = [];


    $http.get('/webservices/mainmenu.json')
        .success(function(data) {
            $scope.menu = data;
        });

    $http.get('/webservices/server.php?q=getIndex')
        .success(function(data) {
            $scope.index = data.list;
        });
    $http.get('/webservices/client.php?q=getListJSON&value1=0&l=')
        .success(function(data) {
            $scope.news = data.row;
        });

    // $http.get('/webservices/server.php?q=getQuery&query=projects')
    //     .success(function (data) {
    //         $scope.pagedItems = data.results;
    //     });
    $http.get('/webservices/server.php?q=getQuery&query=projects')
        .success(function(data) {
            var res = JSON.parse(JSON.stringify(data.results));
            var temp = [];
            for (var v in res) {
                temp[v] = JSON.parse(res[v]);
            }
            $scope.data = temp;
            //alert("Sux:" + $scope.data);
            //$scope.pagedItems = data;
        });

    // $http.get('/webservices/server.php?q=getIndex')
    //     .success(function(data) {
    //         $scope.pagedItems = data.list;
    //     });


    // model.initDb('' + webRoot, //app.getPath('userData'),
    //     // Load a DOM stub here. See renderer.js for the fully composed DOM.
    //     //mainWindow.loadURL(`file:${__dirname}/app/html/index.html`)
    //     console.log('Init Database')
    // );
    // var res = model.GetQuery(dbPath, 'select * from systables order by person_id asc');
    // // console.log(JSON.stringify(res));
    // var list = {
    //     "Data": []
    // };

    // for (var v in res) {
    //     // console.log(JSON.stringify(v));
    //     var t = {
    //         "id": res[v]['person_id'],
    //         "name": res[v]['name'],
    //         "first_name": res[v]['first_name'],
    //         "last_name": res[v]['last_name'],
    //         "zipcode": res[v]['zipcode'],
    //         "url": res[v]['url'],
    //     };
    //     // console.log(JSON.stringify(t));
    //     list['Data'].push(t);
    // }
    // console.log(JSON.stringify(list.Data));
    // $scope.data = list.Data;


    // when the data is altered, filter the items and set the page
    $scope.$watch('data', function(data, old) {
        $scope.filteredItems = $filter('filter')(data, $scope.query);
        if (old === null) setPage();
    });

    // when the query value changes, refilter the data
    $scope.$watch('query|json', function() {
        $scope.filteredItems = $filter('filter')($scope.data, $scope.query);
    });

    // set the pagination for the filtered items
    function setPage() {
        $scope.start = ($scope.currentPage - 2) * $scope.pageSize + ($scope.filteredItems === undefined && $scope.filteredItems.length ? 1 : 0);
        $scope.startItems = $filter('startFrom')($scope.filteredItems, $scope.start - 2);
    }

    // when the current page is changed by the pagination control, update the list of items
    $scope.$watch('currentPage', function(page) {
        setPage();
    });

    // when the filtered items are set, recalculate the number of pages
    $scope.$watch('filteredItems', function(items, old) {
        $scope.currentPage = 0;
        if (items !== undefined && items !== null && items.length !== undefined && items.length > 0)
            $scope.numOfPages = Math.ceil(items.length / $scope.pageSize);
    });

    // when the page start is changed, update the list of paged items
    $scope.$watch('startItems', function(items) {
        $scope.pagedItems = $filter('limitTo')(items, $scope.pageSize);
        if ($scope.pagedItems !== undefined && $scope.pagedItems !== null && $scope.pagedItems.length > 0)
            $scope.end = ($scope.currentPage - 1) * $scope.pageSize + $scope.pagedItems.length;
    });



}

// angular directive to change default behavior from processing input change immediately to on blur or enter
app.directive('ngModelBlur', function() {
    return {
        restrict: 'A',
        require: 'ngModel',
        link: function(scope, elm, attr, ngModelCtrl) {
            if (attr.type === 'radio' || attr.type === 'checkbox') { return; }

            elm.unbind('input').unbind('keydown').unbind('change');
            elm.bind('blur keydown', function(e) {
                if (e.type === 'keydown' && e.which !== 13) { return; }

                scope.$apply(function() {
                    ngModelCtrl.$setViewValue(elm.val());
                });
            });
        }
    };
});

// angular filter to take array items starting from provided index
app.filter('startFrom', function() {
    return function(input, start) {
        if (angular.isArray(input)) {
            var st = parseInt(start, 10);
            if (isNaN(st)) st = 0;
            return input.slice(st);
        }
        return input;
    };
});