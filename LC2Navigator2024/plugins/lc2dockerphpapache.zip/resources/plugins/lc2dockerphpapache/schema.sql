-- select '<h2>Import processes</h2>';
drop table IF EXISTS lc2dockerphpapache;
drop table IF EXISTS lc2dockerphpapache_data;
drop table IF EXISTS lc2dockerphpapache_procdata;
drop table IF EXISTS lc2dockerphpapachetemp;
drop table IF EXISTS lc2dockerphpapache_datatemp;
CREATE TABLE lc2dockerphpapache( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE lc2dockerphpapache_data( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE lc2dockerphpapache_procdata( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE IF NOT EXISTS lc2dockerphpapachetemp (
"name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL
);
-- create table IF NOT EXISTS lc2dockerphpapache_datatemp ( name varchar(255));
CREATE TABLE IF NOT EXISTS lc2dockerphpapache_datatemp (
"name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL
);
-- import menu
-- select '<p>Import processes</p>';
.separator ";"
-- .import .\\resources\\plugins\\lc2dockerphpapache\\import\\import.csv lc2dockerphpapachetemp
-- INSERT INTO lc2dockerphpapache(first_name,name,zipcode, city, description) select first_name,name,zipcode, city, description  from lc2dockerphpapachetemp;
.import .\\resources\\plugins\\lc2dockerphpapache\\import\\import.csv lc2dockerphpapache

--
-- eof insert work data
select 'lc2dockerphpapache count:';
select count(*) from lc2dockerphpapache;
--.separator ';'
.separator ";"
--.import '.\\resources\\plugins\\lc2dockerphpapache\\import\\menu.csv' lc2dockerphpapache_datatemp
.import '.\\resources\\plugins\\lc2dockerphpapache\\import\\menu.csv' lc2dockerphpapache_datatemp
-- INSERT INTO lc2dockerphpapache_data(first_name,name,zipcode, city, description) select first_name,name,zipcode, city, description  from lc2dockerphpapache_datatemp;
.import '.\\resources\\plugins\\lc2dockerphpapache\\import\\menu.csv' lc2dockerphpapache_data
delete from lc2dockerphpapache_datatemp;
--
-- .separator ","
-- .import '.\\resources\\plugins\\lc2dockerphpapache\\import\\lc2dockerphpapachework.csv' lc2dockerphpapache_datatemp
-- INSERT INTO lc2dockerphpapache_procdata(first_name,name,zipcode, city, description) select first_name,name,zipcode, city, description  from lc2dockerphpapache_datatemp;
--
select '<p>lc2dockerphpapache count:';
select count(*) from lc2dockerphpapache;
select 'lc2dockerphpapache_data count:';
select count(*) from lc2dockerphpapache_data;
-- select 'lc2dockerphpapache_procdata count:';
-- select count(*) from lc2dockerphpapache_procdata;
-- .separator ";"
drop table IF EXISTS lc2dockerphpapachetemp;
-- select '<p>Import done</p>';
.exit