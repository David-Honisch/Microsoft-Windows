// function createDir(dir) {
//     const fs = window.nodeRequire('fs');
//     if (!fs.existsSync(dir)) {
//         fs.mkdirSync(dir);
//     }
// }

// function do_Unzip(link, target) {
//     const path = window.nodeRequire('path');
//     const fs = window.nodeRequire('fs');
//     target = path.join(target);
//     link = path.join(link);
//     if (link.includes(".zip")) {
//         document.getElementById('modcnt').innerHTML += '<br><h4>Extracting:</h4><p>' + link + ' to:' + target + '</p>';
//         try {
//             execCMD('extract ' + link, 'modcnt');
//         } catch (error) {
//             alert(error);
//             console.error(error.stack);
//         }
//     } else {
//         document.getElementById('modcnt').innerHTML += '<p> ' + link + ' <strong>NOT</strong> extracted to:' + target + '</p>';
//     }
//     document.getElementById('modcnt').innerHTML += '<hr><strong>DONE</strong>';
//     console.log('Extraction complete')

// }

// function InstallModules(tmpDir) {
//     Install_Modules(corelibs,tmpDir,'modcnt');
// }
// function Install_Modules(libs, tmpDir,id) {
//     try {
//         const { npmImportAsync, npmInstallAsync } = window.nodeRequire('runtime-npm-install');
//         npmInstallAsync(libs, tmpDir)
//             .then(function() {
//                 document.getElementById(id).innerHTML += '<h1>Successfully Installed to:</h1>' + tmpDir + '<br>';
//                 document.getElementById(id).innerHTML += '<h2>Done. Close window now and start main plugin.</h2>';

//             });
//         printDir(path.join(tmpDir, 'node_modules'));
//     } catch (error) {
//         alert(error);
//         document.getElementById(id).innerHTML += '<h2>ERROR:</h2>'+error;
//     }
// }

// function printDir(dir_path) {
//     const path = window.nodeRequire('path');
//     const fs = window.nodeRequire('fs');
//     console.log('DIR:' + dir_path);
//     fs.readdir(dir_path, function(err, files) {
//         //handling error
//         if (err) {
//             return console.log('Unable to find or open the directory: ' + err);
//         }
//         //Print the array of images at one go
//         // console.log(files);
//         //listing all files using forEach
//         files.forEach(function(file) {
//             var isValid = false;
//             console.log(file);
//             document.getElementById("modcnt").innerHTML += "<br>" + file;
//             for (v in rlibs) {
//                 if (file.includes(v)) {
//                     isValid = true;
//                 }
//             }
//             if (isValid) {
//                 document.getElementById("modcnt").innerHTML += "<br>" + file + " <strong>found</strong>.";
//             }
//         });
//     });
// }

// function doDownload(links, target) {
//     for (var v in links) {
//         getDownloadFile(links[v].path, links[v].file, target + links[v].file, target);
//     }
// }

// function getDownloadFile(baseUrl, link, targetFile, target) {
//     get_DownloadFile(baseUrl, link, targetFile, target, "appcnt");
// }

// function get_DownloadFile(baseUrl, link, targetFile, target, divId) {
//     var request = window.nodeRequire('request');
//     var fs = window.nodeRequire('fs');
//     var received_bytes = 0;
//     var total_bytes = 0;
//     var url = baseUrl + link;
//     console.log('DL:' + url)
//     var req = request({
//         method: 'GET',
//         uri: url
//     });

//     var out = fs.createWriteStream(targetFile);
//     req.pipe(out);

//     req.on('response', function(data) {
//         // Change the total bytes value to get progress later.
//         total_bytes = parseInt(data.headers['content-length']);
//     });

//     req.on('data', function(chunk) {
//         // Update the received bytes
//         received_bytes += chunk.length;

//         showProgress(divId, received_bytes, total_bytes);
//     });

//     req.on('end', function() {
//         // alert("File succesfully downloaded");
//         document.getElementById(divId).innerHTML += "<br>" + url + " File succesfully downloaded";
//         document.getElementById(divId).innerHTML += "<br>" + targetFile + " File succesfully written.";
//         document.getElementById(divId).innerHTML += "<br>Path:" + target + ".";
//         document.getElementById(divId).innerHTML += "<br>Link:" + link + ".";
//         if (('' + targetFile).includes(".zip")) {
//             do_Unzip(targetFile, target);
//             document.getElementById(divId).innerHTML += "<br>Unzip:" + targetFile + ".";
//         }
//     });
// }

// function showProgress(divId, received, total) {
//     var percentage = (received * 100) / total;
//     console.log(percentage + "% | " + received + " bytes out of " + total + " bytes.");
//     document.getElementById(divId + "progress").innerHTML = percentage + "% | " + received + " bytes out of " + total + " bytes.";
// }