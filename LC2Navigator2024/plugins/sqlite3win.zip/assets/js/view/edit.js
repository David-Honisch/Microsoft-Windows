'use strict';
var appConfig;
window.onload = init();

function init() {
    getHead();
    $('#out').append('RUNNING DONE.');
    console.log('INIT RUNNING...');
    $('#out').append('INIT RUNNING...');
    const fs = window.nodeRequire('fs');
    if (fs.existsSync(APPCFG)) {
        console.log(APPCFG + " file exists.");
        appConfig = getAppConfig(APPCFG);

    } else {
        console.log(APPCFG + ' file does not exist.\nCreating new Configuration file.' + APPCFG);

        //  setAppConfig(APPCFG, appConfig);
    }
    
    $(document).ready(function () {
        $('#namedetail').on('input', (event) => $("#name").val($('#namedetail').text()));
        $('#first_namedetail').on('input', (event) => $("#first_name").val($('#first_namedetail').text()));
        $('#last_namedetail').on('input', (event) => $("#last_name").val($('#last_namedetail').text()));
        $('#citydetail').on('input', (event) => $("#city").val($('#citydetail').text()));
        $('#streetdetail').on('input', (event) => $("#street").val($('#streetdetail').text()));
        $('#zipcodedetail').on('input', (event) => $("#zipcode").val($('#zipcodedetail').text()));
        $('#descriptiondetail').on('input', (event) => $("#description").val($('#urldetail').text()));
        $('#urldetail').on('input', (event) => $("#url").val($('#urldetail').text()));
    });

    // $("#multilineinput").on('keypress', function (e) {
    //     if (e.which == 13) { //on enter
    //         // e.preventDefault(); //disallow newlines     
    //         // $("#url").val($(this).text());
    //         // here comes your code to submit
    //     }
    // });
    //
    $('#submenu, #alertcnt').on('click', 'a[href^="http"]', function (event) {
        event.preventDefault();
        console.log(this.href + " opens...");
        shell.openExternal(this.href);
    });
    //$('#out').html('Successfully done.');
    // alert($("#url").val());
    // $("#urldetail").text($("#url").val());
    //click



    $('#out').html('Successfully done.');

    console.log('DONE.');
}
function getHead() {
    document.title = 'LETZECHANCE.ORG - Edit Item';
    var head = getHeader(cfg.local);
    // console.log(JSON.stringify(head));    
    $('#head').html(head);
    $('#ptitle').html('LC2Navigator Home - Edit Item');
}