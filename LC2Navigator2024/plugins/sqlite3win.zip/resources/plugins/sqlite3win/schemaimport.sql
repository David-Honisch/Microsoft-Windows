-- select '<h2>Import processes</h2>';
drop table IF EXISTS sqlite3win;
drop table IF EXISTS sqlite3win_Data;
drop table IF EXISTS sqlite3win_data;
drop table IF EXISTS sqlite3wintemp;
drop table IF EXISTS sqlite3win_datatemp;
CREATE TABLE sqlite3win( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE sqlite3win_data( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE IF NOT EXISTS sqlite3wintemp (
"name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL
);
-- create table IF NOT EXISTS sqlite3win_datatemp ( name varchar(255));
CREATE TABLE IF NOT EXISTS sqlite3win_datatemp (
"name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL
);
-- import menu
-- select '<p>Import processes</p>';
.separator ";"
.import .\\resources\\plugins\\sqlite3win\\import\\import.csv sqlite3wintemp
-- INSERT INTO sqlite3win(first_name,name,zipcode, city, description) select name,name, pid,ftype,tpid  from sqlite3wintemp;
-- insert work data
INSERT INTO sqlite3win(first_name,name,zipcode, city, description) select first_name,name,zipcode, city, description  from sqlite3wintemp;
-- eof insert work data
select 'sqlite3win count:';
select count(*) from sqlite3win;
-- select '<p>Import working data processes</p>';
-- .separator ";"
--.import .\\resources\\plugins\\sqlite3win\\import\\sqlite3winwork.csv sqlite3wintemp
-- .import .\\resources\\plugins\\sqlite3win\\import\\sqlite3winwork.csv sqlite3wintemp
-- .import .\\resources\\plugins\\sqlite3win\\blz-aktuell-txt-data.txt  sqlite3wintemp
-- select 'COUNT:'+count(*) from sqlite3wintemp;
-- INSERT INTO sqlite3win_data(first_name,name,zipcode, city, description) select first_name,name,zipcode, city, description  from sqlite3wintemp;
.separator ';'
.import '.\\resources\\plugins\\sqlite3win\\import\\menu.csv' sqlite3win_datatemp
-- select '<h6>Main menu importing done</h6>'; 
-- select '<p>sqlite3win_datatemp count:';
-- select count(*)  from sqlite3win_datatemp;
-- select '</p>';
-- INSERT INTO sqlite3win_Data (first_name,name, description,url) select name,name, menu,url  from sqlite3win_Datatemp;
-- INSERT INTO sqlite3win_data (first_name,name,zipcode, city, description,url) select substr( name, 0, 9 ),rtrim(substr( name, 10, 58 )), substr(name,68,71), substr(name,73,78), name,trim(substr( name, 140, 169))  from sqlite3win_datatemp;
INSERT INTO sqlite3win_data(first_name,name,zipcode, city, description) select first_name,name,zipcode, city, description  from sqlite3win_datatemp;
select '<p>sqlite3win count:';
select count(*) from sqlite3win;
select 'sqlite3win_data count:';
select count(*) from sqlite3win_data;
drop table IF EXISTS sqlite3wintemp;
-- select '<p>Import done</p>';
.exit