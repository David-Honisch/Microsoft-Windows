select '<h2>Import sqlite3win processes</h2>';
-- select '<p>drop plugin tables</p>';
drop table IF EXISTS sqlite3win;
drop table IF EXISTS sqlite3win_main;
drop table IF EXISTS sqlite3win_install;
drop table IF EXISTS sqlite3win_help;
drop table IF EXISTS sqlite3win_data;
drop table IF EXISTS sqlite3win_work;
drop table IF EXISTS sqlite3win_procdata;
drop table IF EXISTS sqlite3wintemp;
drop table IF EXISTS sqlite3win_datatemp;
drop table IF EXISTS sqlite3win_worktemp;

-- select '<p>create plugin tables</p>';
CREATE TABLE sqlite3win( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,  "url" TEXT NULL);
CREATE TABLE sqlite3win_main( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE sqlite3win_install( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE sqlite3win_help( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE sqlite3win_data( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE sqlite3win_work( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);

CREATE TABLE sqlite3win_procdata( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE IF NOT EXISTS sqlite3wintemp (
"name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "url" TEXT NULL
);
-- create table IF NOT EXISTS sqlite3win_datatemp ( name varchar(255));
-- CREATE TABLE IF NOT EXISTS sqlite3win_datatemp (
-- "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL
-- );
CREATE TABLE IF NOT EXISTS sqlite3win_datatemp( "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL, "url" TEXT NULL);
-- CREATE TABLE IF NOT EXISTS sqlite3win_worktemp (
-- "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL
-- );
--CREATE TABLE IF NOT EXISTS sqlite3win_worktemp( "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,"add1" TEXT NULL,"add2" TEXT NULL,"add3" TEXT NULL,  "url" TEXT NULL);
CREATE TABLE IF NOT EXISTS sqlite3win_worktemp( "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "url" TEXT NULL);
-- import menu
-- select '<p>Import processes</p>';
-- select '<p>start import to plugin tables</p>';
.separator ";"
--.import .\\resources\\plugins\\sqlite3win\\import\\import.csv sqlite3wintemp
-- INSERT INTO sqlite3win(first_name,name,zipcode, city, description) select first_name,name,zipcode, city, description  from sqlite3wintemp;
.import .\\resources\\plugins\\sqlite3win\\import\\import.csv sqlite3win
.import .\\resources\\plugins\\sqlite3win\\import\\main.csv sqlite3win_main
.import .\\resources\\plugins\\sqlite3win\\import\\install.csv sqlite3win_install
.import .\\resources\\plugins\\sqlite3win\\import\\help.csv sqlite3win_help
.import .\\resources\\plugins\\sqlite3win\\import\\data.csv sqlite3win_data
--.import .\\resources\\plugins\\sqlite3win\\import\\data.csv sqlite3win_work
--
.separator ","
.import '.\\resources\\plugins\\sqlite3win\\import\\work.csv' sqlite3win_worktemp
INSERT INTO sqlite3win_data(first_name,name,zipcode, description,url) select first_name,name,zipcode, description,url from sqlite3win_worktemp;
INSERT INTO sqlite3win_work(first_name,name,zipcode, description,url) select first_name,name,zipcode, description,url  from sqlite3win_worktemp;
-- eof insert work data
select 'sqlite3win_work count:';
select count(*) from sqlite3win_work;
-- eof insert work data
select 'sqlite3win count:';
select count(*) from sqlite3win;
select '<p>start data import to plugin tables</p>';
.separator ";"
--.import '.\\resources\\plugins\\sqlite3win\\import\\menu.csv' sqlite3win_datatemp
-- .import '.\\resources\\plugins\\sqlite3win\\import\\menu.csv' sqlite3win_datatemp
-- INSERT INTO sqlite3win_data(first_name,name,zipcode, city, description) select first_name,name,zipcode, city, description  from sqlite3win_datatemp;
-- .import '.\\resources\\plugins\\sqlite3win\\import\\menu.csv' sqlite3win_data
-- delete from sqlite3win_datatemp;
--
-- select '<p>start work data import to plugin tables</p>';
-- .separator ","
-- .import '.\\resources\\plugins\\sqlite3win\\import\\data.csv' sqlite3win_worktemp
-- INSERT INTO sqlite3win_work(first_name,name,zipcode, city, description) select first_name,name,zipcode, city, description  from sqlite3win_worktemp;
--
select 'sqlite3win_work count:';
select count(*) from sqlite3win_work;
-- .separator ","
-- .import '.\\resources\\plugins\\sqlite3win\\import\\sqlite3winwork.csv' sqlite3win_datatemp
-- INSERT INTO sqlite3win_procdata(first_name,name,zipcode, city, description) select first_name,name,zipcode, city, description  from sqlite3win_datatemp;
--
select '<p>sqlite3win count:';
select count(*) from sqlite3win;
select 'sqlite3win_data count:';
select count(*) from sqlite3win_data;
select 'sqlite3win_procdata count:';
select count(*) from sqlite3win_procdata;
.separator ";"
drop table IF EXISTS sqlite3wintemp;
-- select '<p>Import done</p>';
.exit