public class TestMe{

    public static final Class<TestMe> CLASS = TestMe.class;
    public static void main(String[] args) {

        System.out.println("Java "+CLASS.getName()+" is running...");
    }
}