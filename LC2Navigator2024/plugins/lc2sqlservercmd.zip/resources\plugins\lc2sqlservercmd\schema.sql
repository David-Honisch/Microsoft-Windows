-- select '<h2>Import processes</h2>';
drop table IF EXISTS lc2sqlservercmd;
drop table IF EXISTS lc2sqlservercmd_data;
drop table IF EXISTS lc2sqlservercmd_procdata;
-- drop table IF EXISTS lc2sqlservercmdtemp;
-- drop table IF EXISTS lc2sqlservercmd_datatemp;
CREATE TABLE lc2sqlservercmd( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE lc2sqlservercmd_data( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
-- CREATE TABLE lc2sqlservercmd_procdata( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
-- CREATE TABLE IF NOT EXISTS lc2sqlservercmdtemp (
-- "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL
-- );
-- create table IF NOT EXISTS lc2sqlservercmd_datatemp ( name varchar(255));
-- CREATE TABLE IF NOT EXISTS lc2sqlservercmd_datatemp (
-- "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL
-- );
-- import menu
-- select '<p>Import processes</p>';
.separator ";"
.import .\\resources\\plugins\\lc2sqlservercmd\\import\\import.csv lc2sqlservercmd
.import '.\\resources\\plugins\\lc2sqlservercmd\\import\\menu.csv' lc2sqlservercmd_data
-- delete from lc2sqlservercmd_datatemp;
--
-- .separator ","
-- .import '.\\resources\\plugins\\lc2sqlservercmd\\import\\lc2sqlservercmdwork.csv' lc2sqlservercmd_datatemp
-- INSERT INTO lc2sqlservercmd_procdata(first_name,name,zipcode, city, description) select first_name,name,zipcode, city, description  from lc2sqlservercmd_datatemp;

select '<p>lc2sqlservercmd count:';
select count(*) from lc2sqlservercmd;
select 'lc2sqlservercmd_data count:';
select count(*) from lc2sqlservercmd_data;
select 'lc2sqlservercmd_procdata count:';
select count(*) from lc2sqlservercmd_procdata;
.separator ";"
drop table IF EXISTS lc2sqlservercmdtemp;
-- select '<p>Import done</p>';
.exit