# DEPRECATED. Please go to [msphpsql](https://github.com/Microsoft/mssql-docker/tree/master/oss-drivers/msphpsql)

# PHP + SQL Server Runtime Environment

This image provides the latest version of the PHP drivers for SQL Server on an Ubuntu base-layer.

## Contributions

Feel free to contribute improvements to this image through pull requests.

