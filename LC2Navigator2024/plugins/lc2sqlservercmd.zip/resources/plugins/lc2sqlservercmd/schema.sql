select '<h2>Import lc2sqlservercmd processes</h2>';
-- select '<p>drop plugin tables</p>';
drop table IF EXISTS lc2sqlservercmd;
drop table IF EXISTS lc2sqlservercmd_main;
drop table IF EXISTS lc2sqlservercmd_install;
drop table IF EXISTS lc2sqlservercmd_help;
drop table IF EXISTS lc2sqlservercmd_data;
drop table IF EXISTS lc2sqlservercmd_work;
drop table IF EXISTS lc2sqlservercmd_procdata;
drop table IF EXISTS lc2sqlservercmdtemp;
drop table IF EXISTS lc2sqlservercmd_datatemp;
drop table IF EXISTS lc2sqlservercmd_worktemp;

-- select '<p>create plugin tables</p>';
CREATE TABLE lc2sqlservercmd( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,  "url" TEXT NULL);
CREATE TABLE lc2sqlservercmd_main( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE lc2sqlservercmd_install( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE lc2sqlservercmd_help( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE lc2sqlservercmd_data( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE lc2sqlservercmd_work( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);

CREATE TABLE lc2sqlservercmd_procdata( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE IF NOT EXISTS lc2sqlservercmdtemp (
"name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "url" TEXT NULL
);
-- create table IF NOT EXISTS lc2sqlservercmd_datatemp ( name varchar(255));
-- CREATE TABLE IF NOT EXISTS lc2sqlservercmd_datatemp (
-- "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL
-- );
CREATE TABLE IF NOT EXISTS lc2sqlservercmd_datatemp( "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL, "url" TEXT NULL);
-- CREATE TABLE IF NOT EXISTS lc2sqlservercmd_worktemp (
-- "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL
-- );
--CREATE TABLE IF NOT EXISTS lc2sqlservercmd_worktemp( "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,"add1" TEXT NULL,"add2" TEXT NULL,"add3" TEXT NULL,  "url" TEXT NULL);
CREATE TABLE IF NOT EXISTS lc2sqlservercmd_worktemp( "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "url" TEXT NULL);
-- import menu
-- select '<p>Import processes</p>';
-- select '<p>start import to plugin tables</p>';
.separator ";"
--.import .\\resources\\plugins\\lc2sqlservercmd\\import\\import.csv lc2sqlservercmdtemp
-- INSERT INTO lc2sqlservercmd(first_name,name,zipcode, city, description) select first_name,name,zipcode, city, description  from lc2sqlservercmdtemp;
.import .\\resources\\plugins\\lc2sqlservercmd\\import\\import.csv lc2sqlservercmd
.import .\\resources\\plugins\\lc2sqlservercmd\\import\\main.csv lc2sqlservercmd_main
.import .\\resources\\plugins\\lc2sqlservercmd\\import\\install.csv lc2sqlservercmd_install
.import .\\resources\\plugins\\lc2sqlservercmd\\import\\help.csv lc2sqlservercmd_help
.import .\\resources\\plugins\\lc2sqlservercmd\\import\\data.csv lc2sqlservercmd_data
--.import .\\resources\\plugins\\lc2sqlservercmd\\import\\data.csv lc2sqlservercmd_work
--
.separator ","
.import '.\\resources\\plugins\\lc2sqlservercmd\\import\\work.csv' lc2sqlservercmd_worktemp
INSERT INTO lc2sqlservercmd_data(first_name,name,zipcode, description,url) select first_name,name,zipcode, description,url from lc2sqlservercmd_worktemp;
INSERT INTO lc2sqlservercmd_work(first_name,name,zipcode, description,url) select first_name,name,zipcode, description,url  from lc2sqlservercmd_worktemp;
-- eof insert work data
select 'lc2sqlservercmd_work count:';
select count(*) from lc2sqlservercmd_work;
-- eof insert work data
select 'lc2sqlservercmd count:';
select count(*) from lc2sqlservercmd;
select '<p>start data import to plugin tables</p>';
.separator ";"
--.import '.\\resources\\plugins\\lc2sqlservercmd\\import\\menu.csv' lc2sqlservercmd_datatemp
-- .import '.\\resources\\plugins\\lc2sqlservercmd\\import\\menu.csv' lc2sqlservercmd_datatemp
-- INSERT INTO lc2sqlservercmd_data(first_name,name,zipcode, city, description) select first_name,name,zipcode, city, description  from lc2sqlservercmd_datatemp;
-- .import '.\\resources\\plugins\\lc2sqlservercmd\\import\\menu.csv' lc2sqlservercmd_data
-- delete from lc2sqlservercmd_datatemp;
--
-- select '<p>start work data import to plugin tables</p>';
-- .separator ","
-- .import '.\\resources\\plugins\\lc2sqlservercmd\\import\\data.csv' lc2sqlservercmd_worktemp
-- INSERT INTO lc2sqlservercmd_work(first_name,name,zipcode, city, description) select first_name,name,zipcode, city, description  from lc2sqlservercmd_worktemp;
--
select 'lc2sqlservercmd_work count:';
select count(*) from lc2sqlservercmd_work;
-- .separator ","
-- .import '.\\resources\\plugins\\lc2sqlservercmd\\import\\lc2sqlservercmdwork.csv' lc2sqlservercmd_datatemp
-- INSERT INTO lc2sqlservercmd_procdata(first_name,name,zipcode, city, description) select first_name,name,zipcode, city, description  from lc2sqlservercmd_datatemp;
--
select '<p>lc2sqlservercmd count:';
select count(*) from lc2sqlservercmd;
select 'lc2sqlservercmd_data count:';
select count(*) from lc2sqlservercmd_data;
select 'lc2sqlservercmd_procdata count:';
select count(*) from lc2sqlservercmd_procdata;
.separator ";"
drop table IF EXISTS lc2sqlservercmdtemp;
-- select '<p>Import done</p>';
.exit