This blog https://techcommunity.microsoft.com/t5/sql-server/near-real-time-monitoring-of-sql-server-linux-containers-using/ba-p/2620050 has the details you can review to setup near real time monitoring for SQL Server on Linux/Containers. We are going to setup the monitoring using the Telegraf-InfluxDB and Grafana.















