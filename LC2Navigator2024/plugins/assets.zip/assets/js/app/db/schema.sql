CREATE TABLE "systables" (
	"person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
	"created" TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
	"modified" TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
	"enddate" TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
	"name" TEXT NOT NULL,
	"first_name" TEXT NULL,
	"last_name" TEXT NULL,
	"description" TEXT NULL,
	"zipcode" TEXT NULL,
	"city" TEXT NULL,
	"street" TEXT NULL,
	"url" TEXT NULL
);
CREATE TABLE "params" (
	"person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
	"created" TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
	"modified" TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
	"enddate" TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
	"name" TEXT NOT NULL,
	"first_name" TEXT NULL,
	"last_name" TEXT NULL,
	"description" TEXT NULL,
	"zipcode" TEXT NULL,
	"city" TEXT NULL,
	"street" TEXT NULL,
	"url" TEXT NULL
);

CREATE TABLE "plugins" (
	"person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
	"created" TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
	"modified" TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
	"enddate" TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
	"name" TEXT NOT NULL,
	"first_name" TEXT NULL,
	"last_name" TEXT NULL,
	"description" TEXT NULL,
	"zipcode" TEXT NULL,
	"city" TEXT NULL,
	"street" TEXT NULL,
	"url" TEXT NULL
);

CREATE TABLE "importscripts" (
	"person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
	"created" TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
	"modified" TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
	"enddate" TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
	"name" TEXT NOT NULL,
	"first_name" TEXT NULL,
	"last_name" TEXT NULL,
	"description" TEXT NULL,
	"zipcode" TEXT NULL,
	"city" TEXT NULL,
	"street" TEXT NULL,
	"url" TEXT NULL
);

CREATE TABLE "api" (
	"person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
	"created" TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
	"modified" TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
	"enddate" TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
	"name" TEXT NOT NULL,
	"first_name" TEXT NULL,
	"last_name" TEXT NULL,
	"description" TEXT NULL,
	"zipcode" TEXT NULL,
	"city" TEXT NULL,
	"street" TEXT NULL,
	"url" TEXT NULL
);

CREATE TABLE "application" (
	"person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
	"created" TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
	"modified" TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
	"enddate" TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
	"name" TEXT NOT NULL,
	"first_name" TEXT NULL,
	"last_name" TEXT NULL,
	"description" TEXT NULL,
	"zipcode" TEXT NULL,
	"city" TEXT NULL,
	"street" TEXT NULL,
	"url" TEXT NULL
);

CREATE TABLE "batch" (
	"person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
	"created" TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
	"modified" TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
	"enddate" TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
	"name" TEXT NOT NULL,
	"first_name" TEXT NULL,
	"last_name" TEXT NULL,
	"description" TEXT NULL,
	"zipcode" TEXT NULL,
	"city" TEXT NULL,
	"street" TEXT NULL,
	"url" TEXT NULL
);

CREATE TABLE "cheats" (
	"person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
	"created" TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
	"modified" TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
	"enddate" TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
	"name" TEXT NOT NULL,
	"first_name" TEXT NULL,
	"last_name" TEXT NULL,
	"description" TEXT NULL,
	"zipcode" TEXT NULL,
	"city" TEXT NULL,
	"street" TEXT NULL,
	"url" TEXT NULL
);

CREATE TABLE "dropdowns" (
	"person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
	"created" TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
	"modified" TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
	"enddate" TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
	"name" TEXT NOT NULL,
	"first_name" TEXT NULL,
	"last_name" TEXT NULL,
	"description" TEXT NULL,
	"zipcode" TEXT NULL,
	"city" TEXT NULL,
	"street" TEXT NULL,
	"url" TEXT NULL
);

CREATE TABLE "games" (
	"person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
	"created" TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
	"modified" TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
	"enddate" TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
	"name" TEXT NOT NULL,
	"first_name" TEXT NULL,
	"last_name" TEXT NULL,
	"description" TEXT NULL,
	"zipcode" TEXT NULL,
	"city" TEXT NULL,
	"street" TEXT NULL,
	"url" TEXT NULL
);

CREATE TABLE "movies" (
	"person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
	"created" TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
	"modified" TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
	"enddate" TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
	"name" TEXT NOT NULL,
	"first_name" TEXT NULL,
	"last_name" TEXT NULL,
	"description" TEXT NULL,
	"zipcode" TEXT NULL,
	"city" TEXT NULL,
	"street" TEXT NULL,
	"url" TEXT NULL
);

CREATE TABLE "music" (
	"person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
	"created" TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
	"modified" TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
	"enddate" TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
	"name" TEXT NOT NULL,
	"first_name" TEXT NULL,
	"last_name" TEXT NULL,
	"description" TEXT NULL,
	"zipcode" TEXT NULL,
	"city" TEXT NULL,
	"street" TEXT NULL,
	"url" TEXT NULL
);

CREATE TABLE "exe" (
	"person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
	"created" TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
	"modified" TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
	"enddate" TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
	"name" TEXT NOT NULL,
	"first_name" TEXT NULL,
	"last_name" TEXT NULL,
	"description" TEXT NULL,
	"zipcode" TEXT NULL,
	"city" TEXT NULL,
	"street" TEXT NULL,
	"url" TEXT NULL
);

CREATE TABLE "radio" (
	"person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
	"created" TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
	"modified" TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
	"enddate" TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
	"name" TEXT NOT NULL,
	"first_name" TEXT NULL,
	"last_name" TEXT NULL,
	"description" TEXT NULL,
	"zipcode" TEXT NULL,
	"city" TEXT NULL,
	"street" TEXT NULL,
	"url" TEXT NULL
);

CREATE TABLE "tv" (
	"person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
	"created" TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
	"modified" TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
	"enddate" TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
	"name" TEXT NOT NULL,
	"first_name" TEXT NULL,
	"last_name" TEXT NULL,
	"description" TEXT NULL,
	"zipcode" TEXT NULL,
	"city" TEXT NULL,
	"street" TEXT NULL,
	"url" TEXT NULL
);

CREATE TABLE "apptools" (
	"person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
	"created" TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
	"modified" TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
	"enddate" TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
	"name" TEXT NOT NULL,
	"first_name" TEXT NULL,
	"last_name" TEXT NULL,
	"description" TEXT NULL,
	"zipcode" TEXT NULL,
	"city" TEXT NULL,
	"street" TEXT NULL,
	"url" TEXT NULL
);

CREATE TABLE "ebooks" (
	"person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
	"created" TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
	"modified" TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
	"enddate" TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
	"name" TEXT NOT NULL,
	"first_name" TEXT NULL,
	"last_name" TEXT NULL,
	"description" TEXT NULL,
	"zipcode" TEXT NULL,
	"city" TEXT NULL,
	"street" TEXT NULL,
	"url" TEXT NULL
);

CREATE TABLE "other" (
	"person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
	"created" TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
	"modified" TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
	"enddate" TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
	"name" TEXT NOT NULL,
	"first_name" TEXT NULL,
	"last_name" TEXT NULL,
	"description" TEXT NULL,
	"zipcode" TEXT NULL,
	"city" TEXT NULL,
	"street" TEXT NULL,
	"url" TEXT NULL
);

CREATE TABLE "people" (
	"person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
	"created" TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
	"modified" TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
	"enddate" TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
	"name" TEXT NOT NULL,
	"first_name" TEXT NULL,
	"last_name" TEXT NULL,
	"description" TEXT NULL,
	"zipcode" TEXT NULL,
	"city" TEXT NULL,
	"street" TEXT NULL,
	"url" TEXT NULL
);

CREATE TABLE "services" (
	"person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
	"created" TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
	"modified" TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
	"enddate" TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
	"name" TEXT NOT NULL,
	"first_name" TEXT NULL,
	"last_name" TEXT NULL,
	"description" TEXT NULL,
	"zipcode" TEXT NULL,
	"city" TEXT NULL,
	"street" TEXT NULL,
	"url" TEXT NULL
);

INSERT INTO `PEOPLE` (
	NAME,
	URL
) VALUES (
	"John Doe",
	"https://www.letztechance.org"
),
(
	"Jane Doe",
	"https://www.letztechance.org"
);

INSERT INTO `OTHER` (
	NAME,
	URL
) VALUES (
	"LCAdressbookSQLite.exe",
	"LCAdressbookSQLite.exe"
);

INSERT INTO `APPLICATION` (
	NAME,
	FIRST_NAME,
	URL
) VALUES (
	"Menu v.1.0",
	"Menu v.1.0",
	"getXML('menu.xml', 'menu.xslt', 'out');"
);

-- INSERT INTO `application`
-- VALUES
-- (NULL, "C:\Windows\System32\inetsrv\iis.msc", "C:\Windows\System32\inetsrv\iis.msc","","","","execCMD('C:\\Windows\\System32\\inetsrv\\iis.msc','out');");




INSERT INTO `APPTOOLS` (
	NAME,
	FIRST_NAME,
	URL
) VALUES (
	"explorer.exe",
	"explorer.exe",
	"execCMD('explorer.exe','out');"
);

INSERT INTO `APPTOOLS` (
	NAME,
	FIRST_NAME,
	URL
) VALUES (
	"adsiedit.msc",
	"adsiedit.msc",
	"execCMD('adsiedit.msc', 'out');"
);

INSERT INTO `APPTOOLS` (
	NAME,
	FIRST_NAME,
	URL
) VALUES (
	"azman.msc",
	"azman.msc",
	"execCMD('azman.msc', 'out');"
);

INSERT INTO `APPTOOLS` (
	NAME,
	FIRST_NAME,
	URL
) VALUES (
	"certlm.msc",
	"certlm.msc",
	"execCMD('certlm.msc', 'out');"
);

INSERT INTO `APPTOOLS` (
	NAME,
	FIRST_NAME,
	URL
) VALUES (
	"certmgr.msc",
	"certlm.msc",
	"execCMD('certmgr.msc', 'out');"
);

INSERT INTO `APPTOOLS` (
	NAME,
	FIRST_NAME,
	URL
) VALUES (
	"certlm.msc",
	"certlm.msc",
	"execCMD('certmgr.msc', 'out');"
);

INSERT INTO `APPTOOLS` (
	NAME,
	FIRST_NAME,
	URL
) VALUES (
	"diskmgmt.msc",
	"diskmgmt.msc",
	"execCMD('diskmgmt.msc', 'out');"
);

INSERT INTO `APPTOOLS` (
	NAME,
	FIRST_NAME,
	URL
) VALUES (
	"compmgmt.msc",
	"compmgmt.msc",
	"execCMD('compmgmt.msc', 'out');"
);

INSERT INTO `APPTOOLS` (
	NAME,
	FIRST_NAME,
	URL
) VALUES (
	"certmgr.msc",
	"eventvwr.msc",
	"execCMD('eventvwr.msc', 'out');"
);

INSERT INTO `APPTOOLS` (
	NAME,
	FIRST_NAME,
	URL
) VALUES (
	"fsmgmt.msc",
	"fsmgmt.msc",
	"execCMD('fsmgmt.msc', 'out');"
);

INSERT INTO `APPTOOLS` (
	NAME,
	FIRST_NAME,
	URL
) VALUES (
	"WmiMgmt.msc",
	"WmiMgmt.msc",
	"execCMD('WmiMgmt.msc', 'out');"
);

INSERT INTO `APPTOOLS` (
	NAME,
	FIRST_NAME,
	URL
) VALUES (
	"certmgr.msc",
	"virtmgmt.msc",
	"execCMD('virtmgmt.msc', 'out');"
);

INSERT INTO `APPTOOLS` (
	NAME,
	FIRST_NAME,
	URL
) VALUES (
	"tpm.msc",
	"tpm.msc",
	"execCMD('tpm.msc', 'out');"
);

INSERT INTO `APPTOOLS` (
	NAME,
	FIRST_NAME,
	URL
) VALUES (
	"taskschd.msc",
	"taskschd.msc",
	"execCMD('taskschd.msc', 'out');"
);

INSERT INTO `APPTOOLS` (
	NAME,
	FIRST_NAME,
	URL
) VALUES (
	"services.msc",
	"services.msc",
	"execCMD('services.msc','out');"
);

INSERT INTO `APPTOOLS` (
	NAME,
	FIRST_NAME,
	URL
) VALUES (
	"dmsys.cpl",
	"dmsys.cpl",
	"execCMD('dmsys.cpl','out');"
);

INSERT INTO `APPTOOLS` (
	NAME,
	FIRST_NAME,
	URL
) VALUES (
	"iis.msc",
	"iis.msc",
	"execCMD('C:\\Windows\\System32\\inetsrv\\iis.msc','out');"
);

INSERT INTO `GAMES` (
	NAME,
	FIRST_NAME,
	URL
) VALUES (
	"calc.exe",
	"calculator",
	"execCMD('calc.exe','out');"
);

INSERT INTO `CHEATS` (
	NAME,
	FIRST_NAME,
	URL
) VALUES (
	"Pong",
	"Pong",
	"alert('Pong');"
);

INSERT INTO `EBOOKS` (
	NAME,
	FIRST_NAME,
	URL
) VALUES (
	"Stephen King",
	"Firechild",
	"alert('Stephen King Firechild');"
);

INSERT INTO `MOVIES` (
	NAME,
	FIRST_NAME,
	URL
) VALUES (
	"Star Wars - Krieg der Sterne",
	"Star Wars - Krieg der Sterne",
	"execCMD('start https://www.imdb.com/title/tt0076759/','out');"
);

INSERT INTO `MUSIC` (
	NAME,
	FIRST_NAME,
	URL
) VALUES (
	"Beyonce",
	"Beyonce",
	"Beyonce"
);

INSERT INTO `SERVICES` (
	NAME,
	FIRST_NAME,
	URL
) VALUES (
	"services.msc",
	"services.msc",
	"execCMD('services.msc','out');"
);

INSERT INTO `BATCH` (
	NAME,
	FIRST_NAME,
	URL
) VALUES (
	"Menu",
	"Menu",
	"getXML('menu.xml', 'menu.xslt', 'out');"
);

INSERT INTO `EXE` (
	NAME,
	FIRST_NAME,
	URL
) VALUES (
	"Menu",
	"Menu",
	"getXML('menu.xml', 'menu.xslt', 'out');"
);

INSERT INTO `OTHER` (
	NAME,
	FIRST_NAME,
	URL
) VALUES (
	"Menu",
	"Menu",
	"getXML('menu.xml', 'menu.xslt', 'out');"
);

INSERT INTO `IMPORTSCRIPTS` (
	NAME,
	FIRST_NAME,
	URL
) VALUES (
	"Menu",
	"Menu",
	"getXML('menu.xml', 'menu.xslt', 'out');"
),
(
	"_Clear",
	"echo.",
	"echo."
);

-- INSERT INTO plugins VALUES(1,'All Plugins Downloader v.0.001','All Plugins Downloader v.0.001 Plugin Downloader',NULL,NULL,NULL,NULL,'execCMD(\'exec .\\resources\\cmd\\getupdates.bat /plugins/all.zip all.zip\', \'out\');');
INSERT INTO PLUGINS (
	NAME,
	FIRST_NAME,
	URL
) VALUES(
	"All Plugins Downloader v.1.12b",
	"All Plugins Downloader v.1.12b Plugin Downloader",
	"execCMD('exec .\\resources\\cmd\\getupdates.bat https://raw.githubusercontent.com/David-Honisch/Microsoft-Windows/master/LC2Navigator2024/ /plugins/all.zip all.zip', 'out');"
);

-- INSERT INTO plugins VALUES(2,'Core SQLITE 3 Downloader v.0.0012','Core SQLITE 3 Update v.0.0012',NULL,NULL,NULL,NULL,'execCMD(\'exec  .\\resources\\cmd\\checksqlite3.bat\', \'out\');');
-- INSERT INTO plugins VALUES(2,'All Plugins Downloader v.0.001','All Plugins Downloader v.0.001 Plugin Downloader',NULL,NULL,NULL,NULL,'exec .\\resources\\cmd\\getupdates.bat /plugins/all.zip all.zip');
-- INSERT INTO plugins VALUES(3,'Core Plugin Downloader v.0.001','Core v.0.001 Plugin Downloader',NULL,NULL,NULL,NULL,'exec .\\resources\\cmd\\getupdates.bat /plugins/core.zip core.zip');
-- INSERT INTO plugins VALUES(3,'Grab Url Plugin Downloader v.0.001','Grab Url v.0.001 Plugin Downloader',NULL,NULL,NULL,NULL,'.\\resources\\cmd\\getupdates.bat /plugins/graburls.zip graburls.zip');
-- INSERT INTO plugins VALUES(4,'GrabAndImportUrls Plugin Downloader v.0.001','GrabAndImportUrls',NULL,NULL,NULL,NULL,'.\\resources\\cmd\\getupdates.bat /plugins/grabandimporturls.zip grabandimporturls.zip');
-- INSERT INTO plugins VALUES(5,'Excel Import/Export Plugin Downloader v.0.001','GrabAndImportUrls',NULL,NULL,NULL,NULL,'.\\resources\\cmd\\getupdates.bat /plugins/excelimport.zip excelimport.zip');
-- INSERT INTO plugins VALUES(6,'Emulator Plugin Downloader v.0.001','Atari JS Emulator Plugin Downloader',NULL,NULL,NULL,NULL,'.\\resources\\cmd\\getupdates.bat /plugins/atariemulator.zip atariemulator.zip');

INSERT INTO `SYSTABLES` (
	NAME,
	FIRST_NAME,
	URL
) VALUES (
	"api",
	"Menu",
	"getXML('menu.xml', 'menu.xslt', 'out');"
),
(
	"application",
	"Menu",
	"getXML('menu.xml', 'menu.xslt', 'out');"
),
(
	"plugins",
	"Menu",
	"getXML('menu.xml', 'menu.xslt', 'out');"
),
(
	"systables",
	"Menu",
	"getXML('menu.xml', 'menu.xslt', 'out');"
),
(
	"importscripts",
	"Menu",
	"getXML('menu.xml', 'menu.xslt', 'out');"
),
(
	"apptools",
	"Menu",
	"getXML('menu.xml', 'menu.xslt', 'out');"
),
(
	"books",
	"Menu",
	"getXML('menu.xml', 'menu.xslt', 'out');"
),
(
	"games",
	"Menu",
	"getXML('menu.xml', 'menu.xslt', 'out');"
),
(
	"movies",
	"Menu",
	"getXML('menu.xml', 'menu.xslt', 'out');"
),
(
	"music",
	"Menu",
	"getXML('menu.xml', 'menu.xslt', 'out');"
),
(
	"people",
	"Menu",
	"getXML('menu.xml', 'menu.xslt', 'out');"
),
(
	"urls",
	"Menu",
	"getXML('menu.xml', 'menu.xslt', 'out');"
),
(
	"params",
	"Menu",
	"getXML('menu.xml', 'menu.xslt', 'out');"
),
(
	"other",
	"Menu",
	"getXML('menu.xml', 'menu.xslt', 'out');"
);

CREATE INDEX "first_name_index" ON PEOPLE (
	"first_name" COLLATE NOCASE ASC
);

CREATE INDEX "name_index" ON PEOPLE (
	"name" COLLATE NOCASE ASC
);

CREATE INDEX "application_name_index" ON APPLICATION (
	"name" COLLATE NOCASE ASC
);

INSERT INTO `API` (
	NAME,
	FIRST_NAME,
	URL
) VALUES (
	"explorer.exe",
	"explorer.exe",
	"execCMD('explorer.exe','out');"
);

INSERT INTO `DROPDOWNS` (
	FIRST_NAME,
	NAME,
	URL
) VALUES (
	"explorer1.exe",
	"explorer.exe",
	"execCMD('explorer.exe','out');"
),
(
	"explorer2.exe",
	"Open windows folder",
	"execCMD('explorer.exe .\\resources\\plugins\\%plugin%','out');"
),
(
	"explorer2.exe",
	"Open windows folder",
	"execCMD('explorer.exe %windir%','out');"
),
(
	"explorer3.exe",
	"explorer.exe",
	"execCMD('explorer.exe','out');"
),
(
	"explorer4.exe",
	"explorer.exe",
	"execCMD('explorer.exe','out');"
),
(
	"explorer5.exe",
	"explorer.exe",
	"execCMD('explorer.exe','out');"
);

-- # for completeness lets do the routine thing of connections and cursors
-- conn = sqlite3.connect(db_file, timeout=1000)

-- cursor = conn.cursor()

-- # get the count of tables with the name
-- tablename = 'KABOOM'
-- cursor.execute("SELECT count(name) FROM sqlite_master WHERE type='table' AND name=? ", (tablename, ))

-- print(cursor.fetchone()) # this SHOULD BE in a tuple containing count(name) integer.

-- # check if the db has existing table named KABOOM
-- # if the count is 1, then table exists
-- if cursor.fetchone()[0] ==1 :
-- print('Table exists. I can do my custom stuff here now.... ')
-- pass
-- else:
-- # then table doesn't exist.
-- custRET = myCustFunc(foo,bar) # replace this with your custom logic