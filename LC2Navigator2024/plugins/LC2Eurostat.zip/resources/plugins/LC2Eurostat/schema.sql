select '<h2>Import LC2Eurostat processes</h2>';
-- select '<p>drop plugin tables</p>';
drop table IF EXISTS LC2Eurostat;
drop table IF EXISTS LC2Eurostat_main;
drop table IF EXISTS LC2Eurostat_install;
drop table IF EXISTS LC2Eurostat_help;
drop table IF EXISTS LC2Eurostat_data;
drop table IF EXISTS LC2Eurostat_work;
drop table IF EXISTS LC2Eurostat_procdata;
drop table IF EXISTS LC2Eurostattemp;
drop table IF EXISTS LC2Eurostat_datatemp;
drop table IF EXISTS LC2Eurostat_worktemp;

-- select '<p>create plugin tables</p>';
CREATE TABLE LC2Eurostat( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,  "url" TEXT NULL);
CREATE TABLE LC2Eurostat_main( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE LC2Eurostat_install( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE LC2Eurostat_help( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE LC2Eurostat_data( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE LC2Eurostat_work( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);

CREATE TABLE LC2Eurostat_procdata( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE IF NOT EXISTS LC2Eurostattemp (
"name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "url" TEXT NULL
);
-- create table IF NOT EXISTS LC2Eurostat_datatemp ( name varchar(255));
-- CREATE TABLE IF NOT EXISTS LC2Eurostat_datatemp (
-- "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL
-- );
CREATE TABLE IF NOT EXISTS LC2Eurostat_datatemp( "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL, "url" TEXT NULL);
-- CREATE TABLE IF NOT EXISTS LC2Eurostat_worktemp (
-- "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL
-- );
--CREATE TABLE IF NOT EXISTS LC2Eurostat_worktemp( "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,"add1" TEXT NULL,"add2" TEXT NULL,"add3" TEXT NULL,  "url" TEXT NULL);
CREATE TABLE IF NOT EXISTS LC2Eurostat_worktemp( "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "url" TEXT NULL);
-- import menu
-- select '<p>Import processes</p>';
-- select '<p>start import to plugin tables</p>';
.separator ";"
--.import .\\resources\\plugins\\LC2Eurostat\\import\\import.csv LC2Eurostattemp
-- INSERT INTO LC2Eurostat(first_name,name,zipcode, city, description) select first_name,name,zipcode, city, description  from LC2Eurostattemp;
.import .\\resources\\plugins\\LC2Eurostat\\import\\import.csv LC2Eurostat
.import .\\resources\\plugins\\LC2Eurostat\\import\\main.csv LC2Eurostat_main
.import .\\resources\\plugins\\LC2Eurostat\\import\\install.csv LC2Eurostat_install
.import .\\resources\\plugins\\LC2Eurostat\\import\\help.csv LC2Eurostat_help
.import .\\resources\\plugins\\LC2Eurostat\\import\\data.csv LC2Eurostat_data
.import .\\resources\\plugins\\LC2Eurostat\\import\\work.csv LC2Eurostat_work
--
--.separator ","
--.import '.\\resources\\plugins\\LC2Eurostat\\import\\work.csv' LC2Eurostat_worktemp
--INSERT INTO LC2Eurostat_data(first_name,name,zipcode, description,url) select first_name,name,zipcode, description,url from LC2Eurostat_worktemp;
--INSERT INTO LC2Eurostat_work(first_name,name,zipcode, description,url) select first_name,name,zipcode, description,url  from LC2Eurostat_worktemp;
-- eof insert work data
select 'LC2Eurostat_work count:';
select count(*) from LC2Eurostat_work;
-- eof insert work data
select 'LC2Eurostat count:';
select count(*) from LC2Eurostat;
select '<p>start data import to plugin tables</p>';
.separator ";"
--.import '.\\resources\\plugins\\LC2Eurostat\\import\\menu.csv' LC2Eurostat_datatemp
-- .import '.\\resources\\plugins\\LC2Eurostat\\import\\menu.csv' LC2Eurostat_datatemp
-- INSERT INTO LC2Eurostat_data(first_name,name,zipcode, city, description) select first_name,name,zipcode, city, description  from LC2Eurostat_datatemp;
-- .import '.\\resources\\plugins\\LC2Eurostat\\import\\menu.csv' LC2Eurostat_data
-- delete from LC2Eurostat_datatemp;
--
-- select '<p>start work data import to plugin tables</p>';
-- .separator ","
-- .import '.\\resources\\plugins\\LC2Eurostat\\import\\data.csv' LC2Eurostat_worktemp
-- INSERT INTO LC2Eurostat_work(first_name,name,zipcode, city, description) select first_name,name,zipcode, city, description  from LC2Eurostat_worktemp;
--
select 'LC2Eurostat_work count:';
select count(*) from LC2Eurostat_work;
-- .separator ","
-- .import '.\\resources\\plugins\\LC2Eurostat\\import\\LC2Eurostatwork.csv' LC2Eurostat_datatemp
-- INSERT INTO LC2Eurostat_procdata(first_name,name,zipcode, city, description) select first_name,name,zipcode, city, description  from LC2Eurostat_datatemp;
--
select '<p>LC2Eurostat count:';
select count(*) from LC2Eurostat;
select 'LC2Eurostat_data count:';
select count(*) from LC2Eurostat_data;
select 'LC2Eurostat_procdata count:';
select count(*) from LC2Eurostat_procdata;
.separator ";"
drop table IF EXISTS LC2Eurostattemp;
-- select '<p>Import done</p>';
.exit