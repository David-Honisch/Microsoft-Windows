try {
  document.getElementById('appcnt').innerHTML = '';
  document.getElementById('modcnt').innerHTML = '';
  for (let v in installDirectories) {
    createDir(installDirectories[v]);
  }
  var opath = window.nodeRequire('path');
  let resDir = opath.join(__dirname, '../../resources/');
  let pluginDir = opath.join(__dirname, `../../resources/plugins/${pluginName}/`);
  let downloadDir = opath.join(__dirname, '../../');
  console.log(resDir);
  console.log(pluginDir);
  console.log(downloadDir);
  // InstallModules(resDir);
  Install_Modules(corelibs, resDir, 'modcnt');


  doDownload(downloadUrls, pluginDir);
  execCMD(`.\\resources\\plugins\\${pluginName}\\mvninstall.bat install`, 'mvncnt');

  // DoUnzip(downloadUrls, targetDir);
} catch (e) {
  alert(e.stack);
}
