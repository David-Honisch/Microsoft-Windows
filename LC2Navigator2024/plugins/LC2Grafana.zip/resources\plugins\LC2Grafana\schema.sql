select '<h4>LC2Grafana Plugin SQL Import</h4>';
drop table IF EXISTS LC2Grafana;
drop table IF EXISTS LC2Grafanatemp;
CREATE TABLE LC2Grafana ( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
create table IF NOT EXISTS LC2Grafanatemp ( name TEXT, url TEXT, type TEXT, tpid TEXT, mem TEXT);
-- .separator "\t"
-- .import .\\import.csv LC2Grafanatemp
.separator ";"
.import .\\resources\\plugins\\LC2Grafana\\import\\default.csv LC2Grafanatemp
.import .\\resources\\plugins\\LC2Grafana\\import\\import.csv LC2Grafanatemp
--.import ..\\import\\materialnohead.csv url
-- DELETE FROM url where url.name = '';
INSERT INTO LC2Grafana (first_name,name, url) select name,name,url from LC2Grafanatemp;
select '<p>LC2Grafana count:';
select count(*) from LC2Grafana;
select '</p>';
-- select '<p>COUNT:'+count(*)+'</p>' from LC2Grafana;
-- select '<p>SQL Menu:</p><br>';
-- select '';
-- select '<hr>';
-- select '<a href="'+url+'">'+name+'</a>' from LC2Grafana;
-- select '<hr>';
-- select '<p>LC2Grafana count:'+count(*)+' successfully imported.</p>' from LC2Grafana;
.exit