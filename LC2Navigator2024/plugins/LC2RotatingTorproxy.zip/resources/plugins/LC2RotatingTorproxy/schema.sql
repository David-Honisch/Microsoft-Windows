select '<h2>Import LC2RotatingTorproxy processes</h2>';
-- select '<p>drop plugin tables</p>';
drop table IF EXISTS LC2RotatingTorproxy;
drop table IF EXISTS LC2RotatingTorproxy_main;
drop table IF EXISTS LC2RotatingTorproxy_install;
drop table IF EXISTS LC2RotatingTorproxy_help;
drop table IF EXISTS LC2RotatingTorproxy_data;
drop table IF EXISTS LC2RotatingTorproxy_work;
drop table IF EXISTS LC2RotatingTorproxy_procdata;
drop table IF EXISTS LC2RotatingTorproxytemp;
drop table IF EXISTS LC2RotatingTorproxy_datatemp;
drop table IF EXISTS LC2RotatingTorproxy_worktemp;

-- select '<p>create plugin tables</p>';
CREATE TABLE LC2RotatingTorproxy( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,  "url" TEXT NULL);
CREATE TABLE LC2RotatingTorproxy_main( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE LC2RotatingTorproxy_install( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE LC2RotatingTorproxy_help( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE LC2RotatingTorproxy_data( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE LC2RotatingTorproxy_work( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);

CREATE TABLE LC2RotatingTorproxy_procdata( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE IF NOT EXISTS LC2RotatingTorproxytemp (
"name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "url" TEXT NULL
);
-- create table IF NOT EXISTS LC2RotatingTorproxy_datatemp ( name varchar(255));
-- CREATE TABLE IF NOT EXISTS LC2RotatingTorproxy_datatemp (
-- "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL
-- );
CREATE TABLE IF NOT EXISTS LC2RotatingTorproxy_datatemp( "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL, "url" TEXT NULL);
-- CREATE TABLE IF NOT EXISTS LC2RotatingTorproxy_worktemp (
-- "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL
-- );
--CREATE TABLE IF NOT EXISTS LC2RotatingTorproxy_worktemp( "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,"add1" TEXT NULL,"add2" TEXT NULL,"add3" TEXT NULL,  "url" TEXT NULL);
CREATE TABLE IF NOT EXISTS LC2RotatingTorproxy_worktemp( "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "url" TEXT NULL);
-- import menu
-- select '<p>Import processes</p>';
-- select '<p>start import to plugin tables</p>';
.separator ";"
--.import .\\resources\\plugins\\LC2RotatingTorproxy\\import\\import.csv LC2RotatingTorproxytemp
-- INSERT INTO LC2RotatingTorproxy(first_name,name,zipcode, city, description) select first_name,name,zipcode, city, description  from LC2RotatingTorproxytemp;
.import .\\resources\\plugins\\LC2RotatingTorproxy\\import\\import.csv LC2RotatingTorproxy
.import .\\resources\\plugins\\LC2RotatingTorproxy\\import\\main.csv LC2RotatingTorproxy_main
.import .\\resources\\plugins\\LC2RotatingTorproxy\\import\\install.csv LC2RotatingTorproxy_install
.import .\\resources\\plugins\\LC2RotatingTorproxy\\import\\help.csv LC2RotatingTorproxy_help
.import .\\resources\\plugins\\LC2RotatingTorproxy\\import\\data.csv LC2RotatingTorproxy_data
.import .\\resources\\plugins\\LC2RotatingTorproxy\\import\\data.csv LC2RotatingTorproxy_work
--
-- .separator ","
-- .import '.\\resources\\plugins\\LC2RotatingTorproxy\\import\\work.csv' LC2RotatingTorproxy_worktemp
-- INSERT INTO LC2RotatingTorproxy_data(first_name,name,zipcode, description,url) select first_name,name,zipcode, description,url from LC2RotatingTorproxy_worktemp;
-- INSERT INTO LC2RotatingTorproxy_work(first_name,name,zipcode, description,url) select first_name,name,zipcode, description,url  from LC2RotatingTorproxy_worktemp;
-- eof insert work data
select 'LC2RotatingTorproxy_work count:';
select count(*) from LC2RotatingTorproxy_work;
-- eof insert work data
select 'LC2RotatingTorproxy count:';
select count(*) from LC2RotatingTorproxy;
select '<p>start data import to plugin tables</p>';
.separator ";"
--.import '.\\resources\\plugins\\LC2RotatingTorproxy\\import\\menu.csv' LC2RotatingTorproxy_datatemp
-- .import '.\\resources\\plugins\\LC2RotatingTorproxy\\import\\menu.csv' LC2RotatingTorproxy_datatemp
-- INSERT INTO LC2RotatingTorproxy_data(first_name,name,zipcode, city, description) select first_name,name,zipcode, city, description  from LC2RotatingTorproxy_datatemp;
-- .import '.\\resources\\plugins\\LC2RotatingTorproxy\\import\\menu.csv' LC2RotatingTorproxy_data
-- delete from LC2RotatingTorproxy_datatemp;
--
-- select '<p>start work data import to plugin tables</p>';
-- .separator ","
-- .import '.\\resources\\plugins\\LC2RotatingTorproxy\\import\\data.csv' LC2RotatingTorproxy_worktemp
-- INSERT INTO LC2RotatingTorproxy_work(first_name,name,zipcode, city, description) select first_name,name,zipcode, city, description  from LC2RotatingTorproxy_worktemp;
--
select 'LC2RotatingTorproxy_work count:';
select count(*) from LC2RotatingTorproxy_work;
-- .separator ","
-- .import '.\\resources\\plugins\\LC2RotatingTorproxy\\import\\LC2RotatingTorproxywork.csv' LC2RotatingTorproxy_datatemp
-- INSERT INTO LC2RotatingTorproxy_procdata(first_name,name,zipcode, city, description) select first_name,name,zipcode, city, description  from LC2RotatingTorproxy_datatemp;
--
select '<p>LC2RotatingTorproxy count:';
select count(*) from LC2RotatingTorproxy;
select 'LC2RotatingTorproxy_data count:';
select count(*) from LC2RotatingTorproxy_data;
select 'LC2RotatingTorproxy_procdata count:';
select count(*) from LC2RotatingTorproxy_procdata;
.separator ";"
drop table IF EXISTS LC2RotatingTorproxytemp;
-- select '<p>Import done</p>';
.exit