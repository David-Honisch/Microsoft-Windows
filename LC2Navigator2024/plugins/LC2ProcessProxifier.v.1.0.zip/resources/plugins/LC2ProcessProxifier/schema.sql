-- select '<h2>Import processes</h2>';
drop table IF EXISTS LC2ProcessProxifier;
drop table IF EXISTS LC2ProcessProxifier_main;
drop table IF EXISTS LC2ProcessProxifier_install;
drop table IF EXISTS LC2ProcessProxifier_help;
drop table IF EXISTS LC2ProcessProxifier_data;
drop table IF EXISTS LC2ProcessProxifier_procdata;
drop table IF EXISTS LC2ProcessProxifiertemp;
drop table IF EXISTS LC2ProcessProxifier_datatemp;
CREATE TABLE LC2ProcessProxifier( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE LC2ProcessProxifier_main( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE LC2ProcessProxifier_install( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE LC2ProcessProxifier_help( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE LC2ProcessProxifier_data( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE LC2ProcessProxifier_procdata( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE IF NOT EXISTS LC2ProcessProxifiertemp (
"name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL
);
-- create table IF NOT EXISTS LC2ProcessProxifier_datatemp ( name varchar(255));
CREATE TABLE IF NOT EXISTS LC2ProcessProxifier_datatemp (
"name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL
);
-- import menu
-- select '<p>Import processes</p>';
.separator ";"
-- .import .\\resources\\plugins\\LC2ProcessProxifier\\import\\import.csv LC2ProcessProxifiertemp
-- INSERT INTO LC2ProcessProxifier(first_name,name,zipcode, city, description) select first_name,name,zipcode, city, description  from LC2ProcessProxifiertemp;
.import .\\resources\\plugins\\LC2ProcessProxifier\\import\\import.csv LC2ProcessProxifier
.import .\\resources\\plugins\\LC2ProcessProxifier\\import\\main.csv LC2ProcessProxifier_main
.import .\\resources\\plugins\\LC2ProcessProxifier\\import\\install.csv LC2ProcessProxifier_install
.import .\\resources\\plugins\\LC2ProcessProxifier\\import\\help.csv LC2ProcessProxifier_help
--
-- eof insert work data
select 'LC2ProcessProxifier count:';
select count(*) from LC2ProcessProxifier;
--.separator ';'
.separator ";"
--.import '.\\resources\\plugins\\LC2ProcessProxifier\\import\\menu.csv' LC2ProcessProxifier_datatemp
-- .import '.\\resources\\plugins\\LC2ProcessProxifier\\import\\menu.csv' LC2ProcessProxifier_datatemp
-- INSERT INTO LC2ProcessProxifier_data(first_name,name,zipcode, city, description) select first_name,name,zipcode, city, description  from LC2ProcessProxifier_datatemp;
.import '.\\resources\\plugins\\LC2ProcessProxifier\\import\\menu.csv' LC2ProcessProxifier_data
delete from LC2ProcessProxifier_datatemp;
--
.separator ","
.import '.\\resources\\plugins\\LC2ProcessProxifier\\import\\data.csv' LC2ProcessProxifier_worktemp
INSERT INTO LC2ProcessProxifier_work(first_name,name,zipcode, city, description) select first_name,name,zipcode, city, description  from LC2ProcessProxifier_worktemp;
--
select 'LC2ProcessProxifier_work count:';
select count(*) from LC2ProcessProxifier_work;
-- .separator ","
-- .import '.\\resources\\plugins\\LC2ProcessProxifier\\import\\LC2ProcessProxifierwork.csv' LC2ProcessProxifier_datatemp
-- INSERT INTO LC2ProcessProxifier_procdata(first_name,name,zipcode, city, description) select first_name,name,zipcode, city, description  from LC2ProcessProxifier_datatemp;
--
select '<p>LC2ProcessProxifier count:';
select count(*) from LC2ProcessProxifier;
select 'LC2ProcessProxifier_data count:';
select count(*) from LC2ProcessProxifier_data;
select 'LC2ProcessProxifier_procdata count:';
select count(*) from LC2ProcessProxifier_procdata;
.separator ";"
drop table IF EXISTS LC2ProcessProxifiertemp;
-- select '<p>Import done</p>';
.exit