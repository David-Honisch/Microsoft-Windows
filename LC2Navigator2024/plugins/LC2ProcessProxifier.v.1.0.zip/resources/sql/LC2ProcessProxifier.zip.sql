SELECT '<h1>LC2ProcessProxifier PLUGIN SQL SCRIPT IS RUNNING</h1>'; 
SELECT '<h5>Deleting import script</h5>'; 
SELECT '<h5>RUNNING IMPORT</h5>'; 
SELECT '<h4>SET CLEAR</h4>'; 
SELECT '<h4>DELETING application</h4>'; 
select count(*) as count from application;
SELECT '<h1>UPDATE LC2ProcessProxifier SQL SCRIPT DONE</h1>'; 
-- INSERT OR REPLACE INTO application(name, first_name, description, zipcode, city, street, url)
-- VALUES('LC2ProcessProxifier v.1.01a','LC2ProcessProxifier v.1.01a','','','','','exec .\\resources\\plugins\\LC2ProcessProxifier\\index.bat .\\resources\\plugins\\LC2ProcessProxifier\\menu.csv'); 
-- INSERT OR REPLACE INTO application(name, first_name, description, zipcode, city, street, url)VALUES('LC2ProcessProxifier Plugin v.1.02a','LC2ProcessProxifier Plugin v.1.01a','','','','','execCMD(''exec .\\resources\\plugins\\LC2ProcessProxifier\\index.bat .\\resources\\plugins\\LC2ProcessProxifier\\menu.csv'', ''out'');'); 
INSERT OR REPLACE INTO application(name, first_name, description, zipcode, city, street, url)VALUES('LC2ProcessProxifier Plugin v.1.2','LC2ProcessProxifier Plugin v.1.01a','','','','','execPluginCMD(''out'',''LC2ProcessProxifier'');');
select count(*) as count from application;
SELECT '<h5>SQL LC2ProcessProxifier IMPORT DONE</h5>'; 
