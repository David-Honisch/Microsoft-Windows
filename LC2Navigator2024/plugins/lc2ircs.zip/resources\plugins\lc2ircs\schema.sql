select '<h4>lc2ircs Plugin SQL Import</h4>';
drop table IF EXISTS lc2ircs;
drop table IF EXISTS lc2ircstemp;
CREATE TABLE lc2ircs ( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
create table IF NOT EXISTS lc2ircstemp ( name varchar(255), menu TEXT, url varchar(255), subtext TEXT);
-- select 'Create table lc2ircs Import';
-- .separator "\t"
-- .import .\\import.csv lc2ircstemp
.separator ";"
.import .\\resources\\plugins\\lc2ircs\\import\\import.csv lc2ircstemp
--.import ..\\import\\materialnohead.csv url
--INSERT INTO person VALUES (4, 'Alice', '351246233');
-- DELETE FROM url where url.name = '';
-- select '<p>lc2ircstemp count:';
-- select count(*) from lc2ircstemp;
-- select '</p>';
-- select '<p>SQL Import successfully done</p>';
-- select '<p>lc2ircs count:'+count(*)+'</p>' from lc2ircstemp;
-- select * from lc2ircstemp limit 1;
-- select '<p>temp table COUNT:'+count(*)+'</p>' from lc2ircstemp;
INSERT INTO lc2ircs (first_name,name, description,url) select name,name, menu,url  from lc2ircstemp;
select '<p>lc2ircs count:';
select count(*) from lc2ircs;
select '</p>';
-- select '<p>COUNT:'+count(*)+'</p>' from lc2ircs;
-- select '<p>SQL Menu:</p><br>';
-- select '';
-- select '<hr>';
-- select '<a href="'+url+'">'+name+'</a>' from lc2ircs;
-- select '<hr>';
-- select '<p>lc2ircs count:'+count(*)+' successfully imported.</p>' from lc2ircs;
.exit