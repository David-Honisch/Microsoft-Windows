select '<h2>Import LC2OpenSSL processes</h2>';
-- select '<p>drop plugin tables</p>';
drop table IF EXISTS LC2OpenSSL;
drop table IF EXISTS LC2OpenSSL_main;
drop table IF EXISTS LC2OpenSSL_install;
drop table IF EXISTS LC2OpenSSL_help;
drop table IF EXISTS LC2OpenSSL_data;
drop table IF EXISTS LC2OpenSSL_work;
drop table IF EXISTS LC2OpenSSL_procdata;
drop table IF EXISTS LC2OpenSSLtemp;
drop table IF EXISTS LC2OpenSSL_datatemp;
drop table IF EXISTS LC2OpenSSL_worktemp;

-- select '<p>create plugin tables</p>';
CREATE TABLE LC2OpenSSL( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,  "url" TEXT NULL);
CREATE TABLE LC2OpenSSL_main( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE LC2OpenSSL_install( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE LC2OpenSSL_help( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE LC2OpenSSL_data( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE LC2OpenSSL_work( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);

CREATE TABLE LC2OpenSSL_procdata( "person_id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL);
CREATE TABLE IF NOT EXISTS LC2OpenSSLtemp (
"name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "url" TEXT NULL
);
-- create table IF NOT EXISTS LC2OpenSSL_datatemp ( name varchar(255));
-- CREATE TABLE IF NOT EXISTS LC2OpenSSL_datatemp (
-- "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL
-- );
CREATE TABLE IF NOT EXISTS LC2OpenSSL_datatemp( "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL, "url" TEXT NULL);
-- CREATE TABLE IF NOT EXISTS LC2OpenSSL_worktemp (
-- "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,	 "url" TEXT NULL
-- );
--CREATE TABLE IF NOT EXISTS LC2OpenSSL_worktemp( "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "city" TEXT NULL,	 "street" TEXT NULL,"add1" TEXT NULL,"add2" TEXT NULL,"add3" TEXT NULL,  "url" TEXT NULL);
CREATE TABLE IF NOT EXISTS LC2OpenSSL_worktemp( "name" TEXT NOT NULL, "first_name" TEXT NULL, "description" TEXT NULL, "zipcode" TEXT NULL, "url" TEXT NULL);
-- import menu
-- select '<p>Import processes</p>';
-- select '<p>start import to plugin tables</p>';
.separator ";"
--.import .\\resources\\plugins\\LC2OpenSSL\\import\\import.csv LC2OpenSSLtemp
-- INSERT INTO LC2OpenSSL(first_name,name,zipcode, city, description) select first_name,name,zipcode, city, description  from LC2OpenSSLtemp;
.import .\\resources\\plugins\\LC2OpenSSL\\import\\import.csv LC2OpenSSL
.import .\\resources\\plugins\\LC2OpenSSL\\import\\main.csv LC2OpenSSL_main
.import .\\resources\\plugins\\LC2OpenSSL\\import\\install.csv LC2OpenSSL_install
.import .\\resources\\plugins\\LC2OpenSSL\\import\\help.csv LC2OpenSSL_help
.import .\\resources\\plugins\\LC2OpenSSL\\import\\data.csv LC2OpenSSL_data
.import .\\resources\\plugins\\LC2OpenSSL\\import\\work.csv LC2OpenSSL_work
--
--.separator ","
--.import '.\\resources\\plugins\\LC2OpenSSL\\import\\work.csv' LC2OpenSSL_worktemp
--INSERT INTO LC2OpenSSL_data(first_name,name,zipcode, description,url) select first_name,name,zipcode, description,url from LC2OpenSSL_worktemp;
--INSERT INTO LC2OpenSSL_work(first_name,name,zipcode, description,url) select first_name,name,zipcode, description,url  from LC2OpenSSL_worktemp;
-- eof insert work data
select 'LC2OpenSSL_work count:';
select count(*) from LC2OpenSSL_work;
-- eof insert work data
select 'LC2OpenSSL count:';
select count(*) from LC2OpenSSL;
select '<p>start data import to plugin tables</p>';
.separator ";"
--.import '.\\resources\\plugins\\LC2OpenSSL\\import\\menu.csv' LC2OpenSSL_datatemp
-- .import '.\\resources\\plugins\\LC2OpenSSL\\import\\menu.csv' LC2OpenSSL_datatemp
-- INSERT INTO LC2OpenSSL_data(first_name,name,zipcode, city, description) select first_name,name,zipcode, city, description  from LC2OpenSSL_datatemp;
-- .import '.\\resources\\plugins\\LC2OpenSSL\\import\\menu.csv' LC2OpenSSL_data
-- delete from LC2OpenSSL_datatemp;
--
-- select '<p>start work data import to plugin tables</p>';
-- .separator ","
-- .import '.\\resources\\plugins\\LC2OpenSSL\\import\\data.csv' LC2OpenSSL_worktemp
-- INSERT INTO LC2OpenSSL_work(first_name,name,zipcode, city, description) select first_name,name,zipcode, city, description  from LC2OpenSSL_worktemp;
--
select 'LC2OpenSSL_work count:';
select count(*) from LC2OpenSSL_work;
-- .separator ","
-- .import '.\\resources\\plugins\\LC2OpenSSL\\import\\LC2OpenSSLwork.csv' LC2OpenSSL_datatemp
-- INSERT INTO LC2OpenSSL_procdata(first_name,name,zipcode, city, description) select first_name,name,zipcode, city, description  from LC2OpenSSL_datatemp;
--
select '<p>LC2OpenSSL count:';
select count(*) from LC2OpenSSL;
select 'LC2OpenSSL_data count:';
select count(*) from LC2OpenSSL_data;
select 'LC2OpenSSL_procdata count:';
select count(*) from LC2OpenSSL_procdata;
.separator ";"
drop table IF EXISTS LC2OpenSSLtemp;
-- select '<p>Import done</p>';
.exit