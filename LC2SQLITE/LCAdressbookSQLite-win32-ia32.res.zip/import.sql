.separator "\t"
.print 'RUNNING IMPORT'
--.separator "\t"
--.headers on
.separator ";"
.import export.csv people
.print 'RUNNING IMPORT DONE'