drop table IF EXISTS batch;
create table IF NOT EXISTS batch (
  name varchar(255)
);
.separator "\t"
.print 'RUNNING IMPORT'
--.separator "\t"
--.headers on
.separator ";"
.import bat.csv batch
.print 'RUNNING IMPORT DONE'